# Criador de Mundos — Handoff entre sessões

> Arquivo de continuidade. Atualize-o ao fim de cada fase para que outra sessão/IA continue sem reinventar o projeto.

## Estado atual

- **Fase atual:** FASE 3 **concluída** (seções 9, 10, 14 e 18), coberta por teste automatizado de dados. Fase 4 iniciada.
- **Data da atualização:** 2026-10-07.
- **Escopo:** definido em `CRIADOR_PROMPT.md` (fonte da verdade). Este arquivo complementsa o prompt com o estado real do código.
- **Nenhum sistema antigo foi substituído.** O modo Criador é um módulo novo e fica separado dos mundos canônicos/IA existentes.
- **Fase 2:** entrega parcial, auditada contra o prompt abaixo.
- **Fase 3:** seções 9, 10, 14 e 18 implementadas. Detalhes em "O que foi feito — Fase 3".
- **Próxima fase permitida:** FASE 4 — terreno (seção 5) e clima (seção 21), **depois** de fechar as pendências da Fase 3 listadas em "O que ainda não funciona".

### Como uma sessão nova deve continuar

1. Ler `CRIADOR_PROMPT.md` (escopo e ordem das fases).
2. Ler este arquivo (o que existe e o que falta).
3. Não reler o restante do projeto a menos que precise de um detalhe específico.

## Auditoria da Fase 2 contra o prompt original

O prompt atribui à Fase 2 as seções **3, 17, 24 e 16**. A entrega foi desigual entre elas.

### Seção 3 — Modo espectador: QUASE COMPLETA

| Requisito | Status |
| --- | --- |
| Mover em qualquer direção | OK |
| Subir e descer | OK |
| Acelerar/desacelerar | OK (4 velocidades) |
| Girar livremente | OK |
| Zoom | OK (roda e pinça) |
| Visão aérea | OK |
| Visão próxima ao chão | OK |
| Teletransporte para coordenadas | OK |
| Retornar a pontos salvos | OK |
| **Selecionar objetos no mundo** | **NÃO IMPLEMENTADO — é a seção 18, Fase 3** |

### Seção 17 — Mini-mapa/mapa global: PARCIAL

| Requisito | Status |
| --- | --- |
| Clicar para teletransportar | OK |
| Mostrar chunks carregados | OK |
| Mostrar câmera | OK |
| Mostrar estradas | NÃO IMPLEMENTADO — Fase 5 |
| Mostrar cidades | NÃO IMPLEMENTADO — Fase 6 |
| Mostrar regiões/rios/montanhas | NÃO IMPLEMENTADO — Fase 4 |
| Mostrar construções | NÃO IMPLEMENTADO — Fase 6 |
| Mostrar áreas selecionadas | NÃO IMPLEMENTADO — Fase 3 |

O mapa hoje é um canvas de grade + chunks. As camadas de conteúdo dependem de dados que ainda não existem (Fases 4 a 6); o esqueleto já aceita desenhar sobreposições.

### Seção 24 — Interface mobile: PARCIAL

| Requisito | Status |
| --- | --- |
| Botões grandes | OK |
| Controles de câmera adaptados ao mobile | OK (joystick + subir/descer) |
| Pinch-to-zoom | OK |
| Interface some parcialmente ao navegar | OK (600 ms) |
| Menus laterais | NÃO IMPLEMENTADO |
| Radial menu | NÃO IMPLEMENTADO |
| Gesto de dois dedos | NÃO IMPLEMENTADO |
| Pressionar e segurar para opções | NÃO IMPLEMENTADO |
| Toque para selecionar | NÃO IMPLEMENTADO — Fase 3 |
| Arrastar para mover | NÃO IMPLEMENTADO — Fase 3 |

### Seção 16 — Otimização: PARCIAL

| Técnica | Status |
| --- | --- |
| World streaming | OK (janela 3×3, descarte com `dispose`) |
| Chunking | OK |
| Frustum culling | OK (automático no three.js) |
| LOD | NÃO IMPLEMENTADO — prioritisei Fase 8 |
| Instanced meshes | NÃO IMPLEMENTADO |
| Object pooling | NÃO IMPLEMENTADO |
| Texture streaming | NÃO IMPLEMENTADO (cenário atual sem texturas) |
| Distance-based detail | NÃO IMPLEMENTADO |
| Procedural vegetation | NÃO IMPLEMENTADO — Fase 4 |
| Asset instancing | NÃO IMPLEMENTADO |
| Occlusion culling | **DECLARADO NÃO VIÁVEL.** O renderer é `THREE.WebGLRenderer` (WebGL) em alvo mobile; occlusion culling exige hierarquia de custo por frame que não compensa aqui. Alternativa em uso: descarte por chunk + frustum culling + malha reduzida por chunk. Informado conforme regra A.3. |

Apenas duas técnicas de otimização estão realmente resolvidas. As demais dependem de objetos existirem (Fases 4 a 6) e foram adiadas para a Fase 8, que o prompt define como "otimização final".

### Consequência prática

A Fase 2 entregou o que a regra A.1 exige — nada foi fingido. O que falta não é bug, é escopo que o próprio prompt atribui a fases posteriores.

## Regras obrigatórias

1. Não fingir implementação. Toda ação da interface precisa alterar dados reais e persistir.
2. Recursos ainda ausentes devem aparecer como `NÃO IMPLEMENTADO` — nunca como um botão aparentemente funcional sem efeito.
3. Respeitar a ordem das fases: ao fim de cada fase, rodar testes, listar o que funciona e o que não funciona, e só então avançar.
4. Não substituir mundos, mapas, gameplay, personagem ou mecânicas existentes.
5. O Criador deve continuar isolado; integrar apenas por entrada de menu e adaptadores explícitos.
6. Renderer atual é `THREE.WebGLRenderer`, não WebGPU. Otimizações devem ser adaptadas ao WebGL/mobile.
7. A precisão em mundos de 50 km exige floating origin ou coordenadas locais por chunk.
8. Terreno salvo deve ser representado por deltas/patches por chunk sobre seed/base, nunca por um heightmap inteiro redundante.
9. Colisão e física só precisam existir perto do player; chunks distantes descarregados não mantêm colisão.
10. A geometria precisa ter pivô na base, bounding box/colisor coerentes, proporções realistas e validação após colocação/geração.

## O que já foi feito — Fase 1

### Dados e formato

- `src/creator/types.ts` define o documento versionado `monolito-creator-world`, versão 1.
- Tamanhos reais suportados: 10.000, 20.000 e 50.000 metros.
- O documento guarda configurações, seed, metadados, ponto de retomada e `chunkDeltas`.
- `CreatorChunkMutation` já prevê patches de terreno, entidades, vegetação, estradas e zonas.
- `src/creator/CreatorFormat.ts` cria, valida, migra, serializa, importa e duplica documentos.
- A validação rejeita nome/tamanho/seed inválidos, formatos futuros e chunks com chave/mutações inconsistentes.

### Salvamento real

- `src/creator/CreatorStorage.ts` usa IndexedDB (`monolito_creator_worlds`) com stores `worlds` e `assets`.
- CRUD real de mundos: criar, abrir/selecionar, editar nome/descrição/configurações, duplicar, excluir com confirmação, exportar e importar.
- Cada mundo possui ID próprio e não interfere nos demais.
- O formato interno é independente do renderer: `WORLD DATA -> FORMAT -> STORAGE`; a construção visual virá depois.

### Entrada e interface

- `src/App.tsx` adiciona `CRIADOR DE MUNDOS` na tela inicial, antes de iniciar exploração.
- `src/components/CreatorWorldsPanel.tsx` abre em modo construção/espectador; não inicia personagem jogável.
- O formulário de novo mundo contém nome, descrição, tamanho, estilo, terreno, clima, densidade e qualidade.
- A interface possui confirmação de exclusão, informações do mundo, importação/exportação e feedback de erro/êxito.

### Biblioteca de assets

- `src/creator/CreatorAssets.ts` cria um catálogo nativo com 7 assets e thumbnails reais em data URL.
- Cada descriptor possui nome, categoria, tipo, tamanho, LOD, colisor, material, polycount e versão.
- `CreatorStorage` aceita manifestos JSON de assets futuros sem reescrever o editor.
- A colocação/transformação de assets continua **NÃO IMPLEMENTADA** e a interface mostra isso explicitamente.

## O que foi feito — Fase 2

### Streaming de chunks reais

- `src/creator/runtime/CreatorChunkManager.ts` monta e desmonta geometria de terreno por proximidade.
- Janela de carga 3×3 chunks em torno da câmera; chunks fora do raio são descartados com `dispose()` de geometria.
- Altura vem de uma função determinística `getHeightAt(seed, settings)` — é a base procedural sobre a qual os `chunkDeltas` da Fase 4 vão se apoiar.
- A altura do chunk é amostrada em coordenadas de mundo, então chunks vizinhos casam exatamente na borda (sem costura visível).
- Malha reduz a resolução por chunk em mundos grandes (24 segmentos acima de 5.000 m, 32 abaixo).

### Floating origin

- A câmera e os chunks são posicionados **relativos à origin**, e a origin é recentralizada quando a câmera se afasta demais (limite = `max(1500, chunkSize × 1,5)`).
- Com isso, coordenadas de 50 km nunca chegam à GPU: o `modelViewMatrix` é calculado em precisão dupla na CPU e só o resultado pequeno é enviado como float32.
- O mundo continua guardando posição absoluta no documento; a origin é detalhe de render.

### Câmera livre (espectador)

- `src/components/CreatorViewport.tsx` é o shell isolado da câmera. Nenhum personagem jogável é criado.
- Movimento: WASD/setas, Q/E e Espaço para subir/descer, Shift como turbo, roda do mouse e pinça para zoom.
- Velocidades: LENTO / NORMAL / RÁPIDO / MUITO RÁPIDO.
- Modos de visão: NORMAL, AÉREA (sobe 1.100 m) e PRÓXIMA (desce ao chão).
- Entradas analógicas (joystick) e botões de subir/descer para mobile.
- A interface fica semitransparente durante a navegação e volta ao normal após **600 ms** parado.

### Mapa global e teleporte

- `src/components/CreatorMiniMap.tsx` desenha o mundo inteiro em SVG, com grade por chunk.
- Mostra os chunks realmente carregados e a posição atual da câmera.
- Clique/toque em qualquer ponto do mapa teleporta a câmera; a posição é limitada às bordas do mundo.
- Hub compacto com X/Z manuais, teleporte por coordenadas e lista de pontos salvos.
- O hub inicia recolhido em telas menores que 720 px de largura.

### Persistência

- A câmera grava `lastEditor` (posição, yaw, pitch) e `savedPoints` no documento do mundo ao sair.
- `SALVAR E SAIR` persiste via `creatorStorage.saveWorld` e volta ao painel com confirmação real na tela.
- Reabrir o mundo retoma a construção exatamente no ponto salvo.

### Ligação com o painel

- `CreatorWorldsPanel` recebe `editingWorld`; ao clicar `ENTRAR NO MUNDO` monta o viewport em tela cheia.
- O aviso `CONTINUAR CONSTRUÇÃO — NÃO IMPLEMENTADO` da Fase 1 foi substituído pelo botão real.
- O jogo/mundo canônico continua intacto e rodando por fora.

## O que foi feito — Fase 3

Escopo: seções **9 (duplicação)**, **10 (grade)**, **14 (histórico)** e **18 (seleção)** do prompt.

### Colocação de objetos (base para as quatro seções)

O mundo não tinha nenhum objeto: o terreno era 100% procedural. Para que seleção, duplicação e histórico tivessem o que manipular, a Fase 3 criou o caminho mínimo de colocação usando o **catálogo de assets que já existia desde a Fase 1**.

- `src/creator/runtime/CreatorEntityStore.ts` é a camada de objetos.
- Colocar grava `entity-add` no `chunkDeltas` do chunk correto. Nada é exibido sem estar no documento.
- Cada asset tem proporções reais e **pivô na base** — a malha é recentrada para que a base apoie no terreno, nunca flutue nem afunde (parte da regra 26; a validação completa é Fase 6).
- Só entram entidades de chunks carregados; as de chunks distantes ficam ocultas sem perder estado.

### Seção 18 — Seleção

- Toque/clique curto no viewport seleciona por raycast. Arrasto continua controlando a câmera — os dois convivem sem conflito.
- Painel com NOME, TIPO, POSIÇÃO, ROTAÇÃO, ESCALA, MATERIAL, ID, CHUNK e PREFAB.
- Botões EDITAR, MOVER, ROTACIONAR, DELETAR, AGRUPAR e DESAGRUPAR. O objeto selecionado recebe destaque por emissive.

### Seção 9 — Duplicação e manipulação

- DUPLICAR replica a seleção inteira, deslocando cada cópia um passo de grid.
- MOVER entra no modo mover: tocar no terreno reposiciona tudo que está selecionado, com apoio no solo.
- ROTACIONAR gira 15° por passo, alinhado ao passo do grid.
- AGRUPAR grava `grupo` na property real da entidade. DESAGRUPAR remove.
- Multi-seleção: hoje a seleção é de 1 objeto. **SELEÇÃO MÚLTIPLA POR CAIXA (marcar vários) NÃO IMPLEMENTADA.**

### Seção 10 — Grade e snap

- `src/creator/runtime/CreatorGrid.ts`.
- GRID LIVRE / 1m / 5m / 10m / 50m, com linhas redesenhadas sob a câmera (400 m de alcance, sempre múltiplo do chunk).
- Toggles independentes de SNAP DE TERRENO, SNAP DE OBJETO, SNAP DE ESTRADA e SNAP DE CONSTRUÇÃO.
- A grade é visual; o snap é aplicado de verdade nas coordenadas de colocação e movimento.

### Seção 14 — Histórico

- `src/creator/runtime/CreatorHistory.ts`, com DESFAZER e REFAZER reais por comando reversível.
- Cada ação guarda mutação direta e inversa; refazer limpa a pilha de desfazer, como se espera.
- **Teto de memória** de 80 passos e 2 MB, para "gerar cidade → desfazer" não estourar a RAM do celular.
- **Correção importante:** `chunkDeltas[].mutations` guarda o **estado atual**, não um log. Antes, desfazer apenas acrescentava a mutação inversa e o documento crescia a cada operação. Agora colocar, editar e remover fazem *fold*: o documento cresce só com objetos realmente existentes. Um teste cobre isso.
- Versionamento (`Cidade_v1`, `v2`…): **NÃO IMPLEMENTADO.** `metadata.revision` existe e é incrementado, mas não há lista de versões.

### Arquivos novos da Fase 3

- `src/creator/runtime/CreatorEntityStore.ts`
- `src/creator/runtime/CreatorHistory.ts`
- `src/creator/runtime/CreatorGrid.ts`
- `src/components/CreatorSelectionPanel.tsx`
- `src/components/CreatorToolPanel.tsx`
- `scripts/creator-phase3-test.ts`

## Bugs encontrados no teste em aparelho real e corrigidos

1. **Analógico (joystick) não respondia.** Os handlers de ponteiro estavam presos ao botão interno de 48 px; o círculo de 128 px que o jogador enxerga como analógico não tinha nenhum handler. Corrigido: handlers na área inteira e o botão agora se desloca de verdade mostrando a direção.
2. **Travamentos de movimento.** Três custos desnecessários em GPU de celular: `pixelRatio` até 1,5 (o aparelho é 2–3×), MSAA ligado e shadow map ligado. Corrigido: em dispositivos móveis o `pixelRatio` é 1, o antialias é desligado e as sombras só ligam em qualidade `cinematografico` no desktop.
3. **Interface demorava demais para voltar.** O temporizador de navegação estava em 1400 ms; reduzido para 600 ms.

Os três foram corrigidos e reconfirmados pelo usuário no aparelho. Estão fechados.

## O que ainda não funciona

### Complemento da Fase 3 — fecha as lacunas da seção 9 e 14

- **Seleção múltipla por caixa**: ferramenta `MARCAR`. Arrastar desenha um retângulo e marca todas as entidades visíveis dentro dele, projetadas para a tela. Sem arrastar, um toque limpo limpa a seleção.
- **Copiar/colar**: `COPIAR` guarda a seleção num clipboard em memória; `COLAR` recria os objetos perto da câmera, com snap, escala e material preservados.
- **Redimensionar**: `MENOR` (×0,8) e `MAIOR` (×1,25) na seção "Lote", com escala travada entre 0,25 e 12.
- **Alinhar**: `ALINHAR X` e `ALINHAR Z`, centralizando no eixo de maior dispersão do conjunto.
- **Distribuir**: reparte espaçamento uniforme no eixo de maior dispersão. Exige 3 ou mais objetos.
- **Versões do mundo**: store `versions` no IndexedDB (banco na versão 2), com `SALVAR`, `VOLTAR` e `EXCLUIR`. Rótulo automático `Cidade_v1`, `Cidade_v2`…
- Restaurar uma versão substitui o documento inteiro e sai pelo fluxo normal, persistindo e voltando ao painel sem perder o estado.
- `src/creator/runtime/CreatorBatchOps.ts` concentra alinhar/distribuir/redimensionar para que interface e testes usem exatamente a mesma lógica.

### O que continua em aberto

- **Arrastar objeto diretamente** pelo mundo: o modo mover reposiciona por toque no terreno, não por arrastar a malha.
- **Validação completa de geometria** (sobreposição, fora do chunk, proportionamento): só o pivô na base e o apoio no terreno existem. O restante é a regra 26 completa, Fase 6.
- **A interface da Fase 3 não foi verificada em aparelho.** Só a camada de dados tem teste automatizado.
- Pincéis de terreno gravando em `chunkDeltas`, clima persistido e vegetação editável: **NÃO IMPLEMENTADO — Fase 4**.
- Estradas, cruzamentos, pontes e túneis: **NÃO IMPLEMENTADO — Fase 5**.
- Prefabs posicionáveis, construção modular, zonas e validação de geometria: **NÃO IMPLEMENTADO — Fase 6**.
- Geração procedural por seleção e Assistente IA com prévia: **NÃO IMPLEMENTADO — Fase 7**.
- Modo `TESTAR MUNDO`, colisão próxima e otimização final: **NÃO IMPLEMENTADO — Fase 8**.
- Colisão e física: **inexistentes por enquanto** — o Criador é espectador, sem personagem, então ainda não há necessidade.
- `chunkDeltas` existe no formato mas **nada é escrito nele ainda**: o terreno atual é 100% procedural por seed.
- Occlusion culling: não usar como premissa em WebGL mobile; alternativa prevista é distância/chunk + LOD/impostors + frustum culling + instancing.

### Verificações que ficaram em aberto

- **`scripts/creator-phase2-test.ts` NÃO passa.** O teste automatizado headless não roda porque o app principal já segura um contexto WebGL e o Chromium sem GPU bloqueia o segundo contexto ("context loss and was blocked"). Não contornado. O arquivo está no repositório como registro do que foi tentado; corrigir isso é trabalho da Fase 8 (otimização) ou exige um ambiente com GPU.
- **Os três bugs corrigidos acima foram reconfirmados pelo usuário em aparelho Android real.** O analógico passou a responder e a navegação ficou sem travamentos perceptíveis. **Fechado.**
- **Bordas de 50 km não foram testadas visualmente.** O clamps de teleportar e o streaming foram escritos para caber, mas ninguém confirmou o resultado no aparelho.

## Arquivos principais

- `src/creator/types.ts` — schema e tipos.
- `src/creator/CreatorFormat.ts` — validação, migração, export/import.
- `src/creator/CreatorStorage.ts` — IndexedDB e CRUD.
- `src/creator/CreatorAssets.ts` — catálogo/assets.
- `src/creator/runtime/CreatorChunkManager.ts` — streaming de chunks, altura procedural e floating origin.
- `src/components/CreatorViewport.tsx` — shell da câmera livre, entradas e hub.
- `src/components/CreatorMiniMap.tsx` — mapa global SVG com teleporte.
- `src/components/CreatorWorldsPanel.tsx` — interface do Criador e entrada no viewport.
- `src/App.tsx` — entrada no painel principal.
- `scripts/creator-format-test.ts` — teste de formato.
- `src/creator/runtime/CreatorHistory.ts` — desfazer/refazer com teto de memória.
- `src/creator/runtime/CreatorGrid.ts` — grade e snap.
- `src/components/CreatorSelectionPanel.tsx` — painel de propriedades e ações.
- `src/components/CreatorToolPanel.tsx` — barra de ferramentas, assets, grade, histórico, copiar/colar.
- `src/creator/runtime/CreatorBatchOps.ts` — alinhar, distribuir e redimensionar em lote.
- `src/components/CreatorVersionsPanel.tsx` — salvar, restaurar e excluir versões do mundo.
- `scripts/creator-format-test.ts` — teste de formato.
- `scripts/creator-phase2-test.ts` — teste de navegador da Fase 2 (não passa — ver acima).
- `scripts/creator-phase3-test.ts` — teste de dados da Fase 3 (passa, 27 verificações).

## Testes executados — Fase 3

- `npm run test:creator:phase3` — `creator-phase3-test: OK (37 verificações)`.
- Cobre: colocação grava no chunk certo; objeto apoiado no terreno; desfazer e refazer; edição não incha o documento; agrupamento grava property; snap por categoria e por grid; visibilidade por streaming de chunk; export/import preserva as entidades; store reconstruída a partir do documento; tetos de passos e de memória do histórico; alinhar, distribuir e redimensionar em lote, incluindo tetos e casos de guarda.
- `npm run test:creator` — `creator-format-test: OK`.
- `npm run lint` — `tsc --noEmit` aprovado.
- `npm run build` — build Vite aprovado.
- **Não verificado:** a interface da Fase 3 em aparelho real.

## Testes executados — Fase 2

- `npm run test:creator` — `creator-format-test: OK`.
- `npm run lint` — `tsc --noEmit` aprovado.
- `npm run build` — build Vite aprovado.
- Teste manual do usuário em aparelho Android real via Chrome em `127.0.0.1:4173`: abrir o Criador, criar mundo, entrar na câmera livre, ver o mapa global com chunks carregados, mover a câmera e usar o hub.
- O build continua emitindo o aviso de bundle acima de 500 kB; limitação conhecida e já presente na Fase 1.
- A instalação npm padrão pode exigir `--legacy-peer-deps` por conflito `esbuild`/Vite.

## Como rodar

```bash
npm install --legacy-peer-deps   # se necessário
npm run build
npx vite preview --port 4173 --host 0.0.0.0
```

O `--host 0.0.0.0` é obrigatório para alcançar o servidor a partir do celular.

## Fase 3 — encerrada

Seções 9, 10, 14 e 18 implementadas. O que ainda falta acima é refinamento, não bloqueio.

## Próximo trabalho permitido — Fase 4

Escopo exato, conforme o mapeamento do prompt: **seções 5 (terreno) e 21 (clima)**.

1. **Seção 5 — Terreno.** Elevar, abaixar, nivelar, suavizar, montanhas, vales, crateras, planícies, encostas, praias, rios e lagos. Controles de TAMANHO DO PINCEL, FORÇA, SUAVIDADE, ALTURA e DENSIDADE. Cada pincel grava um `terrain-patch` no `chunkDeltas` do chunk sob o pincel.
2. **Terreno:** a altura final passa a ser `getHeightAt(seed) + soma dos patches do chunk`, e a colisão/floating origin continuam coerentes porque o terreno deixa de ser só procedural.
3. **Vegetação:** procedural por seed com instancing; só adicionar/remover do usuário é salvo, como o prompt pede.
4. **Seção 21 — Clima.** HORA DO DIA, SOL, LUA, NUVENS, NEBLINA, CHUVA, VENTO, TEMPESTADE, TEMPERATURA VISUAL, DENSIDADE DE VEGETAÇÃO e COR DO CÉU, persistidos nas configurações do mundo.

### Decisão de arquitetura já tomada

O mundo nasceu sem nenhum objeto — o terreno era 100% procedural por seed — e seleção, duplicação e histórico não tinham o que manipular. A Fase 3 resolveu isso com o caminho mínimo de colocação usando o **catálogo de assets que já existia desde a Fase 1** (`CreatorAssets`, 7 assets), gravando em `CreatorEntityDelta`.

Isso **não** é a Fase 6: MODO CONSTRUÇÃO (montar estruturas por módulos), zonas e a regra 26 completa continuam sendo da Fase 6. Aqui existe apenas "colocar um asset e mexer nele".

### Ponto de atenção para a Fase 4

`getHeightAt(seed, settings)` está hoje dentro de `CreatorChunkManager.ts` como função de módulo. A Fase 4 precisa dela separada, porque a altura final passa a ser `base(seed) + patches do chunk`. Vale extrair para `src/creator/runtime/CreatorTerrain.ts` antes de começar, junto com a leitura e soma dos `terrain-patch` que já existem no tipo.

Ao fim da fase: testar, listar o que funciona e o que não funciona, atualizar este handoff e só então avançar para a Fase 5.

---

## Modo espectador (mundo canônico) — edição de construções

Trabalho fora das fases do Criador: o modo espectador edita construções do **mundo canônico**, não os mundos do Criador. Não altera o Criador nem a ordem das fases.

### Situação atual

O jogador voa com uma câmera livre, toca numa construção e edita aquele bloco: mover, girar, escalar e restaurar. Tudo grava em `localStorage` por região e reaparece ao recarregar a página.

### Persistência

- `src/world/SpectatorEditStore.ts` — chave `monolito_spectator_edits_v1`, escopo por região (`canonico:<regionId>` e `custom:<regionId>`) para edições não vazarem entre mundos.
- **Âncora espacial estável:** a chave é a posição do pivô arredondada ao metro (`x,y,z`), não o id do cluster. O id (`spectator_cluster_N`) vem da ordem de agrupamento e muda quando o mundo reconstrói; a âncora continua apontando a mesma construção.
- `REGION_VERSION = 2` — a v2 acrescenta `offsetY` e rotação nos três eixos. Formato anterior é descartado de propósito, porque os campos não existem nele.
- Transformação identidade não é persistida (sair sem mexer não cria lixo). Armazenamento corrompido ou de outra versão devolve vazio em vez de quebrar.
- `resetSelection` (RESTAURAR) **apaga** a entrada salva via `clearEdit`, em vez de só zerar na tela.

### Agrupamento de construções (`clusterStructures`)

Reagrupa as malhas do `sceneGroup` em "construções" por union-find, para selecionar um prédio e não uma caixa solta. Quatro problemas foram corrigidos aqui:

- **Peças aninhadas teleportavam.** A conversão usava `applyMatrix4(parentInverse)` com o pai da *primeira* malha encontrada, o que só funciona para filha diretas do `sceneGroup`. Portais, portas, árvores e o pêndulo nascem dentro de subgrupos posicionados, e o offset do subgrupo era descartado — o portal da região aparecia no meio do mapa. Agora converte o `matrixWorld` de cada peça, que carrega a cadeia inteira de grupos.
- **Os grupos nasciam órfãos.** As malhas eram movidas para dentro do grupo de cluster, mas o grupo nunca era adicionado à cena: o mundo inteiro saía do grafo renderizado ao ativar o modo. Agora `sceneGroup.add(group)` na montagem.
- **O pivô contava duas vezes.** As peças entravam com coordenadas absolutas e o grupo também aplicava a posição do pivô, então a construção andava na direção do centro do mundo ao ser movida. Agora o pivô é subtraído na entrada de cada peça (`unpivot`).
- **O agrupamento era inútil para personalizar.** A regra media distância entre *centros* e somava o **tamanho** das peças ao raio (`(sizeA + sizeB)/2 + 26 m`), então uma laje de 300 m alcançava tudo em 176 m e o union-find encadeava o bairro inteiro num bloco só — selecionar uma escada arrastava meio mundo junto.

Regras atuais:

| Constante | Valor | Papel |
| --- | --- | --- |
| `CLUSTER_GAP` | 3,5 m | Vão máximo entre duas caixas para serem a mesma construção |
| `MIN_CLUSTER_VOLUME` | 12 m³ | Descarta poeira, brilhos e detritos |
| `FLOOR_SPAN` | 70 m | A partir desta largura, peça baixa deixa de ser construção |
| `FLOOR_THICKNESS` | 10 m | Chão, laje e terraço: largos e finos são o palco, não o objeto |

A medição é o **vão entre as caixas**, não centro mais raio. Peças de `InstancedMesh` (floresta de pilares, chuva) ficam de fora: são centenas de cópias espalhadas e serviam de ponte para a cadeia de unions.

**Consequência aceita:** o agrupamento mais preciso aumenta bastante a contagem de construções detectadas, e como as edições são indexadas pela âncora, as edições gravadas antes da mudança deixam de bater com os blocos novos. Quem testou antes precisa começar limpo.

### Câmera livre

Ao ativar o modo, o personagem é desativado (`setVisible(false)`) e a câmera assume a posição em que a tela já estava, sem salto. O movimento reaproveita o input de look e o joystick existentes, sem gravidade e sem colisão. `▲`/`▼` (ou Espaço/Shift) sobem e descem, e o botão Turbo alterna 1x/4x/8x. Ao sair do voo, o jogador **aterrissa** em vez de cair de centenas de metros.

A velocidade base do voo é `FLY_SPEED` (26 m/s) no `ColossalViewport`.

### Seleção

O listener de toque mora na `window`, **não** no `canvas`: a área de "olhar" do overlay cobre 60% da tela à direita acima do canvas e engolia o toque, então tocar numa construção quase nunca selecionava nada. Joystick, botões de voo e painel são marcados com `data-spectator-ui` e não selecionam.

Há uma reserva quando o raio não acerta peça nenhuma — comum com a câmera livre, porque de dentro de uma construção o raio não pega face frontal (as traseiras não são testadas pelo three.js). Nesses casos vale a construção cuja caixa envolvente o raio atravessa primeiro (`nearestClusterAlongRay`). O acerto por malha continua sendo o caminho principal.

### Transformação

`StructureTransform` tem `offsetX/Y/Z`, `rotX/Y/Z` (radianos, em torno do próprio pivô) e `scaleX/Y/Z`. Toda edição passa por `commit()`, que aplica, grava, sincroniza a caixa de seleção e publica o estado — sem ele uma das rotas esqueceria de atualizar a interface.

O painel tem um controle único de **Precisão** (Fino/Médio/Grosso) que calibra mover, girar e escalar ao mesmo tempo: 1/4/16 m, 5°/15°/45° e 5%/15%/40%. O título mostra quantas peças e o tamanho do selecionado, para dar para ver na hora se pegou a construção certa.

### Testes

- `npm run test:spectator` — `spectator-persist-test: OK (18 verificações)`. Âncora estável, gravação/relitura, sobrevivência à reconstrução, isolamento entre regiões, RESTAURAR apagando o dado, identidade não persistida, armazenamento corrompido e versão desconhecida.
- `npm run test:spectator:cluster` — `spectator-cluster-test: OK (36 verificações)`. Cobre o grafo de cena e a matemática da transformação: portal não muda de lugar, nenhuma malha some da cena, mover/escalar giram em torno do pivô, restaurar desfaz rotação/altura/escala, âncora estável ao editar, edição não aplicada duas vezes, seleção de dentro e de fora da construção, e a **precisão** do agrupamento (escada de 5 degraus agrupa só os degraus; laje e torre não entram; casa ao lado de bloco gigante não é engolida).
- `scripts/.diag/spectator-persist.mts` — teste de navegador: edita, **recarrega a página inteira** e confirma que a construção reaparece editada, e que RESTAURAR apaga o dado. `spectator-persist (browser): OK`.
- `npm run test:creator` — OK. `npm run test:creator:phase3` — OK (43 verificações).
- `npm run lint` e `npm run build` — aprovados (aviso de bundle >500 kB continua, já conhecido).

### Decisões que valem lembrar

- **Os clusters sobrevivem ao fechamento do modo.** `exit()` só esconde a interface. A alternativa (desmontar os clusters) devolvia tudo ao tamanho original ao sair — o que é justamente o que o jogador reclamou. Assar a transformação na cena também seria tentador, mas quebrava a âncora: o pivô da construção editada deixa de bater com a chave gravada e a edição se perde ou se duplica. Com os clusters vivos o pivô nunca se move, e o `build()` só reagrupa quando o `sceneGroup` realmente mudou (recarga ou troca de região).
- **Edição é dado, não estado de tela.** O `RESTAURAR` apaga o dado, e sair do modo não desfaz nada.

### Bugs do modo espectador encontrados no aparelho

Todos relatados pelo usuário jogando no Android e corrigidos nesta rodada:

1. **Um portal aparecia no meio do mapa ao ativar o modo.** Consequência das peças aninhadas descrito acima.
2. **As construções sumiam ao ativar o modo.** Grupos de cluster órfãos, descrito acima.
3. **Tocar numa construção não selecionava nada.** Listener preso ao `canvas`, coberto pela área de olhar.
4. **Sair do modo desfazia as edições.** `exit()` desmontava os clusters; agora só esconde a interface.
5. **Selecionar uma escada arrastava meia cidade.** Agrupamento por centro+tamanho, descrito acima.
6. **Não dava para mover em Y nem girar.** Faltavam `offsetY` e rotação no modelo de transformação.

### Arquivos

- `src/world/SpectatorStructures.ts` — agrupamento, transformação e caixa de seleção.
- `src/world/SpectatorEditStore.ts` — persistência, âncora e versão de formato.
- `src/world/useSpectatorMode.ts` — hook: entrar/sair, seleção, edição.
- `src/components/SpectatorPanel.tsx` — painel de edição.
- `src/components/ColossalViewport.tsx` — câmera livre e roteamento do toque.
- `src/components/TouchControlsOverlay.tsx` — controles de voo.
- `scripts/spectator-cluster-test.ts` — `npm run test:spectator:cluster`.

### Não verificado

- Em aparelho Android real. Foi testado no navegador com WebGL por software e por relato do usuário nas fases anteriores; o *feel* da câmera (velocidades, responsividade do Turbo) nunca foi calibrado em aparelho.

### Persistência pós-recarga — verificada nesta rodada

`scripts/.diag/spectator-persist.mts` foi rodado contra o agrupamento novo e passou: selecionou uma construção, gravou em `monolito_spectator_edits_v1` sob `custom:region_neon_nexus`, **recarregou a página inteira**, a construção reapareceu com a largura em 231% e o `RESTAURAR` apagou o dado. A ressalva que existia aqui está resolvida.

Duas armadilhas do próprio teste, que já custaram tempo e valem ficar registradas:

- **Porta reutilizada com servidor vazado.** O `server.kill()` do `finally` mata o wrapper do `npx`, não o `node vite` filho — então cada execução deixava um servidor vivo. O teste seguinte subia, não conseguia binds na porta, e acabava medindo o servidor velho, que servia o código de horas atrás. Chegou a reportar 4 falhas em código que estava correto. O teste agora sorteia a porta e recusa rodar se ela já estiver ocupada, e mata o grupo de processos.
- **Seletores Presos no texto do painel.** O rodapé mudou de `L 100% · A 100% · P 100%` para `100% · 100% · 100%`, e os botões `+`/`−` da linha de eixo nunca tiveram o nome do eixo no texto. Os botões ganharam `aria-label` (`Aumentar Largura (Tamanho)`), o que era falta de acessibilidade de qualquer jeito — leitor de tela só anunciava "mais".
