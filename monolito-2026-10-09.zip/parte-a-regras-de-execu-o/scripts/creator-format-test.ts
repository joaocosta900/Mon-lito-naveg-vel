import assert from 'node:assert/strict';
import {
  createCreatorWorld,
  duplicateCreatorWorld,
  exportCreatorWorld,
  importCreatorWorld,
  parseAssetManifest,
  validateCreatorWorld,
} from '../src/creator/CreatorFormat';
import { BUILTIN_CREATOR_ASSETS, createAssetManifest } from '../src/creator/CreatorAssets';
import { CREATOR_WORLD_FORMAT_VERSION } from '../src/creator/types';

const createdWorld = createCreatorWorld({
  name: 'Vale de Teste',
  description: 'Mundo criado durante a Fase 1.',
  sizeMeters: 50000,
  seed: 123456,
  settings: {
    style: 'futurista',
    terrain: 'montanhoso',
    climate: 'tempestuoso',
    objectDensity: 'vazio',
    quality: 'leve',
  },
});

assert.equal(createdWorld.formatVersion, CREATOR_WORLD_FORMAT_VERSION);
assert.equal(createdWorld.sizeMeters, 50000);
assert.equal(createdWorld.chunkSizeMeters, 5000);
assert.deepEqual(createdWorld.chunkDeltas, {});
assert.deepEqual(createdWorld.savedPoints, []);

const exportedWorld = exportCreatorWorld(createdWorld);
const importedWorld = importCreatorWorld(exportedWorld);
assert.equal(importedWorld.id, createdWorld.id);
assert.equal(importedWorld.name, createdWorld.name);
assert.deepEqual(importedWorld.settings, createdWorld.settings);

const duplicatedWorld = duplicateCreatorWorld(createdWorld);
assert.notEqual(duplicatedWorld.id, createdWorld.id);
assert.equal(duplicatedWorld.name, 'Vale de Teste (cópia)');

const invalidValidation = validateCreatorWorld({
  ...createdWorld,
  sizeMeters: 99999,
  name: '',
});
assert.equal(invalidValidation.valid, false);
assert.ok(invalidValidation.errors.length >= 2);

const migratedLegacyWorld = importCreatorWorld(
  JSON.stringify({
    id: 'legacy_world',
    name: 'Legado',
    size: { width: 10000, scaleLabel: '10km' },
    seed: 77,
    chunkDeltas: {},
  })
);
assert.equal(migratedLegacyWorld.formatVersion, CREATOR_WORLD_FORMAT_VERSION);
assert.equal(migratedLegacyWorld.sizeMeters, 10000);
assert.equal(migratedLegacyWorld.chunkSizeMeters, 1000);

const assetManifest = createAssetManifest(BUILTIN_CREATOR_ASSETS);
const parsedManifest = parseAssetManifest(JSON.stringify(assetManifest));
assert.equal(parsedManifest.assets.length, BUILTIN_CREATOR_ASSETS.length);
assert.ok(
  parsedManifest.assets.every(
    (asset) =>
      asset.thumbnail.startsWith('data:image/') &&
      asset.lods.length > 0 &&
      asset.material.length > 0
  )
);

console.log('creator-format-test: OK');
