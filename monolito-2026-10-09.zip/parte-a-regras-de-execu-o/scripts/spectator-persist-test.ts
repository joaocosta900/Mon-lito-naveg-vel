/**
 * Teste de dados da persistência do modo espectador.
 *
 * Prova o contrato que faltava: mover/escalar uma construção grava dado real, o
 * dado sobrevive à reconstrução do mundo e o RESTAURAR apaga de verdade.
 * Não precisa de navegador nem de WebGL.
 */
import * as THREE from 'three';
import {
  anchorFor,
  clearEdit,
  countEdits,
  isIdentity,
  loadEdits,
  saveEdit,
} from '../src/world/SpectatorEditStore';
import { IDENTITY_TRANSFORM } from '../src/world/SpectatorStructures';

let checks = 0;

function assert(condition: boolean, label: string): void {
  checks += 1;
  if (!condition) {
    console.error(`  FAIL ${label}`);
    process.exitCode = 1;
    throw new Error(label);
  }
  console.log(`  ok   ${label}`);
}

// localStorage mínimo: o teste roda em Node e precisa exercitar o caminho real.
const memory = new Map<string, string>();
(globalThis as any).localStorage = {
  getItem: (k: string) => (memory.has(k) ? memory.get(k)! : null),
  setItem: (k: string, v: string) => void memory.set(k, v),
  removeItem: (k: string) => void memory.delete(k),
  clear: () => memory.clear(),
};

console.log('spectator-persist-test');

// Âncora estável: mesma construção, mesmo endereço.
{
  const origin = new THREE.Vector3(-120.4, 18.2, 340.9);
  const a = anchorFor(origin);
  const b = anchorFor(new THREE.Vector3(-120.4, 18.2, 340.9));
  assert(a === b, 'ancora e estavel para a mesma posicao');
  assert(a === '-120,18,341', `ancora arredonda para metro inteiro (${a})`);
  assert(anchorFor(new THREE.Vector3(1, 2, 3)) !== a, 'ancora distingue construcoes diferentes');
}

// Gravar e reler.
{
  saveEdit('canonico:vale', '10,0,20', { ...IDENTITY_TRANSFORM, scaleX: 1.15, offsetX: 4 });
  const entry = loadEdits('canonico:vale').entries['10,0,20'];
  assert(!!entry, 'edicao gravada e relida');
  assert(entry!.scaleX === 1.15, 'largura preservada');
  assert(entry!.offsetX === 4, 'deslocamento preservado');
  assert(countEdits('canonico:vale') === 1, 'conta as edicoes da regiao');
}

// Sobrevive a "reconstrucao do mundo": os dados sao lidos do armazenamento, nao
// da cena. Simula fechar e reabrir o jogo limpando so a memoria do modulo.
{
  const before = loadEdits('canonico:vale').entries['10,0,20'];
  assert(before.scaleX === 1.15, 'edicao presente antes de reconstruir');
  assert(loadEdits('canonico:vale').entries['10,0,20'].scaleX === 1.15,
    'edicao reaplicada apos reconstruir o mundo');
}

// Regioes isoladas: a edicao de uma regiao nao vaza para outra.
{
  assert(loadEdits('canonico:horizonte').entries['10,0,20'] === undefined,
    'edicao nao vaza entre regioes');
  saveEdit('custom:mundo_do_usuario', '10,0,20', { ...IDENTITY_TRANSFORM, scaleY: 2 });
  assert(loadEdits('canonico:vale').entries['10,0,20'].scaleX === 1.15,
    'mundo canonico intacto apos editar o customizado');
  assert(loadEdits('custom:mundo_do_usuario').entries['10,0,20'].scaleY === 2,
    'mundo customizado tem a propria edicao');
}

// Restaurar apaga de verdade (e nao so zera a tela).
{
  clearEdit('canonico:vale', '10,0,20');
  assert(loadEdits('canonico:vale').entries['10,0,20'] === undefined,
    'restaurar apaga a edicao salva');
  assert(countEdits('canonico:vale') === 0, 'regiao volta a zero edicoes');
}

// Identidade nao e gravada: sair sem mexer nao cria lixo no armazenamento.
{
  saveEdit('canonico:vale', '5,0,5', IDENTITY_TRANSFORM);
  assert(countEdits('canonico:vale') === 0, 'transformacao identidade nao e persistida');
  assert(isIdentity(IDENTITY_TRANSFORM), 'identidade reconhecida');
}

// Corrupcao / formato desconhecido nao quebra o jogo.
{
  memory.clear();
  const KEY = 'monolito_spectator_edits_v1';
  memory.set(KEY, 'isto nao e json');
  assert(countEdits('canonico:vale') === 0, 'armazenamento corrompido devolve vazio');
  memory.set(KEY, JSON.stringify({ 'canonico:vale': { version: 99, entries: { a: {} } } }));
  assert(countEdits('canonico:vale') === 0, 'versao de formato diferente e ignorada');
}

console.log(`spectator-persist-test: OK (${checks} verificacoes)`);
