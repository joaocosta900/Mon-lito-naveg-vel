/**
 * Smoke test real da Fase 2: câmera livre, streaming de chunks, floating origin,
 * mapa global com teleporte, bordas de 50 km e persistência da retomada.
 *
 * Uso: npx tsx scripts/creator-phase2-test.ts
 * Sobe `vite preview` sobre o build de `dist/`, roda Chromium e encerra tudo.
 */
import { spawn, type ChildProcess } from 'node:child_process';
import puppeteer, { Browser, Page } from 'puppeteer-core';

const PORT = 4178;
const BASE_URL = `http://127.0.0.1:${PORT}`;
const CHROMIUM = process.env.CHROMIUM_PATH ?? '/usr/bin/chromium';
const WORLD_NAME = `Teste Fase 2 ${Date.now()}`;

const results: string[] = [];

function ok(label: string, detail = ''): void {
  results.push(`  ok   ${label}${detail ? ` — ${detail}` : ''}`);
  console.log(results[results.length - 1]);
}

function readError(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}

async function waitForServer(url: string, timeoutMs: number): Promise<void> {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const response = await fetch(url);
      if (response.ok) return;
    } catch {
      /* ainda subindo */
    }
    await new Promise((resolve) => setTimeout(resolve, 400));
  }
  throw new Error(`preview não respondeu em ${timeoutMs}ms`);
}

async function clickByText(page: Page, text: string, occurrence = 0): Promise<void> {
  const clicked = await page.evaluate(
    (needle, index) => {
      const buttons = Array.from(document.querySelectorAll('button'));
      const matches = buttons.filter((button) =>
        (button.textContent ?? '').replace(/\s+/g, ' ').includes(needle)
      );
      const target = matches[index] as HTMLElement | undefined;
      if (!target) return false;
      target.click();
      return true;
    },
    text,
    occurrence
  );
  if (!clicked) throw new Error(`botão "${text}" não encontrado`);
  await new Promise((resolve) => setTimeout(resolve, 400));
}

/** Dispara onChange do React em inputs/selects controlados. */
async function setReactValue(page: Page, description: string, value: string): Promise<void> {
  const applied = await page.evaluate(
    (needle, nextValue) => {
      const nodes = Array.from(document.querySelectorAll('input, select'));
      const matches = nodes.filter((node) => {
        const label = node.closest('label');
        const labelText = (label?.querySelector('span')?.textContent ?? '').toUpperCase();
        return labelText.includes(needle);
      });
      const target = matches[0] as HTMLInputElement | HTMLSelectElement | undefined;
      if (!target) return false;
      const prototype =
        target instanceof HTMLSelectElement
          ? window.HTMLSelectElement.prototype
          : window.HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(prototype, 'value')?.set;
      setter?.call(target, nextValue);
      target.dispatchEvent(new Event('input', { bubbles: true }));
      target.dispatchEvent(new Event('change', { bubbles: true }));
      return true;
    },
    description,
    value
  );
  if (!applied) throw new Error(`campo "${description}" não encontrado`);
}

async function setNumericInput(page: Page, index: number, value: string): Promise<void> {
  const applied = await page.evaluate(
    (inputIndex, nextValue) => {
      const inputs = Array.from(
        document.querySelectorAll<HTMLInputElement>('input[inputmode="numeric"]')
      );
      const target = inputs[inputIndex];
      if (!target) return false;
      const setter = Object.getOwnPropertyDescriptor(
        window.HTMLInputElement.prototype,
        'value'
      )?.set;
      setter?.call(target, nextValue);
      target.dispatchEvent(new Event('input', { bubbles: true }));
      return true;
    },
    index,
    value
  );
  if (!applied) throw new Error(`input numérico ${index} não encontrado`);
}

async function readTelemetry(page: Page): Promise<{ x: number; y: number; z: number; chunks: number }> {
  return page.evaluate(() => {
    const node = Array.from(document.querySelectorAll('div')).find(
      (element) =>
        /^X -?\d+ · Y -?\d+ · Z -?\d+ · chunks \d+$/.test(
          (element.textContent ?? '').trim()
        )
    );
    const text = (node?.textContent ?? '').trim();
    const match = text.match(/X (-?\d+) · Y (-?\d+) · Z (-?\d+) · chunks (\d+)/);
    if (!match) return { x: Number.NaN, y: Number.NaN, z: Number.NaN, chunks: -1 };
    return {
      x: Number(match[1]),
      y: Number(match[2]),
      z: Number(match[3]),
      chunks: Number(match[4]),
    };
  });
}

/** Decodifica a captura dentro do próprio Chromium para provar que houve render. */
async function analyzeFrame(
  page: Page,
  base64: string
): Promise<{ uniqueColors: number; meanBrightness: number }> {
  return page.evaluate(async (pngBase64) => {
    const image = new Image();
    image.src = `data:image/png;base64,${pngBase64}`;
    await image.decode();
    const offscreen = document.createElement('canvas');
    offscreen.width = image.width;
    offscreen.height = image.height;
    const context = offscreen.getContext('2d');
    if (!context) return { uniqueColors: -1, meanBrightness: -1 };
    context.drawImage(image, 0, 0);
    const { data } = context.getImageData(0, 0, offscreen.width, offscreen.height);
    const colors = new Set<number>();
    let total = 0;
    let samples = 0;
    for (let index = 0; index < data.length; index += 4) {
      colors.add(
        ((data[index] >> 3) << 10) | ((data[index + 1] >> 3) << 5) | (data[index + 2] >> 3)
      );
      total += (data[index] + data[index + 1] + data[index + 2]) / 3;
      samples += 1;
    }
    return { uniqueColors: colors.size, meanBrightness: total / Math.max(samples, 1) };
  }, base64);
}

async function run(): Promise<void> {
  const preview: ChildProcess = spawn(
    'npx',
    ['vite', 'preview', '--port', String(PORT), '--host', '127.0.0.1'],
    { stdio: 'ignore' }
  );

  let browser: Browser | null = null;
  try {
    await waitForServer(BASE_URL, 30000);
    ok('Preview do build atendendo', BASE_URL);

    browser = await puppeteer.launch({
      executablePath: CHROMIUM,
      headless: true,
      args: [
        '--no-sandbox',
        '--disable-dev-shm-usage',
        '--use-gl=swiftshader-webgl',
        '--use-angle=swiftshader',
        '--enable-unsafe-swiftshader',
        '--ignore-gpu-blocklist',
        '--window-size=1280,900',
      ],
    });
    const page = await browser.newPage();
    await page.setViewport({ width: 1280, height: 900 });

    const consoleErrors: string[] = [];
    page.on('console', (message) => {
      if (message.type() === 'error') consoleErrors.push(message.text());
    });
    page.on('pageerror', (error) => consoleErrors.push(`pageerror: ${error.message}`));

    await page.goto(BASE_URL, { waitUntil: 'networkidle2', timeout: 60000 });
    await clickByText(page, 'CRIADOR DE MUNDOS');
    ok('Criador abre pela tela inicial');

    await clickByText(page, 'NOVO MUNDO');
    await setReactValue(page, 'NOME', WORLD_NAME);
    await setReactValue(page, 'TAMANHO', '50000');
    await setReactValue(page, 'TIPO DE TERRENO', 'montanhoso');
    await clickByText(page, 'CRIAR E SALVAR MUNDO');
    await new Promise((resolve) => setTimeout(resolve, 1000));

    const listed = await page.evaluate(
      (name) => document.body.textContent?.includes(name) ?? false,
      WORLD_NAME
    );
    if (!listed) throw new Error('mundo criado não apareceu na lista');
    ok('Mundo de 50 km criado e persistido', WORLD_NAME);

    await clickByText(page, 'ENTRAR NO MUNDO');
    await page.waitForSelector('canvas', { timeout: 25000 });
    await new Promise((resolve) => setTimeout(resolve, 3000));

    const initial = await readTelemetry(page);
    if (!Number.isFinite(initial.x) || initial.chunks <= 0) {
      throw new Error(`telemetria inválida: ${JSON.stringify(initial)}`);
    }
    ok('Streaming carrega chunks reais', `${initial.chunks} chunks em X ${initial.x} Z ${initial.z}`);

    const frame = await page.screenshot({ encoding: 'base64' });
    const analysis = await analyzeFrame(page, frame);
    if (analysis.uniqueColors < 200 || analysis.meanBrightness <= 2) {
      throw new Error(
        `frame sem terreno (cores=${analysis.uniqueColors}, brilho=${analysis.meanBrightness.toFixed(1)})`
      );
    }
    ok(
      'Viewport desenha terreno WebGL',
      `${analysis.uniqueColors} cores distintas, brilho ${analysis.meanBrightness.toFixed(1)}`
    );

    await page.keyboard.down('KeyW');
    await new Promise((resolve) => setTimeout(resolve, 3000));
    await page.keyboard.up('KeyW');
    await new Promise((resolve) => setTimeout(resolve, 1200));
    const moved = await readTelemetry(page);
    const distance = Math.hypot(moved.x - initial.x, moved.z - initial.z);
    if (distance < 100) throw new Error(`câmera moveu só ${distance.toFixed(1)} m`);
    ok('Câmera livre percorre o terreno', `${distance.toFixed(0)} m em 3s de teclado`);

    await setNumericInput(page, 0, '12000');
    await setNumericInput(page, 1, '-9000');
    await clickByText(page, 'TELETRANSPORTAR');
    await new Promise((resolve) => setTimeout(resolve, 2500));
    const teleported = await readTelemetry(page);
    if (Math.abs(teleported.x - 12000) > 5 || Math.abs(teleported.z + 9000) > 5) {
      throw new Error(`teleporte errou: X ${teleported.x} Z ${teleported.z}`);
    }
    ok('Teleporte posiciona a câmera', `X ${teleported.x} · Z ${teleported.z}`);
    if (teleported.chunks <= 0) throw new Error('nenhum chunk após teleporte');
    ok('Streaming recarrega após teleporte', `${teleported.chunks} chunks`);

    await setNumericInput(page, 0, '24800');
    await setNumericInput(page, 1, '24800');
    await clickByText(page, 'TELETRANSPORTAR');
    await new Promise((resolve) => setTimeout(resolve, 2800));
    const edge = await readTelemetry(page);
    if (edge.chunks <= 0) throw new Error('nenhum chunk na borda de 50 km');
    ok('Borda de 50 km mantém chunks', `${edge.chunks} chunks em X ${edge.x} Z ${edge.z}`);

    const edgeFrame = await page.screenshot({ encoding: 'base64' });
    const edgeAnalysis = await analyzeFrame(page, edgeFrame);
    if (edgeAnalysis.uniqueColors < 200) {
      throw new Error(`borda renderizou vazio (cores=${edgeAnalysis.uniqueColors})`);
    }
    ok('Borda de 50 km renderiza sem breakdown', `${edgeAnalysis.uniqueColors} cores`);

    await clickByText(page, 'SALVAR E SAIR');
    await new Promise((resolve) => setTimeout(resolve, 1500));
    const saved = await page.evaluate(() =>
      document.body.textContent?.includes('salva no IndexedDB') ?? false
    );
    if (!saved) throw new Error('aviso de persistência não apareceu');
    ok('Saída grava câmera e pontos no IndexedDB');

    await page.reload({ waitUntil: 'networkidle2' });
    await clickByText(page, 'CRIADOR DE MUNDOS');
    await new Promise((resolve) => setTimeout(resolve, 900));
    await page.evaluate((name) => {
      const button = Array.from(document.querySelectorAll('button')).find((node) =>
        (node.textContent ?? '').includes(name)
      );
      (button as HTMLElement | undefined)?.click();
    }, WORLD_NAME);
    await new Promise((resolve) => setTimeout(resolve, 600));
    await clickByText(page, 'ENTRAR NO MUNDO');
    await page.waitForSelector('canvas', { timeout: 25000 });
    await new Promise((resolve) => setTimeout(resolve, 2500));
    const resumed = await readTelemetry(page);
    if (Math.abs(resumed.x - 24800) > 5 || Math.abs(resumed.z - 24800) > 5) {
      throw new Error(`retomada errada: X ${resumed.x} Z ${resumed.z}`);
    }
    ok('Retomada exata da construção após recarregar', `X ${resumed.x} · Z ${resumed.z}`);

    if (consoleErrors.length > 0) {
      throw new Error(consoleErrors.slice(0, 3).join(' | '));
    }
    ok('Console sem erros');

    console.log(`\ncreator-phase2-test: OK (${results.length} verificações)`);
  } finally {
    await browser?.close();
    preview.kill('SIGTERM');
  }
}

run().catch((error: unknown) => {
  console.error(`\ncreator-phase2-test: FALHOU\n  ${readError(error)}`);
  process.exitCode = 1;
});
