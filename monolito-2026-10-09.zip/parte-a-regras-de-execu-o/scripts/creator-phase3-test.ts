/**
 * Teste da camada de dados da Fase 3: colocação, seleção, edição, agrupamento,
 * desfazer/refazer, grade/snap e persistência das entidades em chunkDeltas.
 * Não precisa de navegador nem de WebGL.
 */
import * as THREE from 'three';
import { CreatorChunkManager } from '../src/creator/runtime/CreatorChunkManager';
import { CreatorEntityStore } from '../src/creator/runtime/CreatorEntityStore';
import { CreatorHistory } from '../src/creator/runtime/CreatorHistory';
import { applySnap, snapRotation, snapValue } from '../src/creator/runtime/CreatorGrid';
import {
  buildAlign,
  buildDistribute,
  buildResize,
} from '../src/creator/runtime/CreatorBatchOps';
import { createCreatorWorld, exportCreatorWorld, importCreatorWorld } from '../src/creator/CreatorFormat';
import { CreatorChunkMutation, CreatorWorld } from '../src/creator/types';

let checks = 0;

function assert(condition: boolean, label: string): void {
  checks += 1;
  if (!condition) {
    console.error(`  FAIL ${label}`);
    process.exitCode = 1;
    throw new Error(label);
  }
  console.log(`  ok   ${label}`);
}

function newWorld(sizeMeters: 10000 | 20000 | 50000 = 50000): CreatorWorld {
  return createCreatorWorld({
    name: 'Teste Fase 3',
    description: '',
    sizeMeters,
    seed: 4242,
    settings: {
      style: 'realista',
      terrain: 'colinas',
      climate: 'temperado',
      objectDensity: 'media',
      quality: 'equilibrado',
    },
  });
}

function countEntities(world: CreatorWorld): number {
  let total = 0;
  for (const delta of Object.values(world.chunkDeltas)) {
    for (const mutation of delta.mutations) {
      if (mutation.type === 'entity-add') total += 1;
    }
  }
  return total;
}

function allMutations(world: CreatorWorld): CreatorChunkMutation[] {
  return Object.values(world.chunkDeltas).flatMap((delta) => delta.mutations);
}

// ------------------------------------------------------------------

const world = newWorld();
const scene = new THREE.Scene();
const chunkManager = new CreatorChunkManager(world, scene);
const store = new CreatorEntityStore(world, scene, chunkManager);
const history = new CreatorHistory();

// 1. Colocação grava no chunkDeltas do chunk correto.
const placed = store.place('prefab_house_small', 120, -80, 0);
assert(placed.entity !== null && placed.mutation !== null, 'place() devolve entidade e mutação');
assert(placed.chunkKey === store.getChunkKeyAt(120, -80), 'chunkKey da.colocação bate com a posição');
assert(countEntities(world) === 0, 'place() só monta a mutação, não escreve sozinho');

store.apply(placed.mutation!);
assert(countEntities(world) === 1, 'entity-add gravado em chunkDeltas ao aplicar');
assert(allMutations(world)[0].type === 'entity-add', 'primeira mutação é entity-add');

// 2. Base apoiada no terreno (regra de geometria: nada flutua).
const groundAtPlacement = chunkManager.getHeightAt(120, -80);
assert(
  Math.abs(placed.entity!.position[1] - groundAtPlacement) < 1e-6,
  'objeto apoia exatamente na altura do terreno'
);

// 3. Desfazer/refazer through history.
const inverse = store.buildRemove(placed.entity!.entityId)!.mutation;
history.push({ label: 'Colocar casa', forward: [placed.mutation!], backward: [inverse] });
assert(countEntities(world) === 1, 'entidade contabilizada antes do desfazer');
store.apply(history.undo()!.backward[0]);
assert(countEntities(world) === 0, 'desfazer remove a entidade do documento');
store.apply(history.redo()!.forward[0]);
assert(countEntities(world) === 1, 'refazer restaura a entidade');

// 4. Edição de transformação.
const update = store.buildUpdate(placed.entity!.entityId, {
  position: [130, groundAtPlacement, -90],
  rotation: [0, Math.PI / 4, 0],
})!;
store.apply(update.mutation);
assert(
  countEntities(world) === 1,
  'entity-update substitui a entrada em vez de acrescentar (estado, não log)'
);
assert(allMutations(world).length === 1, 'documento não cresce ao editar');
const stored = store.getRecords().find((record) => record.entity.entityId === placed.entity!.entityId);
assert(Math.abs(stored!.entity.position[0] - 130) < 1e-6, 'posição editada é refletida na store');
assert(Math.abs(stored!.entity.rotation[1] - Math.PI / 4) < 1e-6, 'rotação editada é refletida na store');

// 5. Agrupamento escreve property real.
const groupUpdate = store.buildUpdate(placed.entity!.entityId, {
  properties: { grupo: 'grupo_teste' },
})!;
store.apply(groupUpdate.mutation);
assert(
  store.getRecords().some((record) => record.entity.properties.grupo === 'grupo_teste'),
  'agrupamento grava property no documento'
);

// 6. Grade e snap.
assert(snapValue(13, 5) === 15, 'snap 5m arredonda 13 -> 15');
assert(snapValue(-13, 10) === -10, 'snap 10m arredonda -13 -> -10');
assert(snapValue(13.37, 'livre') === 13.37, 'grid livre não altera o valor');
assert(snapRotation(37, 5) === 40, 'rotação usa passo derivado do grid');
assert(
  applySnap(13.37, 5, 'objeto', { terreno: true, objeto: false, estrada: false, construcao: false }) === 13.37,
  'snap desligado para a categoria respeita o valor original'
);
assert(
  applySnap(13.37, 5, 'terreno', { terreno: true, objeto: false, estrada: false, construcao: false }) === 15,
  'snap ligado para a categoria aplica o passo'
);

// 7. Streaming de entidades: chunk distante esconde, chunk proximo mostra.
const entityInFarChunk = store.place('vegetation_tree_basic', 20000, 20000, 0);
store.apply(entityInFarChunk.mutation!);
assert(store.getEntitiesInChunk(entityInFarChunk.chunkKey).length === 1, 'entidade fica associada ao chunk distante');

store.syncVisibleChunks(new Set([placed.chunkKey]));
const farVisible = (store as unknown as {
  meshes: Map<string, THREE.Mesh>;
}).meshes.get(entityInFarChunk.entity!.entityId)?.visible;
const nearVisible = (store as unknown as {
  meshes: Map<string, THREE.Mesh>;
}).meshes.get(placed.entity!.entityId)?.visible;
assert(nearVisible === true, 'entidade do chunk carregado fica visível');
assert(farVisible === false, 'entidade de chunk descarregado fica oculta');

// 8. Persistência: exportar e reimportar preserva as entidades.
const serialized = exportCreatorWorld(world);
const reimported = importCreatorWorld(serialized);
assert(
  countEntities(reimported) === countEntities(world),
  'export/import preserva todas as entidades'
);
const reimportedStore = new CreatorEntityStore(
  reimported,
  new THREE.Scene(),
  new CreatorChunkManager(reimported, new THREE.Scene())
);
assert(
  reimportedStore.getRecords().length === store.getRecords().length,
  'store reconstruída a partir do documento recupera os mesmos objetos'
);

// 9. Limite de memória do histórico.
const tinyHistory = new CreatorHistory(2, 1024 * 1024);
for (let index = 0; index < 10; index += 1) {
  tinyHistory.push({
    label: `ação ${index}`,
    forward: [{ type: 'entity-remove', entityId: `e${index}` }],
    backward: [{ type: 'entity-remove', entityId: `e${index}` }],
  });
}
assert(tinyHistory.snapshot().entries === 2, 'histórico respeita o teto de passos');

const byteCapped = new CreatorHistory(1000, 1024);
for (let index = 0; index < 50; index += 1) {
  byteCapped.push({
    label: `x`.repeat(400),
    forward: [],
    backward: [],
  });
}
assert(
  byteCapped.snapshot().estimatedBytes <= 1024 * 2,
  'histórico respeita o teto de memória'
);


// 10. Operações em lote da seção 9, usando exatamente o código que a interface usa.
const batch = new THREE.Scene();
const batchWorld = newWorld();
const batchChunks = new CreatorChunkManager(batchWorld, batch);
const batchStore = new CreatorEntityStore(batchWorld, batch, batchChunks);

for (const [x, z] of [
  [0, 0],
  [40, 90],
  [80, 10],
] as Array<[number, number]>) {
  const result = batchStore.place('prefab_house_small', x, z, 0);
  batchStore.apply(result.mutation!);
}
assert(countEntities(batchWorld) === 3, 'lote: três objetos colocados');

const applyPlan = (plan: { forward: CreatorChunkMutation[]; backward: CreatorChunkMutation[] }) => {
  for (const mutation of plan.forward) batchStore.apply(mutation);
};

// Alinha no eixo de maior dispersão: X tem 0..80 (80), Z tem 0..90 (90) -> Z.
const alignPlan = buildAlign(batchStore, batchStore.getRecords().map((r) => r.entity))!;
applyPlan(alignPlan);
const alignedZ = batchStore.getRecords().map((record) => record.entity.position[2]);
assert(
  alignedZ.every((value) => Math.abs(value - 45) < 1e-6),
  'alinhar usa o eixo de maior dispersão e centraliza todos'
);
assert(countEntities(batchWorld) === 3, 'alinhar não cria nem remove entidades');

// Distribui: conjunto próprio com espaçamento irregular em X.
const spreadScene = new THREE.Scene();
const spreadWorld = newWorld();
const spreadChunks = new CreatorChunkManager(spreadWorld, spreadScene);
const spreadStore = new CreatorEntityStore(spreadWorld, spreadScene, spreadChunks);
for (const x of [0, 10, 80]) {
  const result = spreadStore.place('prefab_house_small', x, 0, 0);
  spreadStore.apply(result.mutation!);
}
const distributePlan = buildDistribute(
  spreadStore,
  spreadStore.getRecords().map((record) => record.entity)
)!;
for (const mutation of distributePlan.forward) spreadStore.apply(mutation);
const distributedX = spreadStore
  .getRecords()
  .map((record) => record.entity.position[0])
  .sort((left, right) => left - right);
assert(
  Math.abs(distributedX[0]) < 1e-6 &&
    Math.abs(distributedX[1] - 40) < 1e-6 &&
    Math.abs(distributedX[2] - 80) < 1e-6,
  'distribuir reparte espaçamento uniforme no eixo de maior dispersão (0/10/80 -> 0/40/80)'
);
assert(countEntities(spreadWorld) === 3, 'distribuir preserva a contagem de entidades');
spreadStore.dispose();
spreadChunks.dispose();

// Redimensionar respeita os tetos de escala.
const resizePlan = buildResize(batchStore, batchStore.getRecords().map((r) => r.entity), 1.25)!;
applyPlan(resizePlan);
assert(
  Math.abs(batchStore.getRecords()[0].entity.scale[0] - 1.25) < 1e-6,
  'redimensionar aplica a nova escala'
);
const hugePlan = buildResize(batchStore, batchStore.getRecords().map((r) => r.entity), 100)!;
applyPlan(hugePlan);
assert(
  batchStore.getRecords().every((record) => record.entity.scale[0] <= 12),
  'redimensionar respeita o teto de escala'
);

// Desfazer da operação em lote volta ao valor anterior.
const historyBatch = new CreatorHistory();
historyBatch.push(resizePlan);
batchStore.apply(historyBatch.undo()!.backward[0]);
assert(
  Math.abs(batchStore.getRecords()[0].entity.scale[0] - 1) < 1e-6,
  'desfazer de edição em lote restaura a escala anterior'
);

assert(buildAlign(batchStore, [batchStore.getRecords()[0].entity])!.forward.length === 0,
  'alinhar com um objeto só não gera mutação');
assert(buildDistribute(batchStore, batchStore.getRecords().slice(0, 2).map((r) => r.entity))!.forward.length === 0,
  'distribuir com menos de três objetos não gera mutação');

batchStore.dispose();
batchChunks.dispose();


// 11. Regressão: o raycast precisa devolver coordenada de MUNDO, não de render.
// Num mundo de 50 km a floating origin desloca tudo, e devolver o ponto cru
// colocaria o objeto no chunk errado — foi exatamente esse o bug relatado.
const originScene = new THREE.Scene();
const originWorld = newWorld(50000);
const originChunks = new CreatorChunkManager(originWorld, originScene);
const originStore = new CreatorEntityStore(originWorld, originScene, originChunks);

originChunks.update(new THREE.Vector3(18000, 120, -14000));
const origin = originChunks.getOrigin();
assert(
  Math.abs(origin.x) > 1000 || Math.abs(origin.z) > 1000,
  `floating origin deslocada o bastante para o bug aparecer (X ${origin.x} Z ${origin.z})`
);

const camera = new THREE.PerspectiveCamera(70, 1, 0.1, 60000);
camera.position.set(-origin.x + 400, 400, -origin.z + 400);
camera.lookAt(0, 0, 0);
camera.updateMatrixWorld(true);

// Hit cru em espaço de render, calculado do lado do teste.
const rawRay = new THREE.Raycaster();
rawRay.setFromCamera(new THREE.Vector2(0, 0), camera);
const terrainMeshes: THREE.Object3D[] = [];
originScene.traverse((object) => {
  const mesh = object as THREE.Mesh;
  if (mesh.isMesh && mesh.parent?.name?.startsWith('creator_chunk_')) {
    terrainMeshes.push(mesh);
  }
});
const rawHit = rawRay.intersectObjects(terrainMeshes, false)[0];
assert(rawHit !== undefined, 'o teste achieve o terreno com o raycaster');

const worldHit = originStore.pickTerrainWorld(camera, 0, 0);
assert(worldHit !== null, 'pickTerrainWorld devolve um ponto');

// O contrato: hit cru + origin.
assert(
  Math.abs(worldHit!.x - (rawHit!.point.x + origin.x)) < 1e-6 &&
    Math.abs(worldHit!.z - (rawHit!.point.z + origin.z)) < 1e-6,
  'pickTerrainWorld soma a origin ao ponto de render'
);

// E o efeito prático: o chunk bate com a posição de mundo, não com a de render.
const worldChunk = originStore.getChunkKeyAt(worldHit!.x, worldHit!.z);
const renderChunk = originStore.getChunkKeyAt(rawHit!.point.x, rawHit!.point.z);
assert(worldChunk !== renderChunk, 'as duas espaços caem em chunks diferentes');
assert(
  worldChunk === originStore.getChunkKeyAt(rawHit!.point.x + origin.x, rawHit!.point.z + origin.z),
  'o objeto colocado pelo raycast cai no chunk do ponto realmente tocado'
);

originStore.dispose();
originChunks.dispose();

store.dispose();
chunkManager.dispose();

console.log(`\ncreator-phase3-test: OK (${checks} verificações)`);
