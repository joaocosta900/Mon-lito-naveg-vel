import * as THREE from 'three';
import { CreatorChunkManager } from '../../src/creator/runtime/CreatorChunkManager';
import { CreatorEntityStore } from '../../src/creator/runtime/CreatorEntityStore';
import { createCreatorWorld } from '../../src/creator/CreatorFormat';

const world = createCreatorWorld({
  name: 'diag', description: '', sizeMeters: 50000, seed: 4242,
  settings: { style:'realista', terrain:'colinas', climate:'temperado', objectDensity:'media', quality:'equilibrado' },
});
const scene = new THREE.Scene();
const chunks = new CreatorChunkManager(world, scene);
const store = new CreatorEntityStore(world, scene, chunks);

const camPos = new THREE.Vector3(0, 400, 400);
chunks.update(camPos);
const origin = chunks.getOrigin();
store.syncVisibleChunks(new Set(chunks.getLoadedChunks().map(c => c.key)));
console.log('origin:', origin, 'chunks carregados:', chunks.getLoadedChunks().length);

const camera = new THREE.PerspectiveCamera(70, 1, 0.1, 60000);
camera.position.set(camPos.x - origin.x, camPos.y, camPos.z - origin.z);
camera.lookAt(0, 0, 0);
camera.updateMatrixWorld(true);

const hit = store.pickTerrainWorld(camera, 0, 0);
console.log('ponto de mundo tocada:', hit?.toArray().map(v => Math.round(v)));

const placed = store.place('futuristic_spire_module', hit!.x, hit!.z, 0);
store.apply(placed.mutation!);

const meshes = (store as any).meshes as Map<string, THREE.Mesh>;
const mesh = meshes.get(placed.entity!.entityId)!;
console.log('entidade criada:', placed.entity!.entityId);
console.log('posicao entidade (mundo):', placed.entity!.position.map(v => Math.round(v)));
console.log('altura do terreno no ponto:', chunks.getHeightAt(hit!.x, hit!.z).toFixed(2));
console.log('mesh visivel:', mesh.visible);
console.log('mesh pos render:', mesh.position.toArray().map(v => Math.round(v)));
console.log('mesh na hierarquia da cena:', !!mesh.parent);
console.log('activeChunks contem o chunk:', (store as any).activeChunks.has(placed.chunkKey), placed.chunkKey);
console.log('mesh na frente da camera?:', (() => {
  const p = new THREE.Vector3(); mesh.getWorldPosition(p);
  const d = p.distanceTo(camera.position);
  return `${Math.round(d)} m`;
})());
