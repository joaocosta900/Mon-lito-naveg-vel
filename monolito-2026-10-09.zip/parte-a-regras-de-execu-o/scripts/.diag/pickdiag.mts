import * as THREE from 'three';
import { CreatorChunkManager } from '../../src/creator/runtime/CreatorChunkManager';
import { CreatorEntityStore } from '../../src/creator/runtime/CreatorEntityStore';
import { createCreatorWorld } from '../../src/creator/CreatorFormat';

const world = createCreatorWorld({
  name: 'diag', description: '', sizeMeters: 10000, seed: 4242,
  settings: { style:'realista', terrain:'colinas', climate:'temperado', objectDensity:'media', quality:'equilibrado' },
});
const scene = new THREE.Scene();
const chunks = new CreatorChunkManager(world, scene);
const store = new CreatorEntityStore(world, scene, chunks);
const farCam = new THREE.Vector3(3200, 120, 900);
chunks.update(farCam);
store.syncVisibleChunks(new Set(chunks.getLoadedChunks().map(c => c.key)));
store.syncOrigin();
const origin = chunks.getOrigin();
const camera = new THREE.PerspectiveCamera(70, 1, 0.1, 60000);
camera.position.set(farCam.x - origin.x, farCam.y, farCam.z - origin.z);
camera.rotation.x = -0.6;
camera.updateMatrixWorld(true);
const hit = store.pickTerrainWorld(camera, 0, 0)!;
const placed = store.place('futuristic_spire_module', hit.x, hit.z, 0);
store.apply(placed.mutation!);
const mesh = (store as any).meshes.get(placed.entity!.entityId)! as THREE.Mesh;

const posOf = (m: THREE.Mesh) => [m.matrixWorld.elements[12], m.matrixWorld.elements[13], m.matrixWorld.elements[14]].map(v => Math.round(v));
console.log('origem:', JSON.stringify(origin));
console.log('mesh matrixWorld pos ANTES:', posOf(mesh));
console.log('pick ANTES de scene.updateMatrixWorld:', store.pick(camera, 0, 0)?.entityId ?? 'null');
scene.updateMatrixWorld(true);
console.log('mesh matrixWorld pos DEPOIS:', posOf(mesh));
console.log('pick DEPOIS de scene.updateMatrixWorld:', store.pick(camera, 0, 0)?.entityId ?? 'null');
console.log('ponto de mundo tocado:', hit.toArray().map(v => Math.round(v)));
