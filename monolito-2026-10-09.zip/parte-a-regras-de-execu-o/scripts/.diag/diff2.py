import struct, zlib, sys
def read_png(path):
    data=open(path,'rb').read(); pos=8; idat=b''
    while pos<len(data):
        ln=struct.unpack('>I',data[pos:pos+4])[0]; typ=data[pos+4:pos+8]; c=data[pos+8:pos+8+ln]
        if typ==b'IHDR': w,h,_,ct=struct.unpack('>IIBB',c[:10])
        elif typ==b'IDAT': idat+=c
        pos+=12+ln
    raw=zlib.decompress(idat); ch={0:1,2:3,3:1,4:2,6:4}[ct]; st=w*ch
    out=bytearray(); prev=bytearray(st); p=0
    for y in range(h):
        f=raw[p]; p+=1; line=bytearray(raw[p:p+st]); p+=st
        if f==1:
            for i in range(ch,st): line[i]=(line[i]+line[i-ch])&255
        elif f==2:
            for i in range(st): line[i]=(line[i]+prev[i])&255
        elif f==3:
            for i in range(st):
                a=line[i-ch] if i>=ch else 0
                line[i]=(line[i]+((a+prev[i])>>1))&255
        elif f==4:
            for i in range(st):
                a=line[i-ch] if i>=ch else 0; b=prev[i]; c2=prev[i-ch] if i>=ch else 0
                pp=a+b-c2; pa=abs(pp-a); pb=abs(pp-b); pc=abs(pp-c2)
                pr=a if (pa<=pb and pa<=pc) else (b if pb<=pc else c2)
                line[i]=(line[i]+pr)&255
        out+=line; prev=line
    return w,h,ch,bytes(out)
w1,h1,c1,a=read_png(sys.argv[1]); w2,h2,c2,b=read_png(sys.argv[2])
diff=0
for y in range(min(h1,h2)):
    for x in range(min(w1,w2)):
        i=(y*w1+x)*c1; j=(y*w2+x)*c2
        if abs(a[i]-b[j])>14 or abs(a[i+1]-b[j+1])>14 or abs(a[i+2]-b[j+2])>14: diff+=1
print(f'pixels alterados entre antes/depois de aumentar a largura: {diff} de {w1*h1}')
print('>>> CONSTRUCAO REALMENTE MUDOU' if diff>500 else '>>> SEM MUDANCA VISIVEL')
