import { spawn } from 'node:child_process';
import puppeteer, { type Browser } from 'puppeteer-core';

const PORT = 4188;
const server = spawn('npx', ['vite', '--port', String(PORT), '--host', '127.0.0.1'], {
  stdio: 'ignore', env: { ...process.env, DISABLE_HMR: 'true' },
});

async function waitFor(url: string, ms = 60000) {
  const deadline = Date.now() + ms;
  while (Date.now() < deadline) {
    try { if ((await fetch(url)).ok) return; } catch {}
    await new Promise(r => setTimeout(r, 400));
  }
  throw new Error('servidor nao subiu');
}
const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

let browser: Browser | undefined;
try {
  await waitFor(`http://127.0.0.1:${PORT}/harness.html`);
  browser = await puppeteer.launch({
    executablePath: '/usr/bin/chromium',
    headless: true,
    args: ['--no-sandbox', '--disable-dev-shm-usage', '--use-gl=swiftshader-webgl',
           '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'],
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1000, height: 760 });
  const errors: string[] = [];
  page.on('console', m => { if (m.type() === 'error') errors.push(m.text().slice(0, 140)); });
  page.on('pageerror', e => errors.push('PAGEERROR ' + e.message.slice(0, 140)));

  await page.goto(`http://127.0.0.1:${PORT}/harness.html`, { waitUntil: 'networkidle2', timeout: 60000 });
  await page.waitForSelector('canvas', { timeout: 30000 });
  await sleep(4000);
  console.log('canvas pronto');

  const clickText = async (text: string) => {
    const ok = await page.evaluate((needle) => {
      const btn = Array.from(document.querySelectorAll('button'))
        .find(b => (b.textContent ?? '').trim().toUpperCase().includes(needle));
      if (!btn) return false;
      btn.click();
      return true;
    }, text);
    if (!ok) throw new Error(`botao "${text}" nao encontrado`);
    await sleep(600);
  };

  await clickText('COLOCAR');
  await clickText('MÓDULO');
  console.log('ferramenta colocar + asset selecionado');

  const canvasCenter = await page.evaluate(() => {
    const c = document.querySelector('canvas') as HTMLCanvasElement;
    const b = c.getBoundingClientRect();
    return { x: b.left + b.width / 2, y: b.top + b.height / 2, w: b.width, h: b.height };
  });

  // Instrumenta: conta eventos de ponteiro reais no canvas e varre alturas.
  await page.evaluate(() => {
    const w = window as any;
    w.__ev = { down: 0, up: 0 };
    const c = document.querySelector('canvas')!;
    c.addEventListener('pointerdown', () => w.__ev.down++, true);
    c.addEventListener('pointerup', () => w.__ev.up++, true);
  });

  const readStatus = () => page.evaluate(() => {
    const el = Array.from(document.querySelectorAll('div')).find(d => {
      const t = (d.textContent ?? '').trim();
      return t.length > 0 && t.length < 160 && d.className.includes('bg-black/45');
    });
    return el ? (el.textContent ?? '').trim() : '(nenhum)';
  });

  const cRect = await page.evaluate(() => {
    const b = (document.querySelector('canvas') as HTMLCanvasElement).getBoundingClientRect();
    return { left: b.left, top: b.top, w: b.width, h: b.height };
  });

  let placedAt = -1;
  for (const frac of [0.15, 0.25, 0.32, 0.42, 0.5, 0.6]) {
    const x = cRect.left + cRect.w / 2;
    const y = cRect.top + cRect.h * frac;
    await page.mouse.click(x, y);
    await sleep(1200);
    const st = await readStatus();
    const ev = await page.evaluate(() => (window as any).__ev);
    console.log(`  clique em h=${frac}: "${st}" (down=${ev.down} up=${ev.up})`);
    if (st.startsWith('Asset colocado')) { placedAt = frac; break; }
  }
  if (placedAt < 0) {
    console.log('>>> NENHUMA altura resulted em colocacao');
    await browser?.close(); server.kill('SIGTERM');
    process.exit(1);
  }
  console.log('>>> COLOCOU em h=' + placedAt);

  const dump = await page.evaluate(() => (window as any).__diag.dump());
  console.log('DIAG:', JSON.stringify(dump, null, 1));

  await page.screenshot({ path: '/tmp/antes.png' });
  const shot = await page.screenshot({
    encoding: 'base64',
    clip: { x: cRect.left + cRect.w / 2 - 220, y: cRect.top + cRect.h * 0.6 - 220, width: 440, height: 440 },
  });
  const px = await page.evaluate(async (b64) => {
    const img = new Image();
    img.src = 'data:image/png;base64,' + b64;
    await img.decode();
    const c = document.createElement('canvas');
    c.width = img.width; c.height = img.height;
    const ctx = c.getContext('2d')!;
    ctx.drawImage(img, 0, 0);
    const d = ctx.getImageData(0, 0, c.width, c.height).data;
    let cyan = 0, bright = 0;
    for (let i = 0; i < d.length; i += 4) {
      if (d[i] < 150 && d[i+1] > 140 && d[i+2] > 140) cyan++;
      if ((d[i] + d[i+1] + d[i+2]) / 3 > 130) bright++;
    }
    return { cyan, bright, total: d.length / 4 };
  }, shot);

  console.log(`pixels na regiao 440x440 -> ciano(modulo): ${px.cyan}, claros: ${px.bright}, total: ${px.total}`);
  console.log(px.cyan > 400 ? '>>> MODULO VISIVEL NO CHAO' : '>>> MODULO NAO APARECEU');
  await page.screenshot({ path: '/tmp/depois.png' });
  console.log(errors.length ? 'erros de console: ' + errors.slice(0, 3).join(' | ') : 'sem erros de console');
} finally {
  await browser?.close();
  server.kill('SIGTERM');
}
