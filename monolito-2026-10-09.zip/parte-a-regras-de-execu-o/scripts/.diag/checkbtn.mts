import puppeteer from 'puppeteer-core';
const b = await puppeteer.launch({ executablePath:'/usr/bin/chromium', headless:true,
  args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=swiftshader-webgl','--enable-unsafe-swiftshader'] });
const p = await b.newPage();
// Largura de celular, como no print (720x1600)
await p.setViewport({ width: 720, height: 1600, isMobile: true, hasTouch: true, deviceScaleFactor: 2 });
await p.goto('http://127.0.0.1:4178/', { waitUntil:'networkidle2' });
await new Promise(r=>setTimeout(r,6000));
// Entra no jogo: o header so existe depois que a exploracao comeca.
await p.evaluate(() => {
  const b = Array.from(document.querySelectorAll('button')).find(x=>/jogar|iniciar|comecar|começar|entrar/i.test(x.textContent??''));
  b?.click();
});
await new Promise(r=>setTimeout(r,9000));

const btns = await p.evaluate(() => Array.from(document.querySelectorAll('button'))
  .map(x=>({ label:(x.getAttribute('aria-label')||x.textContent||'').trim().slice(0,46),
             disabled:x.hasAttribute('disabled'), y: Math.round(x.getBoundingClientRect().top) }))
  .filter(x=>/espectador|silenciar|ativar áudio|AI Providers|Create World|Mundos|regiões/i.test(x.label)));
console.log('BOTÕES DO TOPO:'); btns.forEach(b=>console.log(`  y=${b.y} disabled=${b.disabled} :: ${b.label}`));
// Onde esta o header?
const hdr = await p.evaluate(() => { const h=document.querySelector('header');
  return h? {y:Math.round(h.getBoundingClientRect().top), h:Math.round(h.getBoundingClientRect().height)}:null; });
console.log('HEADER:', JSON.stringify(hdr));
await p.screenshot({ path:'/tmp/header-check.png' });
await b.close();
