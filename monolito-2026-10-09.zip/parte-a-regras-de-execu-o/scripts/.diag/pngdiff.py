import struct, zlib, sys

def read_png(path):
    data = open(path,'rb').read()
    pos = 8; w=h=ct=None; idat=b''
    while pos < len(data):
        ln = struct.unpack('>I', data[pos:pos+4])[0]
        typ = data[pos+4:pos+8]; chunk = data[pos+8:pos+8+ln]
        if typ==b'IHDR': w,h,_,ct = struct.unpack('>IIBB', chunk[:10])
        elif typ==b'IDAT': idat += chunk
        pos += 12+ln
    raw = zlib.decompress(idat); ch = {0:1,2:3,3:1,4:2,6:4}[ct]; stride = w*ch
    out = bytearray(); prev = bytearray(stride); p=0
    for y in range(h):
        f = raw[p]; p+=1
        line = bytearray(raw[p:p+stride]); p+=stride
        if f==1:
            for i in range(ch,stride): line[i]=(line[i]+line[i-ch])&255
        elif f==2:
            for i in range(stride): line[i]=(line[i]+prev[i])&255
        elif f==3:
            for i in range(stride):
                a=line[i-ch] if i>=ch else 0
                line[i]=(line[i]+((a+prev[i])>>1))&255
        elif f==4:
            for i in range(stride):
                a=line[i-ch] if i>=ch else 0
                b=prev[i]; c=prev[i-ch] if i>=ch else 0
                pp=a+b-c; pa=abs(pp-a); pb=abs(pp-b); pc=abs(pp-c)
                pr=a if (pa<=pb and pa<=pc) else (b if pb<=pc else c)
                line[i]=(line[i]+pr)&255
        out+=line; prev=line
    return w,h,ch,bytes(out)

w1,h1,c1,a = read_png(sys.argv[1])
w2,h2,c2,b = read_png(sys.argv[2])
diff=0; minx,miny,maxx,maxy=10**9,10**9,-1,-1; cyanNew=0
for y in range(min(h1,h2)):
    for x in range(min(w1,w2)):
        i=(y*w1+x)*c1; j=(y*w2+x)*c2
        if abs(a[i]-b[j])>12 or abs(a[i+1]-b[j+1])>12 or abs(a[i+2]-b[j+2])>12:
            diff+=1
            minx=min(minx,x); maxx=max(maxx,x); miny=min(miny,y); maxy=max(maxy,y)
            if b[j]<150 and b[j+1]>140 and b[j+2]>140: cyanNew+=1
print(f'pixels ALTERADOS: {diff}')
if diff: print(f'regiao: x {minx}..{maxx}, y {miny}..{maxy} ({maxx-minx+1}x{maxy-miny+1} px)')
print(f'dentre eles, ciano NOVO (o modulo): {cyanNew}')
