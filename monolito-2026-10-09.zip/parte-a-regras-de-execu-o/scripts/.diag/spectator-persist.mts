/**
 * Prova visual da persistência: edita uma construção, RECARREGA a página e
 * confere que a edição continua lá. É o teste que faltava — antes, a mudança
 * vivia só na tela e morria ao fechar o modo.
 */
import { spawn } from 'node:child_process';
import puppeteer, { type Browser } from 'puppeteer-core';

// Porta alta e variável: um servidor vazado de execucao anterior continua
// a porta e o teste passa a medir codigo velho em vez do atual.
const PORT = 4300 + Math.floor(Math.random() * 400);
// Recusa comecar se ja houver alguem na porta: o `server.kill` do finally
// mata o wrapper do npx, nao o `node vite` filho, e os dois vazavam.
try {
  await fetch(`http://127.0.0.1:${PORT}/`);
  throw new Error(`porta ${PORT} ja ocupada por um servidor antigo`);
} catch (e) {
  if ((e as Error).message.includes('ocupada')) throw e;
}
const server = spawn('npx', ['vite', '--port', String(PORT), '--host', '127.0.0.1'], {
  stdio: 'ignore', env: { ...process.env, DISABLE_HMR: 'true' }, detached: true,
});
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
async function waitFor(url: string, ms = 60000) {
  const end = Date.now() + ms;
  while (Date.now() < end) {
    try { if ((await fetch(url)).ok) return; } catch {}
    await sleep(400);
  }
  throw new Error('servidor nao subiu');
}

let browser: Browser | undefined;
let failures = 0;
const check = (ok: boolean, label: string) => {
  console.log(`  ${ok ? 'ok  ' : 'FAIL'} ${label}`);
  if (!ok) failures++;
};

try {
  await waitFor(`http://127.0.0.1:${PORT}/`);
  browser = await puppeteer.launch({
    executablePath: '/usr/bin/chromium', headless: true,
    args: ['--no-sandbox','--disable-dev-shm-usage','--use-gl=swiftshader-webgl',
           '--enable-unsafe-swiftshader','--ignore-gpu-blocklist'],
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1000, height: 760 });
  await page.goto(`http://127.0.0.1:${PORT}/`, { waitUntil: 'networkidle2', timeout: 60000 });
  await page.waitForSelector('canvas', { timeout: 40000 });
  await sleep(5000);

  // Entra no jogo, liga o modo espectador e seleciona uma construção.
  const setup = async () => {
    await page.evaluate(() => {
      const b = Array.from(document.querySelectorAll('button')).find((x) =>
        /iniciar|começar|comecar|entrar|jogar/i.test((x.textContent ?? '').trim()));
      b?.click();
    });
    await sleep(4000);
    await page.evaluate(() => {
      const b = Array.from(document.querySelectorAll('button'))
        .find(x => /espectador/i.test(x.getAttribute('aria-label') ?? ''));
      b?.click();
    });
    await sleep(2500);
    const box = await page.evaluate(() => {
      const b = (document.querySelector('canvas') as HTMLCanvasElement).getBoundingClientRect();
      return { l: b.left, t: b.top, w: b.width, h: b.height };
    });
    for (const [fx, fy] of [[0.5,0.55],[0.4,0.5],[0.6,0.6],[0.5,0.45],[0.3,0.55],[0.7,0.5]]) {
      await page.mouse.click(box.l + box.w * fx, box.t + box.h * fy);
      await sleep(700);
      const sel = await page.evaluate(() => document.body.innerText.match(/Construção #\d+/)?.[0] ?? '');
      if (sel) return { sel, box };
    }
    return { sel: '', box };
  };

  // O rodapé mostra "100% · 100% · 100%" na ordem X/Y/Z, sem prefixo de eixo.
  const readSliders = () => page.evaluate(() => {
    const m = document.body.innerText.match(/(\d+)% · (\d+)% · (\d+)%/);
    return m ? { larg: +m[1], alt: +m[2], prof: +m[3] } : null;
  });
  const clickBtn = (re: RegExp) => page.evaluate((src) => {
    const rx = new RegExp(src, 'i');
    const b = Array.from(document.querySelectorAll('button')).find(x => rx.test(x.textContent ?? ''));
    if (!b || b.hasAttribute('disabled')) return false;
    b.click(); return true;
  }, re.source);

  const { sel } = await setup();
  check(sel !== '', `selecionou uma construcao (${sel || 'nenhuma'})`);
  if (!sel) throw new Error('sem selecao');

  const before = await readSliders();
  console.log('  sliders antes:', JSON.stringify(before));


  // Amplia bem a largura para a diferenca ser inequivoca.
  // Os botoes +/− nao carregam o nome do eixo no texto, só no aria-label.
  for (let i = 0; i < 6; i++) {
    const clicked = await page.evaluate(() => {
      const b = document.querySelector<HTMLButtonElement>(
        'button[aria-label="Aumentar Largura (Tamanho)"]');
      if (!b || b.hasAttribute('disabled')) return false;
      b.click(); return true;
    });
    if (!clicked) { check(false, `botao de largura indisponivel na tentativa ${i + 1}`); break; }
    await sleep(200);
  }
  const edited = await readSliders();
  console.log('  sliders editado:', JSON.stringify(edited));
  check((edited?.larg ?? 0) > (before?.larg ?? 0), 'largura aumentou na tela');

  // O dado tem de estar no armazenamento, nao so na cena.
  // regionId -> nº de construções editadas. Precisa de JSON.parse: sem isso o
  // Object.entries recebe a string crua e devolve índices de caractere.
  const stored = await page.evaluate(() => {
    const raw = localStorage.getItem('monolito_spectator_edits_v1');
    if (!raw) return [] as [string, number][];
    const parsed = JSON.parse(raw);
    return Object.entries(parsed).map(([k, v]: any) => [k, Object.keys(v?.entries ?? {}).length] as [string, number]);
  });
  check(stored.length > 0 && stored.every(([, n]) => n > 0),
    `edicao gravada em localStorage ${JSON.stringify(stored)}`);

  // RECARREGA a pagina inteira: e o teste que importa.
  await page.reload({ waitUntil: 'networkidle2' });
  await page.waitForSelector('canvas', { timeout: 40000 });
  await sleep(6000);
  const storedAfter = await page.evaluate(() => {
    const raw = localStorage.getItem('monolito_spectator_edits_v1');
    if (!raw) return [] as [string, number][];
    const parsed = JSON.parse(raw);
    return Object.entries(parsed).map(([k, v]: any) => [k, Object.keys(v?.entries ?? {}).length] as [string, number]);
  });
  check(JSON.stringify(storedAfter) === JSON.stringify(stored),
    `edicao sobreviveu ao recarregar a pagina ${JSON.stringify(storedAfter)}`);

  // Reabre o modo e a construcao editada precisa estar no tamanho novo.
  const { sel: sel2 } = await setup();
  if (sel2 === sel) {
    const afterReload = await readSliders();
    console.log('  sliders apos recarregar:', JSON.stringify(afterReload));
    check((afterReload?.larg ?? 0) > (before?.larg ?? 0),
      'construcao reaparece editada ao reabrir o modo');
    await page.screenshot({ path: '/tmp/spec_persist.png' });
  } else {
    console.log('  (selecionou outra construcao apos reload:', sel2 + ')');
  }

  // Restaurar tem que apagar o dado, nao so a tela.
  await clickBtn(/Restaurar/); await sleep(600);
  const storedFinal = await page.evaluate(() => {
    const raw = localStorage.getItem('monolito_spectator_edits_v1');
    if (!raw) return [] as [string, number][];
    const parsed = JSON.parse(raw);
    return Object.entries(parsed).map(([k, v]: any) => [k, Object.keys(v?.entries ?? {}).length] as [string, number]);
  });
  check(storedFinal.every(([, n]) => n === 0), `restaurar apagou o dado ${JSON.stringify(storedFinal)}`);
} catch (e) {
  console.error('ERRO:', (e as Error).message);
  failures++;
} finally {
  await browser?.close();
  // Mata o grupo inteiro, senao o `node vite` filho sobrevive ao SIGTERM do pai.
  try { process.kill(-server.pid!, 'SIGKILL'); } catch { server.kill('SIGKILL'); }
}
console.log(failures === 0 ? 'spectator-persist (browser): OK' : `spectator-persist: ${failures} FALHAS`);
process.exitCode = failures === 0 ? 0 : 1;
