import * as THREE from 'three';
import { CreatorChunkManager } from '../../src/creator/runtime/CreatorChunkManager';
import { createCreatorWorld } from '../../src/creator/CreatorFormat';

const world = createCreatorWorld({
  name: 'diag', description: '', sizeMeters: 10000, seed: 4242,
  settings: { style:'realista', terrain:'colinas', climate:'temperado', objectDensity:'media', quality:'equilibrado' },
});
console.log('chunkSizeMeters:', world.chunkSizeMeters, '| segmentos por chunk: 32');

const scene = new THREE.Scene();
const chunks = new CreatorChunkManager(world, scene);
chunks.update(new THREE.Vector3(0, 120, 0));

// Mede a distancia vertical entre a altura analitica (getHeightAt, usada ao
// colocar o objeto) e a superficie realmente desenhada (triangulacao do chunk).
const terrain: THREE.Mesh[] = [];
scene.traverse(o => {
  const m = o as THREE.Mesh;
  if (m.isMesh && m.parent?.name?.startsWith('creator_chunk_')) terrain.push(m);
});
scene.updateMatrixWorld(true);
console.log("chunks na cena:", terrain.length);

const ray = new THREE.Raycaster();
ray.far = 5000;
const down = new THREE.Vector3(0, -1, 0);

let worst = 0, buried = 0, total = 0;
const diffs: number[] = [];
for (let i = 0; i < 400; i++) {
  const x = (Math.random() - 0.5) * 1400;
  const z = (Math.random() - 0.5) * 1400;
  const analytic = chunks.getHeightAt(x, z);
  ray.set(new THREE.Vector3(x, analytic + 3000, z), down);
  const hit = ray.intersectObjects(terrain, false)[0];
  if (!hit) continue;
  total++;
  const d = analytic - hit.point.y;   // >0 = objeto abaixo do solo
  diffs.push(d);
  if (d > worst) worst = d;
  if (d > 0) buried++;
}
diffs.sort((a, b) => a - b);
console.log('\npontos amostrados:', total);
console.log('erro vertical getHeightAt - malha:');
console.log('  min :', diffs[0].toFixed(2), 'm');
console.log('  p50 :', diffs[Math.floor(diffs.length * 0.5)].toFixed(2), 'm');
console.log('  p90 :', diffs[Math.floor(diffs.length * 0.9)].toFixed(2), 'm');
console.log('  max :', worst.toFixed(2), 'm');
console.log('  pior caso: objeto', worst.toFixed(1), 'm ABAIXO do solo');
console.log('  pontos com objeto enterrado:', buried, '/', total, `(${Math.round(buried/total*100)}%)`);
