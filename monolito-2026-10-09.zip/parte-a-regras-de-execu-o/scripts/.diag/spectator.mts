import { spawn } from 'node:child_process';
import puppeteer, { type Browser } from 'puppeteer-core';

const PORT = 4199;
const server = spawn('npx', ['vite', '--port', String(PORT), '--host', '127.0.0.1'], {
  stdio: 'ignore', env: { ...process.env, DISABLE_HMR: 'true' },
});
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
async function waitFor(url: string, ms = 60000) {
  const end = Date.now() + ms;
  while (Date.now() < end) {
    try { if ((await fetch(url)).ok) return; } catch {}
    await sleep(400);
  }
  throw new Error('servidor nao subiu');
}

let browser: Browser | undefined;
try {
  await waitFor(`http://127.0.0.1:${PORT}/`);
  browser = await puppeteer.launch({
    executablePath: '/usr/bin/chromium', headless: true,
    args: ['--no-sandbox','--disable-dev-shm-usage','--use-gl=swiftshader-webgl',
           '--enable-unsafe-swiftshader','--ignore-gpu-blocklist'],
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1000, height: 760 });
  const errs: string[] = [];
  page.on('pageerror', (e) => errs.push('PAGEERROR ' + e.message.slice(0, 160)));
  page.on('console', (m) => { if (m.type() === 'error') errs.push(m.text().slice(0, 120)); });

  await page.goto(`http://127.0.0.1:${PORT}/`, { waitUntil: 'networkidle2', timeout: 60000 });
  await page.waitForSelector('canvas', { timeout: 40000 });
  await sleep(5000);
  console.log('canvas pronto');

  // Entra no jogo (pula a tela inicial).
  const started = await page.evaluate(() => {
    const b = Array.from(document.querySelectorAll('button')).find((x) =>
      /iniciar|começar|comecar|entrar|jogar|iniciar/i.test((x.textContent ?? '').trim()));
    if (b) { b.click(); return b.textContent?.trim(); }
    return null;
  });
  console.log('botao inicial:', started ?? '(nao achado)');
  await sleep(4000);

  // O botao so existe com hasStarted. A captura de tela inicial e um "Jogar ..."
  // que abre o jogo; pode exigir um segundo clique ou nao ter iniciado.
  const headerInfo = await page.evaluate(() => {
    const hdr = document.querySelector('header');
    return { temHeader: !!hdr, texto: hdr ? hdr.innerText.slice(0, 120) : '' };
  });
  console.log('header:', JSON.stringify(headerInfo));

  const btn = await page.evaluate(() => {
    const all = Array.from(document.querySelectorAll('button'));
    const b = all.find((x) => /espectador/i.test(x.getAttribute('aria-label') ?? ''));
    if (!b) return { achou: false, botoes: all.map(x => (x.getAttribute('aria-label') || x.textContent || '').trim().slice(0, 22)).slice(0, 18) };
    b.click();
    return { achou: true, disabled: b.hasAttribute('disabled') };
  });
  console.log('botao espectador:', JSON.stringify(btn));
  await sleep(2500);

  const panel = await page.evaluate(() => {
    const t = document.body.innerText;
    const btn = Array.from(document.querySelectorAll('button'))
      .find(b => /espectador/i.test(b.getAttribute('aria-label') ?? ''));
    return {
      visivel: t.includes('Espectador'),
      pressed: btn?.getAttribute('aria-pressed'),
      texto: t.split('\n').filter(l => /Espectador|constru|Tamanho|Mover/i.test(l)).slice(0, 6),
    };
  });
  console.log('painel:', JSON.stringify(panel));

  // Tenta selecionar tocando em varios pontos.
  const box = await page.evaluate(() => {
    const b = (document.querySelector('canvas') as HTMLCanvasElement).getBoundingClientRect();
    return { l: b.left, t: b.top, w: b.width, h: b.height };
  });
  let sel = '';
  for (const [fx, fy] of [[0.5,0.55],[0.4,0.5],[0.6,0.6],[0.5,0.45],[0.3,0.55],[0.7,0.5]]) {
    await page.mouse.click(box.l + box.w * fx, box.t + box.h * fy);
    await sleep(700);
    sel = await page.evaluate(() => {
      const m = document.body.innerText.match(/Construção #\d+/);
      return m ? m[0] : '';
    });
    if (sel) { console.log(`selecionou em (${fx},${fy}):`, sel); break; }
  }
  if (!sel) console.log('>>> nao selecionou em nenhum ponto');

  // Mede os sliders antes/depois de mover e escalar.
  const readSliders = () => page.evaluate(() => {
    const m = document.body.innerText.match(/L (\d+)% · A (\d+)% · P (\d+)%/);
    return m ? { larg: +m[1], alt: +m[2], prof: +m[3] } : null;
  });
  const clickBtn = (re: RegExp) => page.evaluate((src) => {
    const rx = new RegExp(src, 'i');
    const b = Array.from(document.querySelectorAll('button')).find(x => rx.test(x.textContent ?? ''));
    if (!b) return false;
    if (b.hasAttribute('disabled')) return 'disabled';
    b.click(); return true;
  }, re.source);

  console.log('sliders antes      :', JSON.stringify(await readSliders()));
  await clickBtn(/\+ Largura/); await sleep(400);
  console.log('apos + Largura     :', JSON.stringify(await readSliders()));
  await clickBtn(/\+ Altura/); await sleep(400);
  console.log('apos + Altura      :', JSON.stringify(await readSliders()));
  const moved = await clickBtn(/← 4m/); await sleep(400);
  console.log('apos mover -4m X   :', JSON.stringify(await readSliders()), '(botao:', moved, ')');
  const rest = await clickBtn(/Restaurar/); await sleep(400);
  console.log('apos Restaurar     :', JSON.stringify(await readSliders()), '(botao:', rest, ')');

  // Prova visual: mesma construção, antes e depois de aumentar 2x a largura.
  const snap = async (name: string) => {
    await page.screenshot({ path: name as any, clip: { x: box.l, y: box.t, width: box.w, height: box.h } });
  };
  await clickBtn(/Restaurar/); await sleep(500);
  await snap('/tmp/spec_antes.png');
  for (let i = 0; i < 4; i++) { await clickBtn(/\+ Largura/); await sleep(250); }
  console.log('sliders após 4x +Largura:', JSON.stringify(await readSliders()));
  await snap('/tmp/spec_depois.png');
  await page.screenshot({ path: '/tmp/spec_ui.png' });
  console.log(errs.length ? 'erros: ' + errs.slice(0,3).join(' | ') : 'sem erros');
} finally {
  await browser?.close();
  server.kill('SIGTERM');
}
