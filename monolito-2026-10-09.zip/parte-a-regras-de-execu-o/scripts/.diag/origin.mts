import * as THREE from 'three';
import { CreatorChunkManager } from '../../src/creator/runtime/CreatorChunkManager';
import { CreatorEntityStore } from '../../src/creator/runtime/CreatorEntityStore';
import { createCreatorWorld } from '../../src/creator/CreatorFormat';

const world = createCreatorWorld({
  name: 'diag', description: '', sizeMeters: 10000, seed: 4242,
  settings: { style:'realista', terrain:'colinas', climate:'temperado', objectDensity:'media', quality:'equilibrado' },
});

const scene = new THREE.Scene();
const chunks = new CreatorChunkManager(world, scene);
const store = new CreatorEntityStore(world, scene, chunks);

// Câmera longe do centro => dispara rebase da floating origin.
const camPos = new THREE.Vector3(3200, 120, 900);
chunks.update(camPos);
const origin = chunks.getOrigin();
console.log('origin apos rebase:', origin);
store.syncVisibleChunks(new Set(chunks.getLoadedChunks().map(c => c.key)));

const camera = new THREE.PerspectiveCamera(70, 1, 0.1, 60000);
// A cena é desenhada em espaço de RENDER (pos - origin).
camera.position.set(camPos.x - origin.x, camPos.y, camPos.z - origin.z);
camera.lookAt(0, 0, 0);
camera.updateMatrixWorld(true);

const hit = store.pickTerrainWorld(camera, 0, 0);
console.log('ponto de mundo tocada:', hit && hit.toArray().map(v => Math.round(v)));
if (!hit) process.exit(1);

const placed = store.place('futuristic_spire_module', hit.x, hit.z, 0);
store.apply(placed.mutation!);

const mesh = (store as any).meshes.get(placed.entity!.entityId)! as THREE.Mesh;
const renderPos = new THREE.Vector3();
mesh.getWorldPosition(renderPos);

console.log('entidade pos de mundo :', placed.entity!.position.map(v => Math.round(v)));
console.log('mesh pos de RENDER    :', renderPos.toArray().map(v => Math.round(v)));
console.log('pos de render esperado:', [placed.entity!.position[0] - origin.x, placed.entity!.position[1], placed.entity!.position[2] - origin.z].map(v => Math.round(v)));
console.log('mesh visivel          :', mesh.visible);
console.log('distancia mesh->camara:', Math.round(renderPos.distanceTo(camera.position)), 'm');
console.log('parent da mesh        :', mesh.parent?.name || mesh.parent?.type);
