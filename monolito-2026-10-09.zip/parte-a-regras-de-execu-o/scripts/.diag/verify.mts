import * as THREE from 'three';
import { CreatorChunkManager } from '../../src/creator/runtime/CreatorChunkManager';
import { CreatorEntityStore } from '../../src/creator/runtime/CreatorEntityStore';
import { createCreatorWorld } from '../../src/creator/CreatorFormat';

const world = createCreatorWorld({
  name: 'diag', description: '', sizeMeters: 10000, seed: 4242,
  settings: { style:'realista', terrain:'colinas', climate:'temperado', objectDensity:'media', quality:'equilibrado' },
});
const scene = new THREE.Scene();
const chunks = new CreatorChunkManager(world, scene);
const store = new CreatorEntityStore(world, scene, chunks);

let failures = 0;
function check(label: string, ok: boolean, detail = '') {
  console.log(`${ok ? 'OK  ' : 'FALHA'} ${label}${detail ? ' -> ' + detail : ''}`);
  if (!ok) failures++;
}

// Cenário A: câmera no centro, origin = 0 (o caso que já "funcionava").
const centerCam = new THREE.Vector3(0, 120, 0);
chunks.update(centerCam);
store.syncVisibleChunks(new Set(chunks.getLoadedChunks().map(c => c.key)));
store.syncOrigin();
{
  const origin = chunks.getOrigin();
  const camera = new THREE.PerspectiveCamera(70, 1, 0.1, 60000);
  camera.position.set(centerCam.x - origin.x, centerCam.y, centerCam.z - origin.z);
  camera.rotation.x = -0.6;
  camera.updateMatrixWorld(true);
  scene.updateMatrixWorld(true);
  const hit = store.pickTerrainWorld(camera, 0, 0)!;
  const placed = store.place('futuristic_spire_module', hit.x, hit.z, 0);
  store.apply(placed.mutation!);
  const mesh = (store as any).meshes.get(placed.entity!.entityId)! as THREE.Mesh;
  const wp = new THREE.Vector3(); mesh.getWorldPosition(wp);
  console.log('\n-- A: origin =', JSON.stringify(origin));
  check('A entidade nasce no topo do terreno', Math.abs(wp.y - placed.entity!.position[1]) < 0.001);
  check('A distancia mesh->camara e curta', wp.distanceTo(camera.position) < 400, `${Math.round(wp.distanceTo(camera.position))} m`);
}

// Cenário B: câmera longe -> origin rebaseia. Este era o bug.
const farCam = new THREE.Vector3(3200, 120, 900);
chunks.update(farCam);
store.syncVisibleChunks(new Set(chunks.getLoadedChunks().map(c => c.key)));
store.syncOrigin();
{
  const origin = chunks.getOrigin();
  check('B origin realmente rebaseou', origin.x !== 0 || origin.z !== 0, JSON.stringify(origin));
  const camera = new THREE.PerspectiveCamera(70, 1, 0.1, 60000);
  camera.position.set(farCam.x - origin.x, farCam.y, farCam.z - origin.z);
  camera.rotation.x = -0.6;
  camera.updateMatrixWorld(true);
  scene.updateMatrixWorld(true);
  const hit = store.pickTerrainWorld(camera, 0, 0)!;
  const placed = store.place('futuristic_spire_module', hit.x, hit.z, 0);
  store.apply(placed.mutation!);
  const mesh = (store as any).meshes.get(placed.entity!.entityId)! as THREE.Mesh;
  const wp = new THREE.Vector3(); mesh.getWorldPosition(wp);
  const expected = new THREE.Vector3(
    placed.entity!.position[0] - origin.x,
    placed.entity!.position[1],
    placed.entity!.position[2] - origin.z
  );
  console.log('\n-- B: origin =', JSON.stringify(origin));
  console.log('   render:', wp.toArray().map(v => Math.round(v)), 'esperado:', expected.toArray().map(v => Math.round(v)));
  check('B malha em espaco de render', wp.distanceTo(expected) < 0.001, `${wp.distanceTo(expected).toFixed(3)} m de erro`);
  check('B entidade visivel', mesh.visible);
  check('B distancia mesh->camara e curta', wp.distanceTo(camera.position) < 400, `${Math.round(wp.distanceTo(camera.position))} m`);
  check('B raycast ainda acha a entidade', store.pick(camera, 0, 0)?.entityId === placed.entity!.entityId);
}

console.log(failures === 0 ? '\n>>> TODOS OS CHECKS PASSARAM' : `\n>>> ${failures} FALHA(S)`);
process.exit(failures === 0 ? 0 : 1);
