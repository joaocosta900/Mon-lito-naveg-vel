/**
 * Teste do grafo de cena do modo espectador.
 *
 * Cobre o contrato que o agrupamento precisa cumprir ao reparentear as peças:
 * nada muda de lugar, nada some da cena, e o que o jogador moveu/escalou
 * continua igual quando o modo fecha. Não precisa de navegador nem de WebGL.
 */
import * as THREE from 'three';
import {
  applyTransform,
  clusterStructures,
  IDENTITY_TRANSFORM,
  readTransform,
  resetTransform,
  SpectatorCluster,
  StructureTransform,
} from '../src/world/SpectatorStructures';
import { nearestClusterAlongRay } from '../src/world/useSpectatorMode';

let checks = 0;

function assert(condition: boolean, label: string): void {
  checks += 1;
  if (!condition) {
    console.error(`  FAIL ${label}`);
    process.exitCode = 1;
    throw new Error(label);
  }
  console.log(`  ok   ${label}`);
}

const fmt = (v: THREE.Vector3) => v.toArray().map((n) => n.toFixed(2)).join(', ');

/** Atalho: parte da identidade e sobrescreve só o que o teste exercising. */
const xf = (over: Partial<StructureTransform>): StructureTransform => ({
  ...IDENTITY_TRANSFORM,
  ...over,
});

/** Reproduz o formato do mundo real: chão solto + portal dentro de subgrupo. */
function buildWorld() {
  const sceneGroup = new THREE.Group();
  const solid = new THREE.MeshStandardMaterial();

  const ground = new THREE.Mesh(new THREE.BoxGeometry(400, 1, 400), solid);
  ground.position.set(0, -0.5, 0);
  sceneGroup.add(ground);

  // O portal real nasce dentro de um grupo posicionado e rotacionado.
  const portalGroup = new THREE.Group();
  portalGroup.position.set(0, 0, 75);
  portalGroup.rotation.y = 0.3;
  const part = (w: number, h: number, d: number, x: number, y: number, z: number) => {
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), solid);
    mesh.position.set(x, y, z);
    return mesh;
  };
  const pillars = [
    part(1.4, 9.5, 2.4, -2.1, 4.75, 0),
    part(1.4, 9.5, 2.4, 2.1, 4.75, 0),
    part(6.2, 2.2, 2.8, 0, 10.2, 0),
  ];
  portalGroup.add(...pillars);

  // Peça miúda: abaixo do volume mínimo, não é construção e não entra no grupo.
  const spark = part(0.4, 0.4, 0.4, 0, 8.9, 1.25);
  portalGroup.add(spark);
  sceneGroup.add(portalGroup);
  sceneGroup.updateMatrixWorld(true);

  return { sceneGroup, pillars, spark, ground };
}

const countMeshes = (group: THREE.Group) => {
  let total = 0;
  group.traverse((object) => {
    if ((object as THREE.Mesh).isMesh) total += 1;
  });
  return total;
};

const boxOf = (meshes: THREE.Mesh[]) => {
  const box = new THREE.Box3();
  for (const mesh of meshes) box.union(new THREE.Box3().setFromObject(mesh));
  return box;
};

console.log('spectator-cluster-test');

// O portal não pode teleportar para o meio do mapa ao ser agrupado.
{
  const { sceneGroup, pillars } = buildWorld();
  const before = boxOf(pillars).getCenter(new THREE.Vector3());

  clusterStructures(sceneGroup);
  sceneGroup.updateMatrixWorld(true);

  const after = boxOf(pillars).getCenter(new THREE.Vector3());
  assert(
    before.distanceTo(after) < 0.001,
    `portal nao muda de lugar (${fmt(before)} -> ${fmt(after)})`
  );
}

// Agrupar não pode tirar nada do mundo renderizado.
{
  const { sceneGroup } = buildWorld();
  const expected = countMeshes(sceneGroup);

  const clusters = clusterStructures(sceneGroup);

  assert(countMeshes(sceneGroup) === expected,
    `nenhuma malha some da cena (${countMeshes(sceneGroup)}/${expected})`);
  assert(clusters.length > 0, `houve agrupamento (${clusters.length} construcao(oes))`);
  assert(clusters.every((cluster) => cluster.group.parent === sceneGroup),
    'todo grupo de construcao entra na cena');
  assert(clusters.some((cluster) => cluster.meshes.length >= 3),
    'as pecas do portal ficam na mesma construcao');
}

// Peça miúda e material transparente não viram construção.
{
  const { sceneGroup, spark } = buildWorld();
  const clusters = clusterStructures(sceneGroup);
  const clustered = clusters.some((cluster) => cluster.meshes.includes(spark));
  assert(!clustered, 'peca abaixo do volume minimo fica de fora');
}

// Mover e escalar movem a construção de verdade.
{
  const { sceneGroup, pillars } = buildWorld();
  const origin = boxOf(pillars).getCenter(new THREE.Vector3());
  const size = boxOf(pillars).getSize(new THREE.Vector3());

  const clusters = clusterStructures(sceneGroup);
  sceneGroup.updateMatrixWorld(true);
  const portal = clusters.find((cluster) => cluster.meshes.length >= 3) as SpectatorCluster;

  applyTransform(portal, xf({ offsetX: 12, offsetZ: -5, scaleX: 1, scaleY: 1, scaleZ: 1 }));
  sceneGroup.updateMatrixWorld(true);
  const moved = boxOf(pillars).getCenter(new THREE.Vector3());
  assert(moved.distanceTo(origin.clone().add(new THREE.Vector3(12, 0, -5))) < 0.001,
    `mover desloca exatamente o offset (${fmt(origin)} -> ${fmt(moved)})`);

  applyTransform(portal, xf({ offsetX: 12, offsetZ: -5, scaleX: 1.5, scaleY: 2, scaleZ: 1.5 }));
  sceneGroup.updateMatrixWorld(true);
  const grown = boxOf(pillars).getSize(new THREE.Vector3());
  assert(Math.abs(grown.y / size.y - 2) < 0.05,
    `escalar cresce em torno do pivo (fator ~${(grown.y / size.y).toFixed(2)})`);
  assert(Math.abs(grown.x / size.x - 1.5) < 0.05,
    `escala por eixo (fator ~${(grown.x / size.x).toFixed(2)})`);
  assert(Math.abs(readTransform(portal).scaleX - 1.5) < 0.001,
    'a transformacao lida bate com a aplicada');
}

// Sair do modo NAO desfaz a edicao: a construcao fica como o jogador deixou.
{
  const { sceneGroup, pillars } = buildWorld();
  const clusters = clusterStructures(sceneGroup);
  sceneGroup.updateMatrixWorld(true);
  const portal = clusters.find((c) => c.meshes.length >= 3) as SpectatorCluster;

  applyTransform(portal, xf({ offsetX: 12, offsetY: 9, offsetZ: -5, scaleX: 1.5, scaleY: 2, scaleZ: 1.5 }));
  sceneGroup.updateMatrixWorld(true);
  const edited = boxOf(pillars);

  // O cluster continua na cena com a transformação aplicada — e isso que o hook
  // faz ao sair: nao mexe em nada, so esconde a interface.
  assert(clusters.every((c) => c.group.parent === sceneGroup),
    'os grupos de construcao continuam na cena com o modo fechado');
  assert(Math.abs(readTransform(portal).scaleY - 2) < 0.001,
    'a transformacao continua valendo depois de sair');
  assert(boxOf(pillars).min.distanceTo(edited.min) < 0.001,
    'a construcao permanece como o jogador deixou');
}

// Reabrir o modo nao reagrupa: o pivô continua o mesmo, entao a ancora bate e a
// edicao nao e somada de novo.
{
  const { sceneGroup, pillars } = buildWorld();
  const first = clusterStructures(sceneGroup);
  sceneGroup.updateMatrixWorld(true);
  const firstPortal = first.find((c) => c.meshes.length >= 3) as SpectatorCluster;
  const anchor = firstPortal.origin.clone();
  const anchorKey = `${Math.round(anchor.x)},${Math.round(anchor.y)},${Math.round(anchor.z)}`;

  applyTransform(firstPortal, xf({ offsetX: 12, scaleY: 2 }));
  sceneGroup.updateMatrixWorld(true);
  const edited = boxOf(pillars);

  // build() ve que o mundo e o mesmo e devolve sem reagrupar: os clusters
  // continuam vivos, entao a ancora e a mesma e nada se move de novo.
  assert(firstPortal.origin.distanceTo(anchor) < 0.001,
    'o pivo do cluster nao muda com a edicao');
  assert(boxOf(pillars).min.distanceTo(edited.min) < 0.001,
    'a edicao nao e aplicada duas vezes ao reabrir');
  assert(
    `${Math.round(firstPortal.origin.x)},${Math.round(firstPortal.origin.y)},${Math.round(firstPortal.origin.z)}` === anchorKey,
    'a ancora gravada continua identica depois de editar'
  );
}

// Mundo reconstruido (recarga/troca de regiao): reagrupa e reaplica do storage.
{
  const { sceneGroup, pillars } = buildWorld();
  const first = clusterStructures(sceneGroup);
  sceneGroup.updateMatrixWorld(true);
  const firstPortal = first.find((c) => c.meshes.length >= 3) as SpectatorCluster;
  const saved = readTransform(firstPortal);
  applyTransform(firstPortal, xf({ offsetX: 12, scaleY: 2 }));
  sceneGroup.updateMatrixWorld(true);

  // Simula o mundo voltando do zero: grupo novo, meshes novas, mesmas medidas.
  const rebuilt = buildWorld();
  const fresh = clusterStructures(rebuilt.sceneGroup);
  rebuilt.sceneGroup.updateMatrixWorld(true);
  const freshPortal = fresh.find((c) => c.meshes.length >= 3) as SpectatorCluster;
  const stored: StructureTransform = { ...saved, offsetX: 12, scaleY: 2 };
  applyTransform(freshPortal, stored);
  rebuilt.sceneGroup.updateMatrixWorld(true);

  const reference = new THREE.Box3().setFromObject(firstPortal.group);
  const replayed = new THREE.Box3().setFromObject(freshPortal.group);
  assert(
    reference.min.distanceTo(replayed.min) < 0.001 && reference.max.distanceTo(replayed.max) < 0.001,
    'reaplicar a edicao salva devolve a construcao ao mesmo lugar e tamanho'
  );
  assert(saved.scaleY === 1, 'a leitura antes de editar era a identidade');
}

// O eixo Y e a rotação entram na transformação e voltam na leitura.
{
  const { sceneGroup, pillars } = buildWorld();
  const clusters = clusterStructures(sceneGroup);
  sceneGroup.updateMatrixWorld(true);
  const portal = clusters.find((c) => c.meshes.length >= 3) as SpectatorCluster;
  const before = boxOf(pillars).getCenter(new THREE.Vector3());

  applyTransform(portal, xf({ offsetY: 17, rotY: Math.PI / 3 }));
  sceneGroup.updateMatrixWorld(true);

  const after = boxOf(pillars).getCenter(new THREE.Vector3());
  assert(Math.abs(after.y - (before.y + 17)) < 0.001,
    `mover em Y tira a construcao do chao (${fmt(before)} -> ${fmt(after)})`);

  const t = readTransform(portal);
  assert(Math.abs(t.offsetY - 17) < 0.001, 'offsetY sobrevive a leitura');
  assert(Math.abs(t.rotY - Math.PI / 3) < 0.001, 'rotY sobrevive a leitura');
  assert(Math.abs(t.rotX) < 0.001 && Math.abs(t.rotZ) < 0.001, 'eixos nao editados ficam em zero');

  // Girar de verdade muda o desenho da construção, não só o número no painel.
  applyTransform(portal, xf({}));
  sceneGroup.updateMatrixWorld(true);
  const upright = boxOf(pillars).getSize(new THREE.Vector3());
  applyTransform(portal, xf({ rotX: Math.PI / 2 }));
  sceneGroup.updateMatrixWorld(true);
  const tilted = boxOf(pillars).getSize(new THREE.Vector3());
  assert(Math.abs(tilted.y - upright.y) > 0.5,
    `inclinar em X deita a construcao (altura ${upright.y.toFixed(1)} -> ${tilted.y.toFixed(1)})`);
}

// Restaurar volta tudo — inclusive rotação e altura — ao estado original.
{
  const { sceneGroup, pillars } = buildWorld();
  const before = boxOf(pillars);
  const clusters = clusterStructures(sceneGroup);
  sceneGroup.updateMatrixWorld(true);
  const portal = clusters.find((c) => c.meshes.length >= 3) as SpectatorCluster;

  applyTransform(portal, xf({ offsetX: 9, offsetY: 12, offsetZ: -3, rotX: 0.4, rotY: 1.1, rotZ: -0.2, scaleX: 1.4, scaleY: 0.7, scaleZ: 2 }));
  sceneGroup.updateMatrixWorld(true);
  resetTransform(portal);
  sceneGroup.updateMatrixWorld(true);

  const after = boxOf(pillars);
  assert(after.min.distanceTo(before.min) < 0.001 && after.max.distanceTo(before.max) < 0.001,
    'restaurar desfaz rotacao, altura e escala');
}

// Câmera dentro da construção: o raio não acerta face nenhuma e a seleção
// depende da reserva pela caixa envolvente.
{
  const { sceneGroup, pillars } = buildWorld();
  const clusters = clusterStructures(sceneGroup);
  sceneGroup.updateMatrixWorld(true);
  const portal = clusters[0];

  const outside = new THREE.Vector3(0, 5.65, 200);
  // Mira num pilar de verdade: o centro da caixa cai no vão entre eles, que
  // atravessaria sem acertar nada.
  const target = pillars[0].getWorldPosition(new THREE.Vector3());

  // De fora, mirando o pilar: acerta a malha normalmente.
  const aimed = new THREE.Raycaster(outside, target.clone().sub(outside).normalize());
  const meshHits = aimed.intersectObjects(portal.meshes, false);
  assert(meshHits.length > 0, 'de fora o raio acerta a malha da construcao');

  // De dentro, o raio sai pelo lado oposto e nao pega face frontal nenhuma.
  const inside = new THREE.Raycaster(
    target.clone(),
    target.clone().sub(outside).normalize()
  );
  const insideHits = inside.intersectObjects(portal.meshes, false);
  assert(insideHits.length === 0, 'de dentro o raio frontal nao acerta nada');

  // A reserva devolve a construcao mesmo assim.
  const found = nearestClusterAlongRay(inside.ray, clusters);
  assert(found === portal, 'a reserva pela caixa encontra a construcao de dentro');

  // E um raio que aponta para o nada nao inventa construcao. Sai de bem acima
  // de tudo: de dentro da caixa o Ray.intersectBox devolve a própria origem.
  const missed = new THREE.Raycaster(
    new THREE.Vector3(0, 900, 200),
    new THREE.Vector3(0, 1, 0)
  );
  assert(nearestClusterAlongRay(missed.ray, clusters) === null,
    'raio sem Nada nao seleciona construcao alguma');
}

// Precisao: uma escada e UMA construcao, e nada mais entra nela.
{
  const sceneGroup = new THREE.Group();
  const solid = new THREE.MeshStandardMaterial();

  // Laje de andar enormes, bem embaixo de tudo: e o palco, nao a construcao.
  const slab = new THREE.Mesh(new THREE.BoxGeometry(300, 1, 300), solid);
  slab.position.set(0, -1, 0);
  sceneGroup.add(slab);

  // Escada: degraus encostados uns nos outros.
  const steps: THREE.Mesh[] = [];
  for (let i = 0; i < 5; i += 1) {
    const step = new THREE.Mesh(new THREE.BoxGeometry(5, 1.5, 3), solid);
    step.position.set(0, i * 1.5, i * 3);
    sceneGroup.add(step);
    steps.push(step);
  }

  // Torre longe, sem encostar em nada.
  const tower = new THREE.Mesh(new THREE.BoxGeometry(10, 40, 10), solid);
  tower.position.set(0, 20, 60);
  sceneGroup.add(tower);

  sceneGroup.updateMatrixWorld(true);
  const clusters = clusterStructures(sceneGroup);
  const stairCluster = clusters.find((c) => c.meshes.includes(steps[0]));

  assert(!!stairCluster, 'a escada forma uma construcao');
  assert(stairCluster!.meshes.length === 5,
    `a escada junta apenas os 5 degraus (${stairCluster!.meshes.length})`);
  assert(!stairCluster!.meshes.includes(tower), 'a torre distante nao entra na escada');
  assert(!stairCluster!.meshes.includes(slab), 'a laje de andar nao entra na escada');
  assert(clusters.some((c) => c.meshes.includes(tower)), 'a torre continua editavel sozinha');
  assert(!clusters.some((c) => c.meshes.includes(slab)),
    'laje larga e fina nao vira construcao');
  assert(clusters.length === 2, `so duas construcoes no cenario (${clusters.length})`);
}

// Uma peca grande nao engole o bairro: a regra mede o vao entre as caixas.
{
  const sceneGroup = new THREE.Group();
  const solid = new THREE.MeshStandardMaterial();
  // Bloco de 120 m bem ao lado de uma casa pequena.
  const block = new THREE.Mesh(new THREE.BoxGeometry(120, 60, 120), solid);
  block.position.set(0, 30, 0);
  const house = new THREE.Mesh(new THREE.BoxGeometry(8, 8, 8), solid);
  house.position.set(70, 4, 0);
  sceneGroup.add(block, house);
  sceneGroup.updateMatrixWorld(true);

  const clusters = clusterStructures(sceneGroup);
  assert(clusters.length === 2,
    `a casa nao e puxada pelo bloco gigante (${clusters.length} construcoes)`);
}

console.log(`spectator-cluster-test: OK (${checks} verificacoes)`);
