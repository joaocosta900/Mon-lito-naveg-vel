import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = parseInt(process.env.PORT || '3000', 10);
const isProd = process.env.NODE_ENV === 'production';

app.use(express.json({ limit: '10mb' }));

// Helper to initialize Gemini SDK on the server with User-Agent header
function getGeminiClient(customApiKey?: string): GoogleGenAI | null {
  const apiKey = customApiKey || process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Endpoint to check server-level Gemini availability
app.get('/api/ai/gemini-available', (_req, res) => {
  const hasEnvKey = Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY');
  res.json({ available: hasEnvKey });
});

// Endpoint to test provider connectivity
app.post('/api/ai/test', async (req, res) => {
  const { providerType, endpoint, apiKey, model, customHeaders } = req.body;
  const startTime = Date.now();

  try {
    if (providerType === 'gemini') {
      const ai = getGeminiClient(apiKey);
      if (!ai) {
        return res.status(400).json({
          status: 'INVALID_KEY',
          latencyMs: Date.now() - startTime,
          message: 'Chave de API do Gemini não configurada.',
        });
      }
      const response = await ai.models.generateContent({
        model: model || 'gemini-3.8-flash',
        contents: 'Ping test. Reply with word: OK',
      });
      const latencyMs = Date.now() - startTime;
      if (response && response.text) {
        return res.json({
          status: 'CONNECTED',
          latencyMs,
          message: `Conectado com sucesso ao modelo ${model || 'gemini-3.8-flash'}.`,
          model: model || 'gemini-3.8-flash',
        });
      } else {
        return res.status(502).json({
          status: 'ERROR',
          latencyMs,
          message: 'Resposta vazia do modelo Gemini.',
        });
      }
    }

    if (providerType === 'anthropic') {
      const url = endpoint || 'https://api.anthropic.com/v1/messages';
      const effectiveKey = apiKey;
      if (!effectiveKey) {
        return res.status(400).json({
          status: 'INVALID_KEY',
          latencyMs: Date.now() - startTime,
          message: 'Chave de API da Anthropic necessária.',
        });
      }

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 12000);

      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': effectiveKey,
          'anthropic-version': '2023-06-01',
          ...(customHeaders || {}),
        },
        body: JSON.stringify({
          model: model || 'claude-3-5-haiku-20241022',
          max_tokens: 10,
          messages: [{ role: 'user', content: 'Ping. Answer OK' }],
        }),
        signal: controller.signal,
      });
      clearTimeout(timeoutId);

      const latencyMs = Date.now() - startTime;
      if (response.ok) {
        return res.json({
          status: 'CONNECTED',
          latencyMs,
          message: `Conectado com sucesso ao Claude (${model}).`,
          model,
        });
      } else {
        const errorText = await response.text();
        return res.status(response.status).json({
          status: response.status === 401 ? 'INVALID_KEY' : response.status === 404 ? 'MODEL_NOT_FOUND' : 'ERROR',
          latencyMs,
          message: `Erro Anthropic (${response.status}): ${errorText.slice(0, 140)}`,
        });
      }
    }

    // OpenAI, OpenRouter, OpenAI-compatible or Custom HTTP
    const url = endpoint || (providerType === 'openrouter' ? 'https://openrouter.ai/api/v1/chat/completions' : 'https://api.openai.com/v1/chat/completions');
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 12000);

    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(customHeaders || {}),
    };
    if (apiKey) {
      headers['Authorization'] = `Bearer ${apiKey}`;
    }
    if (providerType === 'openrouter') {
      headers['HTTP-Referer'] = 'https://ai.studio';
      headers['X-Title'] = 'Monolito World Planner';
    }

    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: JSON.stringify({
        model: model || (providerType === 'openrouter' ? 'meta-llama/llama-3.1-8b-instruct:free' : 'gpt-4o-mini'),
        messages: [{ role: 'user', content: 'Ping test. Reply OK' }],
        max_tokens: 10,
      }),
      signal: controller.signal,
    });
    clearTimeout(timeoutId);

    const latencyMs = Date.now() - startTime;
    if (response.ok) {
      return res.json({
        status: 'CONNECTED',
        latencyMs,
        message: `Conectado com sucesso ao provedor (${model || 'default'}).`,
        model,
      });
    } else {
      const errorText = await response.text();
      return res.status(response.status).json({
        status: response.status === 401 ? 'INVALID_KEY' : response.status === 404 ? 'MODEL_NOT_FOUND' : 'ERROR',
        latencyMs,
        message: `Erro na conexão (${response.status}): ${errorText.slice(0, 140)}`,
      });
    }
  } catch (err: unknown) {
    const error = err as Error;
    const latencyMs = Date.now() - startTime;
    const isTimeout = error.name === 'AbortError' || error.message.toLowerCase().includes('timeout');
    return res.status(500).json({
      status: isTimeout ? 'TIMEOUT' : 'ERROR',
      latencyMs,
      message: isTimeout ? 'Tempo limite de resposta esgotado (Timeout).' : `Falha de rede ou endpoint inacessível: ${error.message}`,
    });
  }
});

// Endpoint to execute LLM chat request (used for planning and patching)
app.post('/api/ai/chat', async (req, res) => {
  const { providerType, endpoint, apiKey, model, messages, systemPrompt, temperature, customHeaders, timeoutMs = 45000 } = req.body;
  const startTime = Date.now();

  try {
    if (providerType === 'gemini') {
      const ai = getGeminiClient(apiKey);
      if (!ai) {
        return res.status(400).json({ error: 'Chave de API do Gemini não disponível no servidor ou cliente.' });
      }

      const promptText = messages.map((m: { role: string; content: string }) => `${m.role.toUpperCase()}: ${m.content}`).join('\n\n');

      const response = await ai.models.generateContent({
        model: model || 'gemini-3.8-flash',
        contents: promptText,
        config: {
          systemInstruction: systemPrompt || 'You are an architectural world director producing structured JSON.',
          responseMimeType: 'application/json',
          temperature: typeof temperature === 'number' ? temperature : 0.7,
        },
      });

      const durationMs = Date.now() - startTime;
      const text = response.text || '';
      return res.json({
        content: text,
        usage: {
          promptTokens: 500, // estimated
          completionTokens: 800,
          totalTokens: 1300,
        },
        durationMs,
        provider: 'gemini',
        model: model || 'gemini-3.8-flash',
      });
    }

    if (providerType === 'anthropic') {
      const url = endpoint || 'https://api.anthropic.com/v1/messages';
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': apiKey || '',
          'anthropic-version': '2023-06-01',
          ...(customHeaders || {}),
        },
        body: JSON.stringify({
          model: model || 'claude-3-5-haiku-20241022',
          max_tokens: 4000,
          system: (systemPrompt || '') + '\nIMPORTANT: You must return raw valid JSON only with NO markdown fences, NO comments and NO extra prose.',
          messages: messages.map((m: { role: string; content: string }) => ({
            role: m.role === 'system' ? 'user' : m.role,
            content: m.content,
          })),
          temperature: typeof temperature === 'number' ? temperature : 0.7,
        }),
        signal: controller.signal,
      });
      clearTimeout(timeoutId);

      const durationMs = Date.now() - startTime;
      if (!response.ok) {
        const errorText = await response.text();
        return res.status(response.status).json({ error: `Anthropic error (${response.status}): ${errorText}` });
      }

      const data = await response.json() as {
        content: Array<{ type: string; text: string }>;
        usage?: { input_tokens?: number; output_tokens?: number };
      };
      const text = data.content?.[0]?.text || '';
      return res.json({
        content: text,
        usage: {
          promptTokens: data.usage?.input_tokens || 0,
          completionTokens: data.usage?.output_tokens || 0,
          totalTokens: (data.usage?.input_tokens || 0) + (data.usage?.output_tokens || 0),
        },
        durationMs,
        provider: 'anthropic',
        model,
      });
    }

    // OpenAI, OpenRouter, OpenAI-compatible or Custom HTTP
    const url = endpoint || (providerType === 'openrouter' ? 'https://openrouter.ai/api/v1/chat/completions' : 'https://api.openai.com/v1/chat/completions');
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(customHeaders || {}),
    };
    if (apiKey) {
      headers['Authorization'] = `Bearer ${apiKey}`;
    }
    if (providerType === 'openrouter') {
      headers['HTTP-Referer'] = 'https://ai.studio';
      headers['X-Title'] = 'Monolito World Planner';
    }

    const formattedMessages = [
      ...(systemPrompt ? [{ role: 'system', content: systemPrompt }] : []),
      ...messages,
    ];

    const bodyPayload: Record<string, unknown> = {
      model: model || 'gpt-4o-mini',
      messages: formattedMessages,
      temperature: typeof temperature === 'number' ? temperature : 0.7,
    };

    // Include response_format if compatible
    if (providerType === 'openai' || providerType === 'openrouter') {
      bodyPayload.response_format = { type: 'json_object' };
    }

    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: JSON.stringify(bodyPayload),
      signal: controller.signal,
    });
    clearTimeout(timeoutId);

    const durationMs = Date.now() - startTime;
    if (!response.ok) {
      const errorText = await response.text();
      return res.status(response.status).json({ error: `Provider error (${response.status}): ${errorText}` });
    }

    const data = await response.json() as {
      choices?: Array<{ message?: { content?: string } }>;
      usage?: { prompt_tokens?: number; completion_tokens?: number; total_tokens?: number };
    };
    const text = data.choices?.[0]?.message?.content || '';
    return res.json({
      content: text,
      usage: {
        promptTokens: data.usage?.prompt_tokens || 0,
        completionTokens: data.usage?.completion_tokens || 0,
        totalTokens: data.usage?.total_tokens || 0,
      },
      durationMs,
      provider: providerType,
      model,
    });
  } catch (err: unknown) {
    const error = err as Error;
    const isTimeout = error.name === 'AbortError';
    return res.status(500).json({
      error: isTimeout ? 'Timeout na chamada do provedor de IA.' : error.message,
    });
  }
});

// Vite middleware integration or static serving
async function startServer() {
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    const targetDist = fs.existsSync(distPath) ? distPath : path.resolve(process.cwd(), 'dist');
    app.use(express.static(targetDist));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(targetDist, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[MONOLITO World Engine] Server active at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('[MONOLITO Server] Failed to start:', err);
});
