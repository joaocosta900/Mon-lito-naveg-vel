# PROMPT ORIGINAL — CRIADOR DE MUNDOS

> Este arquivo é a **fonte da verdade do escopo**. Foi fornecido pelo usuário.
> O `CREATOR_HANDOFF.md` é o complemento: registra o que já foi implementado e o que falta.
> Uma sessão nova deve ler **este arquivo + o CREATOR_HANDOFF.md** e não precisa reler o resto do projeto para continuar.

---

# PARTE A — REGRAS DE EXECUÇÃO (LER PRIMEIRO)

1. NÃO FINGIR. Toda ferramenta deve modificar os dados reais do mundo e persistir no salvamento. Se algo não for implementado, mostrar na interface "NÃO IMPLEMENTADO". Nunca deixar botão sem efeito.
2. Trabalhar em FASES. Ao fim de cada fase: rodar/testar, listar o que funciona e o que não funciona, e só então avançar. Não pular fases.
3. Adaptar as técnicas de otimização ao renderer encontrado na análise. Se uma técnica não for viável (ex.: occlusion culling em mobile/web), dizer isso e usar a melhor alternativa.
4. Ao terminar cada fase, apresentar: o que foi feito, como testar, limitações conhecidas.

ORDEM DAS FASES:
- FASE 0: Análise do projeto (seção "ANTES DE IMPLEMENTAR" no final).
- FASE 1: Dados, formato e salvamento (seções 1, 2, 15, 23, 22).
- FASE 2: Streaming, câmera, mapa e interface mobile (seções 3, 17, 24, 16).
- FASE 3: Núcleo do editor: seleção, duplicação, grid, histórico (seções 9, 10, 14, 18).
- FASE 4: Terreno (seção 5) e clima (seção 21).
- FASE 5: Estradas (seção 6).
- FASE 6: Edifícios, prefabs e zonas (seções 7, 8, 11) + REGRAS DE GEOMETRIA (seção 26).
- FASE 7: Geração procedural e Assistente IA (seções 12, 13).
- FASE 8: Testar mundo e colisão (seções 19, 20), e otimização final.

---

# PARTE B — ESPECIFICAÇÃO COMPLETA

IMPLEMENTAR UM NOVO MODO "CRIADOR DE MUNDOS" NO PAINEL PRINCIPAL DO JOGO.

IMPORTANTE:
Não substituir, apagar ou modificar os mundos, mapas, sistemas de gameplay ou mecânicas existentes. O novo sistema deve ser modular e integrado ao projeto atual. O modo Criador deve funcionar como uma ferramenta separada para criação e edição de mundos.

## 1. NOVA OPÇÃO NO PAINEL PRINCIPAL

Antes de o jogador entrar em qualquer mundo, adicionar uma opção claramente visível:

"CRIADOR DE MUNDOS"

Ao entrar nessa opção, o usuário NÃO começa como personagem jogável.

Ele entra em um modo de construção/espectador, semelhante a um editor de mundo dentro do próprio jogo.

O usuário poderá:

- criar um novo mundo;
- abrir mundos criados anteriormente;
- editar mundos existentes;
- duplicar um mundo;
- renomear mundos;
- excluir seus próprios mundos (com confirmação);
- exportar/importar mundos;
- visualizar informações do mundo;
- continuar uma construção de onde parou.

Cada mundo criado deve possuir seus próprios dados e não interferir nos outros mapas.

## 2. CRIAÇÃO DE NOVO MUNDO

Ao selecionar "Novo Mundo", abrir uma interface:

NOME DO MUNDO
DESCRIÇÃO
TAMANHO DO MUNDO
ESTILO VISUAL
TIPO DE TERRENO
CLIMA
DENSIDADE DE OBJETOS
QUALIDADE GRÁFICA

TAMANHOS DISPONÍVEIS:

- 10 km × 10 km
- 20 km × 20 km
- 50 km × 50 km

O tamanho representa o espaço físico real do mundo.

O sistema deve utilizar streaming/chunking para que mundos de 20 km e 50 km não sejam carregados inteiramente na memória.

Dividir o mundo internamente em regiões/chunks.

Carregar apenas as regiões próximas da câmera/jogador.

Descarregar regiões distantes quando necessário.

ADICIONADO — FLOATING ORIGIN: em mundos grandes, a precisão float32 falha longe da origem (tremores e deformações de geometria). Usar recentralização do mundo (floating origin) ou coordenadas locais por chunk, e testar voando até as bordas de um mundo de 50 km.

## 3. MODO ESPECTADOR

Depois de criar o mundo, colocar o usuário em uma câmera livre.

A câmera deve permitir:

- mover para qualquer direção;
- subir e descer;
- acelerar/desacelerar;
- girar livremente;
- zoom;
- visão aérea;
- visão próxima ao chão;
- teletransporte para coordenadas;
- retornar para pontos salvos;
- selecionar objetos diretamente no mundo.

O usuário deve conseguir observar o mundo como se estivesse voando sobre ele.

Adicionar controles para velocidade da câmera.

Exemplo:

LENTO
NORMAL
RÁPIDO
MUITO RÁPIDO

## 4. SISTEMA DE CONSTRUÇÃO

O objetivo principal é permitir que o usuário construa uma cidade inteira.

Criar uma barra de ferramentas semelhante a um editor profissional.

Categorias:

TERRENO
ESTRADAS
EDIFÍCIOS
CASAS
PRÉDIOS
COMÉRCIO
INDÚSTRIA
PONTES
TÚNEIS
VEGETAÇÃO
ÁRVORES
ROCHAS
ÁGUA
LAGOS
RIOS
MONTANHAS
DECORAÇÃO
ILUMINAÇÃO
VEÍCULOS
OBJETOS
INFRAESTRUTURA
ELEMENTOS FUTURISTAS

## 5. FERRAMENTA DE TERRENO

Criar um editor de terreno completo.

Ferramentas:

- elevar terreno;
- abaixar terreno;
- nivelar;
- suavizar;
- criar montanhas;
- criar vales;
- criar crateras;
- criar planícies;
- criar encostas;
- criar praias;
- criar rios;
- criar lagos;
- pintar diferentes tipos de solo;
- adicionar vegetação;
- remover vegetação.

Adicionar controles de:

TAMANHO DO PINCEL
FORÇA
SUAVIDADE
ALTURA
DENSIDADE

O usuário deve conseguir criar manualmente a geografia do mundo.

ADICIONADO: a edição altera o heightmap por chunk e persiste. A vegetação é procedural (por seed) com instancing; só as exceções feitas pelo usuário (adicionar/remover) são salvas.

## 6. SISTEMA DE ESTRADAS

Criar uma ferramenta específica para construção de estradas.

O usuário poderá clicar no terreno e desenhar uma estrada usando pontos de controle.

Exemplo:

PONTO A → PONTO B → PONTO C → PONTO D

O sistema gera automaticamente a estrada seguindo esses pontos.

Permitir configurar:

- largura;
- número de faixas;
- calçada;
- meio-fio;
- canteiro;
- iluminação;
- sinalização;
- material;
- curvas;
- inclinação.

Adicionar ferramentas:

CRIAR ESTRADA
CRIAR AVENIDA
CRIAR RODOVIA
CRIAR ROTATÓRIA
CRIAR CRUZAMENTO
CRIAR PONTE
CRIAR TÚNEL

ADICIONADO: a estrada deve aplainar/ajustar o terreno por baixo dela, tratar cruzamentos sem sobreposição visual de malhas e possuir colisão.

## 7. SISTEMA DE EDIFÍCIOS

O usuário não deve ficar limitado a simplesmente colocar modelos prontos.

Criar dois modos:

MODO OBJETO
MODO CONSTRUÇÃO

No MODO OBJETO:

O usuário posiciona prédios completos.

No MODO CONSTRUÇÃO:

O usuário consegue montar estruturas utilizando módulos.

Exemplo:

FUNDAÇÃO
→ PAREDES
→ PORTAS
→ JANELAS
→ ANDARES
→ ESCADAS
→ ELEVADORES
→ TELHADO
→ FACHADA
→ ILUMINAÇÃO

Permitir alterar:

- largura;
- comprimento;
- altura;
- número de andares;
- materiais;
- cores;
- janelas;
- portas;
- fachadas;
- iluminação.

## 8. SISTEMA DE ZONAS

Adicionar sistema de planejamento urbano.

O usuário pode definir áreas:

RESIDENCIAL
COMERCIAL
INDUSTRIAL
EMPRESARIAL
PARQUES
CENTRO URBANO
PORTO
AEROPORTO
ÁREA RURAL
ÁREA TECNOLÓGICA
ÁREA FUTURISTA

As zonas devem aparecer visualmente no modo editor.

O usuário poderá criar uma cidade planejada antes de começar a colocar objetos individualmente.

## 9. SISTEMA DE DUPLICAÇÃO

Adicionar ferramentas profissionais:

- copiar;
- colar;
- duplicar;
- mover;
- rotacionar;
- redimensionar;
- alinhar;
- distribuir;
- agrupar;
- desagrupar.

Permitir selecionar vários objetos simultaneamente.

Exemplo:

Selecionar 30 prédios
→ AGRUPAR
→ DUPLICAR
→ mover para outra região.

## 10. SISTEMA DE GRADE

Adicionar grid opcional.

Modos:

GRID LIVRE
GRID 1m
GRID 5m
GRID 10m
GRID 50m

Permitir ativar/desativar:

SNAP DE TERRENO
SNAP DE OBJETO
SNAP DE ESTRADA
SNAP DE CONSTRUÇÃO

Isso deve facilitar construções precisas.

## 11. SISTEMA DE PREFABS

Criar biblioteca de elementos prontos.

Categorias:

CASAS
APARTAMENTOS
ARRANHA-CÉUS
LOJAS
POSTOS
ESCOLAS
HOSPITAIS
ESTAÇÕES
FÁBRICAS
PONTES
TORRES
PARQUES
POSTES
SEMÁFOROS
PLACAS
ÁRVORES
VEÍCULOS
MOBILIÁRIO URBANO

Cada elemento deve poder ser colocado, transformado e personalizado.

## 12. SISTEMA DE PROCEDURAL GENERATION

Adicionar uma ferramenta:

"GERAR ÁREA"

O usuário seleciona uma região do mapa e define parâmetros.

Exemplo:

"Gerar cidade residencial"

Configurações:

DENSIDADE
TAMANHO DOS LOTES
ALTURA DOS PRÉDIOS
LARGURA DAS RUAS
QUANTIDADE DE ÁRVORES
ESTILO ARQUITETÔNICO

O sistema gera automaticamente a área selecionada.

IMPORTANTE:

A geração procedural deve ser limitada à área selecionada.

Nunca substituir ou modificar regiões que o usuário não selecionou.

ADICIONADO: a geração deve ser determinística (usar seed) e reversível pelo DESFAZER.

## 13. IA COMO ASSISTENTE DE CONSTRUÇÃO

Adicionar uma ferramenta opcional:

"ASSISTENTE IA"

O usuário pode escrever:

"Crie uma cidade futurista nessa área."

ou:

"Crie um centro urbano com prédios altos, avenidas largas, parques e uma estação central."

A IA NÃO deve reconstruir o mundo inteiro.

Ela deve transformar a solicitação em uma descrição estruturada e gerar apenas os elementos necessários.

Fluxo:

PROMPT DO USUÁRIO
↓
IA PLANEJADORA
↓
ESTRUTURA DE DADOS DO MUNDO
↓
WORLD BUILDER
↓
OBJETOS / TERRENO / ESTRADAS
↓
VISUALIZAÇÃO

Antes de aplicar alterações grandes, mostrar uma prévia:

"APLICAR ALTERAÇÕES?"

SIM / CANCELAR

ADICIONADO: a IA deve devolver JSON com schema definido, validado antes de qualquer uso, e limitado à área selecionada. Definir o comportamento quando não houver acesso à IA/internet (mostrar aviso, o resto do editor continua funcionando).

## 14. HISTÓRICO

Adicionar:

DESFAZER
REFAZER

O sistema deve manter histórico das alterações.

Exemplo:

Construir prédio
→ desfazer

Construir estrada
→ desfazer

Gerar cidade
→ desfazer

Também permitir salvar versões do mundo.

Exemplo:

Cidade_v1
Cidade_v2
Cidade_v3

ADICIONADO: implementar com comandos reversíveis gravados como deltas por chunk, com limite de memória (para "gerar cidade → desfazer" não estourar a RAM do celular).

## 15. SALVAMENTO

O mundo deve ser salvo separadamente do jogo principal.

Salvar:

- terreno;
- objetos;
- posições;
- rotações;
- escalas;
- materiais;
- estradas;
- edifícios;
- vegetação;
- água;
- iluminação;
- configurações ambientais;
- regiões/chunks;
- metadados;
- versão do mundo.

Utilizar um formato estruturado e eficiente.

Não salvar milhares de objetos redundantes quando eles puderem ser representados como instâncias/prefabs.

ADICIONADO: salvar apenas as EDIÇÕES (deltas) por chunk sobre um terreno base gerado por seed, nunca o terreno inteiro. Incluir número de versão do formato com migração entre versões. Escolher o local de armazenamento adequado à plataforma encontrada na análise (ex.: IndexedDB ou arquivos).

## 16. OTIMIZAÇÃO

O sistema precisa funcionar em dispositivos móveis.

NÃO carregar um mundo de 50 km inteiro simultaneamente.

Implementar:

WORLD STREAMING
CHUNKING
LOD
FRUSTUM CULLING
OCCLUSION CULLING (somente se viável no renderer/mobile; caso contrário, usar alternativa e informar)
INSTANCED MESHES
OBJECT POOLING
TEXTURE STREAMING (adaptar ao renderer)
DISTANCE-BASED DETAIL
PROCEDURAL VEGETATION
ASSET INSTANCING

Objetos distantes devem utilizar versões simplificadas.

Objetos muito distantes podem ser representados apenas por LOD extremamente baixo ou impostors quando apropriado.

## 17. MINI-MAPA / MAPA GLOBAL

Adicionar mapa global do mundo.

O usuário poderá visualizar:

- estradas;
- cidades;
- regiões;
- rios;
- montanhas;
- construções;
- áreas selecionadas.

Permitir clicar no mapa para teletransportar a câmera.

## 18. FERRAMENTA DE SELEÇÃO

Ao clicar em um objeto:

mostrar painel:

NOME
TIPO
POSIÇÃO
ROTAÇÃO
ESCALA
MATERIAL
ID
CHUNK
PREFAB

Botões:

EDITAR
DUPLICAR
MOVER
ROTACIONAR
DELETAR
AGRUPAR

## 19. TESTAR O MUNDO

Adicionar botão:

"TESTAR MUNDO"

Ao pressionar:

- sair temporariamente do modo espectador;
- colocar o personagem jogável no mundo;
- permitir andar pelo mapa;
- testar colisões;
- testar estradas;
- testar edifícios;
- testar veículos;
- testar física.

Adicionar botão:

"VOLTAR AO EDITOR"

O usuário retorna exatamente para a posição anterior da câmera.

## 20. SISTEMA DE COLISÃO

Objetos construídos devem possuir colisões apropriadas.

Não permitir que o personagem simplesmente atravesse:

- prédios;
- paredes;
- objetos grandes;
- estradas elevadas;
- pontes;
- estruturas.

Utilizar colisões simplificadas para objetos distantes e colisões detalhadas apenas quando necessário.

ADICIONADO: física e colisão só existem perto do jogador. Chunk descarregado não tem colisão.

## 21. CLIMA E AMBIENTE

Permitir configurar:

HORA DO DIA
SOL
LUA
NUVENS
NEBLINA
CHUVA
VENTO
TEMPESTADE
TEMPERATURA VISUAL
DENSIDADE DE VEGETAÇÃO
COR DO CÉU

Permitir visualizar o mundo em diferentes condições.

## 22. BIBLIOTECA DE ASSETS

Criar uma biblioteca organizada.

Cada asset deve possuir:

thumbnail
nome
categoria
tipo
tamanho
LOD
colisor
material
polycount

O sistema deve permitir adicionar novos assets futuramente sem precisar reconstruir o editor.

## 23. IMPORTAÇÃO E EXPORTAÇÃO

O sistema deve possuir arquitetura preparada para futuramente importar mundos externos.

Criar uma camada de importação/exportação separada.

O formato interno do mundo deve ser independente do sistema visual.

Arquitetura conceitual:

WORLD DATA
↓
WORLD FORMAT
↓
WORLD LOADER
↓
WORLD BUILDER
↓
RENDERER

Isso permitirá futuramente importar mapas criados por outros softwares, engines ou ferramentas de geração procedural.

## 24. INTERFACE

A interface deve funcionar em celular.

Não criar uma interface desktop impossível de usar no touchscreen.

Utilizar:

- botões grandes;
- menus laterais;
- radial menu;
- gesto de dois dedos;
- pinch-to-zoom;
- toque para selecionar;
- arrastar para mover;
- pressionar e segurar para opções;
- controles de câmera adaptados ao mobile.

A interface deve desaparecer parcialmente durante a navegação para aumentar a área de visualização.

## 25. OBJETIVO FINAL

O resultado deve parecer um verdadeiro:

"SIMULADOR DE CONSTRUÇÃO DE MUNDOS"

e não apenas um menu para colocar objetos.

O usuário deve conseguir entrar no Criador, escolher um mundo de 10 km, 20 km ou 50 km, voar livremente sobre o terreno e construir progressivamente uma cidade completa.

Ele deve poder começar com absolutamente nada:

TERRENO VAZIO
↓
TERRAPLANAGEM
↓
ESTRADAS
↓
LOTES
↓
CASAS
↓
PRÉDIOS
↓
COMÉRCIO
↓
INFRAESTRUTURA
↓
PARQUES
↓
CENTRO URBANO
↓
CIDADE COMPLETA

O sistema deve ser expansível para que futuramente novos assets, ferramentas, tipos de construção, sistemas procedurais e ferramentas de IA possam ser adicionados sem reescrever o núcleo do editor.

## 26. REGRAS DE GEOMETRIA (NOVO — OBRIGATÓRIO)

- Todo objeto se ajusta à altura do terreno. O pivô fica na base. Nada pode flutuar nem ficar enterrado.
- Todo objeto tem bounding box e colisor coerentes com a malha.
- Proporções realistas (portas, andares, veículos, árvores). Nada de casas ou carros deformados.
- Criar uma função de validação de geometria que rode após gerar ou colocar qualquer conteúdo, e que corrija ou reporte os erros encontrados (objeto flutuando, enterrado, sobreposto, fora do chunk).

---

# ANTES DE IMPLEMENTAR (FASE 0)

1. Analisar a arquitetura atual do projeto.
2. Identificar o renderer utilizado.
3. Identificar o sistema atual de mundo/mapa.
4. Identificar o sistema de assets.
5. Identificar o sistema de personagem e colisão.
6. Identificar como os mundos atuais são armazenados.
7. Não substituir sistemas existentes sem necessidade.
8. Implementar o Criador como módulo isolado.
9. Reutilizar os sistemas existentes quando forem compatíveis.
10. Fazer a implementação incrementalmente e testar cada subsistema antes de avançar.

Entregar um plano curto de integração antes de escrever código.

Não criar apenas elementos visuais falsos. As ferramentas do editor devem realmente modificar os dados do mundo e persistir essas modificações no salvamento.
