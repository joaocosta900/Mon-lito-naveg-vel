import { AcousticZone, RegionId, SurfaceMaterialType } from '../types/world';

/**
 * Procedural Web Audio API Spatial Soundscape Engine
 * Adapts dynamically to each of the Colossal Regions, local Acoustic Zones,
 * surface materials under the player's feet, and weather conditions (wind & rain).
 */
export class SpatialAudioEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private reverbConvolver: ConvolverNode | null = null;
  private reverbWetGain: GainNode | null = null;
  private echoDelayL: DelayNode | null = null;
  private echoDelayR: DelayNode | null = null;
  private echoFeedbackGain: GainNode | null = null;
  private echoWetGain: GainNode | null = null;

  // Continuous Wind & Rain Nodes
  private windFilterHigh: BiquadFilterNode | null = null;
  private windFilterLow: BiquadFilterNode | null = null;
  private windGain: GainNode | null = null;
  private rainFilter: BiquadFilterNode | null = null;
  private rainGain: GainNode | null = null;

  // Structural / Cathedral Sub-Bass Drone
  private subDroneOsc: OscillatorNode | null = null;
  private subDroneHarmonic: OscillatorNode | null = null;
  private subDroneGain: GainNode | null = null;

  private noiseBuffer: AudioBuffer | null = null;
  private isInitialized = false;
  private isMuted = false;
  private masterVolume = 0.85;

  private currentRegion: RegionId = 'vale_pilares';
  private currentZone: AcousticZone = 'open_meadow';
  private windMultiplier = 1.0;
  private rainIntensity = 0.0;

  private nextMechanismTime = 0;
  private nextSubRumbleTime = 0;
  private nextWaterDripTime = 0;
  private nextBirdCallTime = 0;
  private stepToggle = false;

  public init(): void {
    if (this.isInitialized) {
      if (this.ctx && this.ctx.state === 'suspended') {
        this.ctx.resume().catch(() => {});
      }
      return;
    }

    const AudioCtx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;

    this.ctx = new AudioCtx();
    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.value = this.isMuted ? 0 : this.masterVolume;
    this.masterGain.connect(this.ctx.destination);

    this.noiseBuffer = this.createPinkNoiseBuffer(this.ctx, 4.5);

    // Create Cavernous / Cathedral Impulse Response (4.8s long tail)
    this.reverbConvolver = this.ctx.createConvolver();
    this.reverbConvolver.buffer = this.createCavernImpulseBuffer(this.ctx, 4.8, 2.1);
    this.reverbWetGain = this.ctx.createGain();
    this.reverbWetGain.gain.value = 0.32;
    this.reverbConvolver.connect(this.reverbWetGain);
    this.reverbWetGain.connect(this.masterGain);

    // Multi-Tap Stereo Echo Network
    this.echoDelayL = this.ctx.createDelay(3.0);
    this.echoDelayR = this.ctx.createDelay(3.0);
    this.echoDelayL.delayTime.value = 0.36;
    this.echoDelayR.delayTime.value = 0.54;

    this.echoFeedbackGain = this.ctx.createGain();
    this.echoFeedbackGain.gain.value = 0.35;

    const echoFilter = this.ctx.createBiquadFilter();
    echoFilter.type = 'bandpass';
    echoFilter.frequency.value = 620;
    echoFilter.Q.value = 0.7;

    this.echoWetGain = this.ctx.createGain();
    this.echoWetGain.gain.value = 0.22;

    this.echoDelayL.connect(this.echoDelayR);
    this.echoDelayR.connect(echoFilter);
    echoFilter.connect(this.echoFeedbackGain);
    this.echoFeedbackGain.connect(this.echoDelayL);

    this.echoDelayL.connect(this.echoWetGain);
    this.echoDelayR.connect(this.echoWetGain);
    this.echoWetGain.connect(this.masterGain);

    this.setupContinuousLayers();

    const now = this.ctx.currentTime;
    this.nextMechanismTime = now + 6.0;
    this.nextSubRumbleTime = now + 15.0;
    this.nextWaterDripTime = now + 2.0;
    this.nextBirdCallTime = now + 4.5;

    this.isInitialized = true;
  }

  private createPinkNoiseBuffer(ctx: AudioContext, durationSec: number): AudioBuffer {
    const sampleRate = ctx.sampleRate;
    const length = Math.floor(sampleRate * durationSec);
    const buffer = ctx.createBuffer(1, length, sampleRate);
    const data = buffer.getChannelData(0);
    let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
    for (let i = 0; i < length; i++) {
      const white = Math.random() * 2 - 1;
      b0 = 0.99886 * b0 + white * 0.0555179;
      b1 = 0.99332 * b1 + white * 0.0750759;
      b2 = 0.96900 * b2 + white * 0.1538520;
      b3 = 0.86650 * b3 + white * 0.3104856;
      b4 = 0.55000 * b4 + white * 0.5329522;
      b5 = -0.7616 * b5 - white * 0.0168980;
      data[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362) * 0.045;
      b6 = white * 0.115926;
    }
    return buffer;
  }

  private createCavernImpulseBuffer(
    ctx: AudioContext,
    durationSec: number,
    decayRate: number
  ): AudioBuffer {
    const sampleRate = ctx.sampleRate;
    const length = Math.floor(sampleRate * durationSec);
    const impulse = ctx.createBuffer(2, length, sampleRate);
    const left = impulse.getChannelData(0);
    const right = impulse.getChannelData(1);
    for (let i = 0; i < length; i++) {
      const t = i / sampleRate;
      const envelope = Math.pow(1 - i / length, decayRate);
      const earlyBoost =
        (t > 0.12 && t < 0.16) || (t > 0.31 && t < 0.35) || (t > 0.64 && t < 0.70) ? 1.7 : 1.0;
      left[i] = (Math.random() * 2 - 1) * envelope * earlyBoost * 0.34;
      right[i] = (Math.random() * 2 - 1) * envelope * earlyBoost * 0.34;
    }
    return impulse;
  }

  private setupContinuousLayers(): void {
    if (!this.ctx || !this.noiseBuffer || !this.masterGain) return;

    // 1. Dynamic Wind Source
    const windSource = this.ctx.createBufferSource();
    windSource.buffer = this.noiseBuffer;
    windSource.loop = true;

    this.windFilterLow = this.ctx.createBiquadFilter();
    this.windFilterLow.type = 'lowpass';
    this.windFilterLow.frequency.value = 340;
    this.windFilterLow.Q.value = 1.2;

    this.windFilterHigh = this.ctx.createBiquadFilter();
    this.windFilterHigh.type = 'bandpass';
    this.windFilterHigh.frequency.value = 520;
    this.windFilterHigh.Q.value = 2.4;

    this.windGain = this.ctx.createGain();
    this.windGain.gain.value = 0.22;

    windSource.connect(this.windFilterLow);
    windSource.connect(this.windFilterHigh);

    const highGain = this.ctx.createGain();
    highGain.gain.value = 0.28;
    this.windFilterHigh.connect(highGain);

    this.windFilterLow.connect(this.windGain);
    highGain.connect(this.windGain);
    this.windGain.connect(this.masterGain);

    if (this.reverbConvolver) {
      this.windGain.connect(this.reverbConvolver);
    }
    windSource.start(0);

    // 2. Continuous Rain Layer (modulated by weather rainIntensity)
    const rainSource = this.ctx.createBufferSource();
    rainSource.buffer = this.noiseBuffer;
    rainSource.loop = true;

    this.rainFilter = this.ctx.createBiquadFilter();
    this.rainFilter.type = 'bandpass';
    this.rainFilter.frequency.value = 1850;
    this.rainFilter.Q.value = 0.65;

    this.rainGain = this.ctx.createGain();
    this.rainGain.gain.value = 0.0;

    rainSource.connect(this.rainFilter);
    this.rainFilter.connect(this.rainGain);
    this.rainGain.connect(this.masterGain);

    if (this.reverbConvolver) {
      this.rainGain.connect(this.reverbConvolver);
    }
    rainSource.start(0.5);

    // 3. Structural / Cathedral Sub-Bass Presence
    this.subDroneOsc = this.ctx.createOscillator();
    this.subDroneOsc.type = 'sine';
    this.subDroneOsc.frequency.value = 36.5;

    this.subDroneHarmonic = this.ctx.createOscillator();
    this.subDroneHarmonic.type = 'triangle';
    this.subDroneHarmonic.frequency.value = 54.75;

    const harmGain = this.ctx.createGain();
    harmGain.gain.value = 0.25;

    this.subDroneGain = this.ctx.createGain();
    this.subDroneGain.gain.value = 0.03;

    this.subDroneOsc.connect(this.subDroneGain);
    this.subDroneHarmonic.connect(harmGain);
    harmGain.connect(this.subDroneGain);
    this.subDroneGain.connect(this.masterGain);

    this.subDroneOsc.start(0);
    this.subDroneHarmonic.start(0);
  }

  public setMuted(muted: boolean): void {
    this.isMuted = muted;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(
        muted ? 0 : this.masterVolume,
        this.ctx.currentTime,
        0.15
      );
    }
  }

  public setWeatherParams(windMultiplier: number, rainIntensity: number): void {
    this.windMultiplier = windMultiplier;
    this.rainIntensity = rainIntensity;
  }

  public update(
    timeSec: number,
    playerPos: { x: number; y: number; z: number },
    forward: { x: number; y: number; z: number },
    region: RegionId,
    zone: AcousticZone
  ): void {
    if (!this.isInitialized || !this.ctx || this.ctx.state !== 'running') return;

    const now = this.ctx.currentTime;

    // Update 3D Listener position & orientation
    const listener = this.ctx.listener;
    if (listener.positionX) {
      listener.positionX.setValueAtTime(playerPos.x, now);
      listener.positionY.setValueAtTime(playerPos.y, now);
      listener.positionZ.setValueAtTime(playerPos.z, now);
      listener.forwardX.setValueAtTime(forward.x, now);
      listener.forwardY.setValueAtTime(forward.y, now);
      listener.forwardZ.setValueAtTime(forward.z, now);
      listener.upX.setValueAtTime(0, now);
      listener.upY.setValueAtTime(1, now);
      listener.upZ.setValueAtTime(0, now);
    } else {
      listener.setPosition(playerPos.x, playerPos.y, playerPos.z);
      listener.setOrientation(forward.x, forward.y, forward.z, 0, 1, 0);
    }

    if (region !== this.currentRegion || zone !== this.currentZone) {
      this.currentRegion = region;
      this.currentZone = zone;
      this.applyRegionAndZoneAcoustics(region, zone, now);
    }

    // Modulate Wind & Rain according to Region, Zone, and Weather
    if (this.windFilterLow && this.windFilterHigh && this.windGain && this.rainGain && this.rainFilter) {
      const gust = Math.sin(timeSec * 0.29) * 0.5 + Math.sin(timeSec * 0.13) * 0.5;
      const isIndoor =
        region === 'catedral_industrial' ||
        region === 'tunel_colossal' ||
        zone === 'industrial_tunnel' ||
        zone === 'cathedral_nave';

      let baseCutoff = 310;
      let baseWhistle = 480;
      let baseWindVol = 0.20;
      let whistleQ = 2.4;

      if (region === 'ponte_nuvens') {
        baseCutoff = 520;
        baseWhistle = 760;
        baseWindVol = 0.36;
        whistleQ = 3.2;
      } else if (region === 'cidade_sem_cidade') {
        baseCutoff = 380;
        baseWhistle = 690;
        baseWindVol = 0.25;
        whistleQ = 5.5;
      } else if (region === 'oceano_concreto') {
        baseCutoff = 440;
        baseWhistle = 540;
        baseWindVol = 0.28;
        whistleQ = 1.6;
      } else if (region === 'campo_torre' || region === 'vale_pilares') {
        baseCutoff = 260;
        baseWhistle = 410;
        baseWindVol = 0.16;
      } else if (region === 'cidade_ceu') {
        baseCutoff = 460;
        baseWhistle = 680;
        baseWindVol = 0.28;
        whistleQ = 2.8;
      } else if (region === 'complexo_maquinas') {
        baseCutoff = 220;
        baseWhistle = 340;
        baseWindVol = 0.18;
        whistleQ = 3.6;
      } else if (region === 'elevador_planetario') {
        baseCutoff = 490;
        baseWhistle = 720;
        baseWindVol = 0.30;
        whistleQ = 3.0;
      } else if (region === 'megacidade_horizonte') {
        baseCutoff = 350;
        baseWhistle = 590;
        baseWindVol = 0.22;
        whistleQ = 4.2;
      } else if (region === 'colonia_dyson_anel') {
        baseCutoff = 560;
        baseWhistle = 880;
        baseWindVol = 0.19;
        whistleQ = 6.2;
      } else if (region === 'aquapolis_abissal') {
        baseCutoff = 160;
        baseWhistle = 280;
        baseWindVol = 0.12;
        whistleQ = 1.4;
      } else if (region === 'metropole_antigravidade') {
        baseCutoff = 480;
        baseWhistle = 740;
        baseWindVol = 0.26;
        whistleQ = 3.8;
      } else if (region === 'citadela_hiperboreia') {
        baseCutoff = 620;
        baseWhistle = 920;
        baseWindVol = 0.42;
        whistleQ = 4.6;
      } else if (isIndoor) {
        baseCutoff = 125;
        baseWhistle = 195;
        baseWindVol = 0.09;
      }

      const wMult = isIndoor ? Math.min(1.0, this.windMultiplier * 0.6) : this.windMultiplier;

      this.windFilterLow.frequency.setTargetAtTime(
        (baseCutoff + gust * 95) * Math.sqrt(wMult),
        now,
        0.25
      );
      this.windFilterHigh.frequency.setTargetAtTime(
        (baseWhistle + gust * 140) * Math.sqrt(wMult),
        now,
        0.25
      );
      this.windFilterHigh.Q.setTargetAtTime(whistleQ, now, 0.3);
      this.windGain.gain.setTargetAtTime(
        Math.min(0.55, (baseWindVol + gust * 0.05) * wMult),
        now,
        0.25
      );

      // Update Rain Layer
      const targetRainVol = isIndoor ? this.rainIntensity * 0.06 : this.rainIntensity * 0.26;
      const targetRainFreq = isIndoor ? 580 : 1850;
      this.rainFilter.frequency.setTargetAtTime(targetRainFreq, now, 0.4);
      this.rainGain.gain.setTargetAtTime(targetRainVol, now, 0.4);
    }

    // 1. Distant Nature / Bird Echoes
    if (
      (region === 'vale_pilares' || region === 'campo_torre') &&
      this.rainIntensity < 0.5 &&
      now >= this.nextBirdCallTime
    ) {
      this.playDistantBirdEcho(playerPos);
      this.nextBirdCallTime = now + 7.5 + Math.random() * 12.0;
    }

    // 2. Water Drips
    if (
      (region === 'tunel_colossal' ||
        region === 'catedral_industrial' ||
        zone === 'industrial_tunnel' ||
        this.rainIntensity > 0) &&
      now >= this.nextWaterDripTime
    ) {
      this.playSpatialWaterDrip(playerPos);
      const dripInterval =
        region === 'tunel_colossal' ? 0.9 + Math.random() * 2.1 : 2.8 + Math.random() * 4.5;
      this.nextWaterDripTime = now + dripInterval;
    }

    // 3. Structural Creaks, Mechanisms & Ambiences
    if (now >= this.nextMechanismTime) {
      if (region === 'ponte_nuvens') {
        this.playBridgeCableCreak(playerPos);
        this.nextMechanismTime = now + 8.0 + Math.random() * 10.0;
      } else if (region === 'catedral_industrial') {
        this.playCathedralDeepChord();
        this.nextMechanismTime = now + 13.0 + Math.random() * 14.0;
      } else if (region === 'cidade_ceu' || region === 'megacidade_horizonte') {
        this.playPassingAircraftSound(playerPos, region === 'megacidade_horizonte');
        this.nextMechanismTime = now + 9.5 + Math.random() * 11.0;
      } else if (region === 'complexo_maquinas') {
        this.playHeavyMachineCycleSound(playerPos);
        this.nextMechanismTime = now + 8.5 + Math.random() * 9.5;
      } else if (region === 'elevador_planetario') {
        this.playPlanetaryTetherResonance(playerPos);
        this.nextMechanismTime = now + 11.0 + Math.random() * 12.0;
      } else if (region === 'colonia_dyson_anel') {
        this.playDysonHarmonicPulse(playerPos);
        this.nextMechanismTime = now + 9.0 + Math.random() * 11.0;
      } else if (region === 'aquapolis_abissal') {
        this.playAquapolisSonarAndPressure(playerPos);
        this.nextMechanismTime = now + 8.0 + Math.random() * 9.0;
      } else if (region === 'metropole_antigravidade') {
        this.playAntigravityLevitationSweep(playerPos);
        this.nextMechanismTime = now + 9.5 + Math.random() * 10.5;
      } else if (region === 'citadela_hiperboreia') {
        this.playQuantumSpireSynchrotron(playerPos);
        this.nextMechanismTime = now + 10.0 + Math.random() * 11.0;
      } else if (region === 'blade_runner_2049' || zone === 'blade_runner_monolith' || zone === 'vegas_dust_basin') {
        this.playBladeRunnerSynthesizerSweep(playerPos);
        this.nextMechanismTime = now + 9.0 + Math.random() * 9.5;
      } else {
        this.playDistantMechanismSound();
        this.nextMechanismTime = now + 14.0 + Math.random() * 15.0;
      }
    }

    // 4. Tectonic Sub-Rumbles
    if (now >= this.nextSubRumbleTime) {
      this.playTectonicSubRumble(
        region === 'viaduto_infinito'
          ? 41.2
          : region === 'complexo_maquinas'
          ? 36.71
          : region === 'elevador_planetario'
          ? 29.14
          : 31.0
      );
      this.nextSubRumbleTime = now + 22.0 + Math.random() * 20.0;
    }
  }

  private applyRegionAndZoneAcoustics(
    region: RegionId,
    zone: AcousticZone,
    now: number
  ): void {
    if (
      !this.reverbWetGain ||
      !this.echoWetGain ||
      !this.echoFeedbackGain ||
      !this.subDroneGain ||
      !this.subDroneOsc ||
      !this.subDroneHarmonic
    ) {
      return;
    }

    let revWet = 0.28;
    let echoWet = 0.22;
    let echoFb = 0.35;
    let subVol = 0.03;
    let subFreq = 36.5;

    switch (region) {
      case 'vale_pilares':
        revWet = 0.36;
        echoWet = 0.28;
        echoFb = 0.42;
        subVol = 0.025;
        break;
      case 'viaduto_infinito':
        revWet = 0.48;
        echoWet = 0.38;
        echoFb = 0.48;
        subVol = 0.075;
        subFreq = 43.65;
        break;
      case 'catedral_industrial':
        revWet = 0.92;
        echoWet = 0.64;
        echoFb = 0.72;
        subVol = 0.095;
        subFreq = 32.7;
        break;
      case 'oceano_concreto':
        revWet = 0.16;
        echoWet = 0.12;
        echoFb = 0.22;
        subVol = 0.03;
        break;
      case 'cidade_sem_cidade':
        revWet = 0.54;
        echoWet = 0.48;
        echoFb = 0.58;
        subVol = 0.045;
        break;
      case 'ponte_nuvens':
        revWet = 0.32;
        echoWet = 0.26;
        echoFb = 0.38;
        subVol = 0.05;
        subFreq = 38.89;
        break;
      case 'tunel_colossal':
        revWet = 0.86;
        echoWet = 0.62;
        echoFb = 0.68;
        subVol = 0.08;
        subFreq = 34.65;
        break;
      case 'estrutura_impossivel':
        revWet = 0.52;
        echoWet = 0.42;
        echoFb = 0.52;
        subVol = 0.065;
        break;
      case 'campo_torre':
        revWet = 0.22;
        echoWet = 0.18;
        echoFb = 0.28;
        subVol = 0.025;
        break;
      case 'cidade_ceu':
        revWet = 0.38;
        echoWet = 0.34;
        echoFb = 0.46;
        subVol = 0.048;
        subFreq = 41.2;
        break;
      case 'complexo_maquinas':
        revWet = 0.66;
        echoWet = 0.52;
        echoFb = 0.62;
        subVol = 0.105;
        subFreq = 34.65;
        break;
      case 'elevador_planetario':
        revWet = 0.46;
        echoWet = 0.40;
        echoFb = 0.54;
        subVol = 0.085;
        subFreq = 30.87;
        break;
      case 'megacidade_horizonte':
        revWet = 0.56;
        echoWet = 0.46;
        echoFb = 0.56;
        subVol = 0.062;
        subFreq = 38.89;
        break;
      case 'colonia_dyson_anel':
        revWet = 0.65;
        echoWet = 0.55;
        echoFb = 0.58;
        subVol = 0.082;
        subFreq = 48.99;
        break;
      case 'aquapolis_abissal':
        revWet = 0.88;
        echoWet = 0.68;
        echoFb = 0.72;
        subVol = 0.125;
        subFreq = 27.5;
        break;
      case 'metropole_antigravidade':
        revWet = 0.44;
        echoWet = 0.38;
        echoFb = 0.48;
        subVol = 0.065;
        subFreq = 43.65;
        break;
      case 'citadela_hiperboreia':
        revWet = 0.72;
        echoWet = 0.58;
        echoFb = 0.64;
        subVol = 0.098;
        subFreq = 32.7;
        break;
    }

    if (zone === 'industrial_tunnel') {
      revWet = Math.max(revWet, 0.8);
      echoWet = Math.max(echoWet, 0.58);
      echoFb = Math.max(echoFb, 0.64);
    }

    this.reverbWetGain.gain.setTargetAtTime(revWet, now, 0.6);
    this.echoWetGain.gain.setTargetAtTime(echoWet, now, 0.6);
    this.echoFeedbackGain.gain.setTargetAtTime(echoFb, now, 0.6);
    this.subDroneGain.gain.setTargetAtTime(subVol, now, 0.8);
    this.subDroneOsc.frequency.setTargetAtTime(subFreq, now, 1.0);
    this.subDroneHarmonic.frequency.setTargetAtTime(subFreq * 1.5, now, 1.0);
  }

  public playFootstep(surface: SurfaceMaterialType, isRunning: boolean): void {
    if (!this.isInitialized || !this.ctx || !this.noiseBuffer || !this.masterGain) return;
    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }

    const now = this.ctx.currentTime;
    this.stepToggle = !this.stepToggle;
    const pitchJitter = (this.stepToggle ? 1.04 : 0.96) * (0.97 + Math.random() * 0.06);
    const intensity = isRunning ? 1.25 : 0.85;

    const thudOsc = this.ctx.createOscillator();
    const thudGain = this.ctx.createGain();
    thudOsc.type = 'sine';
    const baseFreq = surface === 'metal' ? 140 : surface === 'concrete' ? 95 : 68;
    thudOsc.frequency.setValueAtTime(baseFreq * pitchJitter, now);
    thudOsc.frequency.exponentialRampToValueAtTime(28, now + 0.09);
    thudGain.gain.setValueAtTime(0.16 * intensity, now);
    thudGain.gain.exponentialRampToValueAtTime(0.001, now + 0.11);
    thudOsc.connect(thudGain);
    thudGain.connect(this.masterGain);
    thudOsc.start(now);
    thudOsc.stop(now + 0.12);

    const noiseSrc = this.ctx.createBufferSource();
    noiseSrc.buffer = this.noiseBuffer;
    const filter = this.ctx.createBiquadFilter();
    const stepGain = this.ctx.createGain();

    const effectiveSurface =
      this.rainIntensity >= 0.7 && surface === 'concrete' ? 'water' : surface;

    if (effectiveSurface === 'grass') {
      filter.type = 'bandpass';
      filter.frequency.value = 1350 * pitchJitter;
      filter.Q.value = 1.1;
      stepGain.gain.setValueAtTime(0.01, now);
      stepGain.gain.linearRampToValueAtTime(0.15 * intensity, now + 0.02);
      stepGain.gain.exponentialRampToValueAtTime(0.001, now + 0.16);
    } else if (effectiveSurface === 'concrete') {
      filter.type = 'bandpass';
      filter.frequency.value = 920 * pitchJitter;
      filter.Q.value = 2.2;
      stepGain.gain.setValueAtTime(0.24 * intensity, now);
      stepGain.gain.exponentialRampToValueAtTime(0.001, now + 0.085);
    } else if (effectiveSurface === 'metal') {
      filter.type = 'bandpass';
      filter.frequency.value = 1680 * pitchJitter;
      filter.Q.value = 4.5;
      stepGain.gain.setValueAtTime(0.22 * intensity, now);
      stepGain.gain.exponentialRampToValueAtTime(0.001, now + 0.14);
    } else {
      filter.type = 'bandpass';
      filter.frequency.value = 2100 * pitchJitter;
      filter.Q.value = 1.6;
      stepGain.gain.setValueAtTime(0.22 * intensity, now);
      stepGain.gain.exponentialRampToValueAtTime(0.001, now + 0.19);
    }

    noiseSrc.connect(filter);
    filter.connect(stepGain);
    stepGain.connect(this.masterGain);

    if (effectiveSurface !== 'grass' || this.currentRegion !== 'campo_torre') {
      if (this.reverbConvolver) stepGain.connect(this.reverbConvolver);
      if (this.echoDelayL) stepGain.connect(this.echoDelayL);
    }

    noiseSrc.start(now, Math.random() * 2.5, 0.25);
  }

  private playDistantBirdEcho(playerPos: { x: number; y: number; z: number }): void {
    if (!this.ctx || !this.reverbConvolver || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const panner = this.ctx.createPanner();
    panner.panningModel = 'HRTF';
    panner.distanceModel = 'inverse';
    panner.refDistance = 20;
    panner.maxDistance = 500;
    panner.rolloffFactor = 0.7;
    panner.setPosition(
      playerPos.x + (Math.random() - 0.5) * 140,
      45 + Math.random() * 65,
      playerPos.z - 40 - Math.random() * 120
    );

    const notes = [2150 + Math.random() * 350, 1780 + Math.random() * 250];
    notes.forEach((freq, idx) => {
      if (!this.ctx) return;
      const start = now + idx * 0.28;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, start);
      osc.frequency.exponentialRampToValueAtTime(freq * 0.88, start + 0.22);
      gain.gain.setValueAtTime(0.0005, start);
      gain.gain.linearRampToValueAtTime(0.028, start + 0.04);
      gain.gain.exponentialRampToValueAtTime(0.0005, start + 0.24);
      osc.connect(gain);
      gain.connect(panner);
      osc.start(start);
      osc.stop(start + 0.25);
    });

    panner.connect(this.reverbConvolver);
    if (this.echoDelayL) panner.connect(this.echoDelayL);
  }

  private playSpatialWaterDrip(playerPos: { x: number; y: number; z: number }): void {
    if (!this.ctx || !this.reverbConvolver || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const panner = this.ctx.createPanner();
    panner.panningModel = 'HRTF';
    panner.distanceModel = 'inverse';
    panner.refDistance = 3;
    panner.maxDistance = 90;
    panner.rolloffFactor = 1.1;
    panner.setPosition(
      playerPos.x + (Math.random() - 0.5) * 18,
      1.5 + Math.random() * 10,
      playerPos.z + (Math.random() - 0.5) * 34
    );

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const baseFreq = 1100 + Math.random() * 980;
    osc.type = 'sine';
    osc.frequency.setValueAtTime(baseFreq, now);
    osc.frequency.exponentialRampToValueAtTime(baseFreq * 1.65, now + 0.045);
    gain.gain.setValueAtTime(0.075, now);
    gain.gain.exponentialRampToValueAtTime(0.0005, now + 0.065);
    osc.connect(gain);
    gain.connect(panner);
    panner.connect(this.masterGain);
    panner.connect(this.reverbConvolver);
    if (this.echoDelayL) panner.connect(this.echoDelayL);
    osc.start(now);
    osc.stop(now + 0.07);
  }

  private playBridgeCableCreak(playerPos: { x: number; y: number; z: number }): void {
    if (!this.ctx || !this.reverbConvolver || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const panner = this.ctx.createPanner();
    panner.panningModel = 'HRTF';
    panner.refDistance = 25;
    panner.maxDistance = 600;
    panner.setPosition(
      (Math.random() - 0.5) * 40,
      playerPos.y + 35 + Math.random() * 80,
      playerPos.z - 30 - Math.random() * 90
    );

    const dur = 3.8 + Math.random() * 2.5;
    const baseF = 110 + Math.random() * 55;
    const osc1 = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    osc1.type = 'sawtooth';
    osc2.type = 'triangle';
    osc1.frequency.setValueAtTime(baseF, now);
    osc1.frequency.linearRampToValueAtTime(baseF * 0.84, now + dur);
    osc2.frequency.setValueAtTime(baseF * 1.48, now);
    osc2.frequency.linearRampToValueAtTime(baseF * 1.56, now + dur);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.value = 340;
    filter.Q.value = 4.5;

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.11, now + dur * 0.4);
    gain.gain.exponentialRampToValueAtTime(0.001, now + dur);

    osc1.connect(filter);
    osc2.connect(filter);
    filter.connect(gain);
    gain.connect(panner);
    panner.connect(this.masterGain);
    panner.connect(this.reverbConvolver);

    osc1.start(now);
    osc2.start(now);
    osc1.stop(now + dur + 0.1);
    osc2.stop(now + dur + 0.1);
  }

  private playCathedralDeepChord(): void {
    if (!this.ctx || !this.reverbConvolver || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const dur = 8.5;
    const freqs = [32.7, 49.0, 65.41, 98.0];
    const mix = this.ctx.createGain();
    mix.gain.setValueAtTime(0.001, now);
    mix.gain.linearRampToValueAtTime(0.12, now + 2.8);
    mix.gain.exponentialRampToValueAtTime(0.0008, now + dur);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 190;

    freqs.forEach((f, i) => {
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      osc.type = i % 2 === 0 ? 'sine' : 'triangle';
      osc.frequency.setValueAtTime(f, now);
      osc.connect(filter);
      osc.start(now);
      osc.stop(now + dur + 0.1);
    });

    filter.connect(mix);
    mix.connect(this.reverbConvolver);
    mix.connect(this.masterGain);
  }

  public playDistantMechanismSound(customFreq?: number): void {
    if (!this.ctx || !this.reverbConvolver || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const panner = this.ctx.createPanner();
    panner.panningModel = 'HRTF';
    panner.distanceModel = 'inverse';
    panner.refDistance = 45;
    panner.maxDistance = 1200;
    panner.rolloffFactor = 0.45;

    const sourceX = (Math.random() - 0.5) * 180;
    const sourceY = 90 + Math.random() * 180;
    const sourceZ = -260 - Math.random() * 140;
    panner.setPosition(sourceX, sourceY, sourceZ);

    const duration = 5.5 + Math.random() * 3.5;
    const rootFreq = customFreq || 42 + Math.random() * 28;
    const ratios = [1.0, 1.414, 2.38, 3.16];

    const mixGain = this.ctx.createGain();
    mixGain.gain.setValueAtTime(0.001, now);
    mixGain.gain.linearRampToValueAtTime(0.14, now + duration * 0.35);
    mixGain.gain.exponentialRampToValueAtTime(0.0008, now + duration);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(160, now);
    filter.frequency.linearRampToValueAtTime(420, now + duration * 0.45);
    filter.frequency.exponentialRampToValueAtTime(110, now + duration);
    filter.Q.value = 3.2;

    ratios.forEach((ratio, idx) => {
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const partGain = this.ctx.createGain();
      osc.type = idx % 2 === 0 ? 'sawtooth' : 'triangle';
      const startF = rootFreq * ratio;
      osc.frequency.setValueAtTime(startF, now);
      osc.frequency.linearRampToValueAtTime(
        startF * (0.96 + idx * 0.015),
        now + duration
      );
      partGain.gain.value = 0.25 / (idx + 1);
      osc.connect(partGain);
      partGain.connect(filter);
      osc.start(now);
      osc.stop(now + duration + 0.1);
    });

    filter.connect(mixGain);
    mixGain.connect(panner);
    panner.connect(this.masterGain);
    panner.connect(this.reverbConvolver);
    if (this.echoDelayL) panner.connect(this.echoDelayL);
  }

  public playTectonicSubRumble(fundamental = 31.0): void {
    if (!this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const duration = 6.8;

    const subOsc = this.ctx.createOscillator();
    const harmonicOsc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    subOsc.type = 'sine';
    subOsc.frequency.setValueAtTime(fundamental, now);
    subOsc.frequency.linearRampToValueAtTime(fundamental * 0.88, now + duration);

    harmonicOsc.type = 'triangle';
    harmonicOsc.frequency.setValueAtTime(fundamental * 1.5, now);
    harmonicOsc.frequency.linearRampToValueAtTime(fundamental * 1.42, now + duration);

    const lowpass = this.ctx.createBiquadFilter();
    lowpass.type = 'lowpass';
    lowpass.frequency.value = 85;

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.22, now + 2.2);
    gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

    subOsc.connect(lowpass);
    harmonicOsc.connect(lowpass);
    lowpass.connect(gain);
    gain.connect(this.masterGain);
    if (this.reverbConvolver) gain.connect(this.reverbConvolver);

    subOsc.start(now);
    harmonicOsc.start(now);
    subOsc.stop(now + duration + 0.1);
    harmonicOsc.stop(now + duration + 0.1);
  }

  private playPassingAircraftSound(
    playerPos: { x: number; y: number; z: number },
    includeMaglevHarmonic: boolean
  ): void {
    if (!this.ctx || !this.reverbConvolver || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const dur = 6.5 + Math.random() * 3.0;
    const panner = this.ctx.createPanner();
    panner.panningModel = 'HRTF';
    panner.distanceModel = 'inverse';
    panner.refDistance = 35;
    panner.maxDistance = 1200;
    panner.rolloffFactor = 0.5;

    const startX = playerPos.x + (Math.random() > 0.5 ? -220 : 220);
    const endX = -startX;
    const altY = playerPos.y + 75 + Math.random() * 140;
    const posZ = playerPos.z - 60 - Math.random() * 160;

    if (panner.positionX) {
      panner.positionX.setValueAtTime(startX, now);
      panner.positionX.linearRampToValueAtTime(endX, now + dur);
      panner.positionY.setValueAtTime(altY, now);
      panner.positionZ.setValueAtTime(posZ, now);
    } else {
      panner.setPosition(0, altY, posZ);
    }

    const baseFreq = includeMaglevHarmonic ? 68 + Math.random() * 25 : 52 + Math.random() * 20;
    const osc1 = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    osc1.type = 'sawtooth';
    osc2.type = 'sine';

    osc1.frequency.setValueAtTime(baseFreq * 1.06, now);
    osc1.frequency.linearRampToValueAtTime(baseFreq * 0.91, now + dur);
    osc2.frequency.setValueAtTime(baseFreq * 2.02, now);
    osc2.frequency.linearRampToValueAtTime(baseFreq * 1.78, now + dur);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(140, now);
    filter.frequency.linearRampToValueAtTime(360, now + dur * 0.45);
    filter.frequency.exponentialRampToValueAtTime(110, now + dur);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.11, now + dur * 0.45);
    gain.gain.exponentialRampToValueAtTime(0.0008, now + dur);

    osc1.connect(filter);
    osc2.connect(filter);
    filter.connect(gain);
    gain.connect(panner);
    panner.connect(this.masterGain);
    panner.connect(this.reverbConvolver);

    osc1.start(now);
    osc2.start(now);
    osc1.stop(now + dur + 0.1);
    osc2.stop(now + dur + 0.1);
  }

  private playHeavyMachineCycleSound(playerPos: { x: number; y: number; z: number }): void {
    if (!this.ctx || !this.reverbConvolver || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const dur = 5.8;
    const panner = this.ctx.createPanner();
    panner.panningModel = 'HRTF';
    panner.refDistance = 40;
    panner.maxDistance = 1400;
    panner.rolloffFactor = 0.45;
    panner.setPosition(
      (Math.random() - 0.5) * 160,
      playerPos.y + 30 + Math.random() * 70,
      playerPos.z - 80 - Math.random() * 180
    );

    const motorOsc = this.ctx.createOscillator();
    const subOsc = this.ctx.createOscillator();
    motorOsc.type = 'sawtooth';
    subOsc.type = 'triangle';

    const f0 = 38 + Math.random() * 14;
    motorOsc.frequency.setValueAtTime(f0, now);
    motorOsc.frequency.linearRampToValueAtTime(f0 * 1.18, now + dur * 0.65);
    motorOsc.frequency.linearRampToValueAtTime(f0 * 0.92, now + dur);
    subOsc.frequency.setValueAtTime(f0 * 0.5, now);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 195;
    filter.Q.value = 2.8;

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.16, now + 1.8);
    gain.gain.exponentialRampToValueAtTime(0.001, now + dur);

    motorOsc.connect(filter);
    subOsc.connect(filter);
    filter.connect(gain);
    gain.connect(panner);
    panner.connect(this.masterGain);
    panner.connect(this.reverbConvolver);
    if (this.echoDelayL) panner.connect(this.echoDelayL);

    motorOsc.start(now);
    subOsc.start(now);
    motorOsc.stop(now + dur + 0.1);
    subOsc.stop(now + dur + 0.1);
  }

  private playPlanetaryTetherResonance(playerPos: { x: number; y: number; z: number }): void {
    if (!this.ctx || !this.reverbConvolver || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const dur = 7.5;
    const panner = this.ctx.createPanner();
    panner.panningModel = 'HRTF';
    panner.refDistance = 50;
    panner.maxDistance = 1600;
    panner.rolloffFactor = 0.4;
    panner.setPosition(0, playerPos.y + 180, -240);

    const freqs = [30.87, 46.25, 61.74, 92.5];
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(150, now);
    filter.frequency.linearRampToValueAtTime(320, now + dur * 0.5);
    filter.frequency.exponentialRampToValueAtTime(120, now + dur);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.13, now + 2.5);
    gain.gain.exponentialRampToValueAtTime(0.0008, now + dur);

    freqs.forEach((f, i) => {
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      osc.type = i % 2 === 0 ? 'sine' : 'triangle';
      osc.frequency.setValueAtTime(f, now);
      osc.frequency.linearRampToValueAtTime(f * 1.03, now + dur);
      osc.connect(filter);
      osc.start(now);
      osc.stop(now + dur + 0.1);
    });

    filter.connect(gain);
    gain.connect(panner);
    panner.connect(this.masterGain);
    panner.connect(this.reverbConvolver);
  }

  /**
   * Cosmic plasma resonance and orbital magnetosphere sweep for O Anel de Dyson
   */
  private playDysonHarmonicPulse(playerPos: { x: number; y: number; z: number }): void {
    if (!this.ctx || !this.reverbConvolver || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const dur = 8.2;
    const panner = this.ctx.createPanner();
    panner.panningModel = 'HRTF';
    panner.refDistance = 60;
    panner.maxDistance = 2400;
    panner.rolloffFactor = 0.35;
    panner.setPosition(0, playerPos.y + 350, -320);

    const osc1 = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    osc1.type = 'sine';
    osc2.type = 'triangle';
    osc1.frequency.setValueAtTime(48.99, now);
    osc1.frequency.exponentialRampToValueAtTime(73.42, now + dur * 0.5);
    osc1.frequency.exponentialRampToValueAtTime(48.99, now + dur);
    osc2.frequency.setValueAtTime(97.98, now);
    osc2.frequency.linearRampToValueAtTime(110.0, now + dur);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(280, now);
    filter.frequency.linearRampToValueAtTime(620, now + dur * 0.4);
    filter.frequency.exponentialRampToValueAtTime(220, now + dur);
    filter.Q.value = 4.2;

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.14, now + 2.0);
    gain.gain.exponentialRampToValueAtTime(0.0008, now + dur);

    osc1.connect(filter);
    osc2.connect(filter);
    filter.connect(gain);
    gain.connect(panner);
    panner.connect(this.masterGain);
    panner.connect(this.reverbConvolver);

    osc1.start(now);
    osc2.start(now);
    osc1.stop(now + dur + 0.1);
    osc2.stop(now + dur + 0.1);
  }

  /**
   * Oceanic abyss pressure rumble and high-frequency hydro-acoustic sonar ping for Aquapolis
   */
  private playAquapolisSonarAndPressure(playerPos: { x: number; y: number; z: number }): void {
    if (!this.ctx || !this.reverbConvolver || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const dur = 6.8;
    const panner = this.ctx.createPanner();
    panner.panningModel = 'HRTF';
    panner.refDistance = 45;
    panner.maxDistance = 1800;
    panner.setPosition((Math.random() - 0.5) * 140, playerPos.y + 120, -180 - Math.random() * 120);

    // 1. Deep Oceanic Hull Resonance
    const subOsc = this.ctx.createOscillator();
    subOsc.type = 'sine';
    subOsc.frequency.setValueAtTime(27.5, now);
    subOsc.frequency.linearRampToValueAtTime(32.7, now + dur * 0.5);
    subOsc.frequency.linearRampToValueAtTime(25.0, now + dur);

    const subFilter = this.ctx.createBiquadFilter();
    subFilter.type = 'lowpass';
    subFilter.frequency.value = 95;

    const subGain = this.ctx.createGain();
    subGain.gain.setValueAtTime(0.001, now);
    subGain.gain.linearRampToValueAtTime(0.18, now + 1.8);
    subGain.gain.exponentialRampToValueAtTime(0.001, now + dur);

    subOsc.connect(subFilter);
    subFilter.connect(subGain);
    subGain.connect(panner);

    // 2. High Sonar Ping
    const pingStart = now + 1.2;
    const sonarOsc = this.ctx.createOscillator();
    sonarOsc.type = 'sine';
    sonarOsc.frequency.setValueAtTime(1480, pingStart);
    sonarOsc.frequency.exponentialRampToValueAtTime(1420, pingStart + 0.35);

    const sonarGain = this.ctx.createGain();
    sonarGain.gain.setValueAtTime(0.001, pingStart);
    sonarGain.gain.linearRampToValueAtTime(0.08, pingStart + 0.02);
    sonarGain.gain.exponentialRampToValueAtTime(0.0005, pingStart + 0.85);

    sonarOsc.connect(sonarGain);
    sonarGain.connect(panner);

    panner.connect(this.masterGain);
    panner.connect(this.reverbConvolver);
    if (this.echoDelayL) panner.connect(this.echoDelayL);

    subOsc.start(now);
    subOsc.stop(now + dur + 0.1);
    sonarOsc.start(pingStart);
    sonarOsc.stop(pingStart + 0.9);
  }

  /**
   * Floating quantum repulsion field and ion draft for A Metrópole dos Monólitos Flutuantes
   */
  private playAntigravityLevitationSweep(playerPos: { x: number; y: number; z: number }): void {
    if (!this.ctx || !this.reverbConvolver || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const dur = 7.0;
    const panner = this.ctx.createPanner();
    panner.panningModel = 'HRTF';
    panner.refDistance = 50;
    panner.maxDistance = 1600;
    panner.setPosition((Math.random() - 0.5) * 120, playerPos.y + 90, -140);

    const osc1 = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    osc1.type = 'sine';
    osc2.type = 'sawtooth';

    const baseF = 43.65;
    osc1.frequency.setValueAtTime(baseF, now);
    osc1.frequency.linearRampToValueAtTime(baseF * 1.33, now + dur * 0.5);
    osc1.frequency.linearRampToValueAtTime(baseF, now + dur);

    osc2.frequency.setValueAtTime(baseF * 2.5, now);
    osc2.frequency.linearRampToValueAtTime(baseF * 2.2, now + dur);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.value = 320;
    filter.Q.value = 3.6;

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.12, now + 2.2);
    gain.gain.exponentialRampToValueAtTime(0.0008, now + dur);

    osc1.connect(filter);
    osc2.connect(filter);
    filter.connect(gain);
    gain.connect(panner);
    panner.connect(this.masterGain);
    panner.connect(this.reverbConvolver);

    osc1.start(now);
    osc2.start(now);
    osc1.stop(now + dur + 0.1);
    osc2.stop(now + dur + 0.1);
  }

  /**
   * Synchrotron particle pulse and cryogenic metal stress for Citadela Hiperbórea
   */
  private playQuantumSpireSynchrotron(playerPos: { x: number; y: number; z: number }): void {
    if (!this.ctx || !this.reverbConvolver || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const dur = 6.4;
    const panner = this.ctx.createPanner();
    panner.panningModel = 'HRTF';
    panner.refDistance = 60;
    panner.maxDistance = 2200;
    panner.setPosition(0, playerPos.y + 240, -220);

    const osc = this.ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(32.7, now);
    osc.frequency.exponentialRampToValueAtTime(196.0, now + dur * 0.6);
    osc.frequency.exponentialRampToValueAtTime(45.0, now + dur);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(140, now);
    filter.frequency.linearRampToValueAtTime(580, now + dur * 0.5);
    filter.frequency.exponentialRampToValueAtTime(110, now + dur);
    filter.Q.value = 4.8;

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.15, now + 1.5);
    gain.gain.exponentialRampToValueAtTime(0.0008, now + dur);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(panner);
    panner.connect(this.masterGain);
    panner.connect(this.reverbConvolver);
    if (this.echoDelayL) panner.connect(this.echoDelayL);

    osc.start(now);
    osc.stop(now + dur + 0.1);
  }

  /**
   * Iconic analog CS-80 synthesizer swell and distant spinner drone for Blade Runner 2049
   */
  private playBladeRunnerSynthesizerSweep(playerPos: { x: number; y: number; z: number }): void {
    if (!this.ctx || !this.reverbConvolver || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const dur = 7.2;

    const panner = this.ctx.createPanner();
    panner.panningModel = 'HRTF';
    panner.refDistance = 50;
    panner.maxDistance = 2500;
    panner.setPosition(playerPos.x + 20, playerPos.y + 80, playerPos.z - 120);

    // Three detuned oscillators for lush CS-80 brass texture
    const osc1 = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    const subOsc = this.ctx.createOscillator();

    osc1.type = 'sawtooth';
    osc2.type = 'sawtooth';
    subOsc.type = 'sine';

    const rootFreq = 55.0; // A1
    osc1.frequency.setValueAtTime(rootFreq, now);
    osc1.frequency.linearRampToValueAtTime(rootFreq * 1.5, now + dur * 0.45); // Pitch swell to fifth
    osc1.frequency.exponentialRampToValueAtTime(rootFreq, now + dur);

    osc2.frequency.setValueAtTime(rootFreq * 1.008, now); // Detune
    osc2.frequency.linearRampToValueAtTime(rootFreq * 1.512, now + dur * 0.45);
    osc2.frequency.exponentialRampToValueAtTime(rootFreq * 1.008, now + dur);

    subOsc.frequency.setValueAtTime(rootFreq * 0.5, now); // Sub-bass octave

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(110, now);
    filter.frequency.linearRampToValueAtTime(680, now + dur * 0.38); // Filter opens
    filter.frequency.exponentialRampToValueAtTime(95, now + dur); // Filter closes
    filter.Q.value = 3.6;

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.18, now + 1.8);
    gain.gain.exponentialRampToValueAtTime(0.0006, now + dur);

    osc1.connect(filter);
    osc2.connect(filter);
    subOsc.connect(filter);
    filter.connect(gain);
    gain.connect(panner);
    panner.connect(this.masterGain);
    panner.connect(this.reverbConvolver);
    if (this.echoDelayL) panner.connect(this.echoDelayL);
    if (this.echoDelayR) panner.connect(this.echoDelayR);

    osc1.start(now);
    osc2.start(now);
    subOsc.start(now);

    osc1.stop(now + dur + 0.1);
    osc2.stop(now + dur + 0.1);
    subOsc.stop(now + dur + 0.1);
  }
}
