import React from 'react';
import {
  ClipboardCopy,
  ClipboardPaste,
  Grid3x3,
  Hand,
  MousePointerClick,
  Scan as ScanIcon,
  Undo2,
  Redo2,
} from 'lucide-react';
import { CreatorAssetDescriptor, CreatorEntityDelta } from '../creator/types';
import {
  CREATOR_GRID_MODES,
  CREATOR_SNAP_KINDS,
  CreatorGridMode,
  CreatorSnapKind,
} from '../creator/runtime/CreatorGrid';
import { CreatorHistorySnapshot } from '../creator/runtime/CreatorHistory';

export type CreatorTool = 'selecionar' | 'marcar' | 'mover' | 'colocar';

export interface CreatorToolPanelProps {
  tool: CreatorTool;
  onToolChange: (tool: CreatorTool) => void;
  assets: CreatorAssetDescriptor[];
  activePrefabId: string | null;
  onPrefabChange: (prefabId: string) => void;
  gridMode: CreatorGridMode;
  onGridModeChange: (mode: CreatorGridMode) => void;
  gridVisible: boolean;
  onGridVisibleChange: (visible: boolean) => void;
  snaps: Record<CreatorSnapKind, boolean>;
  onSnapChange: (kind: CreatorSnapKind, enabled: boolean) => void;
  history: CreatorHistorySnapshot;
  onUndo: () => void;
  onRedo: () => void;
  onCopy: () => void;
  onPaste: () => void;
  canPaste: boolean;
  selectionCount: number;
  placementHint: string;
}

const PLACEABLE = new Set(['mesh', 'prefab']);

export const CreatorToolPanel: React.FC<CreatorToolPanelProps> = ({
  tool,
  onToolChange,
  assets,
  activePrefabId,
  onPrefabChange,
  gridMode,
  onGridModeChange,
  gridVisible,
  onGridVisibleChange,
  snaps,
  onSnapChange,
  history,
  onUndo,
  onRedo,
  onCopy,
  onPaste,
  canPaste,
  selectionCount,
  placementHint,
}) => {
  const placeable = assets.filter((asset) => PLACEABLE.has(asset.type));

  return (
    <section className="max-h-[52vh] overflow-y-auto rounded-t-2xl border-t border-white/15 bg-[#0b1117]/96 p-2.5 shadow-[0_-10px_30px_rgba(0,0,0,0.55)] backdrop-blur-md">
      <div className="flex items-center gap-1.5">
        <ToolButton
          label="SELECIONAR"
          icon={<MousePointerClick className="w-4 h-4" />}
          active={tool === 'selecionar'}
          onClick={() => onToolChange('selecionar')}
        />
        <ToolButton
          label="MARCAR"
          icon={<ScanIcon className="w-4 h-4" />}
          active={tool === 'marcar'}
          onClick={() => onToolChange('marcar')}
        />
        <ToolButton
          label="MOVER"
          icon={<Hand className="w-4 h-4" />}
          active={tool === 'mover'}
          disabled={selectionCount === 0}
          onClick={() => onToolChange('mover')}
        />
        <ToolButton
          label="COLOCAR"
          icon={<Grid3x3 className="w-4 h-4" />}
          active={tool === 'colocar'}
          onClick={() => onToolChange('colocar')}
        />
        <div className="ml-auto flex items-center gap-1.5">
          <button
            type="button"
            onClick={onUndo}
            disabled={!history.canUndo}
            className="min-h-[40px] rounded-xl border border-white/15 bg-white/5 px-2.5 text-[9px] font-semibold text-white/75 flex items-center gap-1 cursor-pointer disabled:opacity-35"
            title={history.undoLabel}
          >
            <Undo2 className="w-3.5 h-3.5" />
            DESFAZER
          </button>
          <button
            type="button"
            onClick={onCopy}
            disabled={selectionCount === 0}
            className="min-h-[40px] rounded-xl border border-white/15 bg-white/5 px-2.5 text-[9px] font-semibold text-white/75 flex items-center gap-1 cursor-pointer disabled:opacity-35"
          >
            <ClipboardCopy className="w-3.5 h-3.5" />
            COPIAR
          </button>
          <button
            type="button"
            onClick={onPaste}
            disabled={!canPaste}
            className="min-h-[40px] rounded-xl border border-white/15 bg-white/5 px-2.5 text-[9px] font-semibold text-white/75 flex items-center gap-1 cursor-pointer disabled:opacity-35"
          >
            <ClipboardPaste className="w-3.5 h-3.5" />
            COLAR
          </button>
          <button
            type="button"
            onClick={onRedo}
            disabled={!history.canRedo}
            className="min-h-[40px] rounded-xl border border-white/15 bg-white/5 px-2.5 text-[9px] font-semibold text-white/75 flex items-center gap-1 cursor-pointer disabled:opacity-35"
            title={history.redoLabel}
          >
            <Redo2 className="w-3.5 h-3.5" />
            REFAZER
          </button>
        </div>
      </div>

      <div className="mt-2 border-t border-white/10 pt-2">
        <div className="mb-1 text-[9px] uppercase tracking-wider text-white/45">
          Colocar ({placeable.length} assets)
        </div>
        <div className="flex gap-1.5 overflow-x-auto pb-1">
          {placeable.map((asset) => (
            <button
              key={asset.id}
              type="button"
              onClick={() => onPrefabChange(asset.id)}
              className={`min-h-[52px] w-[72px] shrink-0 rounded-xl border text-[9px] font-semibold flex flex-col items-center justify-center gap-1 cursor-pointer ${
                activePrefabId === asset.id
                  ? 'border-emerald-300/70 bg-emerald-300/15 text-emerald-100'
                  : 'border-white/15 bg-white/5 text-white/70'
              }`}
            >
              <img
                src={asset.thumbnail}
                alt=""
                className="h-6 w-9 rounded object-cover"
              />
              {asset.name.split(' ')[0].toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-2 border-t border-white/10 pt-2">
        <div className="flex items-center gap-1.5">
          <span className="text-[9px] uppercase tracking-wider text-white/45">GRADE</span>
          {CREATOR_GRID_MODES.map((option) => (
            <button
              key={String(option.mode)}
              type="button"
              onClick={() => onGridModeChange(option.mode)}
              className={`min-h-[32px] rounded-lg px-2 text-[9px] font-semibold cursor-pointer ${
                gridMode === option.mode
                  ? 'bg-emerald-300 text-[#07110d]'
                  : 'bg-white/8 text-white/65'
              }`}
            >
              {option.label}
            </button>
          ))}
          <label className="ml-auto flex items-center gap-1 text-[9px] text-white/60">
            <input
              type="checkbox"
              checked={gridVisible}
              onChange={(event) => onGridVisibleChange(event.target.checked)}
            />
            VER
          </label>
        </div>
        <div className="mt-1.5 flex flex-wrap gap-1.5">
          {CREATOR_SNAP_KINDS.map((option) => (
            <button
              key={option.kind}
              type="button"
              onClick={() => onSnapChange(option.kind, !snaps[option.kind])}
              className={`min-h-[30px] rounded-lg border px-2 text-[9px] font-semibold cursor-pointer ${
                snaps[option.kind]
                  ? 'border-emerald-300/60 bg-emerald-300/12 text-emerald-100'
                  : 'border-white/12 bg-white/4 text-white/55'
              }`}
            >
              {option.label}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-2 flex items-center justify-between text-[9px] text-white/45">
        <span className="truncate">{placementHint}</span>
        <span className="shrink-0">
          {history.entries} passos · {(history.estimatedBytes / 1024).toFixed(0)} KB
        </span>
      </div>
    </section>
  );
};

const ToolButton: React.FC<{
  label: string;
  icon: React.ReactNode;
  active: boolean;
  disabled?: boolean;
  onClick: () => void;
}> = ({ label, icon, active, disabled, onClick }) => (
  <button
    type="button"
    onClick={onClick}
    disabled={disabled}
    className={`min-h-[40px] rounded-xl border px-2.5 text-[9px] font-semibold flex items-center gap-1 cursor-pointer disabled:opacity-35 ${
      active
        ? 'border-emerald-300/70 bg-emerald-300/15 text-emerald-100'
        : 'border-white/15 bg-white/5 text-white/70'
    }`}
  >
    {icon}
    {label}
  </button>
);
