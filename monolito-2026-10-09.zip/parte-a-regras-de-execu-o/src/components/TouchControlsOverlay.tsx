import React, { useRef, useState } from 'react';
import { ArchitecturalPortal, ResonancePoint } from '../types/world';

interface TouchControlsOverlayProps {
  visible: boolean;
  uiActive: boolean;
  isRunning: boolean;
  onToggleRun: () => void;
  nearbyResonance: ResonancePoint | null;
  nearbyPortal: ArchitecturalPortal | null;
  lookingAtMegastructure: boolean;
  onTriggerContextualAction: () => void;
  onJump: () => void;
  joystickVector: React.MutableRefObject<{ x: number; y: number }>;
  touchLookDelta: React.MutableRefObject<{ x: number; y: number }>;
  onUserActivity: () => void;
  /** Em modo espectador os botões viram controles de voo da câmera livre. */
  spectatorActive?: boolean;
  spectatorFlyRef?: React.MutableRefObject<{ vertical: number; speed: number }>;
}

export const TouchControlsOverlay: React.FC<TouchControlsOverlayProps> = ({
  visible,
  uiActive,
  isRunning,
  onToggleRun,
  nearbyResonance,
  nearbyPortal,
  lookingAtMegastructure,
  onTriggerContextualAction,
  onJump,
  joystickVector,
  touchLookDelta,
  onUserActivity,
  spectatorActive = false,
  spectatorFlyRef,
}) => {
  const [knobOffset, setKnobOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [flySpeed, setFlySpeed] = useState(1);
  // Fallback local: o App sempre passa o ref, mas o overlay não deve quebrar sem ele.
  const localFlyRef = useRef({ vertical: 0, speed: 1 });
  const flyRef = spectatorFlyRef ?? localFlyRef;
  flyRef.current.speed = flySpeed;

  // Segurar o botão move a câmera; soltar (ou o dedo sair) devolve a neutralidade.
  const holdVertical = (value: number) => ({
    onPointerDown: (e: React.PointerEvent<HTMLButtonElement>) => {
      e.preventDefault();
      e.currentTarget.setPointerCapture?.(e.pointerId);
      flyRef.current.vertical = value;
    },
    onPointerUp: () => { flyRef.current.vertical = 0; },
    onPointerLeave: () => { flyRef.current.vertical = 0; },
    onPointerCancel: () => { flyRef.current.vertical = 0; },
  });
  const [joystickActive, setJoystickActive] = useState(false);
  const joystickTouchIdRef = useRef<number | null>(null);
  const joystickOriginRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  const lookTouchIdRef = useRef<number | null>(null);
  const lookPrevPosRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  const maxRadius = 46;

  const handleLeftTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    onUserActivity();
    if (joystickTouchIdRef.current !== null) return;
    const touch = e.changedTouches[0];
    if (!touch) return;
    joystickTouchIdRef.current = touch.identifier;
    const rect = e.currentTarget.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    joystickOriginRef.current = { x: centerX, y: centerY };
    setJoystickActive(true);
    updateJoystickFromPoint(touch.clientX, touch.clientY);
  };

  const handleLeftTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (joystickTouchIdRef.current === null) return;
    for (let i = 0; i < e.changedTouches.length; i++) {
      const t = e.changedTouches[i];
      if (t.identifier === joystickTouchIdRef.current) {
        updateJoystickFromPoint(t.clientX, t.clientY);
        onUserActivity();
        break;
      }
    }
  };

  const handleLeftTouchEnd = (e: React.TouchEvent<HTMLDivElement>) => {
    if (joystickTouchIdRef.current === null) return;
    for (let i = 0; i < e.changedTouches.length; i++) {
      const t = e.changedTouches[i];
      if (t.identifier === joystickTouchIdRef.current) {
        joystickTouchIdRef.current = null;
        joystickVector.current = { x: 0, y: 0 };
        setKnobOffset({ x: 0, y: 0 });
        setJoystickActive(false);
        break;
      }
    }
  };

  const updateJoystickFromPoint = (clientX: number, clientY: number) => {
    let dx = clientX - joystickOriginRef.current.x;
    let dy = clientY - joystickOriginRef.current.y;
    const dist = Math.hypot(dx, dy);
    if (dist > maxRadius) {
      dx = (dx / dist) * maxRadius;
      dy = (dy / dist) * maxRadius;
    }
    setKnobOffset({ x: dx, y: dy });
    joystickVector.current = {
      x: dx / maxRadius,
      y: dy / maxRadius,
    };
  };

  const handleRightTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    onUserActivity();
    if (lookTouchIdRef.current !== null) return;
    const touch = e.changedTouches[0];
    if (!touch) return;
    lookTouchIdRef.current = touch.identifier;
    lookPrevPosRef.current = { x: touch.clientX, y: touch.clientY };
  };

  const handleRightTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (lookTouchIdRef.current === null) return;
    for (let i = 0; i < e.changedTouches.length; i++) {
      const t = e.changedTouches[i];
      if (t.identifier === lookTouchIdRef.current) {
        const dx = t.clientX - lookPrevPosRef.current.x;
        const dy = t.clientY - lookPrevPosRef.current.y;
        lookPrevPosRef.current = { x: t.clientX, y: t.clientY };
        touchLookDelta.current.x += dx;
        touchLookDelta.current.y += dy;
        onUserActivity();
        break;
      }
    }
  };

  const handleRightTouchEnd = (e: React.TouchEvent<HTMLDivElement>) => {
    if (lookTouchIdRef.current === null) return;
    for (let i = 0; i < e.changedTouches.length; i++) {
      const t = e.changedTouches[i];
      if (t.identifier === lookTouchIdRef.current) {
        lookTouchIdRef.current = null;
        break;
      }
    }
  };

  if (!visible) return null;

  const showContextualInteract = Boolean(
    nearbyPortal || nearbyResonance || lookingAtMegastructure
  );

  const controlOpacityClass =
    spectatorActive || joystickActive || uiActive || nearbyPortal
      ? 'opacity-80'
      : 'opacity-20 hover:opacity-70';

  return (
    <div className="fixed inset-0 z-10 pointer-events-none select-none overflow-hidden">
      {/* Right Half of Screen: Invisible Touch-Look Surface */}
      <div
        className="absolute top-14 right-0 bottom-0 w-3/5 pointer-events-auto touch-none"
        onTouchStart={handleRightTouchStart}
        onTouchMove={handleRightTouchMove}
        onTouchEnd={handleRightTouchEnd}
        onTouchCancel={handleRightTouchEnd}
        aria-label="Área de toque para olhar ao redor"
      />

      {/* Bottom-Left: Virtual Joystick for Movement */}
      <div
        data-spectator-ui
        className={`absolute bottom-7 left-7 w-32 h-32 rounded-full border border-white/20 bg-black/25 backdrop-blur-xs flex items-center justify-center pointer-events-auto touch-none transition-opacity duration-500 ${controlOpacityClass}`}
        onTouchStart={handleLeftTouchStart}
        onTouchMove={handleLeftTouchMove}
        onTouchEnd={handleLeftTouchEnd}
        onTouchCancel={handleLeftTouchEnd}
        aria-label="Joystick virtual para caminhar"
      >
        <div className="w-1.5 h-1.5 rounded-full bg-white/25" />
        <div
          className="absolute w-11 h-11 rounded-full border border-white/40 bg-white/15 backdrop-blur-sm transition-transform duration-75"
          style={{
            transform: `translate3d(${knobOffset.x}px, ${knobOffset.y}px, 0)`,
          }}
        />
      </div>

      {/* Bottom-Right Ergonomic Thumb Zone: Optional Run Toggle & Contextual Interaction */}
      <div
        data-spectator-ui
        className={`absolute bottom-8 right-7 flex flex-col items-end gap-3 pointer-events-auto transition-opacity duration-500 ${controlOpacityClass}`}
      >
        {spectatorActive ? (
          <>
            <div className="flex flex-col gap-2">
              <button
                type="button"
                {...holdVertical(1)}
                className="min-h-[48px] min-w-[48px] rounded-xl bg-black/55 border border-white/20 text-white/85 text-sm backdrop-blur-sm active:scale-95 touch-none select-none cursor-pointer"
                aria-label="Subir a câmera"
              >
                ▲
              </button>
              <button
                type="button"
                {...holdVertical(-1)}
                className="min-h-[48px] min-w-[48px] rounded-xl bg-black/55 border border-white/20 text-white/85 text-sm backdrop-blur-sm active:scale-95 touch-none select-none cursor-pointer"
                aria-label="Descer a câmera"
              >
                ▼
              </button>
            </div>
            <button
              type="button"
              onClick={() => {
                setFlySpeed((prev) => (prev >= 8 ? 1 : prev * 4));
                onUserActivity();
              }}
              className={`min-h-[44px] px-4 py-2 rounded-xl border text-xs font-medium tracking-wide transition-all duration-150 active:scale-95 whitespace-nowrap backdrop-blur-sm cursor-pointer ${
                flySpeed > 1
                  ? 'bg-emerald-500/25 border-emerald-400/60 text-emerald-100'
                  : 'bg-black/30 border-white/15 text-white/70'
              }`}
              aria-label="Velocidade da câmera"
            >
              {flySpeed > 1 ? `Turbo ${flySpeed}x` : 'Turbo'}
            </button>
          </>
        ) : (
          <>
        {showContextualInteract && (
          <button
            type="button"
            onClick={onTriggerContextualAction}
            className="min-h-[44px] px-4 py-2.5 rounded-xl bg-black/60 backdrop-blur-md border border-[#b06c49]/65 text-[#e6dfd8] text-xs font-medium tracking-wide transition-all duration-150 active:scale-95 whitespace-nowrap shadow-lg cursor-pointer"
          >
            {nearbyPortal
              ? `Atravessar — ${nearbyPortal.label}`
              : nearbyResonance
              ? 'Escutar Ressonância'
              : 'Contemplar Escala'}
          </button>
        )}
        <button
          type="button"
          onClick={() => {
            onJump();
            onUserActivity();
          }}
          className="min-h-[44px] min-w-[44px] px-4 py-2 rounded-xl bg-black/45 border border-white/20 text-white/85 text-xs font-medium tracking-wide transition-all duration-150 active:scale-95 backdrop-blur-sm cursor-pointer"
          aria-label="Pular"
        >
          Pular
        </button>
        <button
          type="button"
          onClick={() => {
            onToggleRun();
            onUserActivity();
          }}
          className={`min-h-[44px] min-w-[44px] px-4 py-2 rounded-xl border text-xs font-medium tracking-wide transition-all duration-150 active:scale-95 whitespace-nowrap backdrop-blur-sm cursor-pointer ${
            isRunning
              ? 'bg-white/20 border-white/50 text-white'
              : 'bg-black/30 border-white/15 text-white/70 hover:text-white'
          }`}
          aria-pressed={isRunning}
        >
          {isRunning ? 'Passo Rápido' : 'Passo Lento'}
        </button>
          </>
        )}
      </div>
    </div>
  );
};
