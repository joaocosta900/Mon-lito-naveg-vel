import React, { useState } from 'react';
import { Move, RotateCcw, Scaling, Rotate3d, X } from 'lucide-react';
import { SpectatorState } from '../world/useSpectatorMode';

interface SpectatorPanelProps {
  state: SpectatorState;
  onExit: () => void;
  onNudge: (axis: 'x' | 'y' | 'z', delta: number) => void;
  onRotate: (axis: 'x' | 'y' | 'z', delta: number) => void;
  onScale: (axis: 'x' | 'y' | 'z', factor: number) => void;
  onReset: () => void;
  onDeselect: () => void;
}

type Axis = 'x' | 'y' | 'z';
type Precision = 'fino' | 'medio' | 'grosso';

/**
 * Um único controle de precisão calibra as três famílias de edição: com "fino"
 * dá para ajustar metro por metro e 5% por vez; com "grosso" dá para reposicionar
 * uma torre de longe. Sem isso, o passo fixo de 4 m tornava qualquer ajuste fino
 * inviável no celular.
 */
const STEPS: Record<Precision, { move: number; rotate: number; scale: number }> = {
  fino: { move: 1, rotate: (5 * Math.PI) / 180, scale: 1.05 },
  medio: { move: 4, rotate: (15 * Math.PI) / 180, scale: 1.15 },
  grosso: { move: 16, rotate: (45 * Math.PI) / 180, scale: 1.4 },
};

const PRECISION_LABEL: Record<Precision, string> = {
  fino: 'Fino',
  medio: 'Médio',
  grosso: 'Grosso',
};

const AXIS_LABEL: Record<Axis, string> = { x: 'Largura', y: 'Altura', z: 'Profund.' };

/** "40×90×30 m", arredondado: diz o tamanho real do que foi escolhido. */
const dims = (size: { x: number; y: number; z: number }) =>
  [size.x, size.y, size.z].map((n) => Math.round(n)).join('×') + ' m';

const btn =
  'min-h-[32px] rounded-lg border border-white/12 bg-white/5 text-[11px] font-semibold text-white/85 disabled:opacity-30 active:scale-95 transition-transform cursor-pointer select-none touch-none';
const section =
  'rounded-xl border border-white/10 bg-white/[0.03] p-2';

/** Uma linha "rótulo | − | +" usada por mover, girar e escalar. */
const AxisRow: React.FC<{
  group: string;
  label: string;
  disabled: boolean;
  onMinus: () => void;
  onPlus: () => void;
  readout?: string;
}> = ({ group, label, disabled, onMinus, onPlus, readout }) => (
  <div className="flex items-center gap-1">
    <span className="w-[52px] shrink-0 truncate text-[9px] font-semibold uppercase tracking-wider text-white/45">
      {label}
    </span>
    <button
      type="button"
      disabled={disabled}
      onClick={onMinus}
      aria-label={`Diminuir ${label} (${group})`}
      className={`${btn} flex-1`}
    >
      −
    </button>
    {readout !== undefined && (
      <span className="w-[38px] shrink-0 text-center font-mono-tabular text-[9px] text-white/60">
        {readout}
      </span>
    )}
    <button
      type="button"
      disabled={disabled}
      onClick={onPlus}
      aria-label={`Aumentar ${label} (${group})`}
      className={`${btn} flex-1`}
    >
      +
    </button>
  </div>
);

/**
 * Painel do modo espectador: reposicionar, girar e reescalar a construção escolhida.
 * Fica no rodapé para não cobrir o topo, que é onde a câmera livre olha.
 */
export const SpectatorPanel: React.FC<SpectatorPanelProps> = ({
  state,
  onExit,
  onNudge,
  onRotate,
  onScale,
  onReset,
  onDeselect,
}) => {
  const [precision, setPrecision] = useState<Precision>('medio');
  if (!state.active) return null;

  const hasSelection = state.selectedId !== null;
  const t = state.transform;
  const step = STEPS[precision];
  const off = (v: number) => (Math.abs(v) < 0.05 ? '0' : v.toFixed(0));
  const pct = (v: number) => `${Math.round(v * 100)}%`;
  const deg = (r: number) => `${Math.round((r * 180) / Math.PI)}°`;

  return (
    <div className="fixed inset-x-0 bottom-0 z-30 flex flex-col items-center gap-2 px-2.5 pb-2.5 pointer-events-none">
      <div
        data-spectator-ui
        className="pointer-events-auto w-full max-w-lg rounded-2xl border border-emerald-500/30 bg-[#0b1117]/95 px-2.5 py-2 shadow-[0_-8px_28px_rgba(0,0,0,0.55)] backdrop-blur-md"
      >
        {/* Cabeçalho */}
        <div className="mb-1.5 flex items-center justify-between gap-2">
          <div className="min-w-0 flex items-center gap-2">
            <div className="shrink-0 text-[9px] font-semibold uppercase tracking-wider text-emerald-300">
              Espectador
            </div>
            <div className="truncate text-[9px] text-white/60">
              {hasSelection ? (
                <>
                  Construção {state.selectedId?.replace('spectator_cluster_', '#')}
                  {state.selectedSize && (
                    <span className="text-white/40">
                      {' '}
                      · {state.selectedPieces} pec
                      {state.selectedPieces === 1 ? 'a' : 'as'} ·{' '}
                      {dims(state.selectedSize)}
                    </span>
                  )}
                </>
              ) : (
                `${state.clusterCount} construções · toque para editar`
              )}
            </div>
          </div>
          <button
            type="button"
            onClick={onExit}
            className="min-h-[30px] shrink-0 rounded-xl border border-white/15 bg-white/5 px-2 text-[10px] font-semibold text-white/80 active:scale-95 transition-transform cursor-pointer"
            aria-label="Sair do modo espectador"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Precisão: calibra mover, girar e escalar de uma vez */}
        <div className="mb-1.5 flex items-center gap-1">
          <span className="text-[9px] font-semibold uppercase tracking-wider text-white/40">
            Precisão
          </span>
          <div className="flex flex-1 gap-1">
            {(Object.keys(STEPS) as Precision[]).map((option) => (
              <button
                key={option}
                type="button"
                onClick={() => setPrecision(option)}
                className={`min-h-[28px] flex-1 rounded-lg border text-[9px] font-semibold transition-colors cursor-pointer ${
                  precision === option
                    ? 'border-emerald-400/70 bg-emerald-500/25 text-emerald-100'
                    : 'border-white/12 bg-white/5 text-white/55'
                }`}
              >
                {PRECISION_LABEL[option]}
              </button>
            ))}
          </div>
          <span className="shrink-0 font-mono-tabular text-[9px] text-white/40">
            {step.move}m
          </span>
        </div>

        {/* Mover e Girar */}
        <div className="grid grid-cols-2 gap-1.5">
          <div className={section}>
            <div className="mb-1 flex items-center gap-1 text-[9px] font-semibold uppercase tracking-wider text-white/50">
              <Move className="w-3 h-3" />
              Mover
            </div>
            <div className="space-y-1">
              {(['x', 'y', 'z'] as Axis[]).map((axis) => (
                <AxisRow
                  key={axis}
                  group="Mover"
                  label={AXIS_LABEL[axis]}
                  disabled={!hasSelection}
                  readout={off(
                    axis === 'x' ? t.offsetX : axis === 'y' ? t.offsetY : t.offsetZ
                  )}
                  onMinus={() => onNudge(axis, -step.move)}
                  onPlus={() => onNudge(axis, step.move)}
                />
              ))}
            </div>
          </div>

          <div className={section}>
            <div className="mb-1 flex items-center gap-1 text-[9px] font-semibold uppercase tracking-wider text-white/50">
              <Rotate3d className="w-3 h-3" />
              Girar
            </div>
            <div className="space-y-1">
              {(['y', 'x', 'z'] as Axis[]).map((axis) => (
                <AxisRow
                  key={axis}
                  group="Girar"
                  label={AXIS_LABEL[axis]}
                  disabled={!hasSelection}
                  readout={deg(axis === 'x' ? t.rotX : axis === 'y' ? t.rotY : t.rotZ)}
                  onMinus={() => onRotate(axis, -step.rotate)}
                  onPlus={() => onRotate(axis, step.rotate)}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Tamanho */}
        <div className={`mt-1.5 ${section}`}>
          <div className="mb-1 flex items-center gap-1 text-[9px] font-semibold uppercase tracking-wider text-white/50">
            <Scaling className="w-3 h-3" />
            Tamanho
          </div>
          <div className="grid grid-cols-3 gap-1.5">
            {(['x', 'y', 'z'] as Axis[]).map((axis) => (
              <AxisRow
                key={axis}
                group="Tamanho"
                label={AXIS_LABEL[axis]}
                disabled={!hasSelection}
                readout={pct(axis === 'x' ? t.scaleX : axis === 'y' ? t.scaleY : t.scaleZ)}
                onMinus={() => onScale(axis, 1 / step.scale)}
                onPlus={() => onScale(axis, step.scale)}
              />
            ))}
          </div>
        </div>

        {/* Rodapé */}
        <div className="mt-1.5 flex items-center justify-between gap-2 border-t border-white/10 pt-1.5">
          <div className="font-mono-tabular text-[9px] text-white/45">
            {hasSelection
              ? `${pct(t.scaleX)} · ${pct(t.scaleY)} · ${pct(t.scaleZ)}`
              : 'Câmera livre ativa'}
          </div>
          <div className="flex gap-1.5">
            <button
              type="button"
              disabled={!hasSelection}
              onClick={onDeselect}
              className="min-h-[30px] rounded-lg border border-white/12 bg-white/5 px-2 text-[9px] font-semibold text-white/70 disabled:opacity-30 active:scale-95 transition-transform cursor-pointer"
            >
              Desselecionar
            </button>
            <button
              type="button"
              disabled={!hasSelection}
              onClick={onReset}
              className="min-h-[30px] flex items-center gap-1 rounded-lg border border-emerald-500/40 bg-emerald-500/15 px-2 text-[9px] font-semibold text-emerald-100 disabled:opacity-30 active:scale-95 transition-transform cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" />
              Restaurar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
