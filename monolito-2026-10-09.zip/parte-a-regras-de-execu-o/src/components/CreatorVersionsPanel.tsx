import React, { useCallback, useEffect, useState } from 'react';
import { History, RotateCcw, Save, Trash2, X } from 'lucide-react';
import { creatorStorage } from '../creator/CreatorStorage';
import { CreatorWorld, CreatorWorldVersion } from '../creator/types';

interface CreatorVersionsPanelProps {
  world: CreatorWorld;
  onClose: () => void;
  onRestore: (world: CreatorWorld) => void;
}

function formatTimestamp(timestamp: number): string {
  return new Date(timestamp).toLocaleString('pt-BR');
}

export const CreatorVersionsPanel: React.FC<CreatorVersionsPanelProps> = ({
  world,
  onClose,
  onRestore,
}) => {
  const [versions, setVersions] = useState<CreatorWorldVersion[]>([]);
  const [label, setLabel] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    try {
      setVersions(await creatorStorage.listVersions(world.id));
      setError(null);
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : String(loadError));
    }
  }, [world.id]);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const handleSave = async () => {
    setBusy(true);
    try {
      const created = await creatorStorage.saveVersion(world, label);
      setLabel('');
      await refresh();
      setError(null);
      void created;
    } catch (saveError) {
      setError(saveError instanceof Error ? saveError.message : String(saveError));
    } finally {
      setBusy(false);
    }
  };

  const handleRestore = async (versionId: string) => {
    setBusy(true);
    try {
      const restored = await creatorStorage.restoreVersion(versionId);
      if (restored) {
        onRestore(restored);
      }
    } catch (restoreError) {
      setError(restoreError instanceof Error ? restoreError.message : String(restoreError));
    } finally {
      setBusy(false);
    }
  };

  const handleDelete = async (versionId: string) => {
    setBusy(true);
    try {
      await creatorStorage.deleteVersion(versionId);
      await refresh();
    } catch (deleteError) {
      setError(deleteError instanceof Error ? deleteError.message : String(deleteError));
    } finally {
      setBusy(false);
    }
  };

  return (
    <aside className="absolute left-2 top-16 z-30 w-[min(92vw,320px)] max-h-[70vh] overflow-y-auto rounded-2xl border border-white/15 bg-[#0b1117]/96 p-3 shadow-2xl backdrop-blur-md sm:left-4 sm:top-20">
      <div className="flex items-center justify-between gap-2 pb-2 border-b border-white/10">
        <div className="flex items-center gap-1.5">
          <History className="w-4 h-4 text-emerald-300" />
          <div>
            <div className="text-[10px] uppercase tracking-[0.2em] text-emerald-300">
              Versões
            </div>
            <div className="text-xs text-white/75">{world.name}</div>
          </div>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="min-h-[36px] min-w-[36px] rounded-lg border border-white/15 text-white/70 flex items-center justify-center cursor-pointer"
          aria-label="Fechar versões"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="mt-3 flex gap-1.5">
        <input
          value={label}
          onChange={(event) => setLabel(event.target.value)}
          placeholder={`Cidade_v${versions.length + 1}`}
          className="h-10 min-w-0 flex-1 rounded-lg border border-white/15 bg-black/35 px-2 text-xs text-white outline-none"
        />
        <button
          type="button"
          onClick={handleSave}
          disabled={busy}
          className="min-h-[40px] rounded-xl bg-emerald-300 px-3 text-[10px] font-bold text-[#07110d] flex items-center gap-1 cursor-pointer disabled:opacity-50"
        >
          <Save className="w-3.5 h-3.5" />
          SALVAR
        </button>
      </div>
      <div className="mt-1 text-[9px] text-white/40">
        Rev {world.metadata.revision} · salvar cria um ponto de retorno real no IndexedDB.
      </div>

      {error && (
        <div className="mt-2 rounded-lg border border-rose-400/35 bg-rose-500/10 px-2 py-1.5 text-[9px] text-rose-100">
          {error}
        </div>
      )}

      <div className="mt-3 space-y-1">
        {versions.length === 0 ? (
          <div className="text-[10px] text-white/40">
            Nenhuma versão salva ainda.
          </div>
        ) : (
          versions.map((version) => (
            <div
              key={version.id}
              className="flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/4 p-2"
            >
              <div className="min-w-0 flex-1">
                <div className="truncate text-[10px] font-semibold text-white/85">
                  {version.label}
                </div>
                <div className="text-[9px] text-white/40">
                  rev {version.revision} · {formatTimestamp(version.createdAt)} ·{' '}
                  {countEntities(version.snapshot)} objeto(s)
                </div>
              </div>
              <button
                type="button"
                onClick={() => handleRestore(version.id)}
                disabled={busy}
                className="min-h-[34px] rounded-lg border border-emerald-300/40 bg-emerald-300/10 px-2 text-[9px] font-semibold text-emerald-100 flex items-center gap-1 cursor-pointer disabled:opacity-50"
              >
                <RotateCcw className="w-3 h-3" />
                VOLTAR
              </button>
              <button
                type="button"
                onClick={() => handleDelete(version.id)}
                disabled={busy}
                className="min-h-[34px] min-w-[34px] rounded-lg border border-rose-400/30 text-rose-200 flex items-center justify-center cursor-pointer disabled:opacity-50"
                aria-label={`Excluir ${version.label}`}
              >
                <Trash2 className="w-3 h-3" />
              </button>
            </div>
          ))
        )}
      </div>
    </aside>
  );
};

function countEntities(world: CreatorWorld): number {
  let total = 0;
  for (const delta of Object.values(world.chunkDeltas)) {
    for (const mutation of delta.mutations) {
      if (mutation.type === 'entity-add') total += 1;
    }
  }
  return total;
}
