import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import {
  ArchitecturalPortal,
  PlayerTelemetry,
  QualityTier,
  RegionId,
  ResonancePoint,
  WeatherPresetId,
} from '../types/world';
import { REGIONS_MAP, WEATHER_PRESETS } from '../world/AtmospherePresets';
import { buildRegionWorld, BuiltWorld } from '../world/ColossalWorldBuilder';
import { createWorldMaterials, WorldMaterialLibrary } from '../world/ProceduralTextures';
import { SpatialAudioEngine } from '../audio/SpatialAudioEngine';
import { WorldPlan } from '../world/types/worldPlan';
import { WorldPlanCompiler } from '../world/WorldPlanCompiler';
import { WorldStreamingManager, ChunkStreamingState } from '../world/WorldStreamingManager';
import {
  PLAYER_COLLISION_HEIGHT,
  PLAYER_COLLISION_RADIUS,
  PlayerCharacterController,
} from '../player/PlayerCharacterController';

interface ColossalViewportProps {
  hasStarted: boolean;
  regionId: RegionId;
  weatherId: WeatherPresetId;
  fov: number;
  qualityTier: QualityTier;
  isRunning: boolean;
  joystickVector: React.MutableRefObject<{ x: number; y: number }>;
  touchLookDelta: React.MutableRefObject<{ x: number; y: number }>;
  audioEngine: SpatialAudioEngine;
  triggerContextualActionRef: React.MutableRefObject<(() => void) | null>;
  jumpRequestRef: React.MutableRefObject<boolean>;
  onRegionChangeRequest: (targetRegion: RegionId) => void;
  onTelemetryUpdate: (telemetry: PlayerTelemetry) => void;
  onUserActivity: () => void;
  customWorldPlan?: WorldPlan | null;
  activeCustomRegionId?: string | null;
  onStreamingUpdate?: (streaming: ChunkStreamingState) => void;
  /** Cuando ativo, o toque seleciona construções em vez de apenas olhar. */
  spectatorActive?: boolean;
  /** Recebe a cena viva e a câmera assim que o mundo é montado. */
  onSceneReady?: (sceneGroup: THREE.Group | null, camera: THREE.Camera | null) => void;
  /** Permite ao App instalar o handler de seleção usado no toque. */
  spectatorPickHandlerRef?: React.MutableRefObject<
    ((normalizedX: number, normalizedY: number) => void) | null
  >;
  /**
   * Eixo vertical (-1..1) e multiplicador de velocidade da câmera livre.
   * O App escreve aqui a partir dos botões Subir/Descer da interface.
   */
  spectatorFlyRef?: React.MutableRefObject<{ vertical: number; speed: number }>;
}

const EYE_HEIGHT = 1.72;
const WALK_SPEED = 4.4;
const RUN_SPEED = 8.2;
/** Câmera livre: bem mais rápida que a caminhada, para varrer a cidade. */
const FLY_SPEED = 26;

const isCompactViewport = () =>
  window.innerWidth < 700 || window.matchMedia('(pointer: coarse)').matches;

export const ColossalViewport: React.FC<ColossalViewportProps> = ({
  hasStarted,
  regionId,
  weatherId,
  fov,
  qualityTier,
  isRunning,
  joystickVector,
  touchLookDelta,
  audioEngine,
  triggerContextualActionRef,
  jumpRequestRef,
  onRegionChangeRequest,
  onTelemetryUpdate,
  onUserActivity,
  customWorldPlan,
  activeCustomRegionId,
  onStreamingUpdate,
  spectatorActive = false,
  onSceneReady,
  spectatorPickHandlerRef: externalPickHandlerRef,
  spectatorFlyRef: externalFlyRef,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [viewportReady, setViewportReady] = useState(false);
  const fovRef = useRef(fov);
  fovRef.current = fov;
  const isRunningRef = useRef(isRunning);
  isRunningRef.current = isRunning;
  const hasStartedRef = useRef(hasStarted);
  hasStartedRef.current = hasStarted;
  const regionIdRef = useRef(regionId);
  regionIdRef.current = regionId;
  const weatherIdRef = useRef(weatherId);
  weatherIdRef.current = weatherId;
  const qualityRef = useRef(qualityTier);
  qualityRef.current = qualityTier;
  const onRegionChangeRef = useRef(onRegionChangeRequest);
  onRegionChangeRef.current = onRegionChangeRequest;

  const customPlanRef = useRef(customWorldPlan);
  customPlanRef.current = customWorldPlan;
  const activeCustomRegionIdRef = useRef(activeCustomRegionId);
  activeCustomRegionIdRef.current = activeCustomRegionId;

  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  // Reflets das props de espectador: o effect de input é montado uma vez e não
  // deve capturar valores antigos de 'ativo' nem do callback de seleção.
  const spectatorActiveRef = useRef(spectatorActive);
  const onSceneReadyRef = useRef(onSceneReady);
  spectatorActiveRef.current = spectatorActive;
  onSceneReadyRef.current = onSceneReady;
  // Permite que o App injete o handler de seleção sem remontar o effect.
  const localPickHandlerRef = useRef<
    ((normalizedX: number, normalizedY: number) => void) | null
  >(null);
  const spectatorPickHandlerRef = externalPickHandlerRef ?? localPickHandlerRef;
  const localFlyRef = useRef({ vertical: 0, speed: 1 });
  const spectatorFlyRef = externalFlyRef ?? localFlyRef;
  // Marca se a câmera livre já está assumindo, para aplicar a troca uma vez só.
  const prevFlyingRef = useRef(false);
  const fogRef = useRef<THREE.FogExp2 | null>(null);
  const dirLightRef = useRef<THREE.DirectionalLight | null>(null);
  const ambientLightRef = useRef<THREE.HemisphereLight | null>(null);
  const materialsRef = useRef<WorldMaterialLibrary | null>(null);
  const activeWorldRef = useRef<BuiltWorld | null>(null);
  const streamingManagerRef = useRef<WorldStreamingManager | null>(null);
  const playerCharacterRef = useRef<PlayerCharacterController | null>(null);
  const verticalVelocityRef = useRef(0);
  const groundedRef = useRef(true);
  const characterHeadingRef = useRef(0);

  // Player kinematic refs
  const playerPosRef = useRef(new THREE.Vector3(0, 0, 40));
  const velocityRef = useRef(new THREE.Vector3(0, 0, 0));
  const currentGroundYRef = useRef(0);
  const smoothedEyeYRef = useRef(EYE_HEIGHT);
  const targetYawRef = useRef(0);
  const targetPitchRef = useRef(0.08);
  const currentYawRef = useRef(0);
  const currentPitchRef = useRef(0.08);
  const portalCooldownRef = useRef(0);

  // Quality Tier updates
  useEffect(() => {
    const renderer = rendererRef.current;
    const dirLight = dirLightRef.current;
    if (!renderer) return;
    const compactViewport = isCompactViewport();
    const maxDpr =
      qualityTier === 'leve'
        ? 1.0
        : qualityTier === 'equilibrado'
        ? Math.min(window.devicePixelRatio || 1, 1.5)
        : Math.min(window.devicePixelRatio || 1, 2.0);
    renderer.setPixelRatio(Math.min(maxDpr, compactViewport ? 1 : maxDpr));
    renderer.shadowMap.enabled = qualityTier !== 'leve' && !compactViewport;
    if (dirLight) {
      dirLight.castShadow = qualityTier !== 'leve';
    }
  }, [qualityTier]);

  // World & Region Swapping (Handles both Canonical 13 regions and AI-Generated Worlds)
  useEffect(() => {
    const scene = sceneRef.current;
    const materials = materialsRef.current;
    if (!scene || !materials || !viewportReady) return;

    if (activeWorldRef.current) {
      scene.remove(activeWorldRef.current.sceneGroup);
      activeWorldRef.current.dispose();
      activeWorldRef.current = null;
    }

    let built: BuiltWorld;

    if (customWorldPlan) {
      // Compile AI-generated custom world
      streamingManagerRef.current = new WorldStreamingManager(customWorldPlan, (nextRegId) => {
        onRegionChangeRef.current(nextRegId);
      });

      const targetRegDef =
        customWorldPlan.regions.find((r) => r.id === (activeCustomRegionId || regionId)) ||
        customWorldPlan.regions[0];

      built = WorldPlanCompiler.compileWorldRegion(customWorldPlan, targetRegDef, materials);

      playerPosRef.current.set(...targetRegDef.spawnOffset);
      velocityRef.current.set(0, 0, 0);
      currentGroundYRef.current = targetRegDef.spawnOffset[1];
      smoothedEyeYRef.current = targetRegDef.spawnOffset[1] + EYE_HEIGHT;
      verticalVelocityRef.current = 0;
      groundedRef.current = true;
      characterHeadingRef.current = 0;
      playerCharacterRef.current?.teleport(playerPosRef.current, 0);
      targetYawRef.current = 0;
      currentYawRef.current = 0;
      targetPitchRef.current = 0.08;
      currentPitchRef.current = 0.08;
    } else {
      // Compile Canonical world region
      streamingManagerRef.current = null;
      built = buildRegionWorld(regionId, materials);

      const meta = REGIONS_MAP[regionId] || REGIONS_MAP['vale_pilares'];
      playerPosRef.current.set(...meta.spawnPosition);
      velocityRef.current.set(0, 0, 0);
      currentGroundYRef.current = meta.spawnPosition[1];
      smoothedEyeYRef.current = meta.spawnPosition[1] + EYE_HEIGHT;
      const spawnYaw = THREE.MathUtils.degToRad(meta.spawnYawDeg);
      const spawnPitch = THREE.MathUtils.degToRad(meta.spawnPitchDeg);
      verticalVelocityRef.current = 0;
      groundedRef.current = true;
      characterHeadingRef.current = spawnYaw;
      playerCharacterRef.current?.teleport(playerPosRef.current, spawnYaw);
      targetYawRef.current = spawnYaw;
      currentYawRef.current = spawnYaw;
      targetPitchRef.current = spawnPitch;
      currentPitchRef.current = spawnPitch;
    }

    scene.add(built.sceneGroup);
    activeWorldRef.current = built;
    portalCooldownRef.current = 2.0;
    // Entrega a cena viva para o App ligar o modo espectador.
    onSceneReadyRef.current?.(built.sceneGroup, cameraRef.current);
  }, [regionId, customWorldPlan, activeCustomRegionId, viewportReady]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const initialWeather = WEATHER_PRESETS[weatherIdRef.current] || WEATHER_PRESETS.manha_neblina;
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const fog = new THREE.FogExp2(initialWeather.fogColor, initialWeather.fogDensity);
    scene.fog = fog;
    fogRef.current = fog;

    const camera = new THREE.PerspectiveCamera(
      fovRef.current,
      window.innerWidth / window.innerHeight,
      0.25,
      2800
    );
    camera.rotation.order = 'YXZ';
    cameraRef.current = camera;

    const compactViewport = isCompactViewport();
    const renderer = new THREE.WebGLRenderer({
      antialias: !compactViewport && qualityRef.current === 'cinematografico',
      powerPreference: 'default',
      stencil: false,
    });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, compactViewport ? 1 : 1.5));
    renderer.setClearColor(initialWeather.fogColor);
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    renderer.shadowMap.enabled = qualityRef.current !== 'leve' && !compactViewport;
    renderer.shadowMap.type = THREE.PCFShadowMap;
    rendererRef.current = renderer;

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const canvasEl = renderer.domElement;
    const handleContextLost = (e: Event) => e.preventDefault();
    canvasEl.addEventListener('webglcontextlost', handleContextLost, false);

    // Lighting
    const hemiLight = new THREE.HemisphereLight(
      initialWeather.skyHorizonColor,
      initialWeather.ambientColor,
      initialWeather.ambientIntensity
    );
    hemiLight.position.set(0, 320, 0);
    scene.add(hemiLight);
    ambientLightRef.current = hemiLight;

    const dirLight = new THREE.DirectionalLight(
      initialWeather.sunColor,
      initialWeather.sunIntensity
    );
    dirLight.position.set(-160, 175, -260);
    dirLight.target.position.set(0, 0, -180);
    dirLight.castShadow = qualityRef.current !== 'leve';
    dirLight.shadow.mapSize.width = 1024;
    dirLight.shadow.mapSize.height = 1024;
    dirLight.shadow.camera.near = 10;
    dirLight.shadow.camera.far = 750;
    const d = 220;
    dirLight.shadow.camera.left = -d;
    dirLight.shadow.camera.right = d;
    dirLight.shadow.camera.top = d;
    dirLight.shadow.camera.bottom = -d;
    dirLight.shadow.bias = -0.0008;
    scene.add(dirLight);
    scene.add(dirLight.target);
    dirLightRef.current = dirLight;

    // Shared Materials
    const materials = createWorldMaterials();
    materialsRef.current = materials;
    setViewportReady(true);

    const playerCharacter = new PlayerCharacterController();
    playerCharacter.addTo(scene);
    playerCharacter.teleport(playerPosRef.current, characterHeadingRef.current);
    playerCharacterRef.current = playerCharacter;

    // Initial World Setup
    const initialWorld = buildRegionWorld(regionIdRef.current, materials);
    scene.add(initialWorld.sceneGroup);
    activeWorldRef.current = initialWorld;

    const meta = REGIONS_MAP[regionIdRef.current] || REGIONS_MAP['vale_pilares'];
    playerPosRef.current.set(...meta.spawnPosition);
    currentGroundYRef.current = meta.spawnPosition[1];
    smoothedEyeYRef.current = meta.spawnPosition[1] + EYE_HEIGHT;
    targetPitchRef.current = THREE.MathUtils.degToRad(meta.spawnPitchDeg);
    currentPitchRef.current = targetPitchRef.current;

    let walkCycle = 0;
    let lastFootstepCycle = 0;
    let resonanceFovBoost = 0;
    let activeResonanceLookTarget: THREE.Vector3 | null = null;
    let activeResonanceTimer = 0;

    const findNearbyResonance = (): ResonancePoint | null => {
      const world = activeWorldRef.current;
      if (!world) return null;
      for (const rp of world.resonancePoints) {
        const dx = playerPosRef.current.x - rp.position[0];
        const dz = playerPosRef.current.z - rp.position[2];
        if (Math.hypot(dx, dz) <= rp.radius) return rp;
      }
      return null;
    };

    const findNearbyPortal = (): ArchitecturalPortal | null => {
      const world = activeWorldRef.current;
      if (!world) return null;
      for (const p of world.portals) {
        const dx = playerPosRef.current.x - p.position[0];
        const dy = playerPosRef.current.y - p.position[1];
        const dz = playerPosRef.current.z - p.position[2];
        if (Math.hypot(dx, dz) <= p.radius && Math.abs(dy) < 6) return p;
      }
      return null;
    };

    triggerContextualActionRef.current = () => {
      audioEngine.init();
      const portal = findNearbyPortal();
      if (portal) {
        audioEngine.playTectonicSubRumble(36.71);
        onRegionChangeRef.current(portal.targetRegion);
        return;
      }

      const rp = findNearbyResonance();
      if (rp) {
        audioEngine.playTectonicSubRumble(rp.fundamentalFreq);
        audioEngine.playDistantMechanismSound(rp.fundamentalFreq * 1.5);
        activeResonanceLookTarget = new THREE.Vector3(...rp.lookTarget);
        activeResonanceTimer = 3.6;
        resonanceFovBoost = 9.0;
      } else {
        audioEngine.playTectonicSubRumble(32.7);
        audioEngine.playDistantMechanismSound(48.0);
        resonanceFovBoost = 6.5;
      }
      onUserActivity();
    };

    const keys: Record<string, boolean> = {};
    let shiftHeld = false;

    const onKeyDown = (e: KeyboardEvent) => {
      keys[e.code] = true;
      if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') shiftHeld = true;
      if (e.code === 'KeyE' || e.code === 'Space') {
        if (hasStartedRef.current && triggerContextualActionRef.current) {
          triggerContextualActionRef.current();
        }
      }
      if (e.code === 'KeyJ') {
        jumpRequestRef.current = true;
      }
      onUserActivity();
    };

    const onKeyUp = (e: KeyboardEvent) => {
      keys[e.code] = false;
      if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') shiftHeld = false;
    };

    let isDraggingMouse = false;
    let prevMouseX = 0;
    let prevMouseY = 0;

    const onMouseDown = (e: MouseEvent) => {
      if (!hasStartedRef.current) return;
      if (e.button === 0) {
        isDraggingMouse = true;
        prevMouseX = e.clientX;
        prevMouseY = e.clientY;
        audioEngine.init();
        onUserActivity();
      }
    };

    const onMouseUp = () => {
      isDraggingMouse = false;
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!hasStartedRef.current) return;
      const sensitivity = 0.0022;
      if (document.pointerLockElement === canvasEl) {
        targetYawRef.current -= e.movementX * sensitivity;
        targetPitchRef.current -= e.movementY * sensitivity;
        targetPitchRef.current = Math.max(
          -Math.PI * 0.44,
          Math.min(Math.PI * 0.48, targetPitchRef.current)
        );
        onUserActivity();
      } else if (isDraggingMouse) {
        const dx = e.clientX - prevMouseX;
        const dy = e.clientY - prevMouseY;
        prevMouseX = e.clientX;
        prevMouseY = e.clientY;
        targetYawRef.current -= dx * sensitivity * 1.25;
        targetPitchRef.current -= dy * sensitivity * 1.25;
        targetPitchRef.current = Math.max(
          -Math.PI * 0.44,
          Math.min(Math.PI * 0.48, targetPitchRef.current)
        );
        onUserActivity();
      }
    };

    const onResize = () => {
      if (!cameraRef.current || !rendererRef.current) return;
      cameraRef.current.aspect = window.innerWidth / window.innerHeight;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(window.innerWidth, window.innerHeight);
    };

    // Modo espectador: toque na tela escolhe a construção sob o cursor.
    // Só dispara em toque curto e parado, para não colidir com arrastar a câmera.
    //
    // Os listeners ficam na window, NÃO no canvas: a área de "olhar" do overlay
    // cobre os 60% da direita da tela acima do canvas e engolia o toque — era por
    // isso que tocar numa construção quase nunca selecionava nada.
    let spectatorPress: { x: number; y: number; time: number } | null = null;
    // Joystick, botões de voo e o painel são interface, não mira: tocar neles
    // não deve selecionar. A área de olhar, essa sim, seleciona.
    const isSpectatorUi = (target: EventTarget | null) =>
      target instanceof Element && !!target.closest('[data-spectator-ui], button');
    const onSpectatorPointerDown = (event: PointerEvent) => {
      if (!spectatorActiveRef.current) return;
      if (isSpectatorUi(event.target)) return;
      spectatorPress = { x: event.clientX, y: event.clientY, time: performance.now() };
    };
    const onSpectatorPointerUp = (event: PointerEvent) => {
      if (!spectatorActiveRef.current) return;
      const press = spectatorPress;
      spectatorPress = null;
      if (!press || isSpectatorUi(event.target)) return;
      const moved = Math.hypot(event.clientX - press.x, event.clientY - press.y);
      const elapsed = performance.now() - press.time;
      if (moved > 12 || elapsed > 700) return;
      const bounds = canvasEl.getBoundingClientRect();
      if (bounds.width === 0 || bounds.height === 0) return;
      const normalizedX = ((event.clientX - bounds.left) / bounds.width) * 2 - 1;
      const normalizedY = -((event.clientY - bounds.top) / bounds.height) * 2 + 1;
      spectatorPickHandlerRef.current?.(normalizedX, normalizedY);
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    canvasEl.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mouseup', onMouseUp);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('resize', onResize);
    window.addEventListener('pointerdown', onSpectatorPointerDown);
    window.addEventListener('pointerup', onSpectatorPointerUp);
    window.addEventListener('pointercancel', onSpectatorPointerUp);

    const currentFogColor = new THREE.Color(initialWeather.fogColor);
    const currentTopColor = new THREE.Color(initialWeather.skyTopColor);
    const currentHorizonColor = new THREE.Color(initialWeather.skyHorizonColor);
    const currentSunColor = new THREE.Color(initialWeather.sunColor);
    const targetColorTemp = new THREE.Color();
    const birdDummy = new THREE.Object3D();

    let animationFrameId = 0;
    const clock = new THREE.Timer();
    clock.connect(document);
    let telemetryTimer = 0;

    const animate = (timestamp?: number) => {
      animationFrameId = requestAnimationFrame(animate);
      clock.update(timestamp);
      const dt = Math.min(clock.getDelta(), 0.1);
      const elapsed = clock.getElapsed();
      const world = activeWorldRef.current;
      if (!world) return;

      if (portalCooldownRef.current > 0) {
        portalCooldownRef.current -= dt;
      }

      // 1. Atmosphere interpolation
      const targetWeather = WEATHER_PRESETS[weatherIdRef.current] || WEATHER_PRESETS.manha_neblina;
      const weatherLerp = 1.0 - Math.exp(-1.4 * dt);
      currentFogColor.lerp(targetColorTemp.set(targetWeather.fogColor), weatherLerp);
      currentTopColor.lerp(targetColorTemp.set(targetWeather.skyTopColor), weatherLerp);
      currentHorizonColor.lerp(targetColorTemp.set(targetWeather.skyHorizonColor), weatherLerp);
      currentSunColor.lerp(targetColorTemp.set(targetWeather.sunColor), weatherLerp);

      fog.color.copy(currentFogColor);
      fog.density = THREE.MathUtils.lerp(fog.density, targetWeather.fogDensity, weatherLerp);
      renderer.setClearColor(currentFogColor);

      dirLight.color.copy(currentSunColor);
      dirLight.intensity = THREE.MathUtils.lerp(
        dirLight.intensity,
        targetWeather.sunIntensity,
        weatherLerp
      );

      const elevRad = THREE.MathUtils.degToRad(targetWeather.sunElevationDeg);
      const azimRad = THREE.MathUtils.degToRad(targetWeather.sunAzimuthDeg);
      const dist = 360;
      const sy = Math.sin(elevRad) * dist;
      const horiz = Math.cos(elevRad) * dist;
      const sx = Math.sin(azimRad) * horiz;
      const sz = -Math.cos(azimRad) * horiz - 180;
      dirLight.position.set(sx, sy, sz);

      world.handles.skyMaterial.uniforms.uTopColor.value.copy(currentTopColor);
      world.handles.skyMaterial.uniforms.uHorizonColor.value.copy(currentHorizonColor);
      world.handles.skyMaterial.uniforms.uSunColor.value.copy(currentSunColor);
      world.handles.skyMaterial.uniforms.uSunDir.value.set(sx, sy, sz + 180).normalize();

      hemiLight.color.copy(currentHorizonColor);
      hemiLight.intensity = THREE.MathUtils.lerp(
        hemiLight.intensity,
        targetWeather.ambientIntensity,
        weatherLerp
      );

      materials.cloudLayerMaterial.opacity = THREE.MathUtils.lerp(
        materials.cloudLayerMaterial.opacity,
        targetWeather.cloudOpacity,
        weatherLerp
      );
      materials.cloudLayerMaterial.color.copy(currentHorizonColor);

      materials.lowMistMaterial.uniforms.uColor.value.copy(currentFogColor);
      materials.lowMistMaterial.uniforms.uFogDensity.value = fog.density;
      materials.lowMistMaterial.uniforms.uOpacity.value = THREE.MathUtils.lerp(
        materials.lowMistMaterial.uniforms.uOpacity.value,
        targetWeather.cloudOpacity * 0.22,
        weatherLerp
      );

      materials.lightShaftMaterial.uniforms.uColor.value.copy(currentSunColor);
      materials.lightShaftMaterial.uniforms.uFogDensity.value = fog.density;
      materials.lightShaftMaterial.uniforms.uOpacity.value = THREE.MathUtils.lerp(
        materials.lightShaftMaterial.uniforms.uOpacity.value,
        Math.min(0.09, targetWeather.sunIntensity * 0.055),
        weatherLerp
      );

      world.handles.grassShaderUniforms.uTime.value = elapsed;
      world.handles.grassShaderUniforms.uWindStrength.value = targetWeather.windMultiplier;
      audioEngine.setWeatherParams(targetWeather.windMultiplier, targetWeather.rainIntensity);

      if (targetWeather.rainIntensity > 0.02) {
        world.handles.rainLines.visible = true;
        world.handles.rainMaterial.opacity = THREE.MathUtils.lerp(
          world.handles.rainMaterial.opacity,
          targetWeather.rainIntensity * 0.42,
          weatherLerp * 2
        );
        const rainCycleY = (elapsed * 26.0) % 18.0;
        world.handles.rainLines.position.set(
          playerPosRef.current.x,
          playerPosRef.current.y - rainCycleY,
          playerPosRef.current.z
        );
      } else {
        world.handles.rainLines.visible = false;
      }

      // 2. Animate Megastructures
      if (world.handles.pendulumGroup) {
        world.handles.pendulumGroup.rotation.z = Math.sin(elapsed * 0.22) * 0.024;
        world.handles.pendulumGroup.rotation.x = Math.cos(elapsed * 0.17) * 0.016;
      }
      if (world.handles.upperRingMesh) {
        world.handles.upperRingMesh.rotation.z = elapsed * 0.035;
      }
      if (world.handles.lowerRingMesh) {
        world.handles.lowerRingMesh.rotation.z = -elapsed * 0.055;
      }
      if (world.handles.birdFlockInstanced) {
        for (let b = 0; b < 18; b++) {
          const angle = elapsed * 0.08 + b * 0.35;
          const bx = Math.cos(angle) * (85 + (b % 4) * 14);
          const bz = -90 + Math.sin(angle) * (95 + (b % 3) * 18);
          const by = 92 + (b % 5) * 6 + Math.sin(elapsed * 1.8 + b) * 1.5;
          birdDummy.position.set(bx, by, bz);
          birdDummy.rotation.y = -angle;
          birdDummy.updateMatrix();
          world.handles.birdFlockInstanced.setMatrixAt(b, birdDummy.matrix);
        }
        world.handles.birdFlockInstanced.instanceMatrix.needsUpdate = true;
      }
      if (world.handles.futuristicController) {
        world.handles.futuristicController.update(elapsed, dt, playerPosRef.current);
      }

      const windDrift = targetWeather.windMultiplier;
      world.handles.cloudGroup.position.x = Math.sin(elapsed * 0.012 * windDrift) * 95;
      world.handles.cloudGroup.position.z = Math.cos(elapsed * 0.009 * windDrift) * 65;
      world.handles.lowMistGroup.position.x = Math.cos(elapsed * 0.02 * windDrift) * 18;

      // 3. Camera Look
      if (touchLookDelta.current.x !== 0 || touchLookDelta.current.y !== 0) {
        const touchSens = 0.0034;
        targetYawRef.current -= touchLookDelta.current.x * touchSens;
        targetPitchRef.current -= touchLookDelta.current.y * touchSens;
        targetPitchRef.current = Math.max(
          -Math.PI * 0.44,
          Math.min(Math.PI * 0.48, targetPitchRef.current)
        );
        touchLookDelta.current.x = 0;
        touchLookDelta.current.y = 0;
      }

      const keyLookSpeed = 1.15;
      if (keys['ArrowLeft']) targetYawRef.current += keyLookSpeed * dt;
      if (keys['ArrowRight']) targetYawRef.current -= keyLookSpeed * dt;
      if (keys['ArrowUp']) {
        targetPitchRef.current = Math.min(
          Math.PI * 0.48,
          targetPitchRef.current + keyLookSpeed * 0.8 * dt
        );
      }
      if (keys['ArrowDown']) {
        targetPitchRef.current = Math.max(
          -Math.PI * 0.44,
          targetPitchRef.current - keyLookSpeed * 0.8 * dt
        );
      }

      if (activeResonanceTimer > 0 && activeResonanceLookTarget) {
        activeResonanceTimer -= dt;
        const toTarget = activeResonanceLookTarget.clone().sub(camera.position).normalize();
        const desiredPitch = Math.asin(THREE.MathUtils.clamp(toTarget.y, -0.95, 0.95));
        targetPitchRef.current = THREE.MathUtils.lerp(
          targetPitchRef.current,
          desiredPitch,
          dt * 1.4
        );
      }

      const lookSmoothing = 1.0 - Math.exp(-11.0 * dt);
      currentYawRef.current = THREE.MathUtils.lerp(
        currentYawRef.current,
        targetYawRef.current,
        lookSmoothing
      );
      currentPitchRef.current = THREE.MathUtils.lerp(
        currentPitchRef.current,
        targetPitchRef.current,
        lookSmoothing
      );
      camera.rotation.y = currentYawRef.current;
      camera.rotation.x = currentPitchRef.current;

      // 4. Movement & Physics
      let inputForward = 0;
      let inputRight = 0;
      if (hasStartedRef.current) {
        if (keys['KeyW']) inputForward += 1;
        if (keys['KeyS']) inputForward -= 1;
        if (keys['KeyD']) inputRight += 1;
        if (keys['KeyA']) inputRight -= 1;
        inputRight += joystickVector.current.x;
        inputForward += -joystickVector.current.y;
      }

      const rawInputMag = Math.hypot(inputRight, inputForward);
      const inputMag = rawInputMag;
      if (inputMag > 1) {
        inputRight /= inputMag;
        inputForward /= inputMag;
      }

      const flying = spectatorActiveRef.current;
      // Ao alternar o modo, o corpo cede lugar à câmera (e vice-versa) sem salto:
      // a câmera assume a posição em que a tela já estava.
      if (prevFlyingRef.current !== flying) {
        prevFlyingRef.current = flying;
        playerCharacterRef.current?.setVisible(!flying);
        if (flying) {
          playerPosRef.current.copy(camera.position);
        } else {
          // Saindo do voo a câmera pode estar a centenas de metros do chão:
          // aterrissa na hora, senão o jogador cai de uma vez ao voltar.
          const ground = world.resolvePlayerPhysics(
            playerPosRef.current,
            playerPosRef.current,
            PLAYER_COLLISION_RADIUS
          );
          playerPosRef.current.y = ground.groundY;
        }
        velocityRef.current.set(0, 0, 0);
        verticalVelocityRef.current = 0;
      }

      const activeRun = isRunningRef.current || shiftHeld;
      const maxSpeed = flying
        ? FLY_SPEED * spectatorFlyRef.current.speed
        : activeRun
        ? RUN_SPEED
        : WALK_SPEED;
      const sinY = Math.sin(currentYawRef.current);
      const cosY = Math.cos(currentYawRef.current);
      const moveDirX = inputRight * cosY - inputForward * sinY;
      const moveDirZ = -inputRight * sinY - inputForward * cosY;

      const accelSmoothing = 1.0 - Math.exp(-5.5 * dt);
      velocityRef.current.x = THREE.MathUtils.lerp(
        velocityRef.current.x,
        moveDirX * maxSpeed,
        accelSmoothing
      );
      velocityRef.current.z = THREE.MathUtils.lerp(
        velocityRef.current.z,
        moveDirZ * maxSpeed,
        accelSmoothing
      );

      // Ambos os ramos preenchem estes três: a física normal resolve pelo mundo,
      // o voo livre mantém a câmera, mas ambos precisam de zona/superfície.
      let resolved: ReturnType<BuiltWorld['resolvePlayerPhysics']>;
      let horizontalSpeed = 0;

      if (flying) {
        // Câmera livre: o personagem é desativado e o "corpo" passa a ser a própria
        // câmera. Sem gravidade e sem colisão, para alcançar qualquer ângulo de
        // qualquer construção — inclusive por baixo e por cima.
        const fly = spectatorFlyRef.current;
        let vertical = fly.vertical;
        if (keys['Space']) vertical += 1;
        if (keys['ShiftLeft'] || keys['ShiftRight']) vertical -= 1;
        vertical = THREE.MathUtils.clamp(vertical, -1, 1);
        verticalVelocityRef.current = THREE.MathUtils.lerp(
          verticalVelocityRef.current,
          vertical * maxSpeed,
          1.0 - Math.exp(-9.0 * dt)
        );
        // zone/surface continuam vindo do mundo porque áudio e telemetria dependem
        // deles; só a posição final é a da câmera, sem resolver colisão.
        resolved = world.resolvePlayerPhysics(
          playerPosRef.current,
          playerPosRef.current,
          PLAYER_COLLISION_RADIUS
        );
        resolved.position.set(
          playerPosRef.current.x + velocityRef.current.x * dt,
          playerPosRef.current.y + verticalVelocityRef.current * dt,
          playerPosRef.current.z + velocityRef.current.z * dt
        );
        playerPosRef.current.copy(resolved.position);
        currentGroundYRef.current = playerPosRef.current.y;
        groundedRef.current = false;
        horizontalSpeed = Math.hypot(velocityRef.current.x, velocityRef.current.z);
        // A rotação já foi aplicada na seção de look, então a câmera fica
        // exatamente na posição do corpo: aqui não há lookAt nem ombro.
        camera.position.copy(playerPosRef.current);
      } else {
        const wasGrounded = groundedRef.current;
        let justJumped = false;
        let justLanded = false;
        if (jumpRequestRef.current) {
          jumpRequestRef.current = false;
          if (wasGrounded) {
            verticalVelocityRef.current = 7.6;
            groundedRef.current = false;
            justJumped = true;
          }
        } else {
          jumpRequestRef.current = false;
        }

        if (!groundedRef.current) {
          verticalVelocityRef.current -= 19 * dt;
        } else if (!justJumped) {
          verticalVelocityRef.current = 0;
        }

        let nextPlayerY = playerPosRef.current.y + verticalVelocityRef.current * dt;
        const desiredPos = new THREE.Vector3(
          playerPosRef.current.x + velocityRef.current.x * dt,
          nextPlayerY,
          playerPosRef.current.z + velocityRef.current.z * dt
        );

        resolved = world.resolvePlayerPhysics(
          playerPosRef.current,
          desiredPos,
          PLAYER_COLLISION_RADIUS
        );
        const groundY = resolved.groundY;

        if (verticalVelocityRef.current > 0) {
          const previousHeadY = playerPosRef.current.y + PLAYER_COLLISION_HEIGHT;
          const nextHeadY = nextPlayerY + PLAYER_COLLISION_HEIGHT;
          for (const collider of world.colliders) {
            const overlapsHorizontally =
              nextPlayerY < collider.maxY &&
              playerPosRef.current.y + PLAYER_COLLISION_HEIGHT > collider.minY &&
              desiredPos.x > collider.minX - PLAYER_COLLISION_RADIUS &&
              desiredPos.x < collider.maxX + PLAYER_COLLISION_RADIUS &&
              desiredPos.z > collider.minZ - PLAYER_COLLISION_RADIUS &&
              desiredPos.z < collider.maxZ + PLAYER_COLLISION_RADIUS;
            if (
              overlapsHorizontally &&
              previousHeadY <= collider.minY + 0.05 &&
              nextHeadY > collider.minY
            ) {
              nextPlayerY = Math.max(groundY, collider.minY - PLAYER_COLLISION_HEIGHT - 0.02);
              verticalVelocityRef.current = 0;
              break;
            }
          }
        }

        if (nextPlayerY <= groundY + 0.02) {
          nextPlayerY = groundY;
          if (!wasGrounded && !justJumped) justLanded = true;
          groundedRef.current = true;
          verticalVelocityRef.current = 0;
        } else {
          groundedRef.current = false;
        }

        resolved.position.y = nextPlayerY;
        playerPosRef.current.copy(resolved.position);
        currentGroundYRef.current = groundY;
        smoothedEyeYRef.current = THREE.MathUtils.lerp(
          smoothedEyeYRef.current,
          playerPosRef.current.y + EYE_HEIGHT,
          1.0 - Math.exp(-9.0 * dt)
        );

        // Check Chunk Streaming Manager if custom world
        if (streamingManagerRef.current && onStreamingUpdate) {
          const streamingStatus = streamingManagerRef.current.updatePlayerPosition(playerPosRef.current);
          onStreamingUpdate(streamingStatus);
        }

        // Automatic Portal Detection
        if (portalCooldownRef.current <= 0) {
          for (const p of world.portals) {
            const dist = Math.hypot(
              playerPosRef.current.x - p.position[0],
              playerPosRef.current.z - p.position[2]
            );
            if (dist < 2.2 && Math.abs(playerPosRef.current.y - p.position[1]) < 4.0) {
              portalCooldownRef.current = 3.0;
              audioEngine.playTectonicSubRumble(36.71);
              onRegionChangeRef.current(p.targetRegion);
              break;
            }
          }
        }

        // Head-Bob & Footsteps
        horizontalSpeed = Math.hypot(velocityRef.current.x, velocityRef.current.z);
        const speedRatio = Math.min(1.3, horizontalSpeed / WALK_SPEED);
        let bobY = Math.sin(elapsed * 1.15) * 0.012;
        let bobX = 0;
        let rollTilt = 0;

        if (horizontalSpeed > 0.25) {
          const stepFreq = activeRun ? 8.8 : 6.2;
          walkCycle += dt * stepFreq * Math.min(1.0, speedRatio);
          bobY = Math.sin(walkCycle * 2.0) * 0.048 * speedRatio;
          bobX = Math.cos(walkCycle) * 0.028 * speedRatio;
          rollTilt = Math.sin(walkCycle) * 0.0045 * speedRatio;
          const stepPhase = Math.floor((walkCycle * 2.0 + Math.PI * 0.5) / (Math.PI * 2.0));
          if (stepPhase > lastFootstepCycle) {
            lastFootstepCycle = stepPhase;
            audioEngine.playFootstep(resolved.surface, activeRun);
          }
        }

        const targetHeading =
          rawInputMag > 0.08 ? Math.atan2(moveDirX, moveDirZ) : characterHeadingRef.current;
        characterHeadingRef.current = targetHeading;
        playerCharacterRef.current?.update(
          {
            position: playerPosRef.current,
            groundY: nextPlayerY,
            targetHeading,
            inputMagnitude: rawInputMag,
            speed: horizontalSpeed,
            isGrounded: groundedRef.current,
            verticalVelocity: verticalVelocityRef.current,
            sprinting: activeRun,
            justJumped,
            justLanded,
          },
          dt
        );

        const cameraForwardX = -sinY;
        const cameraForwardZ = -cosY;
        const cameraRightX = cosY;
        const cameraRightZ = -sinY;
        const cameraDistance = 4.5;
        const cameraShoulder = 0.68;
        const focusDistance = 7;
        camera.position.set(
          playerPosRef.current.x - cameraForwardX * cameraDistance + cameraRightX * cameraShoulder + bobX * cameraRightX,
          playerPosRef.current.y + 1.72 + bobY,
          playerPosRef.current.z - cameraForwardZ * cameraDistance + cameraRightZ * cameraShoulder + bobX * cameraRightZ
        );
        const focusPitch = THREE.MathUtils.clamp(currentPitchRef.current, -1.15, 1.25);
        camera.lookAt(
          playerPosRef.current.x + cameraForwardX * focusDistance,
          playerPosRef.current.y + 1.5 + Math.tan(focusPitch) * focusDistance,
          playerPosRef.current.z + cameraForwardZ * focusDistance
        );
        camera.rotateZ(rollTilt);
      }

      // Dynamic FOV
      const upwardGazeFactor = Math.max(0, currentPitchRef.current / (Math.PI * 0.45));
      resonanceFovBoost = THREE.MathUtils.lerp(resonanceFovBoost, 0, dt * 0.65);
      const targetDynamicFov =
        fovRef.current +
        upwardGazeFactor * 7.5 +
        resonanceFovBoost +
        (activeRun && horizontalSpeed > 3 ? 2.5 : 0);

      if (Math.abs(camera.fov - targetDynamicFov) > 0.05) {
        camera.fov = THREE.MathUtils.lerp(camera.fov, targetDynamicFov, dt * 4.0);
        camera.updateProjectionMatrix();
      }

      // Audio update
      const forwardVec = new THREE.Vector3(0, 0, -1).applyQuaternion(camera.quaternion);
      audioEngine.update(
        elapsed,
        { x: camera.position.x, y: camera.position.y, z: camera.position.z },
        { x: forwardVec.x, y: forwardVec.y, z: forwardVec.z },
        regionIdRef.current,
        resolved.zone
      );

      // Telemetry update
      telemetryTimer += dt;
      if (telemetryTimer >= 0.12) {
        telemetryTimer = 0;
        const pitchDeg = Math.round(THREE.MathUtils.radToDeg(currentPitchRef.current));
        const yawDeg = Math.round(THREE.MathUtils.radToDeg(currentYawRef.current));
        const lookingHigh = pitchDeg >= 20;
        const regionMeta = REGIONS_MAP[regionIdRef.current] || {
          colossalHeightMeters: customPlanRef.current?.structures[0]?.scale?.[1] || 680,
        };

        onTelemetryUpdate({
          regionId: regionIdRef.current,
          x: Math.round(playerPosRef.current.x),
          y: Math.round(playerPosRef.current.y),
          z: Math.round(playerPosRef.current.z),
          pitchDeg,
          yawDeg,
          zone: resolved.zone,
          surface: resolved.surface,
          nearbyResonance: findNearbyResonance(),
          nearbyPortal: findNearbyPortal(),
          lookingAtMegastructure: lookingHigh,
          perceivedStructureHeightMeters: lookingHigh ? regionMeta.colossalHeightMeters : null,
        });
      }

      renderer.render(scene, camera);
    };

    animationFrameId = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('pointerdown', onSpectatorPointerDown);
      window.removeEventListener('pointerup', onSpectatorPointerUp);
      window.removeEventListener('pointercancel', onSpectatorPointerUp);
    canvasEl.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mouseup', onMouseUp);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('resize', onResize);
      canvasEl.removeEventListener('webglcontextlost', handleContextLost);
      if (activeWorldRef.current) {
        activeWorldRef.current.dispose();
      }
      clock.dispose();
      playerCharacterRef.current?.dispose();
      playerCharacterRef.current = null;
      renderer.dispose();
    };
  }, []);

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 w-full h-full z-0 cursor-grab active:cursor-grabbing"
      aria-label="Universo 3D Contemplativo em Primeira Pessoa"
    />
  );
};
