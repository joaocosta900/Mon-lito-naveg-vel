import React from 'react';
import { X } from 'lucide-react';
import { CreatorLoadedChunk } from '../creator/runtime/CreatorChunkManager';
import { CreatorEntityDelta, CreatorWorld } from '../creator/types';

interface CreatorMiniMapProps {
  world: CreatorWorld;
  cameraPosition: { x: number; y: number; z: number };
  loadedChunks: CreatorLoadedChunk[];
  entities: CreatorEntityDelta[];
  selectedEntityIds: string[];
  onTeleport: (x: number, z: number) => void;
  onClose: () => void;
}

const MAP_SIZE = 280;

export const CreatorMiniMap: React.FC<CreatorMiniMapProps> = ({
  world,
  cameraPosition,
  loadedChunks,
  entities,
  selectedEntityIds,
  onTeleport,
  onClose,
}) => {
  const halfWorld = world.sizeMeters / 2;
  const mapPosition = (worldX: number, worldZ: number) => ({
    x: ((worldX + halfWorld) / world.sizeMeters) * 100,
    y: ((worldZ + halfWorld) / world.sizeMeters) * 100,
  });
  const cameraPoint = mapPosition(cameraPosition.x, cameraPosition.z);
  const chunkFraction = 100 / Math.round(world.sizeMeters / world.chunkSizeMeters);

  const handleMapClick = (event: React.MouseEvent<HTMLDivElement>) => {
    const bounds = event.currentTarget.getBoundingClientRect();
    const normalizedX = (event.clientX - bounds.left) / bounds.width;
    const normalizedY = (event.clientY - bounds.top) / bounds.height;
    const worldX = normalizedX * world.sizeMeters - halfWorld;
    const worldZ = normalizedY * world.sizeMeters - halfWorld;
    onTeleport(worldX, worldZ);
  };

  return (
    <aside className="absolute right-2 top-16 sm:right-4 sm:top-20 z-20 w-[min(92vw,320px)] rounded-2xl border border-white/15 bg-[#0b1015]/95 p-3 shadow-2xl backdrop-blur-md">
      <div className="flex items-center justify-between mb-2">
        <div>
          <div className="text-[10px] uppercase tracking-[0.2em] text-emerald-300">
            Mapa global
          </div>
          <div className="text-xs text-white/75">
            {world.name} · {world.sizeMeters / 1000} km
          </div>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="min-h-[38px] min-w-[38px] rounded-xl border border-white/15 text-white/70 hover:text-white hover:bg-white/10 flex items-center justify-center cursor-pointer"
          aria-label="Fechar mapa"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div
        onClick={handleMapClick}
        className="relative overflow-hidden rounded-xl border border-emerald-300/25 bg-[#17251f] cursor-crosshair"
        style={{ width: '100%', aspectRatio: '1 / 1' }}
        title="Clique para teletransportar a câmera"
      >
        <svg
          viewBox="0 0 100 100"
          className="absolute inset-0 h-full w-full"
          aria-label="Mapa do mundo"
        >
          <defs>
            <pattern id="creator-map-grid" width={chunkFraction} height={chunkFraction} patternUnits="userSpaceOnUse">
              <path
                d={`M ${chunkFraction} 0 L 0 0 0 ${chunkFraction}`}
                fill="none"
                stroke="rgba(255,255,255,0.12)"
                strokeWidth="0.22"
              />
            </pattern>
          </defs>
          <rect x="0" y="0" width="100" height="100" fill="url(#creator-map-grid)" />
          <rect
            x="0.8"
            y="0.8"
            width="98.4"
            height="98.4"
            fill="none"
            stroke="rgba(110,231,183,0.7)"
            strokeWidth="0.7"
          />
          {loadedChunks.map((chunk) => {
            const chunkPoint = mapPosition(chunk.centerX, chunk.centerZ);
            return (
              <rect
                key={chunk.key}
                x={chunkPoint.x - chunkFraction / 2}
                y={chunkPoint.y - chunkFraction / 2}
                width={chunkFraction}
                height={chunkFraction}
                fill="rgba(74,222,128,0.18)"
                stroke="rgba(134,239,172,0.45)"
                strokeWidth="0.22"
              />
            );
          })}
          {entities.map((entity) => {
            const entityPoint = mapPosition(entity.position[0], entity.position[2]);
            const isSelected = selectedEntityIds.includes(entity.entityId);
            return (
              <rect
                key={entity.entityId}
                x={entityPoint.x - 0.45}
                y={entityPoint.y - 0.45}
                width={0.9}
                height={0.9}
                fill={isSelected ? '#34d399' : '#e2e8f0'}
                stroke="#0b1015"
                strokeWidth="0.2"
              />
            );
          })}
          <circle
            cx={cameraPoint.x}
            cy={cameraPoint.y}
            r="2.2"
            fill="#f8fafc"
            stroke="#34d399"
            strokeWidth="0.9"
          />
        </svg>
        <div className="absolute left-2 top-2 rounded-md bg-black/55 px-2 py-1 text-[9px] text-white/70">
          Centro: 0, 0
        </div>
        <div className="absolute right-2 bottom-2 rounded-md bg-black/55 px-2 py-1 text-[9px] text-emerald-200">
          toque = teletransportar
        </div>
      </div>

      <div className="mt-3 grid grid-cols-2 gap-1.5 text-[9px] text-white/55">
        <Legend color="#6ee7b7" label="Chunks carregados" />
        <Legend color="#f8fafc" label="Câmera" />
        <Legend color="#fbbf24" label="Estradas: Fase 5" />
        <Legend color="#e2e8f0" label={`Construções (${entities.length})`} />
      </div>
      <div className="mt-2 text-[9px] leading-relaxed text-white/40">
        Regiões, rios, montanhas e construções serão adicionados conforme os
        dados reais de cada fase forem persistidos.
      </div>
    </aside>
  );
};

const Legend: React.FC<{ color: string; label: string }> = ({
  color,
  label,
}) => (
  <div className="flex items-center gap-1.5">
    <span className="h-2 w-2 rounded-full" style={{ backgroundColor: color }} />
    <span>{label}</span>
  </div>
);
