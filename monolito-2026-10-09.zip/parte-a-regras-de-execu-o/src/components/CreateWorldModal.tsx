import React, { useState } from 'react';
import {
  X,
  Sparkles,
  Dice5,
  Layers,
  Gauge,
  Sliders,
  AlertCircle,
  CheckCircle2,
  Cpu,
} from 'lucide-react';
import { AIProviderManager } from '../ai/AIProviderManager';
import { WorldSizeLabel, WorldPlan } from '../world/types/worldPlan';

interface CreateWorldModalProps {
  isOpen: boolean;
  onClose: () => void;
  onWorldCreated: (plan: WorldPlan, providerUsed: string) => void;
  onOpenProviders: () => void;
}

const PROMPT_PRESETS = [
  {
    title: 'Floresta Amazônica Colossal',
    prompt:
      'Crie uma floresta tropical colossal de 20 km × 20 km, extremamente densa, com rios, montanhas, árvores gigantes, áreas alagadas, neblina volumétrica, chuva tropical, pequenas aldeias abandonadas e uma enorme estrutura futurista parcialmente coberta pela vegetação.',
    size: '20km' as WorldSizeLabel,
    quality: 'high' as const,
  },
  {
    title: 'Megacidade Cyberpunk 50 km',
    prompt:
      'Metrópole vertical futurista de 50 km × 50 km com megatorres de 1.200 m, trens magnéticos suspensos, canais artificiais refletivos, passarelas aéreas, densa fumaça industrial e neblina noturna.',
    size: '50km' as WorldSizeLabel,
    quality: 'ultra' as const,
  },
  {
    title: 'Oceano de Concreto Desolado',
    prompt:
      'Planície infinita de 100 km de lajes de concreto fissuradas, vento uivante, vultos monolíticos de 800 metros no horizonte nebuloso, poças de água rasa e ausência total de vida.',
    size: '100km' as WorldSizeLabel,
    quality: 'medium' as const,
  },
  {
    title: 'Catedral Subterrânea & Viadutos',
    prompt:
      'Complexo monumental subterrâneo com abóbadas ciclópicas de 400 metros de altura, viadutos suspensos em penumbra, feixes de luz clerestorial oblíqua e eco industrial.',
    size: '10km' as WorldSizeLabel,
    quality: 'high' as const,
  },
];

const GENERATION_STEPS = [
  'Planning world...',
  'Generating WorldPlan...',
  'Validating...',
  'Building terrain...',
  'Generating structures...',
  'Streaming regions...',
  'Applying atmosphere...',
  'Generating collisions...',
  'World ready.',
];

export const CreateWorldModal: React.FC<CreateWorldModalProps> = ({
  isOpen,
  onClose,
  onWorldCreated,
  onOpenProviders,
}) => {
  const manager = AIProviderManager.getInstance();
  const activeConfig = manager.getActiveConfig();

  const [worldName, setWorldName] = useState('Amazonas Colossal');
  const [promptText, setPromptText] = useState(PROMPT_PRESETS[0].prompt);
  const [worldSize, setWorldSize] = useState<WorldSizeLabel>('20km');
  const [quality, setQuality] = useState<'preview' | 'low' | 'medium' | 'high' | 'ultra'>('high');
  const [seed, setSeed] = useState<number>(428901);
  const [generationMode, setGenerationMode] = useState<'full' | 'fast' | 'guided'>('full');

  // Generation status state
  const [isGenerating, setIsGenerating] = useState(false);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [statusMessage, setStatusMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleRandomizeSeed = () => {
    setSeed(Math.floor(Math.random() * 900000) + 100000);
  };

  const handleGenerateWorld = async () => {
    if (!promptText.trim()) return;

    setIsGenerating(true);
    setErrorMessage(null);
    setCurrentStepIndex(0);

    // Step progression animation helper
    let stepTimer: number | null = null;
    let step = 0;
    stepTimer = window.setInterval(() => {
      step++;
      if (step < GENERATION_STEPS.length - 2) {
        setCurrentStepIndex(step);
      }
    }, 700);

    try {
      const result = await manager.generateWorldPlanWithFallback(
        {
          worldName: worldName.trim() || 'Mundo Colossal',
          prompt: promptText.trim(),
          worldSize,
          quality,
          seed,
        },
        (msg) => {
          setStatusMessage(msg);
        }
      );

      if (stepTimer) clearInterval(stepTimer);

      // Play final generation steps
      setCurrentStepIndex(GENERATION_STEPS.length - 2);
      await new Promise((r) => setTimeout(r, 400));
      setCurrentStepIndex(GENERATION_STEPS.length - 1);
      await new Promise((r) => setTimeout(r, 500));

      setIsGenerating(false);
      onWorldCreated(result.plan, result.providerUsed);
      onClose();
    } catch (err: unknown) {
      if (stepTimer) clearInterval(stepTimer);
      setIsGenerating(false);
      setErrorMessage((err as Error).message || 'Falha ao gerar o mundo.');
    }
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center p-3 sm:p-6 bg-black/75 backdrop-blur-sm overflow-y-auto select-none">
      <div className="max-w-2xl w-full bg-[#111417] border border-white/10 rounded-2xl shadow-2xl overflow-hidden flex flex-col my-auto">
        {/* Header */}
        <div className="px-6 py-4 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Sparkles className="w-4 h-4 text-white/80" />
            <h2 className="font-display text-2xl text-white tracking-wide">
              Create World
            </h2>
          </div>
          <button
            type="button"
            disabled={isGenerating}
            onClick={onClose}
            className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-white/70 hover:text-white hover:bg-white/10 transition-colors disabled:opacity-40 cursor-pointer"
            aria-label="Fechar modal de criação"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 overflow-y-auto max-h-[75vh]">
          {/* Active Provider Indicator */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-black/40 border border-white/8 text-xs">
            <div className="flex items-center gap-2 text-white/80">
              <Cpu className="w-3.5 h-3.5 text-white/60" />
              <span>Provedor de IA Ativo:</span>
              <span className="font-semibold text-white">
                {activeConfig ? `${activeConfig.name} (${activeConfig.model})` : 'Nenhum provedor ativo'}
              </span>
            </div>
            <button
              type="button"
              onClick={onOpenProviders}
              className="text-white/60 hover:text-white hover:underline transition-colors text-[11px] cursor-pointer"
            >
              Configurar Provedores
            </button>
          </div>

          {/* World Name */}
          <div className="space-y-1.5">
            <label className="block text-xs font-medium text-white/80">
              World Name
            </label>
            <input
              type="text"
              disabled={isGenerating}
              value={worldName}
              onChange={(e) => setWorldName(e.target.value)}
              placeholder="Ex: Amazonas Colossal"
              className="w-full px-3.5 py-2.5 rounded-xl bg-black/35 border border-white/15 text-white text-xs font-medium focus:outline-hidden focus:border-white/40"
            />
          </div>

          {/* Prompt Presets Strip */}
          <div className="space-y-1.5">
            <div className="text-[11px] text-white/50">Inspirações de Mundos Colossais:</div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
              {PROMPT_PRESETS.map((preset) => (
                <button
                  key={preset.title}
                  type="button"
                  disabled={isGenerating}
                  onClick={() => {
                    setWorldName(preset.title);
                    setPromptText(preset.prompt);
                    setWorldSize(preset.size);
                    setQuality(preset.quality);
                  }}
                  className="px-2.5 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/8 text-[11px] text-white/70 hover:text-white truncate transition-colors text-left cursor-pointer"
                >
                  {preset.title}
                </button>
              ))}
            </div>
          </div>

          {/* Prompt */}
          <div className="space-y-1.5">
            <label className="block text-xs font-medium text-white/80">
              Prompt de Síntese Arquitetônica
            </label>
            <textarea
              rows={4}
              disabled={isGenerating}
              value={promptText}
              onChange={(e) => setPromptText(e.target.value)}
              placeholder="Descreva a escala monumental, atmosfera, estruturas, relevo e estilo visual..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-black/35 border border-white/15 text-white text-xs leading-relaxed focus:outline-hidden focus:border-white/40"
            />
          </div>

          {/* World Size (10 km, 20 km, 50 km, 100 km, 500 km) */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs text-white/80">
              <span className="font-medium">Dimensão Lógica do Mundo</span>
              <span className="text-[11px] text-white/50 font-mono-tabular">
                Streaming sob demanda por chunks
              </span>
            </div>
            <div className="grid grid-cols-5 gap-1.5 p-1 bg-black/40 rounded-xl border border-white/10">
              {(['10km', '20km', '50km', '100km', '500km'] as WorldSizeLabel[]).map((s) => (
                <button
                  key={s}
                  type="button"
                  disabled={isGenerating}
                  onClick={() => setWorldSize(s)}
                  className={`py-2 text-xs font-mono-tabular rounded-lg transition-colors cursor-pointer ${
                    worldSize === s
                      ? 'bg-white/20 text-white font-medium'
                      : 'text-white/60 hover:text-white'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          {/* Quality Presets: Preview, Low, Medium, High, Ultra */}
          <div className="space-y-1.5">
            <label className="block text-xs font-medium text-white/80">
              Qualidade &amp; Nível de Detalhe (LOD)
            </label>
            <div className="grid grid-cols-5 gap-1.5 p-1 bg-black/40 rounded-xl border border-white/10">
              {(['preview', 'low', 'medium', 'high', 'ultra'] as const).map((q) => (
                <button
                  key={q}
                  type="button"
                  disabled={isGenerating}
                  onClick={() => setQuality(q)}
                  className={`py-1.5 text-xs capitalize rounded-lg transition-colors cursor-pointer ${
                    quality === q
                      ? 'bg-white/20 text-white font-medium'
                      : 'text-white/60 hover:text-white'
                  }`}
                >
                  {q}
                </button>
              ))}
            </div>
          </div>

          {/* Seed & Generation Mode */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="block text-xs font-medium text-white/80">
                World Seed (Determinismo Procedural)
              </label>
              <div className="flex gap-2">
                <input
                  type="number"
                  disabled={isGenerating}
                  value={seed}
                  onChange={(e) => setSeed(parseInt(e.target.value, 10) || 0)}
                  className="flex-1 px-3 py-2 rounded-xl bg-black/35 border border-white/15 text-white text-xs font-mono-tabular focus:outline-hidden focus:border-white/40"
                />
                <button
                  type="button"
                  disabled={isGenerating}
                  onClick={handleRandomizeSeed}
                  className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs transition-colors flex items-center justify-center cursor-pointer"
                  title="Gerar Seed Aleatória"
                >
                  <Dice5 className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-medium text-white/80">
                Modo de Geração
              </label>
              <select
                disabled={isGenerating}
                value={generationMode}
                onChange={(e) => setGenerationMode(e.target.value as any)}
                className="w-full px-3 py-2 rounded-xl bg-black/35 border border-white/15 text-white text-xs focus:outline-hidden focus:border-white/40"
              >
                <option value="full">Full World Plan (Arquitetura Completa)</option>
                <option value="fast">Fast Prototype (Síntese Rápida)</option>
                <option value="guided">Guided Exploration (Com Portais)</option>
              </select>
            </div>
          </div>

          {/* Live Progress Pipeline Stepper */}
          {isGenerating && (
            <div className="p-4 rounded-xl bg-black/50 border border-white/15 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-white animate-pulse">
                  {GENERATION_STEPS[currentStepIndex]}
                </span>
                <span className="font-mono-tabular text-white/60">
                  {currentStepIndex + 1}/{GENERATION_STEPS.length}
                </span>
              </div>

              {/* Progress Bar */}
              <div className="w-full h-1.5 rounded-full bg-white/10 overflow-hidden">
                <div
                  className="h-full bg-white transition-all duration-300"
                  style={{
                    width: `${((currentStepIndex + 1) / GENERATION_STEPS.length) * 100}%`,
                  }}
                />
              </div>

              {statusMessage && (
                <div className="text-[11px] text-white/60 font-mono-tabular">
                  {statusMessage}
                </div>
              )}
            </div>
          )}

          {/* Error Message */}
          {errorMessage && (
            <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-start gap-2.5 text-xs text-rose-300">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
              <div>
                <div className="font-semibold">Erro na síntese do mundo:</div>
                <div className="mt-0.5">{errorMessage}</div>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 border-t border-white/10 flex items-center justify-between bg-black/25">
          <div className="text-[11px] text-white/50">
            Escala: {worldSize} · Preset: {quality.toUpperCase()}
          </div>
          <div className="flex items-center gap-3">
            <button
              type="button"
              disabled={isGenerating}
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-white/10 text-xs text-white/70 hover:text-white transition-colors cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="button"
              disabled={isGenerating || !promptText.trim()}
              onClick={handleGenerateWorld}
              className="min-h-[44px] px-6 py-2.5 rounded-xl bg-white text-[#0d0f11] font-semibold text-xs tracking-wide hover:bg-white/90 active:scale-98 transition-all disabled:opacity-50 cursor-pointer shadow-lg flex items-center gap-2"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{isGenerating ? 'GENERATING WORLD...' : 'GENERATE WORLD'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
