import React, { useState, useEffect } from 'react';
import {
  X,
  Plus,
  Trash2,
  Edit2,
  CheckCircle2,
  AlertTriangle,
  Clock,
  KeyRound,
  Eye,
  EyeOff,
  Activity,
  Layers,
  Sparkles,
} from 'lucide-react';
import { AIProviderManager } from '../ai/AIProviderManager';
import { AIProviderConfig, ConnectionStatus, ProviderType } from '../ai/types';

interface AIProvidersPanelProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectActiveProvider?: (providerId: string) => void;
}

export const AIProvidersPanel: React.FC<AIProvidersPanelProps> = ({
  isOpen,
  onClose,
  onSelectActiveProvider,
}) => {
  const manager = AIProviderManager.getInstance();
  const [configs, setConfigs] = useState<AIProviderConfig[]>(manager.getConfigs());
  const [activeTab, setActiveTab] = useState<'providers' | 'usage' | 'fallback'>('providers');
  const [editingProvider, setEditingProvider] = useState<AIProviderConfig | null>(null);
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [testingId, setTestingId] = useState<string | null>(null);
  const [showKeyMap, setShowKeyMap] = useState<Record<string, boolean>>({});

  // Form State
  const [formData, setFormData] = useState<Partial<AIProviderConfig>>({
    name: '',
    type: 'gemini',
    endpoint: 'https://generativelanguage.googleapis.com',
    apiKey: '',
    model: 'gemini-3.8-flash',
    priority: 1,
    contextLimit: 128000,
    temperature: 0.7,
    timeoutMs: 45000,
    canGenerateWorlds: true,
    canPlanOnly: false,
    isEnabled: true,
    customFormat: 'openai',
  });

  useEffect(() => {
    const unsubscribe = manager.subscribe(() => {
      setConfigs(manager.getConfigs());
    });
    return unsubscribe;
  }, [manager]);

  if (!isOpen) return null;

  const handleTestConnection = async (id: string) => {
    setTestingId(id);
    try {
      await manager.testProvider(id);
    } finally {
      setTestingId(null);
    }
  };

  const handleStartAdd = () => {
    setFormData({
      name: 'Novo Provedor Personalizado',
      type: 'openai-compatible',
      endpoint: 'http://localhost:11434/v1/chat/completions',
      apiKey: '',
      model: 'llama3.1:latest',
      priority: configs.length + 1,
      contextLimit: 32768,
      temperature: 0.7,
      timeoutMs: 50000,
      canGenerateWorlds: true,
      canPlanOnly: false,
      isEnabled: true,
      customFormat: 'openai',
    });
    setEditingProvider(null);
    setIsAddingNew(true);
  };

  const handleStartEdit = (provider: AIProviderConfig) => {
    setFormData({ ...provider });
    setEditingProvider(provider);
    setIsAddingNew(false);
  };

  const handleSaveForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingProvider) {
      manager.updateProvider(editingProvider.id, formData);
    } else {
      manager.addProvider(formData as Omit<AIProviderConfig, 'id'>);
    }
    setEditingProvider(null);
    setIsAddingNew(false);
  };

  const handleDelete = (id: string) => {
    manager.removeProvider(id);
  };

  const handleTypeChange = (type: ProviderType) => {
    let endpoint = '';
    let model = '';
    if (type === 'gemini') {
      endpoint = 'https://generativelanguage.googleapis.com';
      model = 'gemini-3.8-flash';
    } else if (type === 'openai') {
      endpoint = 'https://api.openai.com/v1/chat/completions';
      model = 'gpt-4o';
    } else if (type === 'anthropic') {
      endpoint = 'https://api.anthropic.com/v1/messages';
      model = 'claude-3-7-sonnet-20250219';
    } else if (type === 'openrouter') {
      endpoint = 'https://openrouter.ai/api/v1/chat/completions';
      model = 'anthropic/claude-3.5-sonnet';
    } else if (type === 'openai-compatible') {
      endpoint = 'http://localhost:11434/v1/chat/completions';
      model = 'llama3.1:latest';
    } else {
      endpoint = 'https://api.mycustomai.com/v1/chat/completions';
      model = 'custom-model';
    }

    setFormData((prev) => ({
      ...prev,
      type,
      endpoint,
      model,
    }));
  };

  const activeProvider = manager.getActiveConfig();
  const usageHistory = manager.getUsageHistory();

  const getStatusBadge = (status?: ConnectionStatus) => {
    switch (status) {
      case 'CONNECTED':
        return (
          <span className="flex items-center gap-1.5 text-xs text-emerald-400 font-medium">
            <CheckCircle2 className="w-3.5 h-3.5" />
            CONNECTED
          </span>
        );
      case 'INVALID_KEY':
        return (
          <span className="flex items-center gap-1.5 text-xs text-rose-400 font-medium">
            <AlertTriangle className="w-3.5 h-3.5" />
            INVALID KEY
          </span>
        );
      case 'TIMEOUT':
        return (
          <span className="flex items-center gap-1.5 text-xs text-amber-400 font-medium">
            <Clock className="w-3.5 h-3.5" />
            TIMEOUT
          </span>
        );
      case 'MODEL_NOT_FOUND':
        return (
          <span className="flex items-center gap-1.5 text-xs text-amber-400 font-medium">
            <AlertTriangle className="w-3.5 h-3.5" />
            MODEL NOT FOUND
          </span>
        );
      case 'ERROR':
        return (
          <span className="flex items-center gap-1.5 text-xs text-rose-400 font-medium">
            <AlertTriangle className="w-3.5 h-3.5" />
            ERROR
          </span>
        );
      default:
        return (
          <span className="text-xs text-white/45">
            UNTESTED
          </span>
        );
    }
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center p-3 sm:p-6 bg-black/75 backdrop-blur-sm overflow-hidden select-none">
      <div className="max-w-4xl w-full h-[90vh] bg-[#111417] border border-white/10 rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-white/10 flex items-center justify-between shrink-0">
          <div>
            <div className="flex items-center gap-3">
              <h2 className="font-display text-2xl text-white tracking-wide">
                AI World Providers
              </h2>
              <span className="text-xs text-white/50 font-mono-tabular">
                {configs.filter((c) => c.isEnabled).length}/{configs.length} ativos
              </span>
            </div>
            <p className="text-xs text-white/60 mt-0.5">
              Conecte qualquer modelo ou endpoint para orquestrar a geração procedural do mundo
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-white/70 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            aria-label="Fechar painel de provedores"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="px-6 py-2.5 bg-black/30 border-b border-white/8 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                setActiveTab('providers');
                setIsAddingNew(false);
                setEditingProvider(null);
              }}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                activeTab === 'providers'
                  ? 'bg-white/15 text-white'
                  : 'text-white/60 hover:text-white'
              }`}
            >
              Provedores &amp; Chaves
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveTab('fallback');
                setIsAddingNew(false);
                setEditingProvider(null);
              }}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                activeTab === 'fallback'
                  ? 'bg-white/15 text-white'
                  : 'text-white/60 hover:text-white'
              }`}
            >
              Cascata de Fallback
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveTab('usage');
                setIsAddingNew(false);
                setEditingProvider(null);
              }}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                activeTab === 'usage'
                  ? 'bg-white/15 text-white'
                  : 'text-white/60 hover:text-white'
              }`}
            >
              Consumo &amp; Auditoria
            </button>
          </div>

          {activeTab === 'providers' && !isAddingNew && !editingProvider && (
            <button
              type="button"
              onClick={handleStartAdd}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-medium transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Adicionar Provedor</span>
            </button>
          )}
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* TAB 1: PROVIDERS LIST OR EDIT FORM */}
          {activeTab === 'providers' && (
            <>
              {isAddingNew || editingProvider ? (
                /* Edit/Add Form */
                <form onSubmit={handleSaveForm} className="space-y-5 max-w-2xl mx-auto">
                  <div className="flex items-center justify-between pb-3 border-b border-white/10">
                    <h3 className="text-sm font-semibold text-white">
                      {isAddingNew ? 'Novo Provedor de IA' : `Editar ${formData.name}`}
                    </h3>
                    <button
                      type="button"
                      onClick={() => {
                        setIsAddingNew(false);
                        setEditingProvider(null);
                      }}
                      className="text-xs text-white/60 hover:text-white cursor-pointer"
                    >
                      Cancelar
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Provider Type */}
                    <div className="space-y-1.5">
                      <label className="block text-xs font-medium text-white/80">
                        Tipo de Provedor
                      </label>
                      <select
                        value={formData.type}
                        onChange={(e) => handleTypeChange(e.target.value as ProviderType)}
                        className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/15 text-white text-xs focus:outline-hidden focus:border-white/40"
                      >
                        <option value="gemini">Google Gemini</option>
                        <option value="openai">OpenAI</option>
                        <option value="anthropic">Anthropic Claude</option>
                        <option value="openrouter">OpenRouter</option>
                        <option value="openai-compatible">Servidor Local (Ollama / vLLM)</option>
                        <option value="custom">Endpoint HTTP Customizado</option>
                      </select>
                    </div>

                    {/* Custom Name */}
                    <div className="space-y-1.5">
                      <label className="block text-xs font-medium text-white/80">
                        Nome Personalizado
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.name || ''}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="Ex: Meu OpenRouter Principal"
                        className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/15 text-white text-xs focus:outline-hidden focus:border-white/40"
                      />
                    </div>
                  </div>

                  {/* Endpoint URL */}
                  <div className="space-y-1.5">
                    <label className="block text-xs font-medium text-white/80">
                      API Endpoint
                    </label>
                    <input
                      type="url"
                      required
                      value={formData.endpoint || ''}
                      onChange={(e) => setFormData({ ...formData, endpoint: e.target.value })}
                      placeholder="https://..."
                      className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/15 text-white text-xs font-mono-tabular focus:outline-hidden focus:border-white/40"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Model */}
                    <div className="space-y-1.5">
                      <label className="block text-xs font-medium text-white/80">
                        Identificador do Modelo
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.model || ''}
                        onChange={(e) => setFormData({ ...formData, model: e.target.value })}
                        placeholder="Ex: gemini-3.8-flash ou gpt-4o"
                        className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/15 text-white text-xs font-mono-tabular focus:outline-hidden focus:border-white/40"
                      />
                    </div>

                    {/* API Key */}
                    <div className="space-y-1.5">
                      <label className="block text-xs font-medium text-white/80 flex items-center justify-between">
                        <span>Chave de API (Armazenamento Seguro)</span>
                        {formData.type === 'gemini' && (
                          <span className="text-[10px] text-emerald-400 font-normal">
                            Injetada automaticamente no AI Studio
                          </span>
                        )}
                      </label>
                      <div className="relative">
                        <input
                          type={showKeyMap['form'] ? 'text' : 'password'}
                          value={formData.apiKey || ''}
                          onChange={(e) => setFormData({ ...formData, apiKey: e.target.value })}
                          placeholder={formData.type === 'gemini' ? 'Opcional se injetada no ambiente' : 'sk-...'}
                          className="w-full px-3 py-2 pr-10 rounded-xl bg-black/40 border border-white/15 text-white text-xs font-mono-tabular focus:outline-hidden focus:border-white/40"
                        />
                        <button
                          type="button"
                          onClick={() => setShowKeyMap((prev) => ({ ...prev, form: !prev.form }))}
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 text-white/40 hover:text-white/80 cursor-pointer"
                        >
                          {showKeyMap['form'] ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Sliders: Priority, Temperature, Timeout */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-1">
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between text-xs text-white/80">
                        <span>Prioridade</span>
                        <span className="font-mono-tabular text-white">{formData.priority}</span>
                      </div>
                      <input
                        type="number"
                        min={1}
                        max={10}
                        value={formData.priority || 1}
                        onChange={(e) => setFormData({ ...formData, priority: parseInt(e.target.value, 10) || 1 })}
                        className="w-full px-3 py-1.5 rounded-xl bg-black/40 border border-white/15 text-white text-xs font-mono-tabular"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between text-xs text-white/80">
                        <span>Temperatura</span>
                        <span className="font-mono-tabular text-white">{formData.temperature}</span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={1}
                        step={0.05}
                        value={formData.temperature ?? 0.7}
                        onChange={(e) => setFormData({ ...formData, temperature: parseFloat(e.target.value) })}
                        className="w-full accent-[#b06c49] cursor-pointer"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between text-xs text-white/80">
                        <span>Timeout</span>
                        <span className="font-mono-tabular text-white">
                          {Math.round((formData.timeoutMs || 45000) / 1000)}s
                        </span>
                      </div>
                      <input
                        type="range"
                        min={10000}
                        max={120000}
                        step={5000}
                        value={formData.timeoutMs || 45000}
                        onChange={(e) => setFormData({ ...formData, timeoutMs: parseInt(e.target.value, 10) })}
                        className="w-full accent-[#b06c49] cursor-pointer"
                      />
                    </div>
                  </div>

                  {/* Capabilities Toggles */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                    <label className="flex items-center gap-2.5 p-3 rounded-xl bg-black/30 border border-white/8 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.canGenerateWorlds ?? true}
                        onChange={(e) => setFormData({ ...formData, canGenerateWorlds: e.target.checked })}
                        className="rounded border-white/20 text-[#b06c49] focus:ring-0"
                      />
                      <div>
                        <div className="text-xs font-medium text-white">Pode Gerar Mundos Completos</div>
                        <div className="text-[11px] text-white/50">Habilita síntese de novos WorldPlans de larga escala</div>
                      </div>
                    </label>

                    <label className="flex items-center gap-2.5 p-3 rounded-xl bg-black/30 border border-white/8 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.canPlanOnly ?? false}
                        onChange={(e) => setFormData({ ...formData, canPlanOnly: e.target.checked })}
                        className="rounded border-white/20 text-[#b06c49] focus:ring-0"
                      />
                      <div>
                        <div className="text-xs font-medium text-white">Apenas Planejamento</div>
                        <div className="text-[11px] text-white/50">Restringe o modelo a alterações semânticas</div>
                      </div>
                    </label>
                  </div>

                  <div className="pt-3 flex items-center justify-end gap-3">
                    <button
                      type="button"
                      onClick={() => {
                        setIsAddingNew(false);
                        setEditingProvider(null);
                      }}
                      className="px-4 py-2 rounded-xl border border-white/10 text-xs text-white/70 hover:text-white transition-colors cursor-pointer"
                    >
                      Cancelar
                    </button>
                    <button
                      type="submit"
                      className="px-6 py-2 rounded-xl bg-white text-[#0d0f11] text-xs font-semibold hover:bg-white/90 transition-colors cursor-pointer"
                    >
                      {editingProvider ? 'Salvar Alterações' : 'Adicionar Provedor'}
                    </button>
                  </div>
                </form>
              ) : (
                /* Providers List */
                <div className="space-y-3">
                  {configs.map((provider) => {
                    const isCurrent = activeProvider?.id === provider.id;
                    const isTesting = testingId === provider.id;

                    return (
                      <div
                        key={provider.id}
                        className={`p-4 rounded-xl border transition-all ${
                          isCurrent
                            ? 'bg-white/8 border-white/30'
                            : 'bg-black/30 border-white/8 hover:border-white/15'
                        }`}
                      >
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-semibold text-white">
                                {provider.name}
                              </span>
                              {isCurrent && (
                                <span className="text-[10px] text-emerald-400 font-mono-tabular">
                                  · ATIVO
                                </span>
                              )}
                              <span className="text-[11px] text-white/45 font-mono-tabular">
                                Prioridade {provider.priority}
                              </span>
                            </div>

                            {/* Clean unboxed metadata */}
                            <div className="flex items-center gap-2 text-xs text-white/50 font-mono-tabular">
                              <span>{provider.type.toUpperCase()}</span>
                              <span aria-hidden="true">·</span>
                              <span>{provider.model}</span>
                              <span aria-hidden="true">·</span>
                              <span>Timeout {Math.round(provider.timeoutMs / 1000)}s</span>
                              <span aria-hidden="true">·</span>
                              <span>Temp {provider.temperature}</span>
                            </div>

                            {/* Masked API Key readout */}
                            <div className="flex items-center gap-1.5 text-[11px] text-white/40 font-mono-tabular">
                              <KeyRound className="w-3 h-3" />
                              <span>
                                {provider.apiKey
                                  ? showKeyMap[provider.id]
                                    ? provider.apiKey
                                    : '••••••••••••••••'
                                  : provider.type === 'gemini'
                                  ? 'Chave do ambiente injetada (AI Studio Secrets)'
                                  : 'Nenhuma chave inserida'}
                              </span>
                              {provider.apiKey && (
                                <button
                                  type="button"
                                  onClick={() =>
                                    setShowKeyMap((prev) => ({
                                      ...prev,
                                      [provider.id]: !prev[provider.id],
                                    }))
                                  }
                                  className="text-white/40 hover:text-white/70 ml-1 cursor-pointer"
                                >
                                  {showKeyMap[provider.id] ? (
                                    <EyeOff className="w-3 h-3" />
                                  ) : (
                                    <Eye className="w-3 h-3" />
                                  )}
                                </button>
                              )}
                            </div>
                          </div>

                          {/* Action Buttons */}
                          <div className="flex items-center gap-2 self-end sm:self-center">
                            {/* Status */}
                            <div className="mr-2">
                              {getStatusBadge(provider.lastTestedStatus)}
                            </div>

                            {/* Test Connection Button */}
                            <button
                              type="button"
                              disabled={isTesting}
                              onClick={() => handleTestConnection(provider.id)}
                              className="px-3 py-1.5 rounded-lg bg-black/40 border border-white/15 text-xs text-white/80 hover:text-white hover:bg-black/60 transition-colors disabled:opacity-50 cursor-pointer"
                            >
                              {isTesting ? 'Testando...' : 'Test Connection'}
                            </button>

                            {/* Select as Active */}
                            <button
                              type="button"
                              onClick={() => {
                                manager.setActiveProvider(provider.id);
                                onSelectActiveProvider?.(provider.id);
                              }}
                              disabled={!provider.isEnabled}
                              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                                isCurrent
                                  ? 'bg-white text-[#0d0f11]'
                                  : 'bg-white/10 text-white hover:bg-white/20 disabled:opacity-30'
                              }`}
                            >
                              {isCurrent ? 'Selecionado' : 'Usar'}
                            </button>

                            {/* Edit */}
                            <button
                              type="button"
                              onClick={() => handleStartEdit(provider)}
                              className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-lg bg-white/5 hover:bg-white/15 text-white/70 hover:text-white transition-colors cursor-pointer"
                              title="Editar configurações do provedor"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>

                            {/* Delete (prevent deleting default gemini) */}
                            {provider.id !== 'provider_gemini' && (
                              <button
                                type="button"
                                onClick={() => handleDelete(provider.id)}
                                className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-lg bg-rose-500/10 hover:bg-rose-500/25 text-rose-400 hover:text-rose-300 transition-colors cursor-pointer"
                                title="Remover provedor"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </div>

                        {/* Test details if exists */}
                        {provider.lastTestMessage && (
                          <div className="mt-2.5 pt-2 border-t border-white/6 flex items-center justify-between text-[11px] text-white/50">
                            <span>{provider.lastTestMessage}</span>
                            {provider.lastLatencyMs !== undefined && (
                              <span className="font-mono-tabular">{provider.lastLatencyMs} ms</span>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </>
          )}

          {/* TAB 2: FALLBACK CASCADE */}
          {activeTab === 'fallback' && (
            <div className="space-y-5 max-w-2xl mx-auto">
              <div className="space-y-1">
                <h3 className="text-sm font-semibold text-white">
                  Ordem da Cascata de Fallback Automático
                </h3>
                <p className="text-xs text-white/60">
                  Se o provedor primário falhar, sofrer timeout ou tiver a cota esgotada, o sistema aciona os provedores subsequentes na ordem de prioridade definida abaixo:
                </p>
              </div>

              <div className="space-y-2">
                {configs
                  .filter((c) => c.isEnabled)
                  .map((provider, idx) => (
                    <div
                      key={provider.id}
                      className="p-3.5 rounded-xl bg-black/35 border border-white/10 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-3">
                        <span className="w-6 h-6 rounded-full bg-white/10 text-white text-xs font-mono-tabular flex items-center justify-center">
                          {idx + 1}
                        </span>
                        <div>
                          <div className="text-xs font-semibold text-white">
                            {provider.name}
                            {idx === 0 && (
                              <span className="text-[10px] text-emerald-400 font-mono-tabular ml-2">
                                (PRIMÁRIO)
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-white/50 font-mono-tabular">
                            {provider.type.toUpperCase()} · {provider.model} · Timeout {Math.round(provider.timeoutMs / 1000)}s
                          </div>
                        </div>
                      </div>
                      <div className="text-xs text-white/60">
                        {getStatusBadge(provider.lastTestedStatus)}
                      </div>
                    </div>
                  ))}
              </div>

              <div className="p-3.5 rounded-xl bg-white/4 border border-white/10 text-xs text-white/60 space-y-1">
                <div className="font-medium text-white/80">Regra de Segurança:</div>
                <p>
                  A chave de cada provedor é transmitida exclusivamente para o endpoint configurado. Nenhuma chave de API jamais é compartilhada entre provedores ou gravada em logs públicos.
                </p>
              </div>
            </div>
          )}

          {/* TAB 3: USAGE & AUDIT LOGS */}
          {activeTab === 'usage' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-semibold text-white">
                    Histórico de Chamadas &amp; Auditoria de Custos
                  </h3>
                  <p className="text-xs text-white/55">
                    Registro de requisições, latências, tokens e estimativas de custo reportadas
                  </p>
                </div>
                {usageHistory.length > 0 && (
                  <button
                    type="button"
                    onClick={() => manager.clearUsageHistory()}
                    className="px-3 py-1.5 rounded-lg border border-white/10 text-xs text-white/60 hover:text-white transition-colors cursor-pointer"
                  >
                    Limpar Histórico
                  </button>
                )}
              </div>

              {usageHistory.length === 0 ? (
                <div className="p-8 text-center border border-dashed border-white/15 rounded-xl text-white/40 text-xs">
                  Nenhuma chamada registrada até o momento. Gere um mundo ou teste uma conexão para popular a telemetria.
                </div>
              ) : (
                <div className="border border-white/10 rounded-xl overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-black/40 text-white/50 border-b border-white/10">
                      <tr>
                        <th className="px-3 py-2.5 font-medium">Horário</th>
                        <th className="px-3 py-2.5 font-medium">Provedor</th>
                        <th className="px-3 py-2.5 font-medium">Modelo</th>
                        <th className="px-3 py-2.5 font-medium">Ação</th>
                        <th className="px-3 py-2.5 font-medium">Tokens</th>
                        <th className="px-3 py-2.5 font-medium">Custo Estimado</th>
                        <th className="px-3 py-2.5 font-medium">Tempo</th>
                        <th className="px-3 py-2.5 font-medium">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/6 text-white/80 font-mono-tabular">
                      {usageHistory.map((rec) => (
                        <tr key={rec.id} className="hover:bg-white/4">
                          <td className="px-3 py-2.5 text-white/50">
                            {new Date(rec.timestamp).toLocaleTimeString()}
                          </td>
                          <td className="px-3 py-2.5 font-sans font-medium text-white">
                            {rec.providerName}
                          </td>
                          <td className="px-3 py-2.5 text-white/70">{rec.model}</td>
                          <td className="px-3 py-2.5 text-white/60 capitalize">
                            {rec.action.replace('_', ' ')}
                          </td>
                          <td className="px-3 py-2.5">{rec.totalTokens}</td>
                          <td className="px-3 py-2.5 text-white/70">{rec.estimatedCost}</td>
                          <td className="px-3 py-2.5">{rec.durationMs} ms</td>
                          <td className="px-3 py-2.5">
                            {rec.success ? (
                              <span className="text-emerald-400">OK</span>
                            ) : (
                              <span className="text-rose-400" title={rec.error}>
                                ERRO
                              </span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
