import React, {
  ChangeEvent,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import {
  AlertTriangle,
  Boxes,
  CheckCircle2,
  Copy,
  Download,
  Eye,
  FileUp,
  Globe2,
  Info,
  PackageOpen,
  Pencil,
  Plus,
  Save,
  Search,
  Trash2,
  X,
} from 'lucide-react';
import { creatorStorage } from '../creator/CreatorStorage';
import {
  CreatorAssetDescriptor,
  CreatorClimate,
  CreatorNewWorldInput,
  CreatorObjectDensity,
  CreatorQuality,
  CreatorTerrainType,
  CreatorWorld,
  CreatorWorldSettings,
  CreatorWorldSizeMeters,
  CreatorWorldStyle,
} from '../creator/types';
import { CreatorViewport } from './CreatorViewport';

interface CreatorWorldsPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

type CreatorPanelTab = 'worlds' | 'assets';

const DEFAULT_SETTINGS: CreatorWorldSettings = {
  style: 'realista',
  terrain: 'plano',
  climate: 'temperado',
  objectDensity: 'media',
  quality: 'equilibrado',
};

const WORLD_SIZE_OPTIONS: Array<{
  value: CreatorWorldSizeMeters;
  label: string;
}> = [
  { value: 10000, label: '10 km × 10 km' },
  { value: 20000, label: '20 km × 20 km' },
  { value: 50000, label: '50 km × 50 km' },
];

const ASSET_CATEGORY_LABELS: Record<string, string> = {
  terreno: 'Terreno',
  estradas: 'Estradas',
  edificios: 'Edifícios',
  casas: 'Casas',
  comercio: 'Comércio',
  industria: 'Indústria',
  infraestrutura: 'Infraestrutura',
  vegetacao: 'Vegetação',
  decoracao: 'Decoração',
  veiculos: 'Veículos',
  futurista: 'Futurista',
};

const CONTROL_CLASS =
  'w-full min-h-[44px] rounded-xl border border-white/15 bg-black/35 px-3 py-2 text-sm text-white outline-none focus:border-white/45';

export const CreatorWorldsPanel: React.FC<CreatorWorldsPanelProps> = ({
  isOpen,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<CreatorPanelTab>('worlds');
  const [worlds, setWorlds] = useState<CreatorWorld[]>([]);
  const [assets, setAssets] = useState<CreatorAssetDescriptor[]>([]);
  const [selectedWorldId, setSelectedWorldId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [deleteCandidateId, setDeleteCandidateId] = useState<string | null>(null);
  const [editingWorld, setEditingWorld] = useState<CreatorWorld | null>(null);
  const [assetSearch, setAssetSearch] = useState('');
  const [newWorld, setNewWorld] = useState<CreatorNewWorldInput>({
    name: 'Meu Novo Mundo',
    description: '',
    sizeMeters: 10000,
    seed: 104729,
    settings: { ...DEFAULT_SETTINGS },
  });
  const [editedName, setEditedName] = useState('');
  const [editedDescription, setEditedDescription] = useState('');
  const [editedSettings, setEditedSettings] =
    useState<CreatorWorldSettings>(DEFAULT_SETTINGS);

  const worldFileInputRef = useRef<HTMLInputElement | null>(null);
  const assetFileInputRef = useRef<HTMLInputElement | null>(null);

  const selectedWorld = useMemo(
    () => worlds.find((world) => world.id === selectedWorldId) ?? null,
    [selectedWorldId, worlds]
  );

  const filteredAssets = useMemo(() => {
    const normalizedSearch = assetSearch.trim().toLocaleLowerCase();
    if (!normalizedSearch) return assets;
    return assets.filter((asset) =>
      `${asset.name} ${asset.category} ${asset.id}`
        .toLocaleLowerCase()
        .includes(normalizedSearch)
    );
  }, [assetSearch, assets]);

  const refreshWorlds = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const storedWorlds = await creatorStorage.listWorlds();
      setWorlds(storedWorlds);
      setSelectedWorldId((currentId) => {
        if (currentId && storedWorlds.some((world) => world.id === currentId)) {
          return currentId;
        }
        return storedWorlds[0]?.id ?? null;
      });
    } catch (refreshError) {
      setError(readErrorMessage(refreshError));
    } finally {
      setIsLoading(false);
    }
  }, []);

  const refreshAssets = useCallback(async () => {
    try {
      setAssets(await creatorStorage.listAssets());
    } catch (refreshError) {
      setError(readErrorMessage(refreshError));
    }
  }, []);

  useEffect(() => {
    if (!isOpen) return;
    setNotice(null);
    setError(null);
    void refreshWorlds();
    void refreshAssets();
  }, [isOpen, refreshAssets, refreshWorlds]);

  useEffect(() => {
    if (!selectedWorld) return;
    setEditedName(selectedWorld.name);
    setEditedDescription(selectedWorld.description);
    setEditedSettings({ ...selectedWorld.settings });
    setDeleteCandidateId(null);
  }, [selectedWorld]);

  const handleEnterViewport = useCallback(() => {
    if (!selectedWorld) return;
    setNotice(null);
    setError(null);
    setEditingWorld(selectedWorld);
  }, [selectedWorld]);

  const handleViewportExit = useCallback(
    async (updatedWorld: CreatorWorld) => {
      setEditingWorld(null);
      setIsLoading(true);
      setError(null);
      setNotice(null);
      try {
        await creatorStorage.saveWorld(updatedWorld);
        await refreshWorlds();
        setSelectedWorldId(updatedWorld.id);
        setNotice(
          `Câmera de "${updatedWorld.name}" salva no IndexedDB: X ${Math.round(
            updatedWorld.lastEditor.position[0]
          )} · Z ${Math.round(
            updatedWorld.lastEditor.position[2]
          )} · ${updatedWorld.savedPoints.length} ponto(s).`
        );
      } catch (saveError) {
        setError(readErrorMessage(saveError));
      } finally {
        setIsLoading(false);
      }
    },
    [refreshWorlds]
  );

  const handleCreateWorld = async (event: React.FormEvent) => {
    event.preventDefault();
    setIsLoading(true);
    setError(null);
    setNotice(null);
    try {
      const createdWorld = await creatorStorage.createWorld(newWorld);
      await refreshWorlds();
      setSelectedWorldId(createdWorld.id);
      setShowCreateForm(false);
      setNotice(`Mundo "${createdWorld.name}" criado e persistido no IndexedDB.`);
      setNewWorld((currentWorld) => ({
        ...currentWorld,
        name: 'Meu Novo Mundo',
        description: '',
        seed: Math.floor(Math.random() * 900000) + 100000,
      }));
    } catch (createError) {
      setError(readErrorMessage(createError));
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveDetails = async () => {
    if (!selectedWorld) return;
    setIsLoading(true);
    setError(null);
    setNotice(null);
    try {
      const currentWorld = await creatorStorage.getWorld(selectedWorld.id);
      if (!currentWorld) throw new Error('O mundo selecionado não existe mais.');
      currentWorld.name = editedName.trim() || currentWorld.name;
      currentWorld.description = editedDescription.trim();
      currentWorld.settings = { ...editedSettings };
      currentWorld.metadata.updatedAt = Date.now();
      currentWorld.metadata.revision += 1;
      await creatorStorage.saveWorld(currentWorld);
      await refreshWorlds();
      setSelectedWorldId(currentWorld.id);
      setNotice('Nome, descrição e configurações salvos.');
    } catch (saveError) {
      setError(readErrorMessage(saveError));
    } finally {
      setIsLoading(false);
    }
  };

  const handleDuplicateWorld = async () => {
    if (!selectedWorld) return;
    setIsLoading(true);
    setError(null);
    setNotice(null);
    try {
      const duplicatedWorld = await creatorStorage.duplicateWorld(
        selectedWorld.id
      );
      await refreshWorlds();
      setSelectedWorldId(duplicatedWorld.id);
      setNotice(`Duplicação criada: ${duplicatedWorld.name}.`);
    } catch (duplicateError) {
      setError(readErrorMessage(duplicateError));
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteWorld = async () => {
    if (!selectedWorld || deleteCandidateId !== selectedWorld.id) return;
    setIsLoading(true);
    setError(null);
    setNotice(null);
    try {
      await creatorStorage.deleteWorld(selectedWorld.id);
      setDeleteCandidateId(null);
      await refreshWorlds();
      setNotice('Mundo excluído definitivamente.');
    } catch (deleteError) {
      setError(readErrorMessage(deleteError));
    } finally {
      setIsLoading(false);
    }
  };

  const handleExportWorld = async () => {
    if (!selectedWorld) return;
    setError(null);
    try {
      const serializedWorld = await creatorStorage.exportWorld(selectedWorld.id);
      downloadText(
        `${slugify(selectedWorld.name)}.monolito-world.json`,
        serializedWorld,
        'application/json'
      );
      setNotice('Arquivo de mundo exportado.');
    } catch (exportError) {
      setError(readErrorMessage(exportError));
    }
  };

  const handleImportWorld = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    setIsLoading(true);
    setError(null);
    setNotice(null);
    try {
      const importedWorld = await creatorStorage.importWorld(
        await file.text()
      );
      await refreshWorlds();
      setSelectedWorldId(importedWorld.id);
      setNotice(`Mundo importado: ${importedWorld.name}.`);
    } catch (importError) {
      setError(readErrorMessage(importError));
    } finally {
      setIsLoading(false);
    }
  };

  const handleImportAssets = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    setIsLoading(true);
    setError(null);
    setNotice(null);
    try {
      const importedAssets = await creatorStorage.importAssets(
        await file.text()
      );
      await refreshAssets();
      setNotice(`${importedAssets.length} asset(s) importado(s).`);
    } catch (importError) {
      setError(readErrorMessage(importError));
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  if (editingWorld) {
    return (
      <CreatorViewport
        world={editingWorld}
        onExit={(updatedWorld) => void handleViewportExit(updatedWorld)}
      />
    );
  }

  return (
    <div className="fixed inset-0 z-45 bg-[#080b0e]/97 backdrop-blur-sm overflow-y-auto select-none">
      <div className="min-h-full w-full max-w-7xl mx-auto p-3 sm:p-6">
        <div className="rounded-2xl border border-white/12 bg-[#11151a]/98 shadow-2xl overflow-hidden">
          <header className="px-4 py-4 sm:px-6 border-b border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2 text-emerald-300">
                <Globe2 className="w-5 h-5" />
                <span className="text-xs font-semibold tracking-[0.22em] uppercase">
                  Simulador de Construção de Mundos
                </span>
              </div>
              <h1 className="font-display text-2xl sm:text-3xl text-white mt-1">
                CRIADOR DE MUNDOS
              </h1>
              <p className="text-xs text-white/50 mt-1">
                Modo de construção e espectador · sem personagem jogável
              </p>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="self-start min-h-[44px] min-w-[44px] rounded-xl border border-white/15 bg-black/30 text-white/75 hover:text-white hover:bg-white/10 flex items-center justify-center cursor-pointer"
              aria-label="Fechar Criador de Mundos"
            >
              <X className="w-5 h-5" />
            </button>
          </header>

          <div className="p-3 sm:p-5 space-y-4">
            <div className="grid grid-cols-2 gap-2 p-1 rounded-xl border border-white/10 bg-black/30">
              <button
                type="button"
                onClick={() => setActiveTab('worlds')}
                className={`min-h-[44px] rounded-lg text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer ${
                  activeTab === 'worlds'
                    ? 'bg-white text-[#0c1014]'
                    : 'text-white/55 hover:text-white'
                }`}
              >
                <Globe2 className="w-4 h-4" />
                MUNDOS ({worlds.length})
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('assets')}
                className={`min-h-[44px] rounded-lg text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer ${
                  activeTab === 'assets'
                    ? 'bg-white text-[#0c1014]'
                    : 'text-white/55 hover:text-white'
                }`}
              >
                <Boxes className="w-4 h-4" />
                BIBLIOTECA DE ASSETS ({assets.length})
              </button>
            </div>

            {(notice || error) && (
              <div
                className={`rounded-xl border px-4 py-3 text-xs flex items-start gap-2 ${
                  error
                    ? 'border-rose-400/35 bg-rose-500/10 text-rose-100'
                    : 'border-emerald-400/30 bg-emerald-500/10 text-emerald-100'
                }`}
                role="status"
              >
                {error ? (
                  <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                ) : (
                  <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
                )}
                <span>{error ?? notice}</span>
              </div>
            )}

            {isLoading && (
              <div className="text-xs text-white/55 font-mono-tabular">
                Salvando alterações reais no IndexedDB...
              </div>
            )}

            {activeTab === 'worlds' ? (
              <div className="grid lg:grid-cols-[340px_minmax(0,1fr)] gap-4">
                <section className="space-y-3">
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setShowCreateForm((visible) => !visible)}
                      className="min-h-[46px] rounded-xl bg-white text-[#0c1014] text-xs font-bold flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Plus className="w-4 h-4" />
                      NOVO MUNDO
                    </button>
                    <button
                      type="button"
                      onClick={() => worldFileInputRef.current?.click()}
                      className="min-h-[46px] rounded-xl border border-white/20 bg-white/5 text-white text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <FileUp className="w-4 h-4" />
                      IMPORTAR
                    </button>
                  </div>

                  <input
                    ref={worldFileInputRef}
                    type="file"
                    accept=".json,application/json"
                    className="hidden"
                    onChange={handleImportWorld}
                  />

                  {showCreateForm && (
                    <form
                      onSubmit={handleCreateWorld}
                      className="rounded-2xl border border-white/15 bg-white/5 p-4 space-y-3"
                    >
                      <div className="text-xs font-semibold text-white uppercase tracking-wider">
                        Criar novo mundo
                      </div>
                      <label className="block space-y-1">
                        <span className="text-[11px] text-white/55">
                          NOME DO MUNDO
                        </span>
                        <input
                          required
                          value={newWorld.name}
                          onChange={(event) =>
                            setNewWorld((world) => ({
                              ...world,
                              name: event.target.value,
                            }))
                          }
                          className={CONTROL_CLASS}
                        />
                      </label>
                      <label className="block space-y-1">
                        <span className="text-[11px] text-white/55">
                          DESCRIÇÃO
                        </span>
                        <textarea
                          rows={2}
                          value={newWorld.description}
                          onChange={(event) =>
                            setNewWorld((world) => ({
                              ...world,
                              description: event.target.value,
                            }))
                          }
                          className={`${CONTROL_CLASS} resize-y`}
                        />
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        <label className="block space-y-1">
                          <span className="text-[11px] text-white/55">
                            TAMANHO
                          </span>
                          <select
                            value={newWorld.sizeMeters}
                            onChange={(event) =>
                              setNewWorld((world) => ({
                                ...world,
                                sizeMeters: Number(
                                  event.target.value
                                ) as CreatorWorldSizeMeters,
                              }))
                            }
                            className={CONTROL_CLASS}
                          >
                            {WORLD_SIZE_OPTIONS.map((sizeOption) => (
                              <option
                                key={sizeOption.value}
                                value={sizeOption.value}
                              >
                                {sizeOption.label}
                              </option>
                            ))}
                          </select>
                        </label>
                        <label className="block space-y-1">
                          <span className="text-[11px] text-white/55">SEED</span>
                          <input
                            type="number"
                            min={1}
                            value={newWorld.seed}
                            onChange={(event) =>
                              setNewWorld((world) => ({
                                ...world,
                                seed: Number(event.target.value),
                              }))
                            }
                            className={CONTROL_CLASS}
                          />
                        </label>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <SelectField
                          label="ESTILO VISUAL"
                          value={newWorld.settings.style}
                          options={STYLE_OPTIONS}
                          onChange={(value) =>
                            updateNewSettings('style', value as CreatorWorldStyle)
                          }
                        />
                        <SelectField
                          label="TIPO DE TERRENO"
                          value={newWorld.settings.terrain}
                          options={TERRAIN_OPTIONS}
                          onChange={(value) =>
                            updateNewSettings(
                              'terrain',
                              value as CreatorTerrainType
                            )
                          }
                        />
                        <SelectField
                          label="CLIMA"
                          value={newWorld.settings.climate}
                          options={CLIMATE_OPTIONS}
                          onChange={(value) =>
                            updateNewSettings(
                              'climate',
                              value as CreatorClimate
                            )
                          }
                        />
                        <SelectField
                          label="DENSIDADE DE OBJETOS"
                          value={newWorld.settings.objectDensity}
                          options={DENSITY_OPTIONS}
                          onChange={(value) =>
                            updateNewSettings(
                              'objectDensity',
                              value as CreatorObjectDensity
                            )
                          }
                        />
                        <SelectField
                          label="QUALIDADE GRÁFICA"
                          value={newWorld.settings.quality}
                          options={QUALITY_OPTIONS}
                          onChange={(value) =>
                            updateNewSettings(
                              'quality',
                              value as CreatorQuality
                            )
                          }
                        />
                      </div>
                      <button
                        type="submit"
                        disabled={isLoading}
                        className="w-full min-h-[46px] rounded-xl bg-emerald-400 text-[#07110d] text-xs font-bold cursor-pointer disabled:opacity-50"
                      >
                        CRIAR E SALVAR MUNDO
                      </button>
                    </form>
                  )}

                  <div className="space-y-2 max-h-[52vh] overflow-y-auto pr-1">
                    {worlds.length === 0 ? (
                      <div className="rounded-xl border border-dashed border-white/20 p-6 text-center text-xs text-white/45">
                        Nenhum mundo criado ainda.
                      </div>
                    ) : (
                      worlds.map((world) => (
                        <button
                          key={world.id}
                          type="button"
                          onClick={() => setSelectedWorldId(world.id)}
                          className={`w-full text-left rounded-xl border p-3 transition-colors cursor-pointer ${
                            world.id === selectedWorldId
                              ? 'border-emerald-300/50 bg-emerald-400/10'
                              : 'border-white/10 bg-white/4 hover:bg-white/8'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-sm font-semibold text-white truncate">
                              {world.name}
                            </span>
                            <span className="text-[10px] text-white/45 shrink-0">
                              {world.sizeMeters / 1000} km
                            </span>
                          </div>
                          <div className="text-[11px] text-white/50 truncate mt-1">
                            {world.description || 'Sem descrição'}
                          </div>
                          <div className="text-[10px] text-white/35 font-mono-tabular mt-1">
                            rev {world.metadata.revision} ·{' '}
                            {formatTimestamp(world.metadata.updatedAt)}
                          </div>
                        </button>
                      ))
                    )}
                  </div>
                </section>

                <section className="rounded-2xl border border-white/12 bg-black/20 p-4 sm:p-5">
                  {!selectedWorld ? (
                    <div className="min-h-[360px] flex flex-col items-center justify-center text-center gap-3 text-white/45">
                      <Info className="w-7 h-7" />
                      <p className="text-sm">Selecione ou crie um mundo.</p>
                    </div>
                  ) : (
                    <div className="space-y-5">
                      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                        <div>
                          <p className="text-[11px] text-emerald-300 tracking-widest uppercase">
                            Mundo selecionado
                          </p>
                          <h2 className="font-display text-2xl text-white mt-1">
                            {selectedWorld.name}
                          </h2>
                          <p className="text-xs text-white/55 mt-1">
                            {selectedWorld.description || 'Sem descrição'}
                          </p>
                        </div>
                        <div className="text-[10px] text-white/40 font-mono-tabular sm:text-right">
                          <div>ID: {selectedWorld.id}</div>
                          <div>FORMATO: v{selectedWorld.formatVersion}</div>
                          <div>CHUNK: {selectedWorld.chunkSizeMeters} m</div>
                          <div>DELTA CHUNKS: {Object.keys(selectedWorld.chunkDeltas).length}</div>
                        </div>
                      </div>

                      <div className="rounded-xl border border-emerald-300/25 bg-emerald-300/8 px-4 py-3 text-xs text-emerald-100 space-y-3">
                        <div>
                          <strong>CÂMERA LIVRE — IMPLEMENTADO (FASE 2).</strong>{' '}
                          Streaming de chunks por perto da câmera, floating origin
                          e retomada exata do ponto de construção. Nenhum
                          personagem jogável é criado.
                        </div>
                        <button
                          type="button"
                          onClick={handleEnterViewport}
                          className="w-full min-h-[48px] rounded-xl bg-emerald-300 text-[#07110d] text-xs font-bold flex items-center justify-center gap-2 cursor-pointer"
                        >
                          <Eye className="w-4 h-4" />
                          ENTRAR NO MUNDO
                        </button>
                        <div className="text-[10px] text-white/50 leading-relaxed">
                          Seleção de grade e edição de objetos: NÃO IMPLEMENTADO —
                          FASE 3.
                        </div>
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                        <button
                          type="button"
                          onClick={handleDuplicateWorld}
                          disabled={isLoading}
                          className="min-h-[44px] rounded-xl border border-white/15 bg-white/5 text-white text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                        >
                          <Copy className="w-4 h-4" />
                          DUPLICAR
                        </button>
                        <button
                          type="button"
                          onClick={handleExportWorld}
                          disabled={isLoading}
                          className="min-h-[44px] rounded-xl border border-white/15 bg-white/5 text-white text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                        >
                          <Download className="w-4 h-4" />
                          EXPORTAR
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            setDeleteCandidateId((candidateId) =>
                              candidateId === selectedWorld.id
                                ? null
                                : selectedWorld.id
                            )
                          }
                          className={`min-h-[44px] rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer ${
                            deleteCandidateId === selectedWorld.id
                              ? 'border-rose-400 bg-rose-500/20 text-rose-100'
                              : 'border-rose-400/30 bg-rose-500/5 text-rose-200'
                          }`}
                        >
                          <Trash2 className="w-4 h-4" />
                          {deleteCandidateId === selectedWorld.id
                            ? 'CONFIRMAR EXCLUSÃO'
                            : 'EXCLUIR'}
                        </button>
                      </div>

                      {deleteCandidateId === selectedWorld.id && (
                        <button
                          type="button"
                          onClick={handleDeleteWorld}
                          className="w-full min-h-[44px] rounded-xl bg-rose-500 text-white text-xs font-bold cursor-pointer"
                        >
                          EXCLUIR "{selectedWorld.name}" DEFINITIVAMENTE
                        </button>
                      )}

                      <form
                        onSubmit={(event) => {
                          event.preventDefault();
                          void handleSaveDetails();
                        }}
                        className="rounded-2xl border border-white/12 bg-white/4 p-4 space-y-3"
                      >
                        <div className="flex items-center gap-2 text-xs font-semibold text-white uppercase tracking-wider">
                          <Pencil className="w-4 h-4 text-emerald-300" />
                          Editar mundo
                        </div>
                        <div className="grid sm:grid-cols-2 gap-3">
                          <label className="block space-y-1">
                            <span className="text-[11px] text-white/55">
                              NOME
                            </span>
                            <input
                              required
                              value={editedName}
                              onChange={(event) =>
                                setEditedName(event.target.value)
                              }
                              className={CONTROL_CLASS}
                            />
                          </label>
                          <div className="space-y-1">
                            <span className="text-[11px] text-white/55 block">
                              TAMANHO / SEED
                            </span>
                            <div
                              className={`${CONTROL_CLASS} flex items-center text-white/60`}
                            >
                              {selectedWorld.sizeMeters / 1000} km · seed{' '}
                              {selectedWorld.seed}
                            </div>
                          </div>
                        </div>
                        <label className="block space-y-1">
                          <span className="text-[11px] text-white/55">
                            DESCRIÇÃO
                          </span>
                          <textarea
                            rows={3}
                            value={editedDescription}
                            onChange={(event) =>
                              setEditedDescription(event.target.value)
                            }
                            className={`${CONTROL_CLASS} resize-y`}
                          />
                        </label>
                        <div className="grid sm:grid-cols-2 gap-3">
                          <SelectField
                            label="ESTILO VISUAL"
                            value={editedSettings.style}
                            options={STYLE_OPTIONS}
                            onChange={(value) =>
                              setEditedSettings((settings) => ({
                                ...settings,
                                style: value as CreatorWorldStyle,
                              }))
                            }
                          />
                          <SelectField
                            label="TIPO DE TERRENO"
                            value={editedSettings.terrain}
                            options={TERRAIN_OPTIONS}
                            onChange={(value) =>
                              setEditedSettings((settings) => ({
                                ...settings,
                                terrain: value as CreatorTerrainType,
                              }))
                            }
                          />
                          <SelectField
                            label="CLIMA"
                            value={editedSettings.climate}
                            options={CLIMATE_OPTIONS}
                            onChange={(value) =>
                              setEditedSettings((settings) => ({
                                ...settings,
                                climate: value as CreatorClimate,
                              }))
                            }
                          />
                          <SelectField
                            label="DENSIDADE"
                            value={editedSettings.objectDensity}
                            options={DENSITY_OPTIONS}
                            onChange={(value) =>
                              setEditedSettings((settings) => ({
                                ...settings,
                                objectDensity: value as CreatorObjectDensity,
                              }))
                            }
                          />
                        </div>
                        <button
                          type="submit"
                          disabled={isLoading}
                          className="w-full min-h-[46px] rounded-xl bg-white text-[#0c1014] text-xs font-bold flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                        >
                          <Save className="w-4 h-4" />
                          SALVAR ALTERAÇÕES
                        </button>
                      </form>
                    </div>
                  )}
                </section>
              </div>
            ) : (
              <section className="space-y-4">
                <div className="flex flex-col sm:flex-row gap-2">
                  <label className="flex-1 relative">
                    <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-white/40" />
                    <input
                      value={assetSearch}
                      onChange={(event) => setAssetSearch(event.target.value)}
                      placeholder="Buscar por nome, categoria ou ID"
                      className={`${CONTROL_CLASS} pl-9`}
                    />
                  </label>
                  <button
                    type="button"
                    onClick={() => assetFileInputRef.current?.click()}
                    className="min-h-[44px] rounded-xl border border-white/20 bg-white/5 px-4 text-xs font-semibold text-white flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <PackageOpen className="w-4 h-4" />
                    IMPORTAR MANIFESTO
                  </button>
                  <input
                    ref={assetFileInputRef}
                    type="file"
                    accept=".json,application/json"
                    className="hidden"
                    onChange={handleImportAssets}
                  />
                </div>

                <div className="rounded-xl border border-amber-300/25 bg-amber-300/8 px-4 py-3 text-xs text-amber-100">
                  <strong>COLOCAR ASSET — NÃO IMPLEMENTADO.</strong> A biblioteca,
                  metadados, thumbnails, LOD, colisor e importação funcionam nesta
                  fase; posicionamento e personalização chegam na Fase 6.
                </div>

                <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-3">
                  {filteredAssets.map((asset) => (
                    <article
                      key={asset.id}
                      className="rounded-2xl border border-white/12 bg-white/4 overflow-hidden"
                    >
                      <img
                        src={asset.thumbnail}
                        alt={`Thumbnail de ${asset.name}`}
                        className="w-full h-28 object-cover"
                      />
                      <div className="p-3 space-y-2">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <h3 className="text-sm font-semibold text-white">
                              {asset.name}
                            </h3>
                            <p className="text-[10px] text-emerald-300 uppercase tracking-wider">
                              {ASSET_CATEGORY_LABELS[asset.category] ??
                                asset.category}
                            </p>
                          </div>
                          <span className="text-[9px] px-2 py-1 rounded-full bg-white/10 text-white/55">
                            {asset.builtin ? 'Nativo' : 'Importado'}
                          </span>
                        </div>
                        <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-[10px] text-white/50 font-mono-tabular">
                          <span>Tipo: {asset.type}</span>
                          <span>Polys: {asset.polycount}</span>
                          <span>LOD: {asset.lods.join('/')}</span>
                          <span>Colisor: {asset.collider}</span>
                          <span>Material: {asset.material}</span>
                          <span>{formatBytes(asset.sizeBytes)}</span>
                        </div>
                        <div className="text-[9px] text-white/35 break-all">
                          {asset.id}
                        </div>
                      </div>
                    </article>
                  ))}
                  {filteredAssets.length === 0 && (
                    <div className="sm:col-span-2 xl:col-span-3 rounded-xl border border-dashed border-white/20 p-8 text-center text-xs text-white/45">
                      Nenhum asset corresponde à busca.
                    </div>
                  )}
                </div>
              </section>
            )}
          </div>
        </div>
      </div>
    </div>
  );

  function updateNewSettings<Key extends keyof CreatorWorldSettings>(
    field: Key,
    value: CreatorWorldSettings[Key]
  ) {
    setNewWorld((world) => ({
      ...world,
      settings: {
        ...world.settings,
        [field]: value,
      },
    }));
  }
};

interface SelectFieldProps {
  label: string;
  value: string;
  options: Array<{ value: string; label: string }>;
  onChange: (value: string) => void;
}

const SelectField: React.FC<SelectFieldProps> = ({
  label,
  value,
  options,
  onChange,
}) => (
  <label className="block space-y-1">
    <span className="text-[11px] text-white/55">{label}</span>
    <select
      value={value}
      onChange={(event) => onChange(event.target.value)}
      className={CONTROL_CLASS}
    >
      {options.map((option) => (
        <option key={option.value} value={option.value}>
          {option.label}
        </option>
      ))}
    </select>
  </label>
);

const STYLE_OPTIONS = [
  { value: 'realista', label: 'Realista' },
  { value: 'minimalista', label: 'Minimalista' },
  { value: 'cyberpunk', label: 'Cyberpunk' },
  { value: 'futurista', label: 'Futurista' },
  { value: 'rustico', label: 'Rústico' },
  { value: 'brutalista', label: 'Brutalista' },
];

const TERRAIN_OPTIONS = [
  { value: 'plano', label: 'Plano' },
  { value: 'colinas', label: 'Colinas' },
  { value: 'montanhoso', label: 'Montanhoso' },
  { value: 'costeiro', label: 'Costeiro' },
  { value: 'deserto', label: 'Deserto' },
  { value: 'ilhas', label: 'Ilhas' },
];

const CLIMATE_OPTIONS = [
  { value: 'equatorial', label: 'Equatorial' },
  { value: 'tropical', label: 'Tropical' },
  { value: 'temperado', label: 'Temperado' },
  { value: 'seco', label: 'Seco' },
  { value: 'polar', label: 'Polar' },
  { value: 'tempestuoso', label: 'Tempestuoso' },
];

const DENSITY_OPTIONS = [
  { value: 'vazio', label: 'Vazio' },
  { value: 'baixa', label: 'Baixa' },
  { value: 'media', label: 'Média' },
  { value: 'alta', label: 'Alta' },
];

const QUALITY_OPTIONS = [
  { value: 'leve', label: 'Leve' },
  { value: 'equilibrado', label: 'Equilibrado' },
  { value: 'cinematografico', label: 'Cinematográfico' },
];

function downloadText(fileName: string, text: string, mimeType: string): void {
  const blob = new Blob([text], { type: mimeType });
  const objectUrl = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = objectUrl;
  anchor.download = fileName;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(objectUrl);
}

function slugify(value: string): string {
  return (
    value
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '') || 'mundo'
  );
}

function formatTimestamp(timestamp: number): string {
  return new Intl.DateTimeFormat('pt-BR', {
    dateStyle: 'short',
    timeStyle: 'short',
  }).format(new Date(timestamp));
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  return `${(bytes / 1024).toFixed(1)} kB`;
}

function readErrorMessage(error: unknown): string {
  return error instanceof Error ? error.message : 'Falha inesperada.';
}
