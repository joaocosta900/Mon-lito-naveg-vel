import React from 'react';
import {
  AlignCenterHorizontal,
  AlignCenterVertical,
  Copy,
  Layers,
  Minus,
  Move3d,
  Pencil,
  Plus,
  RotateCw,
  SquareDashed,
  Trash2,
  Ungroup,
  X,
} from 'lucide-react';
import { CreatorEntityDelta } from '../creator/types';

export interface CreatorSelectionPanelProps {
  selection: CreatorEntityDelta[];
  resolveChunkKey: (entityId: string) => string;
  onEdit: (entity: CreatorEntityDelta) => void;
  onDuplicate: (entity: CreatorEntityDelta) => void;
  onMove: (entity: CreatorEntityDelta) => void;
  onRotate: (entity: CreatorEntityDelta) => void;
  onDelete: (entity: CreatorEntityDelta) => void;
  onGroup: (entities: CreatorEntityDelta[]) => void;
  onUngroup: (entities: CreatorEntityDelta[]) => void;
  onResize: (factor: number) => void;
  onAlign: (axis: 'x' | 'z') => void;
  onDistribute: () => void;
  onClose: () => void;
}

export const CreatorSelectionPanel: React.FC<CreatorSelectionPanelProps> = ({
  selection,
  resolveChunkKey,
  onEdit,
  onDuplicate,
  onMove,
  onRotate,
  onDelete,
  onGroup,
  onUngroup,
  onResize,
  onAlign,
  onDistribute,
  onClose,
}) => {
  const primary = selection[0];
  const multiple = selection.length > 1;

  return (
    <aside className="absolute left-2 top-16 z-20 w-[min(92vw,300px)] max-h-[70vh] overflow-y-auto rounded-2xl border border-white/15 bg-[#0b1117]/95 p-3 shadow-2xl backdrop-blur-md sm:left-4 sm:top-20">
      <div className="flex items-center justify-between gap-2 pb-2 border-b border-white/10">
        <div>
          <div className="text-[10px] uppercase tracking-[0.2em] text-emerald-300">
            Seleção
          </div>
          <div className="text-xs text-white/75">
            {multiple ? `${selection.length} objetos` : primary?.prefabId ?? '—'}
          </div>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="min-h-[36px] min-w-[36px] rounded-lg border border-white/15 text-white/70 flex items-center justify-center cursor-pointer"
          aria-label="Fechar seleção"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {primary ? (
        <dl className="mt-3 space-y-1 text-[10px]">
          <Row label="NOME" value={primary.prefabId} />
          <Row label="TIPO" value={String(primary.properties.tipo ?? 'prefab')} />
          <Row
            label="POSIÇÃO"
            value={primary.position.map((value) => Math.round(value)).join(' · ')}
          />
          <Row
            label="ROTAÇÃO"
            value={primary.rotation.map((value) => Math.round(value)).join(' · ')}
          />
          <Row
            label="ESCALA"
            value={primary.scale.map((value) => value.toFixed(2)).join(' · ')}
          />
          <Row label="MATERIAL" value={primary.materialId} />
          <Row label="ID" value={primary.entityId} />
          <Row label="CHUNK" value={resolveChunkKey(primary.entityId)} />
          <Row label="PREFAB" value={primary.prefabId} />
        </dl>
      ) : (
        <div className="mt-3 text-[10px] text-white/45">
          Toque em um objeto colocado no mundo para selecioná-lo.
        </div>
      )}

      <div className="mt-3 grid grid-cols-3 gap-1.5">
        <Action
          label="EDITAR"
          icon={<Pencil className="w-3.5 h-3.5" />}
          disabled={!primary}
          onClick={() => primary && onEdit(primary)}
        />
        <Action
          label="MOVER"
          icon={<Move3d className="w-3.5 h-3.5" />}
          disabled={!primary}
          onClick={() => primary && onMove(primary)}
        />
        <Action
          label="ROTACIONAR"
          icon={<RotateCw className="w-3.5 h-3.5" />}
          disabled={!primary}
          onClick={() => primary && onRotate(primary)}
        />
        <Action
          label="DUPLICAR"
          icon={<Copy className="w-3.5 h-3.5" />}
          disabled={!primary}
          onClick={() => primary && onDuplicate(primary)}
        />
        <Action
          label="AGRUPAR"
          icon={<Layers className="w-3.5 h-3.5" />}
          disabled={selection.length < 2}
          onClick={() => onGroup(selection)}
        />
        <Action
          label="DESAGRUPAR"
          icon={<Ungroup className="w-3.5 h-3.5" />}
          disabled={!primary}
          onClick={() => onUngroup(selection)}
        />
      </div>
      <button
        type="button"
        onClick={() => onDelete(primary as CreatorEntityDelta)}
        disabled={selection.length === 0}
        className="mt-1.5 min-h-[38px] w-full rounded-xl border border-rose-400/30 bg-rose-500/10 text-[10px] font-semibold text-rose-100 flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-40"
      >
        <Trash2 className="w-3.5 h-3.5" />
        DELETAR
      </button>

      <div className="mt-3 border-t border-white/10 pt-2">
        <div className="mb-1 text-[9px] uppercase tracking-wider text-white/45">
          Lote ({selection.length})
        </div>
        <div className="grid grid-cols-3 gap-1.5">
          <Action
            label="MENOR"
            icon={<Minus className="w-3.5 h-3.5" />}
            disabled={!primary}
            onClick={() => onResize(0.8)}
          />
          <Action
            label="MAIOR"
            icon={<Plus className="w-3.5 h-3.5" />}
            disabled={!primary}
            onClick={() => onResize(1.25)}
          />
          <Action
            label="ALINHAR X"
            icon={<AlignCenterHorizontal className="w-3.5 h-3.5" />}
            disabled={selection.length < 2}
            onClick={() => onAlign('x')}
          />
          <Action
            label="ALINHAR Z"
            icon={<AlignCenterVertical className="w-3.5 h-3.5" />}
            disabled={selection.length < 2}
            onClick={() => onAlign('z')}
          />
          <Action
            label="DISTRIBUIR"
            icon={<SquareDashed className="w-3.5 h-3.5" />}
            disabled={selection.length < 3}
            onClick={onDistribute}
          />
        </div>
      </div>
    </aside>
  );
};

const Row: React.FC<{ label: string; value: string }> = ({ label, value }) => (
  <div className="flex gap-2">
    <dt className="w-[64px] shrink-0 text-white/40">{label}</dt>
    <dd className="min-w-0 flex-1 truncate text-white/80" title={value}>
      {value}
    </dd>
  </div>
);

const Action: React.FC<{
  label: string;
  icon: React.ReactNode;
  disabled: boolean;
  onClick: () => void;
}> = ({ label, icon, disabled, onClick }) => (
  <button
    type="button"
    onClick={onClick}
    disabled={disabled}
    className="min-h-[46px] rounded-xl border border-white/15 bg-white/5 text-[9px] font-semibold text-white/75 flex flex-col items-center justify-center gap-1 cursor-pointer disabled:opacity-35"
  >
    {icon}
    {label}
  </button>
);
