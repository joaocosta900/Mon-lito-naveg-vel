import React, {
  useCallback,
  useEffect,
  useRef,
  useState,
} from 'react';
import * as THREE from 'three';
import {
  ChevronDown,
  ChevronUp,
  Crosshair,
  History,
  Eye,
  Footprints,
  LogOut,
  Map as MapIcon,
  Move3d,
  Save,
  Send,
  Wrench,
  X,
} from 'lucide-react';
import {
  CreatorChunkManager,
  CreatorLoadedChunk,
} from '../creator/runtime/CreatorChunkManager';
import { CreatorEntityStore } from '../creator/runtime/CreatorEntityStore';
import {
  buildAlign,
  buildDistribute,
  buildResize,
} from '../creator/runtime/CreatorBatchOps';
import {
  CreatorHistory,
  CreatorHistorySnapshot,
} from '../creator/runtime/CreatorHistory';
import {
  CreatorGridMode,
  CreatorGridOverlay,
  CreatorSnapKind,
  applySnap,
  snapRotation,
  snapValue,
} from '../creator/runtime/CreatorGrid';
import { BUILTIN_CREATOR_ASSETS } from '../creator/CreatorAssets';
import {
  CreatorChunkMutation,
  CreatorEntityDelta,
  CreatorWorld,
  CreatorSavedPoint,
} from '../creator/types';
import { CreatorMiniMap } from './CreatorMiniMap';
import { CreatorSelectionPanel } from './CreatorSelectionPanel';
import { CreatorVersionsPanel } from './CreatorVersionsPanel';
import { CreatorTool, CreatorToolPanel } from './CreatorToolPanel';

interface CreatorViewportProps {
  world: CreatorWorld;
  onExit: (world: CreatorWorld) => void;
}

type CreatorSpeedMode = 'lento' | 'normal' | 'rapido' | 'muito_rapido';
type CreatorViewMode = 'normal' | 'aerea' | 'chao';

const JOYSTICK_TRAVEL = 40;

const SPEED_BY_MODE: Record<CreatorSpeedMode, number> = {
  lento: 28,
  normal: 90,
  rapido: 360,
  muito_rapido: 1400,
};

const SPEED_LABELS: Array<{ mode: CreatorSpeedMode; label: string }> = [
  { mode: 'lento', label: 'LENTO' },
  { mode: 'normal', label: 'NORMAL' },
  { mode: 'rapido', label: 'RÁPIDO' },
  { mode: 'muito_rapido', label: 'MUITO RÁPIDO' },
];

export const CreatorViewport: React.FC<CreatorViewportProps> = ({
  world,
  onExit,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const joystickBaseRef = useRef<HTMLDivElement | null>(null);
  const joystickKnobRef = useRef<HTMLDivElement | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const chunkManagerRef = useRef<CreatorChunkManager | null>(null);
  const entityStoreRef = useRef<CreatorEntityStore | null>(null);
  const historyRef = useRef<CreatorHistory>(new CreatorHistory());
  const gridRef = useRef<CreatorGridOverlay | null>(null);
  const toolRef = useRef<CreatorTool>('selecionar');
  const prefabIdRef = useRef<string | null>(null);
  const gridModeRef = useRef<CreatorGridMode>('livre');
  const gridVisibleRef = useRef(false);
  const toolPanelRef = useRef<HTMLDivElement | null>(null);
  const selectionRef = useRef<CreatorEntityDelta[]>([]);
  const selectionBoxRef = useRef<{ x0: number; y0: number; x1: number; y1: number } | null>(null);
  const clipboardRef = useRef<CreatorEntityDelta[]>([]);
  const snapsRef = useRef<Record<CreatorSnapKind, boolean>>({
    terreno: true,
    objeto: true,
    estrada: false,
    construcao: false,
  });
  const positionRef = useRef(
    new THREE.Vector3(
      world.lastEditor.position[0],
      world.lastEditor.position[1],
      world.lastEditor.position[2]
    )
  );
  const yawRef = useRef(world.lastEditor.yaw);
  const pitchRef = useRef(world.lastEditor.pitch);
  const fovRef = useRef(world.settings.quality === 'leve' ? 76 : 70);
  const speedModeRef = useRef<CreatorSpeedMode>('normal');
  const verticalInputRef = useRef(0);
  const joystickRef = useRef({ x: 0, y: 0 });
  const keysRef = useRef<Record<string, boolean>>({});
  const pointerMapRef = useRef(
    new Map<number, { x: number; y: number; distance?: number }>()
  );
  const pressMapRef = useRef(new Map<number, { x: number; y: number; time: number }>());
  const worldRef = useRef(world);
  const savedPointsRef = useRef<CreatorSavedPoint[]>([...world.savedPoints]);
  const navigationTimerRef = useRef<number | null>(null);
  const frameRef = useRef(0);
  const streamingTimerRef = useRef(0);
  const telemetryTimerRef = useRef(0);
  const loadedChunkSignatureRef = useRef('');

  const [speedMode, setSpeedMode] = useState<CreatorSpeedMode>('normal');
  const [viewMode, setViewMode] = useState<CreatorViewMode>('normal');
  const [mapOpen, setMapOpen] = useState(true);
  const [hubCollapsed, setHubCollapsed] = useState(
    () => typeof window !== 'undefined' && window.innerWidth < 720
  );
  const [navigationActive, setNavigationActive] = useState(false);
  const [cameraPosition, setCameraPosition] = useState({
    x: world.lastEditor.position[0],
    y: world.lastEditor.position[1],
    z: world.lastEditor.position[2],
  });
  const [loadedChunks, setLoadedChunks] = useState<CreatorLoadedChunk[]>([]);
  const [savedPoints, setSavedPoints] = useState<CreatorSavedPoint[]>(
    [...world.savedPoints]
  );
  const [status, setStatus] = useState(
    'Câmera livre iniciada. Nenhum personagem foi criado.'
  );
  const [teleportX, setTeleportX] = useState(
    String(Math.round(world.lastEditor.position[0]))
  );
  const [teleportZ, setTeleportZ] = useState(
    String(Math.round(world.lastEditor.position[2]))
  );
  const [tool, setTool] = useState<CreatorTool>('selecionar');
  const [toolPanelOpen, setToolPanelOpen] = useState(true);
  const [toolPanelHeight, setToolPanelHeight] = useState(212);
  const [activePrefabId, setActivePrefabId] = useState<string | null>(null);
  const [selection, setSelection] = useState<CreatorEntityDelta[]>([]);
  const [versionsOpen, setVersionsOpen] = useState(false);
  const [selectionBox, setSelectionBox] = useState<{
    x0: number;
    y0: number;
    x1: number;
    y1: number;
  } | null>(null);
  const [gridMode, setGridMode] = useState<CreatorGridMode>('livre');
  const [gridVisible, setGridVisible] = useState(false);
  const [snaps, setSnaps] = useState<Record<CreatorSnapKind, boolean>>({
    terreno: true,
    objeto: true,
    estrada: false,
    construcao: false,
  });
  const [historySnapshot, setHistorySnapshot] = useState<CreatorHistorySnapshot>({
    canUndo: false,
    canRedo: false,
    undoLabel: '',
    redoLabel: '',
    entries: 0,
    estimatedBytes: 0,
  });
  const [placementHint, setPlacementHint] = useState(
    'Toque no terreno para selecionar um objeto.'
  );

  const markNavigation = useCallback(() => {
    setNavigationActive(true);
    if (navigationTimerRef.current) window.clearTimeout(navigationTimerRef.current);
    navigationTimerRef.current = window.setTimeout(
      () => setNavigationActive(false),
      600
    );
  }, []);

  useEffect(() => {
    speedModeRef.current = speedMode;
  }, [speedMode]);

  useEffect(() => {
    toolRef.current = tool;
    if (tool === 'colocar' && !activePrefabId) {
      setActivePrefabId(BUILTIN_CREATOR_ASSETS[0]?.id ?? null);
    }
    setPlacementHint(
      tool === 'colocar'
        ? 'Toque no terreno para colocar o asset. Arraste para girar a câmera.'
        : tool === 'mover'
          ? 'Arraste um objeto selecionado para movê-lo pelo terreno.'
          : 'Toque em um objeto colocado no mundo para selecioná-lo.'
    );
  }, [tool, activePrefabId]);

  useEffect(() => {
    prefabIdRef.current = activePrefabId;
  }, [activePrefabId]);

  useEffect(() => {
    selectionRef.current = selection;
  }, [selection]);

  useEffect(() => {
    gridModeRef.current = gridMode;
    gridRef.current?.setMode(gridMode);
  }, [gridMode]);

  useEffect(() => {
    snapsRef.current = snaps;
  }, [snaps]);

  useEffect(() => {
    gridVisibleRef.current = gridVisible;
    gridRef.current?.setVisible(gridVisible);
  }, [gridVisible]);

  useEffect(() => {
    if (toolPanelOpen) setHubCollapsed(true);
  }, [toolPanelOpen]);

  // A barra inferior muda de altura conforme o conteúdo; joystick, hub e setas
  // se posicionam a partir da altura real em vez de um número fixo.
  useEffect(() => {
    const element = toolPanelRef.current;
    if (!toolPanelOpen || !element) {
      setToolPanelHeight(212);
      return;
    }
    const measure = () => setToolPanelHeight(Math.ceil(element.getBoundingClientRect().height));
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(element);
    window.addEventListener('resize', measure);
    return () => {
      observer.disconnect();
      window.removeEventListener('resize', measure);
    };
  }, [toolPanelOpen]);

  const getGroundHeight = useCallback((x: number, z: number) => {
    return chunkManagerRef.current?.getHeightAt(x, z) ?? 0;
  }, []);

  const teleport = useCallback(
    (x: number, z: number) => {
      const halfWorld = world.sizeMeters / 2;
      const nextX = THREE.MathUtils.clamp(x, -halfWorld + 1, halfWorld - 1);
      const nextZ = THREE.MathUtils.clamp(z, -halfWorld + 1, halfWorld - 1);
      const nextY = getGroundHeight(nextX, nextZ) + 8;
      positionRef.current.set(nextX, nextY, nextZ);
      setCameraPosition({ x: nextX, y: nextY, z: nextZ });
      setTeleportX(String(Math.round(nextX)));
      setTeleportZ(String(Math.round(nextZ)));
      setStatus(
        `Teletransportado para X ${Math.round(nextX)} · Z ${Math.round(nextZ)}.`
      );
      markNavigation();
    },
    [getGroundHeight, markNavigation, world.sizeMeters]
  );

  const applyViewMode = useCallback(
    (nextMode: CreatorViewMode) => {
      const groundHeight = getGroundHeight(
        positionRef.current.x,
        positionRef.current.z
      );
      if (nextMode === 'aerea') {
        positionRef.current.y = groundHeight + 1100;
      } else if (nextMode === 'chao') {
        positionRef.current.y = groundHeight + 7;
      }
      setViewMode(nextMode);
      setStatus(
        nextMode === 'aerea'
          ? 'Visão aérea ativada.'
          : nextMode === 'chao'
            ? 'Visão próxima ao chão ativada.'
            : 'Visão livre restaurada.'
      );
      markNavigation();
    },
    [getGroundHeight, markNavigation]
  );

  const saveCurrentPoint = useCallback(() => {
    const point: CreatorSavedPoint = {
      id: `point_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      label: `Ponto ${savedPointsRef.current.length + 1}`,
      position: [
        positionRef.current.x,
        positionRef.current.y,
        positionRef.current.z,
      ],
      yaw: yawRef.current,
      pitch: pitchRef.current,
      createdAt: Date.now(),
    };
    savedPointsRef.current = [...savedPointsRef.current, point];
    setSavedPoints(savedPointsRef.current);
    setStatus(`${point.label} salvo neste mundo.`);
  }, []);

  const goToSavedPoint = useCallback((point: CreatorSavedPoint) => {
    positionRef.current.set(...point.position);
    yawRef.current = point.yaw;
    pitchRef.current = point.pitch;
    setCameraPosition({
      x: point.position[0],
      y: point.position[1],
      z: point.position[2],
    });
    setStatus(`Retornado para ${point.label}.`);
    markNavigation();
  }, [markNavigation]);

  const commit = useCallback(
    (
      label: string,
      forward: CreatorChunkMutation[],
      backward: CreatorChunkMutation[]
    ) => {
      const store = entityStoreRef.current;
      if (!store) return;
      for (const mutation of forward) store.apply(mutation);
      historyRef.current.push({ label, forward, backward });
      setHistorySnapshot(historyRef.current.snapshot());
    },
    []
  );

  const handleUndo = useCallback(() => {
    const entry = historyRef.current.undo();
    if (!entry) return;
    for (const mutation of entry.backward) {
      entityStoreRef.current?.apply(mutation);
    }
    setSelection([]);
    setHistorySnapshot(historyRef.current.snapshot());
    setStatus(`Desfeito: ${entry.label}.`);
  }, []);

  const handleRedo = useCallback(() => {
    const entry = historyRef.current.redo();
    if (!entry) return;
    for (const mutation of entry.forward) {
      entityStoreRef.current?.apply(mutation);
    }
    setHistorySnapshot(historyRef.current.snapshot());
    setStatus(`Refeito: ${entry.label}.`);
  }, []);

  const handleTap = useCallback(
    (normalizedX: number, normalizedY: number) => {
      const store = entityStoreRef.current;
      const camera = cameraRef.current;
      const chunkManager = chunkManagerRef.current;
      if (!store || !camera || !chunkManager) return;

      if (toolRef.current === 'colocar') {
        const prefabId = prefabIdRef.current;
        if (!prefabId) {
          setStatus('Nenhum asset selecionado para colocar.');
          return;
        }
        const point = store.pickTerrainWorld(camera, normalizedX, normalizedY);
        if (!point) {
          setStatus('Toque sobre o terreno carregado para colocar.');
          return;
        }
        const worldX = applySnap(
          point.x,
          gridModeRef.current,
          'objeto',
          snapsRef.current
        );
        const worldZ = applySnap(
          point.z,
          gridModeRef.current,
          'objeto',
          snapsRef.current
        );
        const placed = store.place(prefabId, worldX, worldZ, yawRef.current);
        const inverse: CreatorChunkMutation = {
          type: 'entity-remove',
          entityId: placed.entity?.entityId ?? '',
        };
        commit(`Colocar ${prefabId}`, [placed.mutation as CreatorChunkMutation], [inverse]);
        setStatus(`Asset colocado em X ${Math.round(worldX)} · Z ${Math.round(worldZ)}.`);
        return;
      }

      if (toolRef.current === 'mover') {
        if (selectionRef.current.length === 0) {
          setStatus('Selecione um objeto antes de mover.');
          return;
        }
        const target = store.pickTerrainWorld(camera, normalizedX, normalizedY);
        if (!target) {
          setStatus('Toque sobre o terreno carregado para mover.');
          return;
        }
        const forward: CreatorChunkMutation[] = [];
        const backward: CreatorChunkMutation[] = [];
        const baseX = applySnap(
          target.x,
          gridModeRef.current,
          'objeto',
          snapsRef.current
        );
        const baseZ = applySnap(
          target.z,
          gridModeRef.current,
          'objeto',
          snapsRef.current
        );
        selectionRef.current.forEach((entity, index) => {
          const offset = snapValue(index * 4, gridModeRef.current);
          const nextX = baseX + offset;
          const nextZ = baseZ + offset;
          const build = store.buildUpdate(entity.entityId, {
            position: [nextX, store.getGroundHeight(nextX, nextZ), nextZ],
          });
          if (!build) return;
          forward.push(build.mutation);
          backward.push({
            type: 'entity-update',
            entityId: entity.entityId,
            changes: { position: [...entity.position] as [number, number, number] },
          });
        });
        commit('Mover objeto', forward, backward);
        setStatus(`${selectionRef.current.length} objeto(s) movido(s).`);
        return;
      }

      const picked = store.pick(camera, normalizedX, normalizedY);
      store.highlight(picked?.entityId ?? null);
      setSelection(picked ? [picked] : []);
      setStatus(
        picked
          ? `${picked.prefabId} selecionado.`
          : 'Nada selecionado nesta posição.'
      );
    },
    [commit]
  );

  const handleDuplicateSelection = useCallback(() => {
    const store = entityStoreRef.current;
    const primary = selection[0];
    if (!store || !primary) return;
    const forward: CreatorChunkMutation[] = [];
    const backward: CreatorChunkMutation[] = [];
    for (const entity of selection) {
      const offset = snapValue(4, gridModeRef.current);
      const placed = store.place(
        entity.prefabId,
        entity.position[0] + offset,
        entity.position[2] + offset,
        entity.rotation[1]
      );
      if (!placed.entity || !placed.mutation) continue;
      forward.push(placed.mutation);
      backward.push({ type: 'entity-remove', entityId: placed.entity.entityId });
    }
    commit(`Duplicar ${selection.length} objeto(s)`, forward, backward);
    setStatus(`${selection.length} objeto(s) duplicado(s).`);
  }, [commit, selection]);

  const handleDeleteSelection = useCallback(() => {
    const store = entityStoreRef.current;
    if (!store || selection.length === 0) return;
    const forward: CreatorChunkMutation[] = [];
    const backward: CreatorChunkMutation[] = [];
    for (const entity of selection) {
      const removal = store.buildRemove(entity.entityId);
      if (!removal) continue;
      forward.push(removal.mutation);
      const readd = store.buildReAdd(entity);
      if (readd) backward.push(readd.mutation);
    }
    commit(`Deletar ${selection.length} objeto(s)`, forward, backward);
    store.highlight(null);
    setSelection([]);
    setStatus(`${selection.length} objeto(s) deletado(s).`);
  }, [commit, selection]);

  const handleRotateSelection = useCallback(() => {
    const store = entityStoreRef.current;
    const primary = selection[0];
    if (!store || !primary) return;
    const step = snapRotation(15, gridModeRef.current);
    const next = (primary.rotation[1] + THREE.MathUtils.degToRad(step)) % (Math.PI * 2);
    const build = store.buildUpdate(primary.entityId, { rotation: [0, next, 0] });
    if (!build) return;
    commit('Rotacionar objeto', [build.mutation], [
      { type: 'entity-update', entityId: primary.entityId, changes: { rotation: [0, primary.rotation[1], 0] } },
    ]);
    setStatus('Objeto rotacionado.');
  }, [commit, selection]);

  const handleCopySelection = useCallback(() => {
    if (selection.length === 0) return;
    clipboardRef.current = selection.map((entity) => structuredClone(entity));
    setStatus(`${selection.length} objeto(s) copiado(s).`);
  }, [selection]);

  const handlePasteClipboard = useCallback(() => {
    const store = entityStoreRef.current;
    const clipboard = clipboardRef.current;
    if (!store || clipboard.length === 0) {
      setStatus('Área de transferência vazia.');
      return;
    }
    const forward: CreatorChunkMutation[] = [];
    const backward: CreatorChunkMutation[] = [];
    const step = snapValue(4, gridModeRef.current);
    clipboard.forEach((entity, index) => {
      const targetX = applySnap(
        positionRef.current.x + (index + 1) * step,
        gridModeRef.current,
        'objeto',
        snapsRef.current
      );
      const targetZ = applySnap(
        positionRef.current.z + (index + 1) * step,
        gridModeRef.current,
        'objeto',
        snapsRef.current
      );
      const placed = store.place(
        entity.prefabId,
        targetX,
        targetZ,
        entity.rotation[1]
      );
      if (!placed.entity || !placed.mutation) return;
      placed.entity.scale = [...entity.scale];
      placed.entity.materialId = entity.materialId;
      forward.push(placed.mutation);
      backward.push({ type: 'entity-remove', entityId: placed.entity.entityId });
    });
    commit(`Colar ${forward.length} objeto(s)`, forward, backward);
    setStatus(`${forward.length} objeto(s) colado(s) perto da câmera.`);
  }, [commit]);

  const handleResizeSelection = useCallback(
    (factor: number) => {
      const store = entityStoreRef.current;
      if (!store) return;
      const plan = buildResize(store, selection, factor);
      if (!plan || plan.forward.length === 0) return;
      commit(plan.label, plan.forward, plan.backward);
      setStatus(plan.detail);
    },
    [commit, selection]
  );

  const handleAlignSelection = useCallback(
    (axis: 'x' | 'z') => {
      const store = entityStoreRef.current;
      if (!store) return;
      const plan = axis === 'x' ? buildAlign(store, selection) : buildAlign(store, selection);
      if (!plan || plan.forward.length === 0) {
        setStatus(plan?.detail ?? 'Nada para alinhar.');
        return;
      }
      commit(plan.label, plan.forward, plan.backward);
      setStatus(plan.detail);
    },
    [commit, selection]
  );

  const handleDistributeSelection = useCallback(() => {
    const store = entityStoreRef.current;
    if (!store) return;
    const plan = buildDistribute(store, selection);
    if (!plan || plan.forward.length === 0) {
      setStatus(plan?.detail ?? 'Nada para distribuir.');
      return;
    }
    commit(plan.label, plan.forward, plan.backward);
    setStatus(plan.detail);
  }, [commit, selection]);

  const handleGroupSelection = useCallback(() => {
    if (selection.length < 2) return;
    const groupId = `grupo_${Date.now().toString(36)}`;
    const forward: CreatorChunkMutation[] = [];
    const backward: CreatorChunkMutation[] = [];
    for (const entity of selection) {
      const build = entityStoreRef.current?.buildUpdate(entity.entityId, {
        properties: { ...entity.properties, grupo: groupId },
      });
      if (!build) continue;
      forward.push(build.mutation);
      backward.push({
        type: 'entity-update',
        entityId: entity.entityId,
        changes: { properties: { ...entity.properties } },
      });
    }
    commit(`Agrupar ${selection.length} objeto(s)`, forward, backward);
    setStatus(`${selection.length} objeto(s) agrupados em ${groupId}.`);
  }, [commit, selection]);

  const handleUngroupSelection = useCallback(() => {
    if (selection.length === 0) return;
    const forward: CreatorChunkMutation[] = [];
    const backward: CreatorChunkMutation[] = [];
    for (const entity of selection) {
      const properties = { ...entity.properties };
      delete properties.grupo;
      const build = entityStoreRef.current?.buildUpdate(entity.entityId, { properties });
      if (!build) continue;
      forward.push(build.mutation);
      backward.push({
        type: 'entity-update',
        entityId: entity.entityId,
        changes: { properties: { ...entity.properties } },
      });
    }
    commit('Desagrupar', forward, backward);
    setStatus('Objetos desagrupados.');
  }, [commit, selection]);

  const handleEditSelection = useCallback(() => {
    const primary = selection[0];
    if (!primary) return;
    setStatus(
      `Edição de malha e materiais: NÃO IMPLEMENTADO — Fase 6. ID ${primary.entityId} selecionado.`
    );
  }, [selection]);

  const handleExit = useCallback(() => {
    const updatedWorld: CreatorWorld = {
      ...worldRef.current,
      lastEditor: {
        chunkKey: worldRef.current.lastEditor.chunkKey,
        position: [
          positionRef.current.x,
          positionRef.current.y,
          positionRef.current.z,
        ],
        yaw: yawRef.current,
        pitch: pitchRef.current,
      },
      savedPoints: [...savedPointsRef.current],
      metadata: {
        ...worldRef.current.metadata,
        updatedAt: Date.now(),
        revision: worldRef.current.metadata.revision + 1,
      },
    };
    onExit(updatedWorld);
  }, [onExit]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const isMobile =
      (navigator.maxTouchPoints ?? 0) > 0 &&
      window.matchMedia('(pointer: coarse)').matches;
    const wantsShadows =
      !isMobile && world.settings.quality === 'cinematografico';

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(
      world.settings.climate === 'polar'
        ? '#c7d8e5'
        : world.settings.climate === 'tempestuoso'
          ? '#52616b'
          : '#91b7c6'
    );
    scene.fog = new THREE.FogExp2(scene.background.getHex(), 0.000045);
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(
      fovRef.current,
      container.clientWidth / container.clientHeight,
      0.1,
      world.sizeMeters * 1.2
    );
    camera.rotation.order = 'YXZ';
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({
      antialias: !isMobile && world.settings.quality !== 'leve',
      powerPreference: 'default',
      stencil: false,
    });
    renderer.setPixelRatio(
      isMobile ? 1 : Math.min(window.devicePixelRatio || 1, 1.5)
    );
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.shadowMap.enabled = wantsShadows;
    renderer.shadowMap.type = THREE.PCFShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.03;
    rendererRef.current = renderer;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const hemisphereLight = new THREE.HemisphereLight(
      '#d9f1ff',
      '#435345',
      world.settings.quality === 'leve' ? 1.25 : 1.7
    );
    scene.add(hemisphereLight);
    const sunLight = new THREE.DirectionalLight('#fff4d6', 2.1);
    sunLight.position.set(-420, 700, 280);
    sunLight.castShadow = wantsShadows;
    sunLight.shadow.mapSize.set(1024, 1024);
    sunLight.shadow.camera.near = 1;
    sunLight.shadow.camera.far = 1800;
    sunLight.shadow.camera.left = -500;
    sunLight.shadow.camera.right = 500;
    sunLight.shadow.camera.top = 500;
    sunLight.shadow.camera.bottom = -500;
    scene.add(sunLight);

    const chunkManager = new CreatorChunkManager(world, scene);
    chunkManagerRef.current = chunkManager;

    const entityStore = new CreatorEntityStore(world, scene, chunkManager);
    entityStoreRef.current = entityStore;

    const gridOverlay = new CreatorGridOverlay();
    gridOverlay.setMode(gridModeRef.current);
    gridOverlay.setVisible(gridVisibleRef.current);
    scene.add(gridOverlay.object);
    gridRef.current = gridOverlay;
    if (positionRef.current.y === 0) {
      positionRef.current.y =
        chunkManager.getHeightAt(positionRef.current.x, positionRef.current.z) + 8;
    }
    const initialStream = chunkManager.update(positionRef.current);
    setLoadedChunks(initialStream.loaded);
    setCameraPosition({
      x: positionRef.current.x,
      y: positionRef.current.y,
      z: positionRef.current.z,
    });

    const canvas = renderer.domElement;
    const onKeyDown = (event: KeyboardEvent) => {
      keysRef.current[event.code] = true;
      markNavigation();
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(event.code)) {
        event.preventDefault();
      }
    };
    const onKeyUp = (event: KeyboardEvent) => {
      keysRef.current[event.code] = false;
    };
    const onWheel = (event: WheelEvent) => {
      event.preventDefault();
      fovRef.current = THREE.MathUtils.clamp(
        fovRef.current + event.deltaY * 0.035,
        34,
        96
      );
      camera.fov = fovRef.current;
      camera.updateProjectionMatrix();
      markNavigation();
    };
    const onPointerDown = (event: PointerEvent) => {
      canvas.setPointerCapture(event.pointerId);
      pointerMapRef.current.set(event.pointerId, { x: event.clientX, y: event.clientY });
      pressMapRef.current.set(event.pointerId, {
        x: event.clientX,
        y: event.clientY,
        time: performance.now(),
      });
      if (toolRef.current === 'marcar' && pointerMapRef.current.size === 1) {
        const box = { x0: event.clientX, y0: event.clientY, x1: event.clientX, y1: event.clientY };
        selectionBoxRef.current = box;
        setSelectionBox(box);
        return;
      }
      markNavigation();
    };
    const onPointerMove = (event: PointerEvent) => {
      const previous = pointerMapRef.current.get(event.pointerId);
      if (!previous) return;
      const current = { x: event.clientX, y: event.clientY };
      pointerMapRef.current.set(event.pointerId, current);
      const pointers = Array.from(pointerMapRef.current.values());
      if (toolRef.current === 'marcar' && pointers.length === 1) {
        const box = selectionBoxRef.current;
        if (box) {
          const next = { ...box, x1: event.clientX, y1: event.clientY };
          selectionBoxRef.current = next;
          setSelectionBox(next);
        }
        return;
      }
      if (pointers.length === 1) {
        const deltaX = current.x - previous.x;
        const deltaY = current.y - previous.y;
        yawRef.current -= deltaX * 0.003;
        pitchRef.current = THREE.MathUtils.clamp(
          pitchRef.current - deltaY * 0.003,
          -Math.PI * 0.47,
          Math.PI * 0.47
        );
      } else if (pointers.length >= 2) {
        const first = pointers[0];
        const second = pointers[1];
        const distance = Math.hypot(first.x - second.x, first.y - second.y);
        const previousDistance =
          pointerMapRef.current.get(event.pointerId)?.distance ?? distance;
        if (previousDistance > 0) {
          fovRef.current = THREE.MathUtils.clamp(
            fovRef.current - (distance - previousDistance) * 0.08,
            34,
            96
          );
          camera.fov = fovRef.current;
          camera.updateProjectionMatrix();
        }
        for (const pointer of pointerMapRef.current.values()) {
          pointer.distance = distance;
        }
      }
      markNavigation();
    };
    const onPointerUp = (event: PointerEvent) => {
      const press = pressMapRef.current.get(event.pointerId);
      pointerMapRef.current.delete(event.pointerId);
      pressMapRef.current.delete(event.pointerId);
      if (canvas.hasPointerCapture(event.pointerId)) {
        canvas.releasePointerCapture(event.pointerId);
      }
      const box = selectionBoxRef.current;
      selectionBoxRef.current = null;
      setSelectionBox(null);
      const store = entityStoreRef.current;
      if (box && store) {
        const minX = Math.min(box.x0, box.x1);
        const maxX = Math.max(box.x0, box.x1);
        const minY = Math.min(box.y0, box.y1);
        const maxY = Math.max(box.y0, box.y1);
        if (Math.abs(maxX - minX) < 6 && Math.abs(maxY - minY) < 6) {
          store.highlight(null);
          setSelection([]);
          setStatus('Seleção limpa.');
          return;
        }
        const found = collectEntitiesInBox(camera, store, canvas, minX, minY, maxX, maxY);
        found.forEach((entity) => entityStoreRef.current?.highlight(entity.entityId));
        setSelection(found);
        setStatus(
          found.length === 0
            ? 'Nenhum objeto dentro da área marcada.'
            : `${found.length} objeto(s) selecionado(s).`
        );
        return;
      }
      if (!press) return;
      const moved = Math.hypot(event.clientX - press.x, event.clientY - press.y);
      const elapsed = performance.now() - press.time;
      // Toque = pressed, parado e breve. Arrasto continua sendo controle de câmera.
      if (moved < 8 && elapsed < 450) {
        const bounds = canvas.getBoundingClientRect();
        const normalizedX = ((event.clientX - bounds.left) / bounds.width) * 2 - 1;
        const normalizedY = -((event.clientY - bounds.top) / bounds.height) * 2 + 1;
        handleTap(normalizedX, normalizedY);
      }
    };
    const onResize = () => {
      if (!cameraRef.current || !rendererRef.current || !containerRef.current) return;
      const width = containerRef.current.clientWidth;
      const height = containerRef.current.clientHeight;
      cameraRef.current.aspect = width / height;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(width, height);
    };
    const onContextMenu = (event: Event) => event.preventDefault();

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    canvas.addEventListener('wheel', onWheel, { passive: false });
    canvas.addEventListener('pointerdown', onPointerDown);
    canvas.addEventListener('pointermove', onPointerMove);
    canvas.addEventListener('pointerup', onPointerUp);
    canvas.addEventListener('pointercancel', onPointerUp);
    canvas.addEventListener('contextmenu', onContextMenu);
    window.addEventListener('resize', onResize);

    const clock = new THREE.Timer();
    clock.connect(document);
    const animate = (timestamp?: number) => {
      frameRef.current = requestAnimationFrame(animate);
      clock.update(timestamp);
      const delta = Math.min(clock.getDelta(), 0.1);
      const speed =
        SPEED_BY_MODE[speedModeRef.current] *
        (keysRef.current['ShiftLeft'] || keysRef.current['ShiftRight'] ? 1.65 : 1);
      const forwardInput =
        (keysRef.current['KeyW'] ? 1 : 0) -
        (keysRef.current['KeyS'] ? 1 : 0) -
        joystickRef.current.y;
      const rightInput =
        (keysRef.current['KeyD'] ? 1 : 0) -
        (keysRef.current['KeyA'] ? 1 : 0) +
        joystickRef.current.x;
      const verticalInput =
        (keysRef.current['KeyE'] || keysRef.current['Space'] ? 1 : 0) -
        (keysRef.current['KeyQ'] ? 1 : 0) +
        verticalInputRef.current;
      const horizontalLength = Math.hypot(forwardInput, rightInput);
      const normalizedForward =
        horizontalLength > 1 ? forwardInput / horizontalLength : forwardInput;
      const normalizedRight =
        horizontalLength > 1 ? rightInput / horizontalLength : rightInput;
      const sinYaw = Math.sin(yawRef.current);
      const cosYaw = Math.cos(yawRef.current);
      positionRef.current.x +=
        (-sinYaw * normalizedForward + cosYaw * normalizedRight) * speed * delta;
      positionRef.current.z +=
        (-cosYaw * normalizedForward - sinYaw * normalizedRight) * speed * delta;
      positionRef.current.y += verticalInput * speed * delta;

      const halfWorld = world.sizeMeters / 2;
      positionRef.current.x = THREE.MathUtils.clamp(
        positionRef.current.x,
        -halfWorld,
        halfWorld
      );
      positionRef.current.z = THREE.MathUtils.clamp(
        positionRef.current.z,
        -halfWorld,
        halfWorld
      );
      const groundHeight = chunkManager.getHeightAt(
        positionRef.current.x,
        positionRef.current.z
      );
      positionRef.current.y = Math.max(
        positionRef.current.y,
        groundHeight + 1.5
      );
      positionRef.current.y = Math.min(
        positionRef.current.y,
        groundHeight + world.sizeMeters
      );

      streamingTimerRef.current += delta;
      if (streamingTimerRef.current >= 0.18) {
        streamingTimerRef.current = 0;
        const streaming = chunkManager.update(positionRef.current);
        if (streaming.rebased) {
          setStatus('Floating origin recentralizado para manter a precisão.');
          entityStore.syncOrigin();
        }
        const chunkSignature = streaming.loaded
          .map((chunk) => chunk.key)
          .join('|');
        if (chunkSignature !== loadedChunkSignatureRef.current) {
          loadedChunkSignatureRef.current = chunkSignature;
          setLoadedChunks(streaming.loaded);
          entityStore.syncVisibleChunks(
            new Set(streaming.loaded.map((chunk) => chunk.key))
          );
        }
      }

      gridOverlay.update(
        positionRef.current,
        chunkManager.getHeightAt(positionRef.current.x, positionRef.current.z)
      );

      const origin = chunkManager.getOrigin();
      camera.position.set(
        positionRef.current.x - origin.x,
        positionRef.current.y,
        positionRef.current.z - origin.z
      );
      camera.rotation.y = yawRef.current;
      camera.rotation.x = pitchRef.current;

      telemetryTimerRef.current += delta;
      if (telemetryTimerRef.current >= 0.14) {
        telemetryTimerRef.current = 0;
        setCameraPosition({
          x: positionRef.current.x,
          y: positionRef.current.y,
          z: positionRef.current.z,
        });
      }
      renderer.render(scene, camera);
    };
    frameRef.current = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(frameRef.current);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      canvas.removeEventListener('wheel', onWheel);
      canvas.removeEventListener('pointerdown', onPointerDown);
      canvas.removeEventListener('pointermove', onPointerMove);
      canvas.removeEventListener('pointerup', onPointerUp);
      canvas.removeEventListener('pointercancel', onPointerUp);
      canvas.removeEventListener('contextmenu', onContextMenu);
      window.removeEventListener('resize', onResize);
      clock.dispose();
      gridOverlay.dispose();
      entityStore.dispose();
      chunkManager.dispose();
      renderer.dispose();
      rendererRef.current = null;
      sceneRef.current = null;
      cameraRef.current = null;
      chunkManagerRef.current = null;
      entityStoreRef.current = null;
      gridRef.current = null;
      if (navigationTimerRef.current) window.clearTimeout(navigationTimerRef.current);
    };
  }, [world, markNavigation]);

  const handleJoystickPointerDown = (event: React.PointerEvent<HTMLDivElement>) => {
    event.currentTarget.setPointerCapture(event.pointerId);
    updateJoystick(event.currentTarget, event.clientX, event.clientY, (x, y) => {
      joystickRef.current = { x, y };
      applyJoystickVisual(x, y);
    });
    markNavigation();
  };
  const handleJoystickPointerMove = (event: React.PointerEvent<HTMLDivElement>) => {
    if (event.currentTarget.hasPointerCapture(event.pointerId)) {
      updateJoystick(event.currentTarget, event.clientX, event.clientY, (x, y) => {
        joystickRef.current = { x, y };
        applyJoystickVisual(x, y);
      });
      markNavigation();
    }
  };
  const handleJoystickPointerUp = (event: React.PointerEvent<HTMLDivElement>) => {
    if (event.currentTarget.hasPointerCapture(event.pointerId)) {
      event.currentTarget.releasePointerCapture(event.pointerId);
    }
    joystickRef.current = { x: 0, y: 0 };
    if (joystickKnobRef.current) {
      joystickKnobRef.current.style.transform = 'translate(-50%, -50%)';
    }
  };

  const applyJoystickVisual = (x: number, y: number): void => {
    const knob = joystickKnobRef.current;
    if (!knob) return;
    knob.style.transform = `translate(calc(-50% + ${x * JOYSTICK_TRAVEL}px), calc(-50% + ${y * JOYSTICK_TRAVEL}px))`;
  };

  return (
    <div
      className="creator-ui fixed inset-0 z-50 bg-[#080c10] overflow-hidden select-none"
      onContextMenu={(event) => event.preventDefault()}
    >
      <div
        ref={containerRef}
        className="absolute inset-0 touch-none"
        aria-label="Viewport do Criador de Mundos"
      />

      {selectionBox && (
        <div
          className="pointer-events-none absolute z-20 rounded-sm border-2 border-emerald-300 bg-emerald-300/15"
          style={{
            left: Math.min(selectionBox.x0, selectionBox.x1),
            top: Math.min(selectionBox.y0, selectionBox.y1),
            width: Math.abs(selectionBox.x1 - selectionBox.x0),
            height: Math.abs(selectionBox.y1 - selectionBox.y0),
          }}
        />
      )}

      <header
        className={`absolute left-2 right-2 top-2 z-20 flex flex-wrap items-center gap-2 rounded-2xl border border-white/15 bg-[#0b1117]/88 p-2 backdrop-blur-md transition-opacity sm:left-4 sm:right-4 sm:top-4 ${
          navigationActive ? 'opacity-35' : 'opacity-100'
        }`}
      >
        <div className="min-w-0 flex-1">
          <div className="truncate text-xs font-semibold text-white">
            {world.name}
          </div>
          <div className="truncate font-mono-tabular text-[10px] text-emerald-200/80">
            X {Math.round(cameraPosition.x)} · Y {Math.round(cameraPosition.y)} · Z{' '}
            {Math.round(cameraPosition.z)} · chunks {loadedChunks.length}
          </div>
        </div>
        <div className="hidden items-center gap-1 sm:flex">
          {SPEED_LABELS.map((speedOption) => (
            <button
              key={speedOption.mode}
              type="button"
              onClick={() => {
                setSpeedMode(speedOption.mode);
                setStatus(`Velocidade da câmera: ${speedOption.label}.`);
                markNavigation();
              }}
              className={`min-h-[34px] rounded-lg px-2 text-[9px] font-bold cursor-pointer ${
                speedMode === speedOption.mode
                  ? 'bg-emerald-300 text-[#07110d]'
                  : 'bg-white/8 text-white/65 hover:bg-white/15'
              }`}
            >
              {speedOption.label}
            </button>
          ))}
        </div>
        <button
          type="button"
          onClick={() => setVersionsOpen((open) => !open)}
          className={`min-h-[36px] rounded-xl px-3 text-[10px] font-semibold flex items-center gap-1.5 cursor-pointer ${
            versionsOpen
              ? 'border border-emerald-300/50 bg-emerald-300/15 text-emerald-100'
              : 'border border-white/15 bg-white/8 text-white/80'
          }`}
        >
          <History className="w-3.5 h-3.5" />
          VERSÕES
        </button>
        <button
          type="button"
          onClick={() => setHubCollapsed((collapsed) => !collapsed)}
          className={`min-h-[36px] rounded-xl px-3 text-[10px] font-semibold flex items-center gap-1.5 cursor-pointer ${
            hubCollapsed
              ? 'border border-white/15 bg-white/8 text-white/80'
              : 'border border-emerald-300/50 bg-emerald-300/15 text-emerald-100'
          }`}
        >
          HUB
        </button>
        <button
          type="button"
          onClick={() => setToolPanelOpen((open) => !open)}
          className={`min-h-[36px] rounded-xl px-3 text-[10px] font-semibold flex items-center gap-1.5 cursor-pointer ${
            toolPanelOpen
              ? 'border border-emerald-300/50 bg-emerald-300/15 text-emerald-100'
              : 'border border-white/15 bg-white/8 text-white/80'
          }`}
        >
          <Wrench className="w-3.5 h-3.5" />
          FERRAMENTAS
        </button>
        <button
          type="button"
          onClick={() => setMapOpen((open) => !open)}
          className="min-h-[36px] rounded-xl border border-white/15 bg-white/8 px-3 text-[10px] font-semibold text-white/80 flex items-center gap-1.5 cursor-pointer"
        >
          <MapIcon className="w-3.5 h-3.5" />
          MAPA
        </button>
        <button
          type="button"
          onClick={handleExit}
          className="min-h-[36px] rounded-xl bg-white px-3 text-[10px] font-bold text-[#0b1117] flex items-center gap-1.5 cursor-pointer"
        >
          <LogOut className="w-3.5 h-3.5" />
          SALVAR E SAIR
        </button>
      </header>

      <div className="absolute left-2 top-20 z-10 max-w-[calc(100vw-1rem)] rounded-xl border border-white/10 bg-black/45 px-3 py-2 text-[10px] text-white/70 backdrop-blur-sm sm:left-4 sm:top-24">
        {status}
      </div>

      {versionsOpen && (
        <CreatorVersionsPanel
          world={worldRef.current}
          onClose={() => setVersionsOpen(false)}
          onRestore={(restored) => {
            // Restaurar substitui o documento inteiro; sair pelo fluxo normal
            // persiste o mundo restaurado e devolve ao painel sem perder a câmera.
            setVersionsOpen(false);
            onExit(restored);
          }}
        />
      )}

      {selection.length > 0 && (
        <CreatorSelectionPanel
          selection={selection}
          resolveChunkKey={(entityId) =>
            entityStoreRef.current?.getChunkKeyAt(
              selection.find((entity) => entity.entityId === entityId)?.position[0] ?? 0,
              selection.find((entity) => entity.entityId === entityId)?.position[2] ?? 0
            ) ?? '—'
          }
          onEdit={handleEditSelection}
          onDuplicate={handleDuplicateSelection}
          onMove={() => {
            setTool('mover');
            setStatus('Modo mover: toque no terreno para posicionar o selecionado.');
          }}
          onRotate={handleRotateSelection}
          onDelete={handleDeleteSelection}
          onGroup={handleGroupSelection}
          onUngroup={handleUngroupSelection}
          onResize={handleResizeSelection}
          onAlign={handleAlignSelection}
          onDistribute={handleDistributeSelection}
          onClose={() => {
            entityStoreRef.current?.highlight(null);
            setSelection([]);
          }}
        />
      )}

      {toolPanelOpen && (
        <div
          ref={toolPanelRef}
          className="absolute bottom-0 left-0 right-0 z-30"
        >
          <CreatorToolPanel
          tool={tool}
          onToolChange={setTool}
          assets={BUILTIN_CREATOR_ASSETS}
          activePrefabId={activePrefabId}
          onPrefabChange={setActivePrefabId}
          gridMode={gridMode}
          onGridModeChange={setGridMode}
          gridVisible={gridVisible}
          onGridVisibleChange={setGridVisible}
          snaps={snaps}
          onSnapChange={(kind, enabled) =>
            setSnaps((current) => ({ ...current, [kind]: enabled }))
          }
          history={historySnapshot}
          onUndo={handleUndo}
          onRedo={handleRedo}
          onCopy={handleCopySelection}
          onPaste={handlePasteClipboard}
          canPaste={clipboardRef.current.length > 0}
            selectionCount={selection.length}
            placementHint={placementHint}
          />
        </div>
      )}

      {mapOpen && (
        <CreatorMiniMap
          world={world}
          cameraPosition={cameraPosition}
          loadedChunks={loadedChunks}
          entities={entityStoreRef.current?.getVisibleEntities() ?? []}
          selectedEntityIds={selection.map((entity) => entity.entityId)}
          onTeleport={teleport}
          onClose={() => setMapOpen(false)}
        />
      )}

      <div
        className={`absolute left-2 z-20 transition-opacity sm:left-4 ${
          navigationActive ? 'opacity-45' : 'opacity-100'
        }`}
        style={{ bottom: toolPanelOpen ? toolPanelHeight + 12 : 8 }}
      >
        <div
          ref={joystickBaseRef}
          onPointerDown={handleJoystickPointerDown}
          onPointerMove={handleJoystickPointerMove}
          onPointerUp={handleJoystickPointerUp}
          onPointerCancel={handleJoystickPointerUp}
          className="relative h-32 w-32 touch-none rounded-full border border-white/20 bg-black/35 backdrop-blur-sm cursor-grab active:cursor-grabbing"
        >
          <div
            ref={joystickKnobRef}
            className="pointer-events-none absolute left-1/2 top-1/2 h-12 w-12 rounded-full border border-emerald-200/60 bg-emerald-300/75 shadow-lg"
            style={{ transform: 'translate(-50%, -50%)' }}
          />
        </div>
      </div>

      <div
        className="creator-touch-surface absolute right-2 z-20 flex flex-col gap-2 sm:right-4"
        style={{ bottom: toolPanelOpen ? toolPanelHeight + 12 : 12 }}
        onContextMenu={(event) => event.preventDefault()}
      >
        <VerticalButton
          direction={1}
          label="Subir"
          icon={<ChevronUp className="w-5 h-5" />}
          verticalInputRef={verticalInputRef}
          onHoldStart={markNavigation}
        />
        <VerticalButton
          direction={-1}
          label="Descer"
          icon={<ChevronDown className="w-5 h-5" />}
          verticalInputRef={verticalInputRef}
          onHoldStart={markNavigation}
        />
      </div>

      <section
        className={`absolute right-16 z-20 w-[min(92vw,350px)] rounded-2xl border border-white/15 bg-[#0b1117]/94 p-3 shadow-2xl backdrop-blur-md transition-opacity sm:right-20 ${
          navigationActive ? 'opacity-45' : 'opacity-100'
        } ${hubCollapsed ? 'hidden' : ''}`}
        style={{ bottom: toolPanelOpen ? toolPanelHeight + 12 : 12 }}
      >
        <div className="flex items-center justify-between gap-2 pb-2 border-b border-white/10">
          <div>
            <div className="text-[10px] uppercase tracking-[0.18em] text-emerald-300">
              Hub compacto
            </div>
            <div className="text-xs text-white/75">Câmera e navegação</div>
          </div>
          <button
            type="button"
            onClick={() => setHubCollapsed(true)}
            className="min-h-[36px] min-w-[36px] rounded-lg border border-white/15 text-white/70 flex items-center justify-center cursor-pointer"
            aria-label="Recolher hub"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="mt-3 grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => applyViewMode('normal')}
            className={`min-h-[40px] rounded-xl border text-[10px] font-semibold cursor-pointer ${
              viewMode === 'normal'
                ? 'border-emerald-300/60 bg-emerald-300/15 text-emerald-100'
                : 'border-white/15 bg-white/5 text-white/70'
            }`}
          >
            <Eye className="mx-auto mb-1 w-4 h-4" />
            NORMAL
          </button>
          <button
            type="button"
            onClick={() => applyViewMode('aerea')}
            className={`min-h-[40px] rounded-xl border text-[10px] font-semibold cursor-pointer ${
              viewMode === 'aerea'
                ? 'border-emerald-300/60 bg-emerald-300/15 text-emerald-100'
                : 'border-white/15 bg-white/5 text-white/70'
            }`}
          >
            <Crosshair className="mx-auto mb-1 w-4 h-4" />
            AÉREA
          </button>
          <button
            type="button"
            onClick={() => applyViewMode('chao')}
            className={`min-h-[40px] rounded-xl border text-[10px] font-semibold cursor-pointer ${
              viewMode === 'chao'
                ? 'border-emerald-300/60 bg-emerald-300/15 text-emerald-100'
                : 'border-white/15 bg-white/5 text-white/70'
            }`}
          >
            <Footprints className="mx-auto mb-1 w-4 h-4" />
            PRÓXIMA
          </button>
          <button
            type="button"
            onClick={saveCurrentPoint}
            className="min-h-[40px] rounded-xl border border-white/15 bg-white/5 text-[10px] font-semibold text-white/75 flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Save className="w-4 h-4" />
            SALVAR PONTO
          </button>
        </div>

        <div className="mt-3 grid grid-cols-2 gap-2">
          <label className="space-y-1">
            <span className="text-[9px] text-white/50">TELEPORTAR X</span>
            <input
              value={teleportX}
              onChange={(event) => setTeleportX(event.target.value)}
              inputMode="numeric"
              className="h-10 w-full rounded-lg border border-white/15 bg-black/35 px-2 text-xs text-white outline-none"
            />
          </label>
          <label className="space-y-1">
            <span className="text-[9px] text-white/50">TELEPORTAR Z</span>
            <input
              value={teleportZ}
              onChange={(event) => setTeleportZ(event.target.value)}
              inputMode="numeric"
              className="h-10 w-full rounded-lg border border-white/15 bg-black/35 px-2 text-xs text-white outline-none"
            />
          </label>
        </div>
        <button
          type="button"
          onClick={() => teleport(Number(teleportX), Number(teleportZ))}
          className="mt-2 min-h-[40px] w-full rounded-xl bg-emerald-300 text-[#07110d] text-[10px] font-bold flex items-center justify-center gap-1.5 cursor-pointer"
        >
          <Send className="w-4 h-4" />
          TELETRANSPORTAR
        </button>

        <div className="mt-3 border-t border-white/10 pt-2">
          <div className="mb-1 text-[9px] uppercase tracking-wider text-white/45">
            Pontos salvos ({savedPoints.length})
          </div>
          <div className="max-h-24 space-y-1 overflow-y-auto pr-1">
            {savedPoints.length === 0 ? (
              <div className="text-[10px] text-white/40">
                Nenhum ponto salvo.
              </div>
            ) : (
              savedPoints.map((point) => (
                <button
                  key={point.id}
                  type="button"
                  onClick={() => goToSavedPoint(point)}
                  className="flex min-h-[34px] w-full items-center justify-between rounded-lg border border-white/10 bg-white/4 px-2 text-left text-[10px] text-white/70 hover:bg-white/10 cursor-pointer"
                >
                  <span className="truncate">{point.label}</span>
                  <Move3d className="w-3.5 h-3.5 shrink-0 text-emerald-300" />
                </button>
              ))
            )}
          </div>
        </div>

        <div className="mt-3 rounded-lg border border-amber-300/20 bg-amber-300/8 px-2 py-2 text-[9px] leading-relaxed text-amber-100/85">
          SELEÇÃO DE OBJETOS: NÃO IMPLEMENTADO — FASE 3.
        </div>
        <div className="mt-2 flex items-center justify-between text-[9px] text-white/40">
          <span>WASD · Q/E · Shift · roda = zoom</span>
          <span>pinça = zoom</span>
        </div>
      </section>

    </div>
  );
};

/**
 * Projeta as entidades visiveis para a tela e devolve as que caem dentro do
 * retangulo arrastado — e o que permite marcar varios objetos de uma vez.
 */
function collectEntitiesInBox(
  camera: THREE.Camera,
  store: CreatorEntityStore,
  canvas: HTMLCanvasElement,
  minX: number,
  minY: number,
  maxX: number,
  maxY: number
): CreatorEntityDelta[] {
  const bounds = canvas.getBoundingClientRect();
  const projected = new THREE.Vector3();
  const origin = store.getOrigin();
  const found: CreatorEntityDelta[] = [];
  for (const entity of store.getVisibleEntities()) {
    projected.set(
      entity.position[0] - origin.x,
      entity.position[1],
      entity.position[2] - origin.z
    );
    projected.project(camera);
    if (projected.z < -1 || projected.z > 1) continue;
    const screenX = bounds.left + ((projected.x + 1) / 2) * bounds.width;
    const screenY = bounds.top + ((1 - projected.y) / 2) * bounds.height;
    if (screenX >= minX && screenX <= maxX && screenY >= minY && screenY <= maxY) {
      found.push(entity);
    }
  }
  return found;
}

interface VerticalButtonProps {
  direction: 1 | -1;
  label: string;
  icon: React.ReactNode;
  verticalInputRef: React.MutableRefObject<number>;
  onHoldStart: () => void;
}

/**
 * Seta de subir/descer. Usa captura de ponteiro para continuar respondendo com o
 * dedo deslizando, e zera em up/cancel para a câmera nunca ficar subindo sozinha.
 */
function VerticalButton({
  direction,
  label,
  icon,
  verticalInputRef,
  onHoldStart,
}: VerticalButtonProps): React.JSX.Element {
  const [held, setHeld] = React.useState(false);
  const heldRef = React.useRef(false);

  React.useEffect(() => {
    const release = () => {
      if (!heldRef.current) return;
      heldRef.current = false;
      setHeld(false);
      verticalInputRef.current = 0;
    };
    window.addEventListener('pointerup', release);
    window.addEventListener('pointercancel', release);
    window.addEventListener('blur', release);
    return () => {
      window.removeEventListener('pointerup', release);
      window.removeEventListener('pointercancel', release);
      window.removeEventListener('blur', release);
    };
  }, [verticalInputRef]);

  return (
    <button
      type="button"
      onPointerDown={(event) => {
        event.preventDefault();
        event.currentTarget.setPointerCapture?.(event.pointerId);
        heldRef.current = true;
        setHeld(true);
        verticalInputRef.current = direction;
        onHoldStart();
      }}
      onContextMenu={(event) => event.preventDefault()}
      className={`min-h-[44px] min-w-[44px] rounded-xl border text-white/85 flex items-center justify-center cursor-pointer ${
        held ? 'border-emerald-300/70 bg-emerald-300/25' : 'border-white/20 bg-black/55'
      }`}
      aria-label={label}
      aria-pressed={held}
    >
      {icon}
    </button>
  );
}

function updateJoystick(
  element: HTMLDivElement,
  clientX: number,
  clientY: number,
  onValue: (x: number, y: number) => void
): void {
  const bounds = element.getBoundingClientRect();
  const centerX = bounds.left + bounds.width / 2;
  const centerY = bounds.top + bounds.height / 2;
  const radius = JOYSTICK_TRAVEL;
  const deltaX = clientX - centerX;
  const deltaY = clientY - centerY;
  const distance = Math.min(radius, Math.hypot(deltaX, deltaY));
  const angle = Math.atan2(deltaY, deltaX);
  const valueX = (distance * Math.cos(angle)) / radius;
  const valueY = (distance * Math.sin(angle)) / radius;
  onValue(valueX, valueY);
}
