import React, { useState } from 'react';
import { X, Wrench, AlertCircle, Sparkles } from 'lucide-react';
import { AIProviderManager } from '../ai/AIProviderManager';
import { WorldPlan, WorldPatch } from '../world/types/worldPlan';

interface WorldPatchModalProps {
  isOpen: boolean;
  onClose: () => void;
  activePlan: WorldPlan | null;
  currentRegionId: string;
  onPatchApplied: (patch: WorldPatch, providerUsed: string) => void;
}

export const WorldPatchModal: React.FC<WorldPatchModalProps> = ({
  isOpen,
  onClose,
  activePlan,
  currentRegionId,
  onPatchApplied,
}) => {
  const manager = AIProviderManager.getInstance();
  const [targetRegion, setTargetRegion] = useState(currentRegionId);
  const [modificationPrompt, setModificationPrompt] = useState(
    'Adicione um complexo de três megatorres de 850 metros interligadas por passarelas no setor norte, com iluminação suave nas fendas.'
  );
  const [isPatching, setIsPatching] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen || !activePlan) return null;

  const handleApplyPatch = async () => {
    if (!modificationPrompt.trim()) return;

    setIsPatching(true);
    setErrorMessage(null);

    try {
      const result = await manager.generateWorldPatchWithFallback({
        worldPlan: activePlan,
        targetRegionId: targetRegion || currentRegionId,
        modificationPrompt: modificationPrompt.trim(),
      });

      setIsPatching(false);
      onPatchApplied(result.patch, result.providerUsed);
      onClose();
    } catch (err: unknown) {
      setIsPatching(false);
      setErrorMessage((err as Error).message || 'Falha ao aplicar patch.');
    }
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center p-4 sm:p-6 bg-black/75 backdrop-blur-sm select-none">
      <div className="max-w-xl w-full bg-[#111417] border border-white/10 rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Wrench className="w-4 h-4 text-white/80" />
            <div>
              <h2 className="font-display text-xl text-white tracking-wide">
                Modificar Região do Mundo (WorldPatch)
              </h2>
              <p className="text-[11px] text-white/50">
                Altera exclusivamente o setor alvo, mantendo intactas todas as demais regiões
              </p>
            </div>
          </div>
          <button
            type="button"
            disabled={isPatching}
            onClick={onClose}
            className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-white/70 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            aria-label="Fechar modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-4">
          <div className="space-y-1.5">
            <label className="block text-xs font-medium text-white/80">
              Região Alvo
            </label>
            <select
              disabled={isPatching}
              value={targetRegion}
              onChange={(e) => setTargetRegion(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-black/35 border border-white/15 text-white text-xs focus:outline-hidden focus:border-white/40"
            >
              {activePlan.regions.map((reg) => (
                <option key={reg.id} value={reg.id}>
                  {reg.title} ({reg.id})
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="block text-xs font-medium text-white/80">
              Instrução de Alteração Localizada
            </label>
            <textarea
              rows={3}
              disabled={isPatching}
              value={modificationPrompt}
              onChange={(e) => setModificationPrompt(e.target.value)}
              placeholder="Ex: adicione uma ponte colossal entre as torres, ou mude a neblina para tempestade neste setor..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-black/35 border border-white/15 text-white text-xs leading-relaxed focus:outline-hidden focus:border-white/40"
            />
          </div>

          {errorMessage && (
            <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-start gap-2 text-xs text-rose-300">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-white/10 flex items-center justify-end gap-3 bg-black/25">
          <button
            type="button"
            disabled={isPatching}
            onClick={onClose}
            className="px-4 py-2 rounded-xl border border-white/10 text-xs text-white/70 hover:text-white transition-colors cursor-pointer"
          >
            Cancelar
          </button>
          <button
            type="button"
            disabled={isPatching || !modificationPrompt.trim()}
            onClick={handleApplyPatch}
            className="px-6 py-2.5 rounded-xl bg-white text-[#0d0f11] font-semibold text-xs hover:bg-white/90 transition-all flex items-center gap-2 cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{isPatching ? 'Aplicando Patch...' : 'Aplicar WorldPatch'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
