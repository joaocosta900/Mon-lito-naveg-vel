import React, { useState, useEffect } from 'react';
import {
  X,
  Globe2,
  Trash2,
  Sparkles,
  Wrench,
  Compass,
  ArrowRight,
} from 'lucide-react';
import { WorldPlanCache } from '../world/WorldPlanCache';
import { WorldPlan } from '../world/types/worldPlan';
import { REGIONS_LIST } from '../world/AtmospherePresets';
import { RegionId } from '../types/world';

interface SavedWorldsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  activePlan: WorldPlan | null;
  activeCanonicalRegionId: RegionId;
  onSelectCanonicalRegion: (id: RegionId) => void;
  onSelectCustomWorld: (plan: WorldPlan) => void;
  onOpenCreateWorld: () => void;
  onOpenPatchModal: () => void;
}

export const SavedWorldsDrawer: React.FC<SavedWorldsDrawerProps> = ({
  isOpen,
  onClose,
  activePlan,
  activeCanonicalRegionId,
  onSelectCanonicalRegion,
  onSelectCustomWorld,
  onOpenCreateWorld,
  onOpenPatchModal,
}) => {
  const [savedPlans, setSavedPlans] = useState<WorldPlan[]>([]);
  const [tab, setTab] = useState<'ai_worlds' | 'canon_worlds'>('ai_worlds');

  useEffect(() => {
    if (isOpen) {
      setSavedPlans(WorldPlanCache.getAllPlans());
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleDeletePlan = (e: React.MouseEvent, worldId: string) => {
    e.stopPropagation();
    WorldPlanCache.deletePlan(worldId);
    setSavedPlans(WorldPlanCache.getAllPlans());
  };

  return (
    <div className="fixed inset-0 z-35 flex justify-end bg-black/50 backdrop-blur-xs select-none">
      <aside className="w-full max-w-md h-full bg-[#111417]/95 border-l border-white/10 p-6 overflow-y-auto flex flex-col justify-between space-y-6">
        <div className="space-y-5">
          {/* Header */}
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <div>
              <h2 className="font-display text-2xl text-white">Mundos &amp; Regiões</h2>
              <p className="text-xs text-white/55">
                Alterne entre os {REGIONS_LIST.length} setores canônicos e mundos colossais sintetizados por IA
              </p>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-white/70 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
              aria-label="Fechar gaveta"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Tab Switcher */}
          <div className="grid grid-cols-2 gap-1.5 p-1 bg-black/40 rounded-xl border border-white/10">
            <button
              type="button"
              onClick={() => setTab('ai_worlds')}
              className={`py-2 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                tab === 'ai_worlds'
                  ? 'bg-white/18 text-white'
                  : 'text-white/60 hover:text-white'
              }`}
            >
              Mundos IA ({savedPlans.length})
            </button>
            <button
              type="button"
              onClick={() => setTab('canon_worlds')}
              className={`py-2 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                tab === 'canon_worlds'
                  ? 'bg-white/18 text-white'
                  : 'text-white/60 hover:text-white'
              }`}
            >
              Setores ({REGIONS_LIST.length})
            </button>
          </div>

          {/* TAB 1: AI WORLDS */}
          {tab === 'ai_worlds' ? (
            <div className="space-y-4">
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenCreateWorld();
                }}
                className="w-full py-3 px-4 rounded-xl border border-dashed border-white/25 hover:border-white/50 text-white text-xs font-medium flex items-center justify-center gap-2 bg-white/4 hover:bg-white/8 transition-colors cursor-pointer"
              >
                <Sparkles className="w-4 h-4 text-white/80" />
                <span>Sintetizar Novo Mundo com IA</span>
              </button>

              {activePlan && (
                <div className="p-4 rounded-xl bg-white/10 border border-white/30 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] text-emerald-400 font-mono-tabular">
                      MUNDO ATIVO CARREGADO
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onOpenPatchModal();
                      }}
                      className="text-xs text-white/80 hover:text-white flex items-center gap-1.5 underline cursor-pointer"
                    >
                      <Wrench className="w-3.5 h-3.5" />
                      <span>Modificar Região</span>
                    </button>
                  </div>
                  <div className="font-display text-lg text-white">{activePlan.name}</div>
                  <p className="text-xs text-white/60">{activePlan.tagline}</p>
                  <div className="text-[11px] text-white/45 font-mono-tabular">
                    Dimensão {activePlan.size.scaleLabel} · Seed {activePlan.seed} · Provedor {activePlan.metadata.generatedByProvider}
                  </div>
                </div>
              )}

              {savedPlans.length === 0 ? (
                <div className="p-8 text-center text-xs text-white/40 border border-white/8 rounded-xl">
                  Nenhum mundo salvo. Clique acima para planejar seu primeiro mundo colossal com OpenAI, Gemini, Claude ou OpenRouter!
                </div>
              ) : (
                <div className="space-y-2.5">
                  <div className="text-[11px] text-white/50">Mundos Salvos em Cache:</div>
                  {savedPlans.map((plan) => {
                    const isSelected = activePlan?.worldId === plan.worldId;
                    return (
                      <div
                        key={plan.worldId}
                        onClick={() => {
                          onSelectCustomWorld(plan);
                          onClose();
                        }}
                        className={`p-3.5 rounded-xl border transition-colors cursor-pointer text-left ${
                          isSelected
                            ? 'bg-white/14 border-white/40 text-white'
                            : 'bg-white/4 border-white/8 text-white/75 hover:bg-white/8'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-semibold text-white">
                            {plan.name}
                          </span>
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] text-white/50 font-mono-tabular">
                              {plan.size.scaleLabel}
                            </span>
                            <button
                              type="button"
                              onClick={(e) => handleDeletePlan(e, plan.worldId)}
                              className="text-white/30 hover:text-rose-400 p-1 cursor-pointer"
                              title="Excluir mundo salvo"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                        <div className="text-[11px] text-white/55 mt-0.5 truncate">
                          {plan.tagline}
                        </div>
                        <div className="text-[10px] text-white/40 mt-1 font-mono-tabular">
                          Criado via {plan.metadata.generatedByProvider} ({plan.metadata.model})
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          ) : (
            /* TAB 2: 13 CANONICAL REGIONS */
            <div className="space-y-2">
              {REGIONS_LIST.map((region) => {
                const active = !activePlan && region.id === activeCanonicalRegionId;
                return (
                  <button
                    key={region.id}
                    type="button"
                    onClick={() => {
                      onSelectCanonicalRegion(region.id);
                      onClose();
                    }}
                    className={`w-full text-left px-4 py-3 rounded-xl border transition-colors cursor-pointer ${
                      active
                        ? 'bg-white/14 border-white/40 text-white'
                        : 'bg-white/4 border-white/8 text-white/75 hover:bg-white/8'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs font-semibold">
                      <span>
                        {region.number}. {region.title}
                      </span>
                      <span className="font-mono-tabular text-[11px] text-white/55">
                        {region.colossalHeightMeters} m
                      </span>
                    </div>
                    <div className="text-[11px] text-white/55 mt-0.5 leading-snug">
                      {region.subtitle}
                    </div>
                    <div className="text-[10px] text-white/40 mt-1">
                      {region.acousticDescription}
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        <div className="pt-4 border-t border-white/10 text-[11px] text-white/40 text-center font-mono-tabular">
          MONOLITO ENGINE · ARQUITETURA AGNOSTICA DE IA
        </div>
      </aside>
    </div>
  );
};
