import {
  createCreatorWorld,
  migrateCreatorWorld,
  duplicateCreatorWorld,
  importCreatorWorld,
  exportCreatorWorld,
  validateAssetDescriptor,
} from './CreatorFormat';
import { BUILTIN_CREATOR_ASSETS } from './CreatorAssets';
import {
  CREATOR_ASSET_FORMAT,
  CREATOR_ASSET_FORMAT_VERSION,
  CreatorAssetDescriptor,
  CreatorAssetManifest,
  CreatorNewWorldInput,
  CreatorWorld,
  CreatorWorldVersion,
} from './types';

function worldRevisionGuard(world: CreatorWorld): number {
  return world.metadata.revision + 1;
}

const DATABASE_NAME = 'monolito_creator_worlds';
const DATABASE_VERSION = 2;
const WORLDS_STORE = 'worlds';
const ASSETS_STORE = 'assets';
const VERSIONS_STORE = 'versions';

function requestResult<T>(request: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () =>
      reject(request.error ?? new Error('Falha ao acessar o IndexedDB.'));
  });
}

function transactionDone(transaction: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    transaction.oncomplete = () => resolve();
    transaction.onerror = () =>
      reject(transaction.error ?? new Error('Transação IndexedDB falhou.'));
    transaction.onabort = () =>
      reject(transaction.error ?? new Error('Transação IndexedDB abortada.'));
  });
}

export class CreatorStorage {
  private databasePromise: Promise<IDBDatabase> | null = null;

  private openDatabase(): Promise<IDBDatabase> {
    if (this.databasePromise) return this.databasePromise;
    if (typeof indexedDB === 'undefined') {
      return Promise.reject(
        new Error('IndexedDB indisponível neste navegador ou contexto.')
      );
    }

    this.databasePromise = new Promise((resolve, reject) => {
      const openRequest = indexedDB.open(DATABASE_NAME, DATABASE_VERSION);
      openRequest.onupgradeneeded = () => {
        const database = openRequest.result;
        if (!database.objectStoreNames.contains(WORLDS_STORE)) {
          const worldsStore = database.createObjectStore(WORLDS_STORE, {
            keyPath: 'id',
          });
          worldsStore.createIndex('updatedAt', 'metadata.updatedAt');
        }
        if (!database.objectStoreNames.contains(ASSETS_STORE)) {
          database.createObjectStore(ASSETS_STORE, { keyPath: 'id' });
        }
        if (!database.objectStoreNames.contains(VERSIONS_STORE)) {
          const versionsStore = database.createObjectStore(VERSIONS_STORE, {
            keyPath: 'id',
          });
          versionsStore.createIndex('worldId', 'worldId');
        }
      };
      openRequest.onsuccess = () => {
        const database = openRequest.result;
        database.onversionchange = () => {
          database.close();
          this.databasePromise = null;
        };
        resolve(database);
      };
      openRequest.onerror = () =>
        reject(openRequest.error ?? new Error('Falha ao abrir o IndexedDB.'));
      openRequest.onblocked = () =>
        reject(new Error('O banco do Criador está bloqueado por outra aba.'));
    });

    return this.databasePromise;
  }

  // ---------------------------------------------------------------- versões

  public async listVersions(worldId: string): Promise<CreatorWorldVersion[]> {
    const database = await this.openDatabase();
    const transaction = database.transaction(VERSIONS_STORE, 'readonly');
    const index = transaction
      .objectStore(VERSIONS_STORE)
      .index('worldId');
    const stored = await requestResult(index.getAll(worldId));
    return (stored as CreatorWorldVersion[]).sort(
      (left, right) => right.createdAt - left.createdAt
    );
  }

  public async saveVersion(world: CreatorWorld, label?: string): Promise<CreatorWorldVersion> {
    const database = await this.openDatabase();
    const existing = await this.listVersions(world.id);
    const nextNumber = existing.length + 1;
    const version: CreatorWorldVersion = {
      id: `${world.id}_v${nextNumber}_${Date.now().toString(36)}`,
      worldId: world.id,
      label: label?.trim() || `Cidade_v${nextNumber}`,
      revision: world.metadata.revision,
      createdAt: Date.now(),
      snapshot: structuredClone(world),
    };
    const transaction = database.transaction(VERSIONS_STORE, 'readwrite');
    transaction.objectStore(VERSIONS_STORE).put(version);
    await transactionDone(transaction);
    return version;
  }

  public async restoreVersion(versionId: string): Promise<CreatorWorld | null> {
    const database = await this.openDatabase();
    const transaction = database.transaction(VERSIONS_STORE, 'readonly');
    const stored = (await requestResult(
      transaction.objectStore(VERSIONS_STORE).get(versionId)
    )) as CreatorWorldVersion | undefined;
    if (!stored) return null;
    const restored = migrateCreatorWorld(structuredClone(stored.snapshot));
    restored.metadata.revision = Math.max(
      restored.metadata.revision,
      worldRevisionGuard(restored)
    );
    await this.saveWorld(restored);
    return restored;
  }

  public async deleteVersion(versionId: string): Promise<void> {
    const database = await this.openDatabase();
    const transaction = database.transaction(VERSIONS_STORE, 'readwrite');
    transaction.objectStore(VERSIONS_STORE).delete(versionId);
    await transactionDone(transaction);
  }

  public async listWorlds(): Promise<CreatorWorld[]> {
    const database = await this.openDatabase();
    const transaction = database.transaction(WORLDS_STORE, 'readonly');
    const stored = await requestResult(
      transaction.objectStore(WORLDS_STORE).getAll()
    );
    const worlds = (stored as unknown[]).map(migrateCreatorWorld);
    return worlds.sort(
      (leftWorld, rightWorld) =>
        rightWorld.metadata.updatedAt - leftWorld.metadata.updatedAt
    );
  }

  public async getWorld(worldId: string): Promise<CreatorWorld | null> {
    const database = await this.openDatabase();
    const transaction = database.transaction(WORLDS_STORE, 'readonly');
    const stored = await requestResult(
      transaction.objectStore(WORLDS_STORE).get(worldId)
    );
    return stored ? migrateCreatorWorld(stored) : null;
  }

  public async saveWorld(world: CreatorWorld): Promise<CreatorWorld> {
    const normalizedWorld = migrateCreatorWorld(world);
    const database = await this.openDatabase();
    const transaction = database.transaction(WORLDS_STORE, 'readwrite');
    transaction.objectStore(WORLDS_STORE).put(normalizedWorld);
    await transactionDone(transaction);
    return normalizedWorld;
  }

  public async createWorld(input: CreatorNewWorldInput): Promise<CreatorWorld> {
    return this.saveWorld(createCreatorWorld(input));
  }

  public async deleteWorld(worldId: string): Promise<void> {
    const database = await this.openDatabase();
    const transaction = database.transaction(WORLDS_STORE, 'readwrite');
    transaction.objectStore(WORLDS_STORE).delete(worldId);
    await transactionDone(transaction);
  }

  public async duplicateWorld(worldId: string): Promise<CreatorWorld> {
    const world = await this.getWorld(worldId);
    if (!world) throw new Error('Mundo não encontrado para duplicação.');
    return this.saveWorld(duplicateCreatorWorld(world));
  }

  public async renameWorld(
    worldId: string,
    name: string,
    description?: string
  ): Promise<CreatorWorld> {
    const world = await this.getWorld(worldId);
    if (!world) throw new Error('Mundo não encontrado para edição.');
    world.name = name.trim() || world.name;
    if (description !== undefined) world.description = description.trim();
    world.metadata.updatedAt = Date.now();
    world.metadata.revision += 1;
    return this.saveWorld(world);
  }

  public async exportWorld(worldId: string): Promise<string> {
    const world = await this.getWorld(worldId);
    if (!world) throw new Error('Mundo não encontrado para exportação.');
    return exportCreatorWorld(world);
  }

  public async importWorld(text: string): Promise<CreatorWorld> {
    const importedWorld = importCreatorWorld(text);
    const existingWorld = await this.getWorld(importedWorld.id);
    if (existingWorld) {
      importedWorld.id = `creator_world_${crypto.randomUUID()}`;
      importedWorld.name = `${importedWorld.name} (importado)`;
    }
    importedWorld.metadata.updatedAt = Date.now();
    importedWorld.metadata.lastProviderUsed = 'Importado por arquivo';
    return this.saveWorld(importedWorld);
  }

  public async listAssets(): Promise<CreatorAssetDescriptor[]> {
    await this.seedBuiltinAssets(await this.openDatabase());
    const database = await this.openDatabase();
    const transaction = database.transaction(ASSETS_STORE, 'readonly');
    const stored = await requestResult(
      transaction.objectStore(ASSETS_STORE).getAll()
    );
    return (stored as unknown[]).map((asset) =>
      validateAssetDescriptor(asset)
    );
  }

  public async importAssets(text: string): Promise<CreatorAssetDescriptor[]> {
    const parsed = JSON.parse(text) as Partial<CreatorAssetManifest>;
    if (parsed.format !== CREATOR_ASSET_FORMAT) {
      throw new Error('Manifesto de assets com formato desconhecido.');
    }
    if (
      typeof parsed.formatVersion !== 'number' ||
      parsed.formatVersion > CREATOR_ASSET_FORMAT_VERSION
    ) {
      throw new Error('A versão do manifesto de assets não é suportada.');
    }
    if (!Array.isArray(parsed.assets)) {
      throw new Error('O manifesto não contém a lista "assets".');
    }

    const assets = parsed.assets.map(validateAssetDescriptor);
    const database = await this.openDatabase();
    const transaction = database.transaction(ASSETS_STORE, 'readwrite');
    const store = transaction.objectStore(ASSETS_STORE);
    for (const asset of assets) store.put({ ...asset, builtin: false });
    await transactionDone(transaction);
    return assets;
  }

  private async seedBuiltinAssets(database: IDBDatabase): Promise<void> {
    const transaction = database.transaction(ASSETS_STORE, 'readwrite');
    const store = transaction.objectStore(ASSETS_STORE);
    for (const asset of BUILTIN_CREATOR_ASSETS) store.put(asset);
    await transactionDone(transaction);
  }
}

export const creatorStorage = new CreatorStorage();
