import {
  CREATOR_ASSET_FORMAT,
  CREATOR_ASSET_FORMAT_VERSION,
  CREATOR_WORLD_FORMAT,
  CREATOR_WORLD_FORMAT_VERSION,
  CreatorAssetDescriptor,
  CreatorAssetManifest,
  CreatorNewWorldInput,
  CreatorWorld,
  CreatorWorldSizeMeters,
} from './types';

const WORLD_SIZE_VALUES: CreatorWorldSizeMeters[] = [10000, 20000, 50000];
const CHUNK_SIZE_BY_WORLD_SIZE: Record<CreatorWorldSizeMeters, number> = {
  10000: 1000,
  20000: 2000,
  50000: 5000,
};

export interface CreatorValidationResult {
  valid: boolean;
  errors: string[];
  world?: CreatorWorld;
}

export function createCreatorWorld(input: CreatorNewWorldInput): CreatorWorld {
  const now = Date.now();
  const sizeMeters = WORLD_SIZE_VALUES.includes(input.sizeMeters)
    ? input.sizeMeters
    : 20000;

  return {
    format: CREATOR_WORLD_FORMAT,
    formatVersion: CREATOR_WORLD_FORMAT_VERSION,
    id: createId('creator_world'),
    name: input.name.trim() || 'Novo Mundo',
    description: input.description.trim(),
    sizeMeters,
    seed: normalizeSeed(input.seed),
    settings: { ...input.settings },
    chunkSizeMeters: CHUNK_SIZE_BY_WORLD_SIZE[sizeMeters],
    chunkDeltas: {},
    lastEditor: {
      chunkKey: null,
      position: [0, 0, 0],
      yaw: 0,
      pitch: 0,
    },
    savedPoints: [],
    metadata: {
      createdAt: now,
      updatedAt: now,
      lastProviderUsed: 'Creator Manual',
      revision: 1,
    },
  };
}

export function migrateCreatorWorld(value: unknown): CreatorWorld {
  if (!value || typeof value !== 'object') {
    throw new Error('O documento do mundo não é um objeto válido.');
  }

  const source = value as Record<string, unknown>;
  const legacyWorld = source as Partial<CreatorWorld> & {
    formatVersion?: number;
    size?: { width?: number; scaleLabel?: string };
  };
  const legacySize =
    legacyWorld.sizeMeters ??
    (legacyWorld.size?.width && WORLD_SIZE_VALUES.includes(legacyWorld.size.width as CreatorWorldSizeMeters)
      ? (legacyWorld.size.width as CreatorWorldSizeMeters)
      : 20000);
  const sizeMeters = WORLD_SIZE_VALUES.includes(legacySize as CreatorWorldSizeMeters)
    ? (legacySize as CreatorWorldSizeMeters)
    : 20000;
  const now = Date.now();
  const createdAt =
    typeof legacyWorld.metadata?.createdAt === 'number'
      ? legacyWorld.metadata.createdAt
      : now;

  return {
    format: CREATOR_WORLD_FORMAT,
    formatVersion: CREATOR_WORLD_FORMAT_VERSION,
    id:
      typeof legacyWorld.id === 'string' && legacyWorld.id.trim()
        ? legacyWorld.id
        : createId('creator_world'),
    name:
      typeof legacyWorld.name === 'string' && legacyWorld.name.trim()
        ? legacyWorld.name
        : 'Mundo importado',
    description:
      typeof legacyWorld.description === 'string' ? legacyWorld.description : '',
    sizeMeters,
    seed: normalizeSeed(typeof legacyWorld.seed === 'number' ? legacyWorld.seed : 1),
    settings: {
      style: legacyWorld.settings?.style ?? 'realista',
      terrain: legacyWorld.settings?.terrain ?? 'plano',
      climate: legacyWorld.settings?.climate ?? 'temperado',
      objectDensity: legacyWorld.settings?.objectDensity ?? 'media',
      quality: legacyWorld.settings?.quality ?? 'equilibrado',
    },
    chunkSizeMeters:
      typeof legacyWorld.chunkSizeMeters === 'number' && legacyWorld.chunkSizeMeters > 0
        ? legacyWorld.chunkSizeMeters
        : CHUNK_SIZE_BY_WORLD_SIZE[sizeMeters],
    chunkDeltas:
      legacyWorld.chunkDeltas && typeof legacyWorld.chunkDeltas === 'object'
        ? structuredClone(legacyWorld.chunkDeltas)
        : {},
    lastEditor: {
      chunkKey:
        typeof legacyWorld.lastEditor?.chunkKey === 'string'
          ? legacyWorld.lastEditor.chunkKey
          : null,
      position: normalizeVector(legacyWorld.lastEditor?.position),
      yaw:
        typeof legacyWorld.lastEditor?.yaw === 'number'
          ? legacyWorld.lastEditor.yaw
          : 0,
      pitch:
        typeof legacyWorld.lastEditor?.pitch === 'number'
          ? legacyWorld.lastEditor.pitch
          : 0,
    },
    savedPoints: Array.isArray(legacyWorld.savedPoints)
      ? legacyWorld.savedPoints
          .filter(
            (point): point is import('./types').CreatorSavedPoint =>
              Boolean(
                point &&
                  typeof point.id === 'string' &&
                  typeof point.label === 'string' &&
                  Array.isArray(point.position) &&
                  point.position.length === 3
              )
          )
          .map((point) => ({
            ...point,
            position: normalizeVector(point.position),
            yaw: Number.isFinite(point.yaw) ? point.yaw : 0,
            pitch: Number.isFinite(point.pitch) ? point.pitch : 0,
            createdAt: Number.isFinite(point.createdAt)
              ? point.createdAt
              : now,
          }))
      : [],
    metadata: {
      createdAt,
      updatedAt:
        typeof legacyWorld.metadata?.updatedAt === 'number'
          ? legacyWorld.metadata.updatedAt
          : now,
      lastProviderUsed:
        typeof legacyWorld.metadata?.lastProviderUsed === 'string'
          ? legacyWorld.metadata.lastProviderUsed
          : 'Importado',
      revision:
        typeof legacyWorld.metadata?.revision === 'number'
          ? legacyWorld.metadata.revision
          : 1,
    },
  };
}

export function validateCreatorWorld(value: unknown): CreatorValidationResult {
  try {
    const errors: string[] = [];
    const source =
      value && typeof value === 'object'
        ? (value as Record<string, unknown>)
        : {};
    const sourceWorld = source as Partial<CreatorWorld> & {
      size?: { width?: number };
    };

    if (
      'name' in source &&
      (typeof sourceWorld.name !== 'string' || !sourceWorld.name.trim())
    ) {
      errors.push('O nome do mundo está vazio.');
    }
    const sourceSize =
      sourceWorld.sizeMeters ??
      (sourceWorld.size?.width as CreatorWorldSizeMeters | undefined);
    if ('sizeMeters' in source || 'size' in source) {
      if (
        typeof sourceSize !== 'number' ||
        !WORLD_SIZE_VALUES.includes(sourceSize)
      ) {
        errors.push('O tamanho deve ser 10 km, 20 km ou 50 km.');
      }
    }
    if ('seed' in source && !Number.isFinite(sourceWorld.seed)) {
      errors.push('A seed deve ser um número.');
    }
    if ('id' in source && typeof sourceWorld.id !== 'string') {
      errors.push('O mundo não possui ID.');
    }
    if (
      typeof sourceWorld.formatVersion === 'number' &&
      sourceWorld.formatVersion > CREATOR_WORLD_FORMAT_VERSION
    ) {
      errors.push(
        `O formato ${sourceWorld.formatVersion} é mais novo que o suportado (${CREATOR_WORLD_FORMAT_VERSION}).`
      );
    }
    if ('chunkDeltas' in source && !sourceWorld.chunkDeltas) {
      errors.push('O mundo não contém o registro de deltas por chunk.');
    }

    if (errors.length > 0) return { valid: false, errors };

    const world = migrateCreatorWorld(value);
    if (
      sourceWorld.chunkDeltas &&
      typeof sourceWorld.chunkDeltas === 'object'
    ) {
      for (const [chunkKey, chunkDelta] of Object.entries(
        sourceWorld.chunkDeltas
      )) {
        if (chunkDelta?.chunkKey !== chunkKey) {
          errors.push(`O chunk ${chunkKey} possui uma chave inconsistente.`);
        }
        if (!Array.isArray(chunkDelta?.mutations)) {
          errors.push(`O chunk ${chunkKey} não contém uma lista de mutações.`);
        }
      }
    }

    return { valid: errors.length === 0, errors, world };
  } catch (error) {
    return {
      valid: false,
      errors: [error instanceof Error ? error.message : 'Documento inválido.'],
    };
  }
}

export function exportCreatorWorld(world: CreatorWorld): string {
  const validated = validateCreatorWorld(world);
  if (!validated.valid || !validated.world) {
    throw new Error(validated.errors.join(' '));
  }
  return JSON.stringify(validated.world, null, 2);
}

export function importCreatorWorld(text: string): CreatorWorld {
  let parsed: unknown;
  try {
    parsed = JSON.parse(text);
  } catch {
    throw new Error('O arquivo não contém JSON válido.');
  }

  const source =
    parsed &&
    typeof parsed === 'object' &&
    'world' in (parsed as Record<string, unknown>) &&
    'format' in (parsed as Record<string, unknown>)
      ? (parsed as { world: unknown }).world
      : parsed;
  const validated = validateCreatorWorld(source);
  if (!validated.valid || !validated.world) {
    throw new Error(validated.errors.join(' '));
  }
  return validated.world;
}

export function duplicateCreatorWorld(world: CreatorWorld): CreatorWorld {
  const now = Date.now();
  const duplicate = structuredClone(world);
  duplicate.id = createId('creator_world');
  duplicate.name = `${world.name} (cópia)`;
  duplicate.metadata = {
    ...duplicate.metadata,
    createdAt: now,
    updatedAt: now,
    revision: 1,
    lastProviderUsed: 'Duplicado pelo Criador',
  };
  return duplicate;
}

export function validateAssetDescriptor(value: unknown): CreatorAssetDescriptor {
  if (!value || typeof value !== 'object') {
    throw new Error('Asset inválido.');
  }

  const source = value as Partial<CreatorAssetDescriptor>;
  const requiredStrings: Array<keyof CreatorAssetDescriptor> = [
    'id',
    'name',
    'category',
    'type',
    'material',
    'thumbnail',
  ];
  const missing = requiredStrings.filter(
    (field) => typeof source[field] !== 'string' || !String(source[field]).trim()
  );
  if (missing.length > 0) {
    throw new Error(`Asset sem campos obrigatórios: ${missing.join(', ')}.`);
  }
  if (!source.thumbnail?.startsWith('data:image/')) {
    throw new Error('O thumbnail deve ser uma imagem embutida ou data URL.');
  }

  return {
    id: source.id as string,
    name: source.name as string,
    category: source.category as CreatorAssetDescriptor['category'],
    type: source.type as CreatorAssetDescriptor['type'],
    sizeBytes: Number.isFinite(source.sizeBytes) ? Number(source.sizeBytes) : 0,
    lods: Array.isArray(source.lods) ? source.lods.filter(Number.isFinite) : [0],
    collider: source.collider ?? 'box',
    material: source.material as string,
    polycount: Number.isFinite(source.polycount) ? Number(source.polycount) : 0,
    thumbnail: source.thumbnail as string,
    version: Number.isFinite(source.version) ? Number(source.version) : 1,
    builtin: Boolean(source.builtin),
  };
}

export function parseAssetManifest(text: string): CreatorAssetManifest {
  const parsed = JSON.parse(text) as Partial<CreatorAssetManifest>;
  if (parsed.format !== CREATOR_ASSET_FORMAT) {
    throw new Error('Manifesto de assets com formato desconhecido.');
  }
  if (
    typeof parsed.formatVersion !== 'number' ||
    parsed.formatVersion > CREATOR_ASSET_FORMAT_VERSION
  ) {
    throw new Error('A versão do manifesto de assets não é suportada.');
  }
  if (!Array.isArray(parsed.assets)) {
    throw new Error('O manifesto não contém a lista "assets".');
  }

  return {
    format: CREATOR_ASSET_FORMAT,
    formatVersion: CREATOR_ASSET_FORMAT_VERSION,
    assets: parsed.assets.map(validateAssetDescriptor),
  };
}

function normalizeSeed(seed: number): number {
  if (!Number.isFinite(seed)) return 1;
  return Math.abs(Math.trunc(seed)) || 1;
}

function normalizeVector(value: unknown): [number, number, number] {
  if (
    Array.isArray(value) &&
    value.length === 3 &&
    value.every((entry) => Number.isFinite(entry))
  ) {
    return [Number(value[0]), Number(value[1]), Number(value[2])];
  }
  return [0, 0, 0];
}

function createId(prefix: string): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) {
    return `${prefix}_${crypto.randomUUID()}`;
  }
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2)}`;
}
