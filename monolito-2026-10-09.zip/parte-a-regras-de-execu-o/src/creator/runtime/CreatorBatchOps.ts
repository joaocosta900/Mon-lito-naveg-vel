import { CreatorChunkMutation, CreatorEntityDelta } from '../types';
import { CreatorEntityStore } from './CreatorEntityStore';

export interface CreatorBatchPlan {
  forward: CreatorChunkMutation[];
  backward: CreatorChunkMutation[];
  label: string;
  detail: string;
}

type PlanBuilder = (
  store: CreatorEntityStore,
  entities: CreatorEntityDelta[]
) => CreatorBatchPlan | null;

function emptyPlan(label: string, detail: string): CreatorBatchPlan {
  return { forward: [], backward: [], label, detail };
}

/**
 * Centraliza as operações em lote da seção 9 para que a interface e os testes
 * exercitem exatamente a mesma lógica.
 */
export const buildAlign: PlanBuilder = (store, entities) => {
  if (entities.length < 2) {
    return emptyPlan('Alinhar', 'Alinhar exige dois ou mais objetos.');
  }
  const axis = spreadX(entities) >= spreadZ(entities) ? 'x' : 'z';
  const values = entities.map((entity) =>
    axis === 'x' ? entity.position[0] : entity.position[2]
  );
  const target = (Math.min(...values) + Math.max(...values)) / 2;
  return planFor(
    store,
    entities,
    (entity) => reposition(entity, axis, target),
    `Alinhar ${axis.toUpperCase()}`,
    `${entities.length} objeto(s) alinhados em ${axis.toUpperCase()}.`
  );
};

export const buildDistribute: PlanBuilder = (store, entities) => {
  if (entities.length < 3) {
    return emptyPlan('Distribuir', 'Distribuir exige três ou mais objetos.');
  }
  const axis = spreadX(entities) >= spreadZ(entities) ? 'x' : 'z';
  const sorted = [...entities].sort((left, right) =>
    axis === 'x' ? left.position[0] - right.position[0] : left.position[2] - right.position[2]
  );
  const keys = sorted.map((entity) =>
    axis === 'x' ? entity.position[0] : entity.position[2]
  );
  const min = Math.min(...keys);
  const step = (Math.max(...keys) - min) / (sorted.length - 1);

  const forward: CreatorChunkMutation[] = [];
  const backward: CreatorChunkMutation[] = [];
  sorted.forEach((entity, index) => {
    const mutation = buildReposition(store, entity, axis, min + step * index);
    if (!mutation) return;
    forward.push(mutation);
    backward.push(restorePosition(entity));
  });
  return {
    forward,
    backward,
    label: 'Distribuir',
    detail: `${sorted.length} objeto(s) distribuídos em ${axis.toUpperCase()}.`,
  };
};

function resizeWithFactor(
  store: CreatorEntityStore,
  entities: CreatorEntityDelta[],
  factor: number
): CreatorBatchPlan | null {
  if (entities.length === 0) return null;
  const forward: CreatorChunkMutation[] = [];
  const backward: CreatorChunkMutation[] = [];
  for (const entity of entities) {
    const next: [number, number, number] = [
      clamp(entity.scale[0] * factor),
      clamp(entity.scale[1] * factor),
      clamp(entity.scale[2] * factor),
    ];
    const build = store.buildUpdate(entity.entityId, { scale: next });
    if (!build) continue;
    forward.push(build.mutation);
    backward.push({
      type: 'entity-update',
      entityId: entity.entityId,
      changes: { scale: [...entity.scale] as [number, number, number] },
    });
  }
  return {
    forward,
    backward,
    label: 'Redimensionar',
    detail: `Escala ajustada em ×${factor}.`,
  };
}

function clamp(value: number): number {
  return Math.min(12, Math.max(0.25, value));
}

function spreadX(entities: CreatorEntityDelta[]): number {
  const values = entities.map((entity) => entity.position[0]);
  return Math.max(...values) - Math.min(...values);
}

function spreadZ(entities: CreatorEntityDelta[]): number {
  const values = entities.map((entity) => entity.position[2]);
  return Math.max(...values) - Math.min(...values);
}

function reposition(
  entity: CreatorEntityDelta,
  axis: 'x' | 'z',
  value: number
): [number, number, number] {
  return axis === 'x'
    ? [value, entity.position[1], entity.position[2]]
    : [entity.position[0], entity.position[1], value];
}

function buildReposition(
  store: CreatorEntityStore,
  entity: CreatorEntityDelta,
  axis: 'x' | 'z',
  value: number
): CreatorChunkMutation | null {
  const [nextX, , nextZ] = reposition(entity, axis, value);
  const build = store.buildUpdate(entity.entityId, {
    position: [nextX, store.getGroundHeight(nextX, nextZ), nextZ],
  });
  return build?.mutation ?? null;
}

function restorePosition(entity: CreatorEntityDelta): CreatorChunkMutation {
  return {
    type: 'entity-update',
    entityId: entity.entityId,
    changes: { position: [...entity.position] as [number, number, number] },
  };
}

function planFor(
  store: CreatorEntityStore,
  entities: CreatorEntityDelta[],
  resolve: (entity: CreatorEntityDelta) => [number, number, number],
  label: string,
  detail: string
): CreatorBatchPlan {
  const forward: CreatorChunkMutation[] = [];
  const backward: CreatorChunkMutation[] = [];
  for (const entity of entities) {
    const [nextX, , nextZ] = resolve(entity);
    const build = store.buildUpdate(entity.entityId, {
      position: [nextX, store.getGroundHeight(nextX, nextZ), nextZ],
    });
    if (!build) continue;
    forward.push(build.mutation);
    backward.push(restorePosition(entity));
  }
  return { forward, backward, label, detail };
}

export function buildResize(
  store: CreatorEntityStore,
  entities: CreatorEntityDelta[],
  factor: number
): CreatorBatchPlan | null {
  return resizeWithFactor(store, entities, factor);
}
