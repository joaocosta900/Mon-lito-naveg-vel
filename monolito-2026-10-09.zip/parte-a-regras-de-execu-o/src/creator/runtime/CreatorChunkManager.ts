import * as THREE from 'three';
import { CreatorWorld, CreatorWorldSettings } from '../types';

export interface CreatorLoadedChunk {
  key: string;
  col: number;
  row: number;
  centerX: number;
  centerZ: number;
}

export interface CreatorStreamingUpdate {
  currentKey: string;
  loaded: CreatorLoadedChunk[];
  unloaded: string[];
  rebased: boolean;
}

interface CreatorLoadedChunkRecord {
  key: string;
  col: number;
  row: number;
  centerX: number;
  centerZ: number;
  group: THREE.Group;
}

export class CreatorChunkManager {
  private readonly world: CreatorWorld;
  private readonly scene: THREE.Scene;
  private readonly loaded = new Map<string, CreatorLoadedChunkRecord>();
  private readonly geometries = new Set<THREE.BufferGeometry>();
  private readonly material: THREE.MeshStandardMaterial;
  private originX = 0;
  private originZ = 0;
  private currentCol = -1;
  private currentRow = -1;
  private disposed = false;

  public constructor(world: CreatorWorld, scene: THREE.Scene) {
    this.world = world;
    this.scene = scene;
    this.material = new THREE.MeshStandardMaterial({
      vertexColors: true,
      roughness: 0.92,
      metalness: 0.02,
      flatShading: false,
    });
  }

  public update(cameraPosition: THREE.Vector3): CreatorStreamingUpdate {
    if (this.disposed) {
      return { currentKey: '', loaded: [], unloaded: [], rebased: false };
    }

    const rebased = this.rebaseIfNeeded(cameraPosition);
    const chunkCoord = this.getChunkCoord(cameraPosition.x, cameraPosition.z);
    const currentKey = this.getKey(chunkCoord.col, chunkCoord.row);
    this.currentCol = chunkCoord.col;
    this.currentRow = chunkCoord.row;

    const wantedKeys = new Set<string>();
    for (let rowOffset = -1; rowOffset <= 1; rowOffset += 1) {
      for (let colOffset = -1; colOffset <= 1; colOffset += 1) {
        const col = chunkCoord.col + colOffset;
        const row = chunkCoord.row + rowOffset;
        if (!this.isInsideWorld(col, row)) continue;
        const key = this.getKey(col, row);
        wantedKeys.add(key);
        if (!this.loaded.has(key)) {
          this.loaded.set(key, this.createChunk(col, row));
        }
      }
    }

    const unloaded: string[] = [];
    for (const [key, record] of this.loaded) {
      const distance = Math.max(
        Math.abs(record.col - chunkCoord.col),
        Math.abs(record.row - chunkCoord.row)
      );
      if (distance > 2 || !wantedKeys.has(key)) {
        this.disposeRecord(record);
        this.loaded.delete(key);
        unloaded.push(key);
      }
    }

    this.updateGroupPositions();
    return {
      currentKey,
      loaded: this.getLoadedChunks(),
      unloaded,
      rebased,
    };
  }

  public getHeightAt(worldX: number, worldZ: number): number {
    return getHeightAt(
      worldX,
      worldZ,
      this.world.seed,
      this.world.settings
    );
  }

  public getLoadedChunks(): CreatorLoadedChunk[] {
    return Array.from(this.loaded.values())
      .map((record) => ({
        key: record.key,
        col: record.col,
        row: record.row,
        centerX: record.centerX,
        centerZ: record.centerZ,
      }))
      .sort((leftChunk, rightChunk) =>
        leftChunk.key.localeCompare(rightChunk.key)
      );
  }

  public getOrigin(): { x: number; z: number } {
    return { x: this.originX, z: this.originZ };
  }

  public dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    for (const record of this.loaded.values()) {
      this.disposeRecord(record);
    }
    this.loaded.clear();
    for (const geometry of this.geometries) geometry.dispose();
    this.geometries.clear();
    this.material.dispose();
  }

  private createChunk(col: number, row: number): CreatorLoadedChunkRecord {
    const halfWidth = this.world.sizeMeters / 2;
    const centerX = -halfWidth + (col + 0.5) * this.world.chunkSizeMeters;
    const centerZ = -halfWidth + (row + 0.5) * this.world.chunkSizeMeters;
    const segmentCount = this.world.chunkSizeMeters >= 5000 ? 24 : 32;
    const geometry = new THREE.PlaneGeometry(
      this.world.chunkSizeMeters,
      this.world.chunkSizeMeters,
      segmentCount,
      segmentCount
    );
    geometry.rotateX(-Math.PI / 2);
    this.trackGeometry(geometry);

    const positions = geometry.getAttribute('position') as THREE.BufferAttribute;
    const colors = new Float32Array(positions.count * 3);
    const heightColors = new THREE.Color();
    for (let vertexIndex = 0; vertexIndex < positions.count; vertexIndex += 1) {
      const localX = positions.getX(vertexIndex);
      const localZ = positions.getZ(vertexIndex);
      const worldX = centerX + localX;
      const worldZ = centerZ + localZ;
      const height = this.getHeightAt(worldX, worldZ);
      positions.setY(vertexIndex, height);
      const normalizedHeight = THREE.MathUtils.clamp((height + 40) / 160, 0, 1);
      heightColors.setHSL(
        THREE.MathUtils.lerp(0.28, 0.12, normalizedHeight),
        THREE.MathUtils.lerp(0.2, 0.45, normalizedHeight),
        THREE.MathUtils.lerp(0.24, 0.46, normalizedHeight)
      );
      colors[vertexIndex * 3] = heightColors.r;
      colors[vertexIndex * 3 + 1] = heightColors.g;
      colors[vertexIndex * 3 + 2] = heightColors.b;
    }
    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    positions.needsUpdate = true;
    geometry.computeVertexNormals();

    const group = new THREE.Group();
    group.name = `creator_chunk_${col}_${row}`;
    const mesh = new THREE.Mesh(geometry, this.material);
    mesh.receiveShadow = true;
    group.add(mesh);
    this.scene.add(group);

    return {
      key: this.getKey(col, row),
      col,
      row,
      centerX,
      centerZ,
      group,
    };
  }

  private updateGroupPositions(): void {
    for (const record of this.loaded.values()) {
      record.group.position.set(
        record.centerX - this.originX,
        0,
        record.centerZ - this.originZ
      );
    }
  }

  private rebaseIfNeeded(cameraPosition: THREE.Vector3): boolean {
    const threshold = Math.max(1500, this.world.chunkSizeMeters * 1.5);
    const deltaX = cameraPosition.x - this.originX;
    const deltaZ = cameraPosition.z - this.originZ;
    if (Math.abs(deltaX) < threshold && Math.abs(deltaZ) < threshold) {
      return false;
    }

    const rebasingGrid = Math.max(250, Math.round(this.world.chunkSizeMeters / 4));
    this.originX = Math.round(cameraPosition.x / rebasingGrid) * rebasingGrid;
    this.originZ = Math.round(cameraPosition.z / rebasingGrid) * rebasingGrid;
    this.updateGroupPositions();
    return true;
  }

  private getChunkCoord(worldX: number, worldZ: number): { col: number; row: number } {
    const halfWidth = this.world.sizeMeters / 2;
    const col = Math.floor((worldX + halfWidth) / this.world.chunkSizeMeters);
    const row = Math.floor((worldZ + halfWidth) / this.world.chunkSizeMeters);
    return {
      col: THREE.MathUtils.clamp(col, 0, this.getGridSize() - 1),
      row: THREE.MathUtils.clamp(row, 0, this.getGridSize() - 1),
    };
  }

  private isInsideWorld(col: number, row: number): boolean {
    return col >= 0 && row >= 0 && col < this.getGridSize() && row < this.getGridSize();
  }

  private getGridSize(): number {
    return Math.round(this.world.sizeMeters / this.world.chunkSizeMeters);
  }

  private getKey(col: number, row: number): string {
    return `${col}:${row}`;
  }

  private trackGeometry(geometry: THREE.BufferGeometry): void {
    this.geometries.add(geometry);
  }

  private disposeRecord(record: CreatorLoadedChunkRecord): void {
    record.group.removeFromParent();
    record.group.traverse((object) => {
      const mesh = object as THREE.Mesh;
      if (!mesh.isMesh) return;
      mesh.geometry.dispose();
      this.geometries.delete(mesh.geometry);
    });
  }
}

function getHeightAt(
  worldX: number,
  worldZ: number,
  seed: number,
  settings: CreatorWorldSettings
): number {
  const broadNoise =
    Math.sin((worldX + seed * 0.013) * 0.00115) *
      Math.cos((worldZ - seed * 0.017) * 0.00131) +
    Math.sin((worldX - worldZ) * 0.00047 + seed * 0.0007) * 0.55;
  const fineNoise =
    Math.sin(worldX * 0.0061 + seed) * Math.cos(worldZ * 0.0057 - seed) * 0.18;
  const base = broadNoise * 24 + fineNoise * 8;

  switch (settings.terrain) {
    case 'plano':
      return base * 0.25;
    case 'colinas':
      return base * 1.8 + Math.abs(broadNoise) * 22;
    case 'montanhoso':
      return Math.abs(broadNoise) * 95 + Math.abs(fineNoise) * 34 - 8;
    case 'costeiro':
      return base * 1.2 + Math.sin(worldX * 0.00025) * 30;
    case 'deserto':
      return Math.abs(broadNoise) * 38 + fineNoise * 18;
    case 'ilhas':
      return Math.max(-18, Math.abs(broadNoise) * 72 - 28);
    default:
      return base;
  }
}
