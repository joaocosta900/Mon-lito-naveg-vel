import * as THREE from 'three';

export type CreatorGridMode = 'livre' | 1 | 5 | 10 | 50;

export type CreatorSnapKind = 'terreno' | 'objeto' | 'estrada' | 'construcao';

export const CREATOR_GRID_MODES: Array<{ mode: CreatorGridMode; label: string }> = [
  { mode: 'livre', label: 'GRID LIVRE' },
  { mode: 1, label: 'GRID 1m' },
  { mode: 5, label: 'GRID 5m' },
  { mode: 10, label: 'GRID 10m' },
  { mode: 50, label: 'GRID 50m' },
];

export const CREATOR_SNAP_KINDS: Array<{ kind: CreatorSnapKind; label: string }> = [
  { kind: 'terreno', label: 'SNAP TERRENO' },
  { kind: 'objeto', label: 'SNAP OBJETO' },
  { kind: 'estrada', label: 'SNAP ESTRADA' },
  { kind: 'construcao', label: 'SNAP CONSTRUÇÃO' },
];

/** A grade é múltipla do chunk para nunca desenhar Millions de linhas. */
const GRID_SPAN_METERS = 400;

export function snapValue(value: number, mode: CreatorGridMode): number {
  if (mode === 'livre') return value;
  return Math.round(value / mode) * mode;
}

export function applySnap(
  value: number,
  mode: CreatorGridMode,
  kind: CreatorSnapKind,
  enabled: Record<CreatorSnapKind, boolean>
): number {
  if (!enabled[kind]) return value;
  return snapValue(value, mode);
}

export function snapRotation(degrees: number, mode: CreatorGridMode): number {
  if (mode === 'livre') return degrees;
  const step = mode * 4;
  return Math.round(degrees / step) * step;
}

export class CreatorGridOverlay {
  private readonly lines: THREE.LineSegments;
  private readonly geometry = new THREE.BufferGeometry();
  private readonly material: THREE.LineBasicMaterial;
  private readonly half = GRID_SPAN_METERS / 2;

  public constructor() {
    this.material = new THREE.LineBasicMaterial({
      color: 0x6ee7b7,
      transparent: true,
      opacity: 0.28,
    });
    this.lines = new THREE.LineSegments(this.geometry, this.material);
    this.lines.name = 'creator_grid';
    this.lines.frustumCulled = false;
    this.lines.visible = false;
    this.rebuild('livre');
  }

  public get object(): THREE.Object3D {
    return this.lines;
  }

  public setMode(mode: CreatorGridMode): void {
    this.rebuild(mode);
  }

  public setVisible(visible: boolean): void {
    this.lines.visible = visible && this.hasLines;
  }

  /** Reposiciona a grade sob a câmera, sempre centrada nela. */
  public update(cameraPosition: THREE.Vector3, groundHeight: number): void {
    this.lines.position.set(cameraPosition.x, groundHeight + 0.35, cameraPosition.z);
  }

  public dispose(): void {
    this.geometry.dispose();
    this.material.dispose();
  }

  private hasLines = false;

  private rebuild(mode: CreatorGridMode): void {
    if (mode === 'livre') {
      this.geometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array(0), 3));
      this.hasLines = false;
      this.lines.visible = false;
      return;
    }
    const step = mode as number;
    const divisions = Math.floor(GRID_SPAN_METERS / step);
    const positions: number[] = [];
    for (let index = 0; index <= divisions; index += 1) {
      const offset = -this.half + index * step;
      positions.push(-this.half, 0, offset, this.half, 0, offset);
      positions.push(offset, 0, -this.half, offset, 0, this.half);
    }
    const geometry = new THREE.BufferAttribute(new Float32Array(positions), 3);
    this.geometry.setAttribute('position', geometry);
    this.geometry.computeBoundingSphere();
    this.hasLines = true;
    this.lines.visible = true;
  }
}
