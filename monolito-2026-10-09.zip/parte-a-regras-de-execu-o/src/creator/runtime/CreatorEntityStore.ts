import * as THREE from 'three';
import { CreatorChunkDelta, CreatorChunkMutation, CreatorEntityDelta } from '../types';
import { CreatorWorld } from '../types';
import { CreatorChunkManager } from './CreatorChunkManager';

export interface CreatorEntityRecord {
  entity: CreatorEntityDelta;
  chunkKey: string;
}

export interface CreatorPlacementResult {
  entity: CreatorEntityDelta | null;
  mutation: CreatorChunkMutation | null;
  chunkKey: string;
}

interface EntityShape {
  width: number;
  depth: number;
  height: number;
  color: number;
}

const DEFAULT_SHAPE: EntityShape = {
  width: 4,
  depth: 4,
  height: 4,
  color: 0x9aa4b0,
};

/**
 * Proporções realistas por prefab, com pivô na base (regra de geometria 26).
 * Cada valor foi escolhido para não gerar casas/carros deformados.
 */
const SHAPES_BY_PREFAB: Record<string, EntityShape> = {
  prefab_foundation_8x10: { width: 8, depth: 10, height: 0.6, color: 0x8d8b86 },
  prefab_house_small: { width: 8, depth: 10, height: 4.2, color: 0xc58b62 },
  road_segment_straight: { width: 8, depth: 24, height: 0.2, color: 0x4a4f55 },
  vegetation_tree_basic: { width: 1.2, depth: 1.2, height: 6.5, color: 0x4e8a52 },
  urban_street_light: { width: 0.4, depth: 0.4, height: 7, color: 0x6f7680 },
  vehicle_basic_car: { width: 1.9, depth: 4.4, height: 1.5, color: 0xb85d5d },
  futuristic_spire_module: { width: 5, depth: 5, height: 12, color: 0x67d9dc },
};

function getShape(prefabId: string): EntityShape {
  return SHAPES_BY_PREFAB[prefabId] ?? DEFAULT_SHAPE;
}

function createEntityId(): string {
  return `entity_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

/**
 * Camada de objetos do mundo. Lê e escreve em `chunkDeltas` — nunca inventa estado
 * fora do documento, para que tudo o que é colocado seja persistido de verdade.
 */
export class CreatorEntityStore {
  private readonly world: CreatorWorld;
  private readonly scene: THREE.Scene;
  private readonly chunkManager: CreatorChunkManager;
  private readonly root = new THREE.Group();
  private readonly records = new Map<string, CreatorEntityRecord>();
  private readonly meshes = new Map<string, THREE.Mesh>();
  private readonly geometries = new Set<THREE.BufferGeometry>();
  private readonly materials = new Map<string, THREE.MeshStandardMaterial>();
  private readonly activeChunks = new Set<string>();
  private readonly raycaster = new THREE.Raycaster();

  public constructor(
    world: CreatorWorld,
    scene: THREE.Scene,
    chunkManager: CreatorChunkManager
  ) {
    this.world = world;
    this.scene = scene;
    this.chunkManager = chunkManager;
    this.root.name = 'creator_entities';
    this.scene.add(this.root);
    this.loadAllFromDocument();
    this.syncOrigin();
  }

  /**
   * Desloca o grupo de entidades pelo mesmo `-origin` que os chunks usam.
   *
   * O documento guarda posição absoluta de mundo, mas a cena é desenhada em
   * espaço de render (tudo menos a origin). Sem este offset, cada entidade fica
   * `origin` metros longe do terreno assim que a floating origin recentraliza —
   * o objeto é criado, fica visível, mas some do mapa.
   */
  public syncOrigin(): void {
    const origin = this.chunkManager.getOrigin();
    this.root.position.set(-origin.x, 0, -origin.z);
    this.root.updateMatrixWorld(true);
  }

  /** Sincroniza quais chunks têm objetos visíveis. */
  public syncVisibleChunks(chunkKeys: Set<string>): void {
    for (const key of Array.from(this.activeChunks)) {
      if (!chunkKeys.has(key)) {
        this.activeChunks.delete(key);
        for (const record of this.records.values()) {
          if (record.chunkKey === key) this.hideMesh(record.entity.entityId);
        }
      }
    }
    for (const key of chunkKeys) {
      if (this.activeChunks.has(key)) continue;
      this.activeChunks.add(key);
      for (const record of this.records.values()) {
        if (record.chunkKey === key) this.showMesh(record.entity.entityId);
      }
    }
  }

  /** Entidades montadas e visíveis — é o que a seleção por caixa pode atingir. */
  public getVisibleEntities(): CreatorEntityDelta[] {
    return this.getRecords()
      .filter((record) => this.meshes.get(record.entity.entityId)?.visible)
      .map((record) => record.entity);
  }

  public getRecords(): CreatorEntityRecord[] {
    return Array.from(this.records.values());
  }

  public getEntitiesInChunk(chunkKey: string): CreatorEntityDelta[] {
    return this.getRecords()
      .filter((record) => record.chunkKey === chunkKey)
      .map((record) => record.entity);
  }

  /** Origem do floating origin, para quem precisar projetar em espaço de render. */
  public getOrigin(): { x: number; z: number } {
    return this.chunkManager.getOrigin();
  }

  public getGroundHeight(worldX: number, worldZ: number): number {
    return this.chunkManager.getHeightAt(worldX, worldZ);
  }

  public getChunkKeyAt(worldX: number, worldZ: number): string {
    const halfWidth = this.world.sizeMeters / 2;
    const gridSize = Math.round(this.world.sizeMeters / this.world.chunkSizeMeters);
    const col = THREE.MathUtils.clamp(
      Math.floor((worldX + halfWidth) / this.world.chunkSizeMeters),
      0,
      gridSize - 1
    );
    const row = THREE.MathUtils.clamp(
      Math.floor((worldZ + halfWidth) / this.world.chunkSizeMeters),
      0,
      gridSize - 1
    );
    return `${col}:${row}`;
  }

  /** Coloca um asset. A base fica apoiada no terreno (nada flutua). */
  public place(prefabId: string, worldX: number, worldZ: number, yaw: number): CreatorPlacementResult {
    const chunkKey = this.getChunkKeyAt(worldX, worldZ);
    const ground = this.chunkManager.getHeightAt(worldX, worldZ);
    const entity: CreatorEntityDelta = {
      entityId: createEntityId(),
      prefabId,
      position: [worldX, ground, worldZ],
      rotation: [0, yaw, 0],
      scale: [1, 1, 1],
      materialId: 'padrao',
      properties: {},
    };
    return {
      entity,
      mutation: { type: 'entity-add', entity },
      chunkKey,
    };
  }

  public buildUpdate(
    entityId: string,
    changes: Partial<CreatorEntityDelta>
  ): { mutation: CreatorChunkMutation; chunkKey: string } | null {
    const record = this.records.get(entityId);
    if (!record) return null;
    const next: CreatorEntityDelta = { ...record.entity, ...changes };
    return {
      mutation: { type: 'entity-update', entityId, changes: next },
      chunkKey: record.chunkKey,
    };
  }

  public buildRemove(entityId: string): { mutation: CreatorChunkMutation; chunkKey: string } | null {
    const record = this.records.get(entityId);
    if (!record) return null;
    return {
      mutation: { type: 'entity-remove', entityId },
      chunkKey: record.chunkKey,
    };
  }

  public buildReAdd(entity: CreatorEntityDelta): { mutation: CreatorChunkMutation; chunkKey: string } {
    return {
      mutation: { type: 'entity-add', entity: structuredClone(entity) },
      chunkKey: this.getChunkKeyAt(entity.position[0], entity.position[2]),
    };
  }

  /**
   * Aplica uma mutação no documento e reflete na cena.
   *
   * O array `mutations` do chunk guarda o ESTADO ATUAL, não um log. Sem isso,
   * cada desfazer acrescentaria a mutação inversa e o documento cresceria sem
   * limite — justamente o que a seção 14 proíbe no celular.
   */
  public apply(mutation: CreatorChunkMutation): void {
    this.fold(mutation);
    this.applyToScene(mutation);
  }

  private entityIdOfMutation(mutation: CreatorChunkMutation): string | null {
    switch (mutation.type) {
      case 'entity-add':
        return mutation.entity.entityId;
      case 'entity-update':
        return mutation.entityId;
      case 'entity-remove':
        return mutation.entityId;
      default:
        return null;
    }
  }

  private findEntry(
    entityId: string
  ): { chunkKey: string; delta: CreatorChunkDelta; index: number } | null {
    for (const delta of Object.values(this.world.chunkDeltas)) {
      const index = delta.mutations.findIndex(
        (mutation) =>
          (mutation.type === 'entity-add' || mutation.type === 'entity-update') &&
          this.entityIdOfMutation(mutation) === entityId
      );
      if (index >= 0) {
        return { chunkKey: delta.chunkKey, delta, index };
      }
    }
    return null;
  }

  private ensureDelta(chunkKey: string): CreatorChunkDelta {
    const existing = this.world.chunkDeltas[chunkKey];
    if (existing) return existing;
    const created: CreatorChunkDelta = { chunkKey, revision: 0, mutations: [] };
    this.world.chunkDeltas[chunkKey] = created;
    return created;
  }

  private bump(delta: CreatorChunkDelta): void {
    delta.revision += 1;
    if (delta.mutations.length === 0) {
      delete this.world.chunkDeltas[delta.chunkKey];
    }
  }

  private fold(mutation: CreatorChunkMutation): void {
    switch (mutation.type) {
      case 'entity-add': {
        const target = this.ensureDelta(this.getChunkKeyAt(mutation.entity.position[0], mutation.entity.position[2]));
        const existing = target.mutations.findIndex(
          (item) => item.type === 'entity-add' && item.entity.entityId === mutation.entity.entityId
        );
        if (existing >= 0) {
          target.mutations[existing] = mutation;
        } else {
          target.mutations.push(mutation);
        }
        this.bump(target);
        break;
      }
      case 'entity-update': {
        const found = this.findEntry(mutation.entityId);
        const merged: CreatorEntityDelta = {
          ...(found?.delta.mutations[found.index].type === 'entity-add'
            ? (found.delta.mutations[found.index] as { entity: CreatorEntityDelta }).entity
            : ({ entityId: mutation.entityId, prefabId: '', position: [0, 0, 0], rotation: [0, 0, 0], scale: [1, 1, 1], materialId: '', properties: {} } as CreatorEntityDelta)),
          ...mutation.changes,
        };
        if (found) {
          found.delta.mutations.splice(found.index, 1);
        }
        const target = this.ensureDelta(this.getChunkKeyAt(merged.position[0], merged.position[2]));
        target.mutations.push({ type: 'entity-add', entity: merged });
        this.bump(target);
        if (found) this.bump(found.delta);
        break;
      }
      case 'entity-remove': {
        const found = this.findEntry(mutation.entityId);
        if (!found) return;
        found.delta.mutations.splice(found.index, 1);
        this.bump(found.delta);
        break;
      }
      default:
        return;
    }
  }

  /** Aplica e devolve a mutação inversa, para o histórico. */
  public applyWithInverse(mutation: CreatorChunkMutation): CreatorChunkMutation | null {
    const inverse = this.invert(mutation);
    this.apply(mutation);
    return inverse;
  }

  public pick(
    camera: THREE.Camera,
    normalizedX: number,
    normalizedY: number
  ): CreatorEntityDelta | null {
    this.raycaster.setFromCamera(
      new THREE.Vector2(normalizedX, normalizedY),
      camera
    );
    const hits = this.raycaster.intersectObjects(
      Array.from(this.meshes.values()),
      false
    );
    const hit = hits[0];
    if (!hit) return null;
    return this.records.get(hit.object.userData.entityId as string)?.entity ?? null;
  }

  /**
   * Raio contra o terreno, devolvendo o ponto em COORDENADA DE MUNDO.
   *
   * A cena é desenhada em espaço de render (cada chunk deslocado em -origin), então
   * o hit do raycast vem sem a origin. Somar a origin de volta aqui evita o
   * objeto nascer no chunk errado — a origin é conhecimento do store, não da UI.
   */
  public pickTerrainWorld(
    camera: THREE.Camera,
    normalizedX: number,
    normalizedY: number
  ): THREE.Vector3 | null {
    this.raycaster.setFromCamera(
      new THREE.Vector2(normalizedX, normalizedY),
      camera
    );
    const terrainMeshes: THREE.Object3D[] = [];
    this.scene.traverse((object) => {
      const mesh = object as THREE.Mesh;
      if (mesh.isMesh && mesh.parent?.name?.startsWith('creator_chunk_')) {
        terrainMeshes.push(mesh);
      }
    });
    const hits = this.raycaster.intersectObjects(terrainMeshes, false);
    const hit = hits[0];
    if (!hit) return null;
    const origin = this.chunkManager.getOrigin();
    return new THREE.Vector3(
      hit.point.x + origin.x,
      hit.point.y,
      hit.point.z + origin.z
    );
  }

  public highlight(entityId: string | null): void {
    for (const [id, mesh] of this.meshes) {
      const material = mesh.material as THREE.MeshStandardMaterial;
      material.emissive.setHex(id === entityId ? 0x1f6f4a : 0x000000);
      material.emissiveIntensity = id === entityId ? 1 : 0;
    }
  }

  public dispose(): void {
    this.root.removeFromParent();
    for (const geometry of this.geometries) geometry.dispose();
    this.geometries.clear();
    for (const material of this.materials.values()) material.dispose();
    this.materials.clear();
    this.meshes.clear();
    this.records.clear();
  }

  private loadAllFromDocument(): void {
    for (const delta of Object.values(this.world.chunkDeltas)) {
      for (const mutation of delta.mutations) {
        this.applyToScene(mutation);
      }
    }
  }

  private getChunkKeyFromMutation(mutation: CreatorChunkMutation): string {
    switch (mutation.type) {
      case 'entity-add':
        return this.getChunkKeyAt(mutation.entity.position[0], mutation.entity.position[2]);
      case 'entity-update': {
        const record = this.records.get(mutation.entityId);
        if (record) return record.chunkKey;
        const changes = mutation.changes;
        if (changes?.position) {
          return this.getChunkKeyAt(changes.position[0], changes.position[2]);
        }
        return '0:0';
      }
      case 'entity-remove': {
        const record = this.records.get(mutation.entityId);
        return record?.chunkKey ?? '0:0';
      }
      default:
        return '0:0';
    }
  }

  private invert(mutation: CreatorChunkMutation): CreatorChunkMutation | null {
    switch (mutation.type) {
      case 'entity-add':
        return { type: 'entity-remove', entityId: mutation.entity.entityId };
      case 'entity-remove': {
        const record = this.records.get(mutation.entityId);
        if (!record) return null;
        return { type: 'entity-add', entity: structuredClone(record.entity) };
      }
      case 'entity-update':
        return {
          type: 'entity-update',
          entityId: mutation.entityId,
          changes: { ...this.records.get(mutation.entityId)?.entity },
        };
      default:
        return null;
    }
  }

  private applyToScene(mutation: CreatorChunkMutation): void {
    switch (mutation.type) {
      case 'entity-add':
        this.upsert(mutation.entity);
        break;
      case 'entity-update': {
        const current = this.records.get(mutation.entityId)?.entity;
        if (!current) return;
        this.upsert({ ...current, ...mutation.changes });
        break;
      }
      case 'entity-remove':
        this.removeMesh(mutation.entityId);
        break;
      default:
        break;
    }
  }

  private upsert(entity: CreatorEntityDelta): void {
    const chunkKey = this.getChunkKeyAt(entity.position[0], entity.position[2]);
    this.records.set(entity.entityId, { entity, chunkKey });

    let mesh = this.meshes.get(entity.entityId);
    if (!mesh) {
      const shape = getShape(entity.prefabId);
      const geometry = new THREE.BoxGeometry(shape.width, shape.height, shape.depth);
      // Pivô na base: a malha desce até y=0 em vez de ficar centrada.
      geometry.translate(0, shape.height / 2, 0);
      this.geometries.add(geometry);
      const materialKey = `${entity.prefabId}:${entity.materialId}`;
      let material = this.materials.get(materialKey);
      if (!material) {
        material = new THREE.MeshStandardMaterial({
          color: shape.color,
          roughness: 0.85,
          metalness: 0.05,
        });
        this.materials.set(materialKey, material);
      }
      mesh = new THREE.Mesh(geometry, material);
      mesh.userData.entityId = entity.entityId;
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      this.meshes.set(entity.entityId, mesh);
      this.root.add(mesh);
    }
    mesh.position.set(entity.position[0], entity.position[1], entity.position[2]);
    mesh.rotation.set(entity.rotation[0], entity.rotation[1], entity.rotation[2]);
    mesh.scale.set(entity.scale[0], entity.scale[1], entity.scale[2]);
    mesh.visible = this.activeChunks.has(chunkKey);
    mesh.updateMatrixWorld();
  }

  private showMesh(entityId: string): void {
    const mesh = this.meshes.get(entityId);
    if (mesh) mesh.visible = true;
  }

  private hideMesh(entityId: string): void {
    const mesh = this.meshes.get(entityId);
    if (mesh) mesh.visible = false;
  }

  private removeMesh(entityId: string): void {
    this.records.delete(entityId);
    const mesh = this.meshes.get(entityId);
    if (!mesh) return;
    mesh.removeFromParent();
    this.geometries.delete(mesh.geometry);
    mesh.geometry.dispose();
    this.meshes.delete(entityId);
  }
}
