import { CreatorChunkMutation } from '../types';

export interface CreatorHistoryEntry {
  label: string;
  forward: CreatorChunkMutation[];
  backward: CreatorChunkMutation[];
}

export interface CreatorHistorySnapshot {
  canUndo: boolean;
  canRedo: boolean;
  undoLabel: string;
  redoLabel: string;
  entries: number;
  estimatedBytes: number;
}

/**
 * Histórico por comandos reversíveis gravados como deltas por chunk.
 * O teto de memória é o que impede "gerar cidade -> desfazer" de estourar a RAM do celular.
 */
const DEFAULT_MAX_ENTRIES = 80;
const DEFAULT_MAX_BYTES = 2 * 1024 * 1024;

export class CreatorHistory {
  private readonly undoStack: CreatorHistoryEntry[] = [];
  private readonly redoStack: CreatorHistoryEntry[] = [];
  private readonly maxEntries: number;
  private readonly maxBytes: number;
  private bytes = 0;

  public constructor(maxEntries = DEFAULT_MAX_ENTRIES, maxBytes = DEFAULT_MAX_BYTES) {
    this.maxEntries = maxEntries;
    this.maxBytes = maxBytes;
  }

  public push(entry: CreatorHistoryEntry): void {
    this.undoStack.push(entry);
    this.bytes += CreatorHistory.measure(entry);
    for (const redoEntry of this.redoStack) {
      this.bytes -= CreatorHistory.measure(redoEntry);
    }
    this.redoStack.length = 0;
    this.trim();
  }

  public undo(): CreatorHistoryEntry | null {
    const entry = this.undoStack.pop();
    if (!entry) return null;
    this.redoStack.push(entry);
    return entry;
  }

  public redo(): CreatorHistoryEntry | null {
    const entry = this.redoStack.pop();
    if (!entry) return null;
    this.undoStack.push(entry);
    return entry;
  }

  public clear(): void {
    this.undoStack.length = 0;
    this.redoStack.length = 0;
    this.bytes = 0;
  }

  public snapshot(): CreatorHistorySnapshot {
    return {
      canUndo: this.undoStack.length > 0,
      canRedo: this.redoStack.length > 0,
      undoLabel: this.undoStack[this.undoStack.length - 1]?.label ?? '',
      redoLabel: this.redoStack[this.redoStack.length - 1]?.label ?? '',
      entries: this.undoStack.length,
      estimatedBytes: this.bytes,
    };
  }

  private trim(): void {
    while (
      (this.undoStack.length > this.maxEntries || this.bytes > this.maxBytes) &&
      this.undoStack.length > 0
    ) {
      const removed = this.undoStack.shift();
      if (removed) this.bytes -= CreatorHistory.measure(removed);
    }
  }

  private static measure(entry: CreatorHistoryEntry): number {
    let total = entry.label.length * 2;
    for (const mutation of [...entry.forward, ...entry.backward]) {
      total += JSON.stringify(mutation).length * 2;
    }
    return total;
  }
}
