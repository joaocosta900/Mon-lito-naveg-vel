export const CREATOR_WORLD_FORMAT = 'monolito-creator-world';
export const CREATOR_WORLD_FORMAT_VERSION = 1;
export const CREATOR_ASSET_FORMAT = 'monolito-creator-assets';
export const CREATOR_ASSET_FORMAT_VERSION = 1;

export type CreatorWorldSizeMeters = 10000 | 20000 | 50000;
export type CreatorWorldStyle =
  | 'realista'
  | 'minimalista'
  | 'cyberpunk'
  | 'futurista'
  | 'rustico'
  | 'brutalista';
export type CreatorTerrainType =
  | 'plano'
  | 'colinas'
  | 'montanhoso'
  | 'costeiro'
  | 'deserto'
  | 'ilhas';
export type CreatorClimate =
  | 'equatorial'
  | 'tropical'
  | 'temperado'
  | 'seco'
  | 'polar'
  | 'tempestuoso';
export type CreatorObjectDensity = 'vazio' | 'baixa' | 'media' | 'alta';
export type CreatorQuality = 'leve' | 'equilibrado' | 'cinematografico';

export interface CreatorWorldSettings {
  style: CreatorWorldStyle;
  terrain: CreatorTerrainType;
  climate: CreatorClimate;
  objectDensity: CreatorObjectDensity;
  quality: CreatorQuality;
}

export interface CreatorWorldMetadata {
  createdAt: number;
  updatedAt: number;
  lastProviderUsed: string;
  revision: number;
}

export interface CreatorEditorPosition {
  chunkKey: string | null;
  position: [number, number, number];
  yaw: number;
  pitch: number;
}

export interface CreatorSavedPoint {
  id: string;
  label: string;
  position: [number, number, number];
  yaw: number;
  pitch: number;
  createdAt: number;
}

export interface CreatorTerrainPatch {
  chunkKey: string;
  width: number;
  height: number;
  origin: [number, number];
  indices: number[];
  values: number[];
}

export interface CreatorEntityDelta {
  entityId: string;
  prefabId: string;
  position: [number, number, number];
  rotation: [number, number, number];
  scale: [number, number, number];
  materialId: string;
  properties: Record<string, string | number | boolean>;
}

export type CreatorChunkMutation =
  | { type: 'terrain-patch'; patch: CreatorTerrainPatch }
  | { type: 'entity-add'; entity: CreatorEntityDelta }
  | { type: 'entity-update'; entityId: string; changes: Partial<CreatorEntityDelta> }
  | { type: 'entity-remove'; entityId: string }
  | { type: 'vegetation-add'; instances: number[] }
  | { type: 'vegetation-remove'; indices: number[] }
  | { type: 'road-add'; roadId: string; data: unknown }
  | { type: 'zone-add'; zoneId: string; data: unknown };

export interface CreatorChunkDelta {
  chunkKey: string;
  revision: number;
  mutations: CreatorChunkMutation[];
}

export interface CreatorWorld {
  format: typeof CREATOR_WORLD_FORMAT;
  formatVersion: typeof CREATOR_WORLD_FORMAT_VERSION;
  id: string;
  name: string;
  description: string;
  sizeMeters: CreatorWorldSizeMeters;
  seed: number;
  settings: CreatorWorldSettings;
  chunkSizeMeters: number;
  chunkDeltas: Record<string, CreatorChunkDelta>;
  lastEditor: CreatorEditorPosition;
  savedPoints: CreatorSavedPoint[];
  metadata: CreatorWorldMetadata;
}

export interface CreatorWorldVersion {
  id: string;
  worldId: string;
  label: string;
  revision: number;
  createdAt: number;
  snapshot: CreatorWorld;
}

export interface CreatorNewWorldInput {
  name: string;
  description: string;
  sizeMeters: CreatorWorldSizeMeters;
  seed: number;
  settings: CreatorWorldSettings;
}

export type CreatorAssetCategory =
  | 'terreno'
  | 'estradas'
  | 'edificios'
  | 'casas'
  | 'comercio'
  | 'industria'
  | 'infraestrutura'
  | 'vegetacao'
  | 'decoracao'
  | 'veiculos'
  | 'futurista';

export type CreatorAssetType =
  | 'mesh'
  | 'prefab'
  | 'terrain-brush'
  | 'road-tool'
  | 'zone-tool';

export interface CreatorAssetDescriptor {
  id: string;
  name: string;
  category: CreatorAssetCategory;
  type: CreatorAssetType;
  sizeBytes: number;
  lods: number[];
  collider: 'box' | 'capsule' | 'mesh' | 'none';
  material: string;
  polycount: number;
  thumbnail: string;
  version: number;
  builtin: boolean;
}

export interface CreatorAssetManifest {
  format: typeof CREATOR_ASSET_FORMAT;
  formatVersion: typeof CREATOR_ASSET_FORMAT_VERSION;
  assets: CreatorAssetDescriptor[];
}
