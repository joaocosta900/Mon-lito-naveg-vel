import {
  CREATOR_ASSET_FORMAT,
  CREATOR_ASSET_FORMAT_VERSION,
  CreatorAssetCategory,
  CreatorAssetDescriptor,
  CreatorAssetManifest,
} from './types';

const THUMBNAIL_COLORS: Record<CreatorAssetCategory, [string, string]> = {
  terreno: ['#8b6b4a', '#4e3928'],
  estradas: ['#545b64', '#252a30'],
  edificios: ['#a9b0b7', '#555d65'],
  casas: ['#c58b62', '#69452f'],
  comercio: ['#6aa7c7', '#31586c'],
  industria: ['#b78a54', '#5f452c'],
  infraestrutura: ['#8d96a2', '#48505a'],
  vegetacao: ['#5eaa68', '#2f6138'],
  decoracao: ['#c2a765', '#6d5c34'],
  veiculos: ['#b85d5d', '#633030'],
  futurista: ['#67d9dc', '#275d65'],
};

function createThumbnail(label: string, category: CreatorAssetCategory): string {
  const [accent, background] = THUMBNAIL_COLORS[category];
  const safeLabel = label.replace(/[<>&"]/g, '').slice(0, 14);
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="192" height="128" viewBox="0 0 192 128"><rect width="192" height="128" rx="16" fill="${background}"/><path d="M34 92L96 36l62 56H34z" fill="${accent}" opacity=".9"/><rect x="64" y="61" width="64" height="40" rx="5" fill="#111820" opacity=".78"/><text x="96" y="86" text-anchor="middle" font-family="sans-serif" font-size="13" font-weight="700" fill="white">${safeLabel}</text></svg>`;
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

const ASSET_DEFINITIONS: Array<
  Omit<CreatorAssetDescriptor, 'thumbnail' | 'builtin' | 'version'>
> = [
  {
    id: 'prefab_foundation_8x10',
    name: 'Fundação 8 × 10 m',
    category: 'edificios',
    type: 'prefab',
    sizeBytes: 96,
    lods: [0, 1, 2],
    collider: 'box',
    material: 'concreto',
    polycount: 12,
  },
  {
    id: 'prefab_house_small',
    name: 'Casa pequena',
    category: 'casas',
    type: 'prefab',
    sizeBytes: 320,
    lods: [0, 1, 2],
    collider: 'box',
    material: 'parede_pintada',
    polycount: 96,
  },
  {
    id: 'road_segment_straight',
    name: 'Trecho de estrada',
    category: 'estradas',
    type: 'road-tool',
    sizeBytes: 160,
    lods: [0, 1],
    collider: 'box',
    material: 'asfalto',
    polycount: 24,
  },
  {
    id: 'vegetation_tree_basic',
    name: 'Árvore básica',
    category: 'vegetacao',
    type: 'mesh',
    sizeBytes: 240,
    lods: [0, 1, 2],
    collider: 'capsule',
    material: 'folhagem',
    polycount: 72,
  },
  {
    id: 'urban_street_light',
    name: 'Poste de iluminação',
    category: 'infraestrutura',
    type: 'mesh',
    sizeBytes: 184,
    lods: [0, 1, 2],
    collider: 'capsule',
    material: 'metal_pintado',
    polycount: 54,
  },
  {
    id: 'vehicle_basic_car',
    name: 'Veículo básico',
    category: 'veiculos',
    type: 'mesh',
    sizeBytes: 272,
    lods: [0, 1, 2],
    collider: 'box',
    material: 'pintura_automotiva',
    polycount: 84,
  },
  {
    id: 'futuristic_spire_module',
    name: 'Módulo de torre futurista',
    category: 'futurista',
    type: 'prefab',
    sizeBytes: 384,
    lods: [0, 1, 2],
    collider: 'box',
    material: 'vidro_tecnologico',
    polycount: 144,
  },
];

export const BUILTIN_CREATOR_ASSETS: CreatorAssetDescriptor[] =
  ASSET_DEFINITIONS.map((definition) => ({
    ...definition,
    thumbnail: createThumbnail(definition.name, definition.category),
    version: 1,
    builtin: true,
  }));

export function createAssetManifest(
  assets: CreatorAssetDescriptor[]
): CreatorAssetManifest {
  return {
    format: CREATOR_ASSET_FORMAT,
    formatVersion: CREATOR_ASSET_FORMAT_VERSION,
    assets,
  };
}
