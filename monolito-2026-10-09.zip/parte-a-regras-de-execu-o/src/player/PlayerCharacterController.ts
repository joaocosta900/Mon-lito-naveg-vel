import * as THREE from 'three';

export const PLAYER_COLLISION_RADIUS = 0.65;
export const PLAYER_COLLISION_HEIGHT = 1.8;

export interface PlayerAnimationSnapshot {
  position: THREE.Vector3;
  groundY: number;
  targetHeading: number | null;
  inputMagnitude: number;
  speed: number;
  isGrounded: boolean;
  verticalVelocity: number;
  sprinting: boolean;
  justJumped: boolean;
  justLanded: boolean;
}

export class PlayerCharacterController {
  private readonly root = new THREE.Group();
  private readonly visual = new THREE.Group();
  private readonly arms: THREE.Object3D[] = [];
  private readonly legs: THREE.Object3D[] = [];
  private readonly body: THREE.Object3D;
  private phase = 0;
  private heading = 0;
  private disposed = false;

  public constructor() {
    this.root.name = 'PlayerCharacter';
    this.root.userData.controller = 'procedural-avatar';

    const suitMaterial = new THREE.MeshStandardMaterial({
      color: 0x183b56,
      roughness: 0.72,
      metalness: 0.18,
    });
    const accentMaterial = new THREE.MeshStandardMaterial({
      color: 0x27d3c2,
      roughness: 0.46,
      metalness: 0.28,
      emissive: 0x063c39,
      emissiveIntensity: 0.5,
    });
    const darkMaterial = new THREE.MeshStandardMaterial({
      color: 0x07131d,
      roughness: 0.38,
      metalness: 0.46,
    });
    const skinMaterial = new THREE.MeshStandardMaterial({
      color: 0xc98f6c,
      roughness: 0.82,
      metalness: 0,
    });

    const torso = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.32, 0.58, 5, 10),
      suitMaterial
    );
    torso.position.y = 1.05;

    const chest = new THREE.Mesh(
      new THREE.BoxGeometry(0.34, 0.16, 0.08),
      accentMaterial
    );
    chest.position.set(0, 1.18, -0.305);

    const head = new THREE.Mesh(
      new THREE.SphereGeometry(0.24, 14, 10),
      skinMaterial
    );
    head.position.y = 1.67;

    const visor = new THREE.Mesh(
      new THREE.BoxGeometry(0.3, 0.1, 0.06),
      darkMaterial
    );
    visor.position.set(0, 1.7, -0.22);

    this.body = new THREE.Group();
    this.body.add(torso, chest, head, visor);

    const leftArm = this.createLimb(0.1, 0.48, suitMaterial, -0.43, 1.1);
    const rightArm = this.createLimb(0.1, 0.48, suitMaterial, 0.43, 1.1);
    const leftLeg = this.createLimb(0.13, 0.48, suitMaterial, -0.18, 0.38);
    const rightLeg = this.createLimb(0.13, 0.48, suitMaterial, 0.18, 0.38);

    this.arms.push(leftArm, rightArm);
    this.legs.push(leftLeg, rightLeg);
    this.visual.add(this.body, leftArm, rightArm, leftLeg, rightLeg);
    this.root.add(this.visual);

    this.root.traverse((object) => {
      const mesh = object as THREE.Mesh;
      if (!mesh.isMesh) return;
      mesh.castShadow = true;
      mesh.receiveShadow = true;
    });
  }

  public addTo(scene: THREE.Scene): void {
    scene.add(this.root);
  }

  public teleport(position: THREE.Vector3, heading = this.heading): void {
    this.root.position.copy(position);
    this.heading = heading;
    this.root.rotation.y = heading;
  }

  public update(snapshot: PlayerAnimationSnapshot, delta: number): void {
    if (this.disposed) return;

    this.root.position.set(snapshot.position.x, snapshot.groundY, snapshot.position.z);

    if (snapshot.targetHeading !== null && snapshot.inputMagnitude > 0.08 && snapshot.speed > 0.08) {
      this.heading = snapshot.targetHeading;
    }

    const turnSmoothing = 1 - Math.exp(-12 * delta);
    const turnDelta = this.shortestAngle(this.root.rotation.y, this.heading);
    this.root.rotation.y += turnDelta * turnSmoothing;

    const movementAmount = snapshot.isGrounded
      ? THREE.MathUtils.clamp(snapshot.speed / 8.2, 0, 1)
      : 0;
    const cycleSpeed = snapshot.sprinting ? 11 : 7.5;
    this.phase += delta * cycleSpeed * Math.max(movementAmount, snapshot.isGrounded ? 0.08 : 0);

    const swing = Math.sin(this.phase) * movementAmount;
    const armSwing = snapshot.isGrounded ? swing * 0.72 : -0.48;
    const legSwing = snapshot.isGrounded ? swing * 0.64 : 0.28;

    this.arms[0].rotation.x = armSwing;
    this.arms[1].rotation.x = -armSwing;
    this.legs[0].rotation.x = -legSwing;
    this.legs[1].rotation.x = legSwing;

    const bobAmount = snapshot.isGrounded
      ? Math.abs(Math.sin(this.phase * 2)) * movementAmount * 0.025
      : 0.035;
    this.body.position.y = bobAmount;
    this.body.rotation.x = snapshot.isGrounded ? movementAmount * 0.045 : -0.08;
  }

  public setVisible(visible: boolean): void {
    this.root.visible = visible;
  }

  public dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    this.root.removeFromParent();
    this.root.traverse((object) => {
      const mesh = object as THREE.Mesh;
      if (!mesh.isMesh) return;
      mesh.geometry.dispose();
      const materials = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
      materials.forEach((material) => material.dispose());
    });
  }

  private createLimb(
    radius: number,
    length: number,
    material: THREE.Material,
    x: number,
    y: number
  ): THREE.Object3D {
    const limb = new THREE.Mesh(
      new THREE.CapsuleGeometry(radius, length, 4, 8),
      material
    );
    limb.position.set(x, y, 0);
    return limb;
  }

  private shortestAngle(from: number, to: number): number {
    return Math.atan2(Math.sin(to - from), Math.cos(to - from));
  }
}
