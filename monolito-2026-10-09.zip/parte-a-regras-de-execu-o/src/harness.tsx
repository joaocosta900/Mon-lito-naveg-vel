import React from 'react';
import { createRoot } from 'react-dom/client';
import { CreatorViewport } from './components/CreatorViewport';
import { createCreatorWorld } from './creator/CreatorFormat';
import './index.css';

const world = createCreatorWorld({
  name: 'Harness Fase 3',
  description: 'Mundo isolado para teste',
  sizeMeters: 10000,
  seed: 4242,
  settings: {
    style: 'realista',
    terrain: 'colinas',
    climate: 'temperado',
    objectDensity: 'media',
    quality: 'equilibrado',
  },
});

function Harness() {
  const [exited, setExited] = React.useState<Record<string, unknown> | null>(null);
  if (exited) {
    return (
      <pre style={{ color: 'white', padding: 16, fontSize: 12 }}>
        {JSON.stringify(exited, null, 2)}
      </pre>
    );
  }
  return (
    <CreatorViewport
      world={world}
      onExit={(updated) => {
        (window as unknown as { __harnessExit?: unknown }).__harnessExit = updated;
        setExited(updated as unknown as Record<string, unknown>);
      }}
    />
  );
}

createRoot(document.getElementById('root') as HTMLElement).render(<Harness />);
