import { WorldPlan, WorldPatch } from '../world/types/worldPlan';

export type ProviderType =
  | 'gemini'
  | 'openai'
  | 'anthropic'
  | 'openrouter'
  | 'openai-compatible'
  | 'custom';

export type ConnectionStatus =
  | 'CONNECTED'
  | 'ERROR'
  | 'TIMEOUT'
  | 'INVALID_KEY'
  | 'MODEL_NOT_FOUND'
  | 'UNTESTED';

export interface AIProviderConfig {
  id: string;
  name: string;
  type: ProviderType;
  endpoint: string;
  apiKey: string; // Stored securely; masked in UI
  model: string;
  priority: number; // 1 = highest priority (Primary), 2 = Fallback 1, 3 = Fallback 2, etc.
  contextLimit: number;
  temperature: number;
  timeoutMs: number;
  canGenerateWorlds: boolean;
  canPlanOnly: boolean;
  isEnabled: boolean;
  customHeaders?: Record<string, string>;
  customFormat?: 'openai' | 'anthropic' | 'gemini';
  lastTestedStatus?: ConnectionStatus;
  lastTestedAt?: number;
  lastLatencyMs?: number;
  lastTestMessage?: string;
}

export interface ConnectionTestResult {
  status: ConnectionStatus;
  latencyMs: number;
  message: string;
  model?: string;
}

export interface APIUsageRecord {
  id: string;
  timestamp: number;
  providerId: string;
  providerName: string;
  providerType: ProviderType;
  model: string;
  promptTokens: number;
  completionTokens: number;
  totalTokens: number;
  estimatedCost: string; // e.g. "$0.0014" or "Unknown"
  durationMs: number;
  success: boolean;
  error?: string;
  action: 'test' | 'generate_plan' | 'patch_world';
}

export interface GenerateWorldPlanRequest {
  worldName: string;
  prompt: string;
  worldSize: '10km' | '20km' | '50km' | '100km' | '500km';
  quality: 'preview' | 'low' | 'medium' | 'high' | 'ultra';
  seed: number;
}

export interface GenerateWorldPatchRequest {
  worldPlan: WorldPlan;
  targetRegionId: string;
  modificationPrompt: string;
}

export interface LLMResponse {
  content: string;
  usage?: {
    promptTokens?: number;
    completionTokens?: number;
    totalTokens?: number;
  };
  durationMs: number;
  provider: string;
  model: string;
}
