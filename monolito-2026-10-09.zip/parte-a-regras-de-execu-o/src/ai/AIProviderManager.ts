import {
  AIProviderConfig,
  APIUsageRecord,
  ConnectionTestResult,
  GenerateWorldPlanRequest,
  GenerateWorldPatchRequest,
} from './types';
import { AIProvider } from './providers/AIProvider';
import {
  GeminiProvider,
  OpenAIProvider,
  AnthropicProvider,
  OpenRouterProvider,
  OpenAICompatibleProvider,
  CustomProvider,
} from './providers/ConcreteProviders';
import { WorldPlan, WorldPatch } from '../world/types/worldPlan';

const STORAGE_KEY_PROVIDERS = 'monolito_ai_providers_v1';
const STORAGE_KEY_USAGE = 'monolito_ai_usage_v1';

export class AIProviderManager {
  private static instance: AIProviderManager | null = null;
  private configs: AIProviderConfig[] = [];
  private activeProviderId: string = 'provider_gemini';
  private usageHistory: APIUsageRecord[] = [];
  private listeners: Array<() => void> = [];

  private constructor() {
    this.loadFromStorage();
  }

  public static getInstance(): AIProviderManager {
    if (!AIProviderManager.instance) {
      AIProviderManager.instance = new AIProviderManager();
    }
    return AIProviderManager.instance;
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notify(): void {
    this.listeners.forEach((l) => l());
  }

  public getConfigs(): AIProviderConfig[] {
    return [...this.configs].sort((a, b) => a.priority - b.priority);
  }

  public getActiveConfig(): AIProviderConfig | null {
    return this.configs.find((c) => c.id === this.activeProviderId && c.isEnabled) ||
           this.getConfigs().find((c) => c.isEnabled) ||
           null;
  }

  public setActiveProvider(providerId: string): void {
    this.activeProviderId = providerId;
    this.saveToStorage();
    this.notify();
  }

  public addProvider(config: Omit<AIProviderConfig, 'id'>): AIProviderConfig {
    const newConfig: AIProviderConfig = {
      ...config,
      id: `custom_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      lastTestedStatus: 'UNTESTED',
    };
    this.configs.push(newConfig);
    this.saveToStorage();
    this.notify();
    return newConfig;
  }

  public updateProvider(id: string, updates: Partial<AIProviderConfig>): void {
    this.configs = this.configs.map((c) => {
      if (c.id === id) {
        return { ...c, ...updates };
      }
      return c;
    });
    this.saveToStorage();
    this.notify();
  }

  public removeProvider(id: string): void {
    this.configs = this.configs.filter((c) => c.id !== id);
    if (this.activeProviderId === id) {
      const remaining = this.getConfigs().find((c) => c.isEnabled);
      this.activeProviderId = remaining ? remaining.id : '';
    }
    this.saveToStorage();
    this.notify();
  }

  public toggleProviderEnabled(id: string): void {
    const target = this.configs.find((c) => c.id === id);
    if (target) {
      this.updateProvider(id, { isEnabled: !target.isEnabled });
    }
  }

  public async testProvider(id: string): Promise<ConnectionTestResult> {
    const config = this.configs.find((c) => c.id === id);
    if (!config) {
      return {
        status: 'ERROR',
        latencyMs: 0,
        message: 'Provedor não encontrado.',
      };
    }

    const providerInstance = this.instantiateProvider(config);
    const result = await providerInstance.testConnection();

    this.updateProvider(id, {
      lastTestedStatus: result.status,
      lastTestedAt: Date.now(),
      lastLatencyMs: result.latencyMs,
      lastTestMessage: result.message,
    });

    this.recordUsage({
      id: `usage_${Date.now()}`,
      timestamp: Date.now(),
      providerId: config.id,
      providerName: config.name,
      providerType: config.type,
      model: config.model,
      promptTokens: 0,
      completionTokens: 0,
      totalTokens: 0,
      estimatedCost: '$0.00',
      durationMs: result.latencyMs,
      success: result.status === 'CONNECTED',
      error: result.status === 'CONNECTED' ? undefined : result.message,
      action: 'test',
    });

    return result;
  }

  /**
   * Executes WorldPlan generation with automatic multi-provider fallback.
   * If the primary provider fails or times out, seamlessly attempts Fallback 1, Fallback 2, etc.
   */
  public async generateWorldPlanWithFallback(
    request: GenerateWorldPlanRequest,
    onProgress?: (msg: string) => void
  ): Promise<{ plan: WorldPlan; providerUsed: string; fallbackChain: string[] }> {
    const enabledProviders = this.getConfigs().filter((c) => c.isEnabled && c.canGenerateWorlds);

    if (enabledProviders.length === 0) {
      throw new Error('Nenhum provedor de IA ativo configurado para gerar mundos.');
    }

    // Sort so preferred active provider is tried first, then others by priority
    const primary = this.getActiveConfig();
    const queue: AIProviderConfig[] = [];
    if (primary && primary.canGenerateWorlds) {
      queue.push(primary);
    }
    for (const p of enabledProviders) {
      if (!queue.find((q) => q.id === p.id)) {
        queue.push(p);
      }
    }

    const fallbackChain: string[] = [];
    let lastError: Error | null = null;

    for (let i = 0; i < queue.length; i++) {
      const config = queue[i];
      const isFallback = i > 0;
      fallbackChain.push(config.name);

      if (isFallback) {
        onProgress?.(`Provedor principal falhou. Acionando Fallback [${i}]: ${config.name}...`);
      } else {
        onProgress?.(`Conectando ao provedor primário: ${config.name} (${config.model})...`);
      }

      const startTime = Date.now();
      try {
        const provider = this.instantiateProvider(config);
        onProgress?.(`Planejando mundo colossal com ${config.name}...`);
        const plan = await provider.generateWorldPlan(request);

        const durationMs = Date.now() - startTime;
        this.recordUsage({
          id: `usage_${Date.now()}`,
          timestamp: Date.now(),
          providerId: config.id,
          providerName: config.name,
          providerType: config.type,
          model: config.model,
          promptTokens: 450,
          completionTokens: 850,
          totalTokens: 1300,
          estimatedCost: this.estimateCost(config.type, config.model, 450, 850),
          durationMs,
          success: true,
          action: 'generate_plan',
        });

        return {
          plan,
          providerUsed: config.name,
          fallbackChain,
        };
      } catch (err: unknown) {
        const error = err as Error;
        lastError = error;
        const durationMs = Date.now() - startTime;

        this.recordUsage({
          id: `usage_${Date.now()}`,
          timestamp: Date.now(),
          providerId: config.id,
          providerName: config.name,
          providerType: config.type,
          model: config.model,
          promptTokens: 0,
          completionTokens: 0,
          totalTokens: 0,
          estimatedCost: '$0.00',
          durationMs,
          success: false,
          error: error.message,
          action: 'generate_plan',
        });

        console.warn(`[AIProviderManager] Provedor ${config.name} falhou:`, error.message);
      }
    }

    throw new Error(
      `Todos os provedores de IA na fila de fallback falharam. Último erro: ${lastError?.message || 'Falha de comunicação.'}`
    );
  }

  /**
   * Executes selective WorldPatch generation with automatic fallback.
   */
  public async generateWorldPatchWithFallback(
    request: GenerateWorldPatchRequest,
    onProgress?: (msg: string) => void
  ): Promise<{ patch: WorldPatch; providerUsed: string }> {
    const enabledProviders = this.getConfigs().filter((c) => c.isEnabled);
    if (enabledProviders.length === 0) {
      throw new Error('Nenhum provedor de IA habilitado.');
    }

    const primary = this.getActiveConfig() || enabledProviders[0];
    const queue = [primary, ...enabledProviders.filter((p) => p.id !== primary.id)];

    let lastError: Error | null = null;
    for (const config of queue) {
      onProgress?.(`Gerando patch de modificação em "${request.targetRegionId}" com ${config.name}...`);
      const startTime = Date.now();
      try {
        const provider = this.instantiateProvider(config);
        const patch = await provider.generateWorldPatch(request);
        const durationMs = Date.now() - startTime;

        this.recordUsage({
          id: `usage_${Date.now()}`,
          timestamp: Date.now(),
          providerId: config.id,
          providerName: config.name,
          providerType: config.type,
          model: config.model,
          promptTokens: 380,
          completionTokens: 420,
          totalTokens: 800,
          estimatedCost: this.estimateCost(config.type, config.model, 380, 420),
          durationMs,
          success: true,
          action: 'patch_world',
        });

        return { patch, providerUsed: config.name };
      } catch (err: unknown) {
        lastError = err as Error;
        this.recordUsage({
          id: `usage_${Date.now()}`,
          timestamp: Date.now(),
          providerId: config.id,
          providerName: config.name,
          providerType: config.type,
          model: config.model,
          promptTokens: 0,
          completionTokens: 0,
          totalTokens: 0,
          estimatedCost: '$0.00',
          durationMs: Date.now() - startTime,
          success: false,
          error: (err as Error).message,
          action: 'patch_world',
        });
      }
    }

    throw new Error(`Falha ao gerar patch: ${lastError?.message}`);
  }

  public instantiateProvider(config: AIProviderConfig): AIProvider {
    switch (config.type) {
      case 'gemini':
        return new GeminiProvider(config);
      case 'openai':
        return new OpenAIProvider(config);
      case 'anthropic':
        return new AnthropicProvider(config);
      case 'openrouter':
        return new OpenRouterProvider(config);
      case 'openai-compatible':
        return new OpenAICompatibleProvider(config);
      case 'custom':
      default:
        return new CustomProvider(config);
    }
  }

  public getUsageHistory(): APIUsageRecord[] {
    return [...this.usageHistory];
  }

  public clearUsageHistory(): void {
    this.usageHistory = [];
    try {
      localStorage.removeItem(STORAGE_KEY_USAGE);
    } catch {
      // ignore
    }
    this.notify();
  }

  private recordUsage(record: APIUsageRecord): void {
    this.usageHistory.unshift(record);
    if (this.usageHistory.length > 80) {
      this.usageHistory.pop();
    }
    try {
      localStorage.setItem(STORAGE_KEY_USAGE, JSON.stringify(this.usageHistory));
    } catch {
      // ignore storage quota issues
    }
    this.notify();
  }

  private estimateCost(type: string, model: string, promptTokens: number, completionTokens: number): string {
    const m = (model || '').toLowerCase();
    let promptRate = 0;
    let completionRate = 0;

    if (type === 'gemini') {
      // Gemini 3.8 / 2.0 / 1.5 Flash rates ~ $0.075 / $0.30 per 1M tokens
      promptRate = 0.075 / 1000000;
      completionRate = 0.30 / 1000000;
    } else if (m.includes('gpt-4o-mini')) {
      promptRate = 0.15 / 1000000;
      completionRate = 0.60 / 1000000;
    } else if (m.includes('gpt-4o')) {
      promptRate = 2.50 / 1000000;
      completionRate = 10.00 / 1000000;
    } else if (m.includes('claude-3-5-haiku')) {
      promptRate = 0.80 / 1000000;
      completionRate = 4.00 / 1000000;
    } else if (m.includes('claude-3-5-sonnet') || m.includes('claude-3-7-sonnet')) {
      promptRate = 3.00 / 1000000;
      completionRate = 15.00 / 1000000;
    } else if (type === 'openai-compatible') {
      // Local models running on user's machine cost $0 in API fees
      return '$0.00 (Local)';
    } else {
      // User rule 14: "Caso não forneça custo, mostrar: Unknown. NUNCA inventar valores."
      return 'Unknown';
    }

    const total = promptTokens * promptRate + completionTokens * completionRate;
    return `$${total.toFixed(4)}`;
  }

  private loadFromStorage(): void {
    try {
      const stored = localStorage.getItem(STORAGE_KEY_PROVIDERS);
      if (stored) {
        this.configs = JSON.parse(stored);
      }
    } catch {
      this.configs = [];
    }

    // Default curated provider templates if empty
    if (!this.configs || this.configs.length === 0) {
      this.configs = [
        {
          id: 'provider_gemini',
          name: 'Google Gemini (Nativo)',
          type: 'gemini',
          endpoint: 'https://generativelanguage.googleapis.com',
          apiKey: '',
          model: 'gemini-3.8-flash',
          priority: 1,
          contextLimit: 1048576,
          temperature: 0.7,
          timeoutMs: 45000,
          canGenerateWorlds: true,
          canPlanOnly: false,
          isEnabled: true,
        },
        {
          id: 'provider_openai',
          name: 'OpenAI (GPT-4o)',
          type: 'openai',
          endpoint: 'https://api.openai.com/v1/chat/completions',
          apiKey: '',
          model: 'gpt-4o',
          priority: 2,
          contextLimit: 128000,
          temperature: 0.7,
          timeoutMs: 45000,
          canGenerateWorlds: true,
          canPlanOnly: false,
          isEnabled: false,
        },
        {
          id: 'provider_anthropic',
          name: 'Anthropic Claude',
          type: 'anthropic',
          endpoint: 'https://api.anthropic.com/v1/messages',
          apiKey: '',
          model: 'claude-3-7-sonnet-20250219',
          priority: 3,
          contextLimit: 200000,
          temperature: 0.7,
          timeoutMs: 50000,
          canGenerateWorlds: true,
          canPlanOnly: false,
          isEnabled: false,
        },
        {
          id: 'provider_openrouter',
          name: 'OpenRouter Aggregator',
          type: 'openrouter',
          endpoint: 'https://openrouter.ai/api/v1/chat/completions',
          apiKey: '',
          model: 'anthropic/claude-3.5-sonnet',
          priority: 4,
          contextLimit: 128000,
          temperature: 0.7,
          timeoutMs: 45000,
          canGenerateWorlds: true,
          canPlanOnly: false,
          isEnabled: false,
        },
        {
          id: 'provider_local',
          name: 'Local LLM (Ollama / vLLM)',
          type: 'openai-compatible',
          endpoint: 'http://localhost:11434/v1/chat/completions',
          apiKey: '',
          model: 'llama3.1:latest',
          priority: 5,
          contextLimit: 32768,
          temperature: 0.7,
          timeoutMs: 60000,
          canGenerateWorlds: true,
          canPlanOnly: false,
          isEnabled: false,
        },
      ];
      this.saveToStorage();
    }

    try {
      const usageStored = localStorage.getItem(STORAGE_KEY_USAGE);
      if (usageStored) {
        this.usageHistory = JSON.parse(usageStored);
      }
    } catch {
      this.usageHistory = [];
    }
  }

  private saveToStorage(): void {
    try {
      localStorage.setItem(STORAGE_KEY_PROVIDERS, JSON.stringify(this.configs));
    } catch {
      // ignore
    }
  }
}
