import { BaseProvider } from './BaseProvider';
import { AIProviderConfig } from '../types';

export class GeminiProvider extends BaseProvider {
  constructor(config?: Partial<AIProviderConfig>) {
    super({
      id: config?.id || 'provider_gemini',
      name: config?.name || 'Google Gemini',
      type: 'gemini',
      endpoint: config?.endpoint || 'https://generativelanguage.googleapis.com',
      apiKey: config?.apiKey || '',
      model: config?.model || 'gemini-3.8-flash',
      priority: config?.priority ?? 1,
      contextLimit: config?.contextLimit || 1048576,
      temperature: config?.temperature ?? 0.7,
      timeoutMs: config?.timeoutMs || 45000,
      canGenerateWorlds: config?.canGenerateWorlds ?? true,
      canPlanOnly: config?.canPlanOnly ?? false,
      isEnabled: config?.isEnabled ?? true,
    });
  }
}

export class OpenAIProvider extends BaseProvider {
  constructor(config?: Partial<AIProviderConfig>) {
    super({
      id: config?.id || 'provider_openai',
      name: config?.name || 'OpenAI',
      type: 'openai',
      endpoint: config?.endpoint || 'https://api.openai.com/v1/chat/completions',
      apiKey: config?.apiKey || '',
      model: config?.model || 'gpt-4o',
      priority: config?.priority ?? 2,
      contextLimit: config?.contextLimit || 128000,
      temperature: config?.temperature ?? 0.7,
      timeoutMs: config?.timeoutMs || 45000,
      canGenerateWorlds: config?.canGenerateWorlds ?? true,
      canPlanOnly: config?.canPlanOnly ?? false,
      isEnabled: config?.isEnabled ?? true,
    });
  }
}

export class AnthropicProvider extends BaseProvider {
  constructor(config?: Partial<AIProviderConfig>) {
    super({
      id: config?.id || 'provider_anthropic',
      name: config?.name || 'Anthropic Claude',
      type: 'anthropic',
      endpoint: config?.endpoint || 'https://api.anthropic.com/v1/messages',
      apiKey: config?.apiKey || '',
      model: config?.model || 'claude-3-7-sonnet-20250219',
      priority: config?.priority ?? 3,
      contextLimit: config?.contextLimit || 200000,
      temperature: config?.temperature ?? 0.7,
      timeoutMs: config?.timeoutMs || 50000,
      canGenerateWorlds: config?.canGenerateWorlds ?? true,
      canPlanOnly: config?.canPlanOnly ?? false,
      isEnabled: config?.isEnabled ?? true,
    });
  }
}

export class OpenRouterProvider extends BaseProvider {
  constructor(config?: Partial<AIProviderConfig>) {
    super({
      id: config?.id || 'provider_openrouter',
      name: config?.name || 'OpenRouter',
      type: 'openrouter',
      endpoint: config?.endpoint || 'https://openrouter.ai/api/v1/chat/completions',
      apiKey: config?.apiKey || '',
      model: config?.model || 'anthropic/claude-3.5-sonnet',
      priority: config?.priority ?? 4,
      contextLimit: config?.contextLimit || 128000,
      temperature: config?.temperature ?? 0.7,
      timeoutMs: config?.timeoutMs || 45000,
      canGenerateWorlds: config?.canGenerateWorlds ?? true,
      canPlanOnly: config?.canPlanOnly ?? false,
      isEnabled: config?.isEnabled ?? true,
    });
  }
}

export class OpenAICompatibleProvider extends BaseProvider {
  constructor(config?: Partial<AIProviderConfig>) {
    super({
      id: config?.id || 'provider_local',
      name: config?.name || 'Servidor Local (Ollama / vLLM)',
      type: 'openai-compatible',
      endpoint: config?.endpoint || 'http://localhost:11434/v1/chat/completions',
      apiKey: config?.apiKey || '',
      model: config?.model || 'llama3.1:latest',
      priority: config?.priority ?? 5,
      contextLimit: config?.contextLimit || 32768,
      temperature: config?.temperature ?? 0.7,
      timeoutMs: config?.timeoutMs || 60000,
      canGenerateWorlds: config?.canGenerateWorlds ?? true,
      canPlanOnly: config?.canPlanOnly ?? false,
      isEnabled: config?.isEnabled ?? true,
    });
  }
}

export class CustomProvider extends BaseProvider {
  constructor(config: AIProviderConfig) {
    super(config);
  }
}
