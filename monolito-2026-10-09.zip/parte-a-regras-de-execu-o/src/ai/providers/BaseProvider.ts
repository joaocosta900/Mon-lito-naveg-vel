import {
  AIProvider,
  WORLD_PLANNER_SYSTEM_PROMPT,
  WORLD_PATCH_SYSTEM_PROMPT,
} from './AIProvider';
import {
  AIProviderConfig,
  ConnectionTestResult,
  GenerateWorldPlanRequest,
  GenerateWorldPatchRequest,
  LLMResponse,
} from '../types';
import { WorldPlan, WorldPatch } from '../../world/types/worldPlan';
import { WorldPlanValidator } from '../../world/WorldPlanValidator';

export abstract class BaseProvider implements AIProvider {
  public readonly config: AIProviderConfig;

  constructor(config: AIProviderConfig) {
    this.config = config;
  }

  public async testConnection(): Promise<ConnectionTestResult> {
    const startTime = Date.now();
    try {
      const res = await fetch('/api/ai/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          providerType: this.config.type,
          endpoint: this.config.endpoint,
          apiKey: this.config.apiKey,
          model: this.config.model,
          customHeaders: this.config.customHeaders,
        }),
      });

      const data = await res.json();
      const latencyMs = data.latencyMs || Date.now() - startTime;

      if (res.ok && data.status === 'CONNECTED') {
        return {
          status: 'CONNECTED',
          latencyMs,
          message: data.message || `Conectado com sucesso a ${this.config.name} (${this.config.model}).`,
          model: this.config.model,
        };
      }

      return {
        status: data.status || 'ERROR',
        latencyMs,
        message: data.message || `Falha de conexão (${res.status}).`,
        model: this.config.model,
      };
    } catch (err: unknown) {
      const error = err as Error;
      return {
        status: 'ERROR',
        latencyMs: Date.now() - startTime,
        message: error.message || 'Erro de rede ao testar provedor.',
        model: this.config.model,
      };
    }
  }

  public async generateWorldPlan(request: GenerateWorldPlanRequest): Promise<WorldPlan> {
    const userPrompt = `
Generate a complete WorldPlan for MONOLITO:
- World Name: "${request.worldName}"
- User Vision Prompt: "${request.prompt}"
- World Scale: ${request.worldSize}
- Quality Preset: ${request.quality}
- World Seed: ${request.seed}

Ensure architectural monumentalism with extreme vertical scale (500m to 2500m), contrast with tiny 2.1m human scale doors/benches, rich acoustics, and appropriate atmospheric conditions.
Return raw JSON only conforming to the schema.
    `.trim();

    const response = await this.executeChatCompletion([
      { role: 'user', content: userPrompt },
    ], WORLD_PLANNER_SYSTEM_PROMPT);

    const parsedJson = this.extractJson(response.content);
    const validated = WorldPlanValidator.validate(parsedJson, request.prompt);

    // Attach metadata
    validated.data.metadata = {
      generatedByProvider: this.config.name,
      model: this.config.model,
      createdAt: Date.now(),
      version: '1.0.0',
      generationPrompt: request.prompt,
    };
    validated.data.name = request.worldName || validated.data.name;
    validated.data.seed = request.seed;

    return validated.data;
  }

  public async generateWorldPatch(request: GenerateWorldPatchRequest): Promise<WorldPatch> {
    const userPrompt = `
Existing World Context:
- World Name: "${request.worldPlan.name}"
- Current Size: ${request.worldPlan.size.scaleLabel}
- Target Region to modify: "${request.targetRegionId}"
- Modification Request: "${request.modificationPrompt}"

Remember: ONLY modify the requested target region. Do not change other regions.
Return raw JSON only for the WorldPatch schema.
    `.trim();

    const response = await this.executeChatCompletion([
      { role: 'user', content: userPrompt },
    ], WORLD_PATCH_SYSTEM_PROMPT);

    const parsedJson = this.extractJson(response.content);
    const validated = WorldPlanValidator.validatePatch(parsedJson, request.worldPlan);

    return validated.data;
  }

  protected async executeChatCompletion(
    messages: Array<{ role: string; content: string }>,
    systemPrompt: string
  ): Promise<LLMResponse> {
    const startTime = Date.now();

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), this.config.timeoutMs || 50000);

    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          providerType: this.config.type,
          endpoint: this.config.endpoint,
          apiKey: this.config.apiKey,
          model: this.config.model,
          messages,
          systemPrompt,
          temperature: this.config.temperature,
          timeoutMs: this.config.timeoutMs,
          customHeaders: this.config.customHeaders,
        }),
        signal: controller.signal,
      });
      clearTimeout(timeoutId);

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({ error: `HTTP ${res.status}` }));
        throw new Error(errorData.error || `Erro HTTP ${res.status} ao contatar provedor ${this.config.name}`);
      }

      const data = await res.json();
      return {
        content: data.content,
        usage: data.usage,
        durationMs: data.durationMs || Date.now() - startTime,
        provider: this.config.name,
        model: this.config.model,
      };
    } catch (err: unknown) {
      clearTimeout(timeoutId);
      const error = err as Error;
      if (error.name === 'AbortError') {
        throw new Error(`Timeout: Provedor ${this.config.name} não respondeu em ${Math.round((this.config.timeoutMs || 50000) / 1000)}s.`);
      }
      throw error;
    }
  }

  protected extractJson(content: string): any {
    if (!content || typeof content !== 'string') {
      throw new Error('Conteúdo retornado pelo provedor de IA está vazio.');
    }

    const trimmed = content.trim();

    // 1. Try direct parse
    try {
      return JSON.parse(trimmed);
    } catch {
      // Continue to cleaners
    }

    // 2. Remove markdown code fences if model enclosed in ```json ... ```
    const fenceMatch = trimmed.match(/```(?:json)?\s*([\s\S]*?)\s*```/i);
    if (fenceMatch && fenceMatch[1]) {
      try {
        return JSON.parse(fenceMatch[1].trim());
      } catch {
        // continue
      }
    }

    // 3. Find first { and last }
    const firstBrace = trimmed.indexOf('{');
    const lastBrace = trimmed.lastIndexOf('}');
    if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
      const candidate = trimmed.substring(firstBrace, lastBrace + 1);
      try {
        return JSON.parse(candidate);
      } catch (parseErr) {
        throw new Error(`Falha ao converter resposta da IA em JSON: ${(parseErr as Error).message}`);
      }
    }

    throw new Error('Nenhum objeto JSON detectado na resposta do modelo.');
  }
}
