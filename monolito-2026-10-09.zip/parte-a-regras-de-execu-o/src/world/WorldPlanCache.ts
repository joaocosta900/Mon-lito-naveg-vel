import { WorldPlan, WorldState, WorldRegionDefinition } from './types/worldPlan';

const STORAGE_KEY_PLANS = 'monolito_saved_world_plans_v1';
const STORAGE_KEY_STATES = 'monolito_saved_world_states_v1';

export const DEFAULT_BLADE_RUNNER_PLAN: WorldPlan = {
  worldId: 'world_blade_runner_2049',
  name: 'Blade Runner 2049: Distrito Wallace & Vegas',
  tagline: 'Pirâmides colossais, chuva ácida, nevasca ocre e spinners voadores',
  theme: 'megacity',
  seed: 2049,
  size: {
    width: 20000,
    depth: 20000,
    scaleLabel: '20km',
  },
  terrain: {
    type: 'concrete_ocean',
    heightVariation: 0.35,
    waterLevel: 0.15,
    roughness: 0.6,
    baseElevation: 0,
  },
  atmosphere: {
    presetId: 'br2049_laranja_vegas',
    skyTopColor: '#4d2008',
    skyHorizonColor: '#ad4913',
    fogColor: '#963d0e',
    fogDensity: 0.0042,
    sunColor: '#ff7726',
    sunIntensity: 1.75,
    ambientColor: '#8c3a10',
    ambientIntensity: 0.95,
    sunElevationDeg: 16,
    sunAzimuthDeg: -55,
    cloudOpacity: 0.96,
    windMultiplier: 1.6,
    rainIntensity: 0.0,
  },
  biomes: [
    {
      id: 'biome_br2049',
      name: 'Setor Megacidade & Deserto Radioativo',
      description: 'Asfalto negro, estátuas caídas na poeira ocre e monólitos da Wallace Corp',
      coverageRatio: 1.0,
      colorPalette: {
        ground: '#42372f',
        accent: '#ff7726',
        foliage: '#332b26',
        water: '#14181f',
      },
      dominantSurface: 'concrete',
      acousticZone: 'blade_runner_monolith',
    },
  ],
  structures: [
    {
      id: 'struct_wallace_pyramid',
      name: 'Quartel-General da Wallace Corporation',
      type: 'megatower',
      style: 'cyberpunk',
      position: [0, 0, -380],
      scale: [240, 1850, 240],
      density: 0.9,
      heightRange: [90, 1850],
      materials: ['concreteDarkRib', 'concreteColossal'],
      features: ['human_doors', 'skybridges', 'cantilever_slabs'],
    },
    {
      id: 'struct_vegas_ruins',
      name: 'Ruínas e Colunatas de Las Vegas',
      type: 'colossal_pillars',
      style: 'ancient_futuristic',
      position: [145, 0, -180],
      scale: [36, 60, 36],
      density: 0.85,
      heightRange: [40, 70],
      materials: ['rustedSteel', 'concreteDarkRib'],
      features: ['human_doors'],
    },
    {
      id: 'struct_seawall',
      name: 'Sepulveda Sea Wall',
      type: 'viaduct_network',
      style: 'brutalist',
      position: [-210, 0, -220],
      scale: [32, 140, 520],
      density: 0.8,
      heightRange: [80, 140],
      materials: ['concreteFissuredOcean'],
      features: ['cantilever_slabs'],
    },
  ],
  roads: [
    {
      id: 'road_cardinal',
      name: 'Avenida Principal dos Spinners',
      widthMeters: 34,
      elevation: 0,
      fromPosition: [0, 0, 160],
      toPosition: [0, 0, -420],
      isElevatedViaduct: false,
      material: 'concrete',
    },
    {
      id: 'road_transverse',
      name: 'Boulevard Sepulveda-Vegas',
      widthMeters: 28,
      elevation: 0,
      fromPosition: [-320, 0, -80],
      toPosition: [320, 0, -80],
      isElevatedViaduct: false,
      material: 'concrete',
    },
    {
      id: 'road_viaduct_spinner',
      name: 'Viaduto Expresso de Spinners (+38m)',
      widthMeters: 20,
      elevation: 38,
      fromPosition: [-240, 38, -135],
      toPosition: [240, 38, -135],
      isElevatedViaduct: true,
      material: 'concrete',
    },
  ],
  vegetation: {
    density: 0.05,
    dominantType: 'none',
    foliageColor: '#3d342d',
    averageHeightMeters: 2.0,
  },
  landmarks: [
    {
      id: 'lm_wallace',
      title: 'Quartel-General da Wallace Corporation (1.850 m)',
      subtitle: 'Átrio monumental dos Replicantes sob espelho d\'água',
      scaleNote: 'Perspectiva humana a 1,72m diante da pirâmide brutalista de 1.850m',
      position: [0, 0, -250],
      colossalHeightMeters: 1850,
      lookTarget: [0, 480, -380],
      fundamentalFreq: 30.8,
    },
    {
      id: 'lm_vegas',
      title: 'Ruínas Ocre de Las Vegas',
      subtitle: 'A cabeça da deusa clássica caída na poeira radioativa',
      scaleNote: 'Silhuetas sob a névoa alaranjada de Roger Deakins',
      position: [145, 0, -165],
      colossalHeightMeters: 65,
      lookTarget: [145, 36, -180],
      fundamentalFreq: 34.6,
    },
  ],
  portals: [
    {
      id: 'portal_blade_to_vale',
      targetRegionId: 'vale_pilares',
      position: [0, 0, 95],
      radius: 10,
      label: 'Vale dos Pilares Colossais',
      passageType: 'Pórtico Retrô de Retorno Canônico',
    },
    {
      id: 'portal_blade_to_horizonte',
      targetRegionId: 'megacidade_horizonte',
      position: [260, 0, -80],
      radius: 10,
      label: 'Megacidade Horizonte',
      passageType: 'Pórtico da Megacidade',
    },
  ],
  regions: [
    {
      id: 'region_blade_runner_2049',
      gridCoord: [0, 0],
      title: 'Distrito Wallace & Vegas',
      subtitle: 'Megacidade Distópica Blade Runner 2049',
      acousticDescription: 'Sintetizador CS-80 · Sirenes de Spinners · Zumbido grave',
      biomeId: 'biome_br2049',
      acousticZone: 'blade_runner_monolith',
      defaultWeather: 'br2049_laranja_vegas',
      colossalHeightMeters: 1850,
      spawnOffset: [0, 0, 75],
      structureIds: ['struct_wallace_pyramid', 'struct_vegas_ruins', 'struct_seawall'],
      portalIds: ['portal_blade_to_vale', 'portal_blade_to_horizonte'],
      landmarkIds: ['lm_wallace', 'lm_vegas'],
    },
  ],
  metadata: {
    generatedByProvider: 'MONOLITO AI Director',
    model: 'Gemini Pro 2049 Synthesis',
    createdAt: 1728219600000,
    version: '2.0',
    generationPrompt:
      'Blade Runner 2049 Wallace Corp Pyramid, Las Vegas orange dust, Sepulveda sea wall, flying spinners, neon rain',
  },
};

export class WorldPlanCache {
  private static memoryPlans: Map<string, WorldPlan> = new Map([
    [DEFAULT_BLADE_RUNNER_PLAN.worldId, DEFAULT_BLADE_RUNNER_PLAN],
  ]);
  private static memoryStates: Map<string, WorldState> = new Map();

  public static savePlan(plan: WorldPlan): void {
    this.memoryPlans.set(plan.worldId, plan);
    try {
      const stored = this.getAllPlans();
      const filtered = stored.filter((p) => p.worldId !== plan.worldId);
      filtered.unshift(plan);
      localStorage.setItem(STORAGE_KEY_PLANS, JSON.stringify(filtered.slice(0, 15)));
    } catch {
      // ignore quota
    }
  }

  public static getPlan(worldId: string): WorldPlan | null {
    if (this.memoryPlans.has(worldId)) {
      return this.memoryPlans.get(worldId)!;
    }
    const stored = this.getAllPlans();
    const found = stored.find((p) => p.worldId === worldId);
    if (found) {
      this.memoryPlans.set(worldId, found);
      return found;
    }
    return null;
  }

  public static getAllPlans(): WorldPlan[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEY_PLANS);
      if (raw) {
        const parsed: WorldPlan[] = JSON.parse(raw);
        if (!parsed.some((p) => p.worldId === DEFAULT_BLADE_RUNNER_PLAN.worldId)) {
          parsed.unshift(DEFAULT_BLADE_RUNNER_PLAN);
        }
        return parsed;
      }
    } catch {
      // fallback
    }
    if (!this.memoryPlans.has(DEFAULT_BLADE_RUNNER_PLAN.worldId)) {
      this.memoryPlans.set(DEFAULT_BLADE_RUNNER_PLAN.worldId, DEFAULT_BLADE_RUNNER_PLAN);
    }
    return Array.from(this.memoryPlans.values());
  }

  public static deletePlan(worldId: string): void {
    this.memoryPlans.delete(worldId);
    this.memoryStates.delete(worldId);
    try {
      const stored = this.getAllPlans().filter((p) => p.worldId !== worldId);
      localStorage.setItem(STORAGE_KEY_PLANS, JSON.stringify(stored));
    } catch {
      // ignore
    }
  }

  public static saveState(state: WorldState): void {
    this.memoryStates.set(state.worldId, state);
    try {
      const stored = this.getAllStates();
      const filtered = stored.filter((s) => s.worldId !== state.worldId);
      filtered.unshift(state);
      localStorage.setItem(STORAGE_KEY_STATES, JSON.stringify(filtered.slice(0, 10)));
    } catch {
      // ignore
    }
  }

  public static getState(worldId: string): WorldState | null {
    if (this.memoryStates.has(worldId)) {
      return this.memoryStates.get(worldId)!;
    }
    const stored = this.getAllStates();
    const found = stored.find((s) => s.worldId === worldId);
    if (found) {
      this.memoryStates.set(worldId, found);
      return found;
    }
    return null;
  }

  public static getAllStates(): WorldState[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEY_STATES);
      if (raw) {
        return JSON.parse(raw);
      }
    } catch {
      // fallback
    }
    return Array.from(this.memoryStates.values());
  }

  public static createInitialState(plan: WorldPlan): WorldState {
    const regionMap: Record<string, WorldRegionDefinition> = {};
    plan.regions.forEach((r) => {
      regionMap[r.id] = r;
    });

    const structureMap: Record<string, any> = {};
    plan.structures.forEach((s) => {
      structureMap[s.id] = s;
    });

    const landmarkMap: Record<string, any> = {};
    plan.landmarks.forEach((l) => {
      landmarkMap[l.id] = l;
    });

    const portalMap: Record<string, any> = {};
    plan.portals.forEach((p) => {
      portalMap[p.id] = p;
    });

    const state: WorldState = {
      worldId: plan.worldId,
      seed: plan.seed,
      dimensions: {
        widthMeters: plan.size.width,
        depthMeters: plan.size.depth,
        scaleLabel: plan.size.scaleLabel,
      },
      plan,
      regions: regionMap,
      structures: structureMap,
      landmarks: landmarkMap,
      portals: portalMap,
      modifications: [],
      activeRegionId: plan.regions[0]?.id || 'region_0',
      playerPosition: [0, 0, 40],
      metadata: {
        createdAt: Date.now(),
        updatedAt: Date.now(),
        lastProviderUsed: plan.metadata?.generatedByProvider || 'System',
        version: 1,
      },
    };

    this.saveState(state);
    return state;
  }
}
