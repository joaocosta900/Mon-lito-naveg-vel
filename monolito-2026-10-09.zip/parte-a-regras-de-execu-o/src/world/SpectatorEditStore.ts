import * as THREE from 'three';
import { IDENTITY_TRANSFORM, StructureTransform } from './SpectatorStructures';

const STORAGE_KEY = 'monolito_spectator_edits_v1';
// v2: adiciona offsetY e rotação nos três eixos. Formatos antigos
// são descartados de propósito — os campos não existem mais neles.
const REGION_VERSION = 2;

export interface RegionEdits {
  version: number;
  /** Anchor → transformação já aplicada naquela construção. */
  entries: Record<string, StructureTransform>;
}

type RegionMap = Record<string, RegionEdits>;

function emptyRegion(): RegionEdits {
  return { version: REGION_VERSION, entries: {} };
}

function readAll(): RegionMap {
  if (typeof localStorage === 'undefined') return {};
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as RegionMap;
    if (!parsed || typeof parsed !== 'object') return {};
    return parsed;
  } catch {
    return {};
  }
}

function writeAll(map: RegionMap): void {
  if (typeof localStorage === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(map));
  } catch {
    // Cota estourada: o espectador continua funcionando em memória.
  }
}

/**
 * Âncora estável de uma construção.
 *
 * O id do cluster (`spectator_cluster_N`) é gerado por ordem de agrupamento e
 * muda se o mundo for reconstruído com outra quantidade de peças. A âncora usa
 * a posição do pivô arredondada: mesma construção, mesmo endereço, mesmo após
 * recarregar a região ou fechar o jogo.
 */
export function anchorFor(origin: THREE.Vector3): string {
  return `${Math.round(origin.x)},${Math.round(origin.y)},${Math.round(origin.z)}`;
}

export function isIdentity(transform: StructureTransform): boolean {
  return (
    Math.abs(transform.offsetX) < 0.001 &&
    Math.abs(transform.offsetY) < 0.001 &&
    Math.abs(transform.offsetZ) < 0.001 &&
    Math.abs(transform.rotX) < 0.001 &&
    Math.abs(transform.rotY) < 0.001 &&
    Math.abs(transform.rotZ) < 0.001 &&
    Math.abs(transform.scaleX - 1) < 0.001 &&
    Math.abs(transform.scaleY - 1) < 0.001 &&
    Math.abs(transform.scaleZ - 1) < 0.001
  );
}

/** Lê as edições salvas de uma região. */
export function loadEdits(regionId: string): RegionEdits {
  const region = readAll()[regionId];
  if (!region || region.version !== REGION_VERSION || !region.entries) {
    return emptyRegion();
  }
  return region;
}

/** Grava (ou limpa, se a transformação for a identidade) a edição de uma construção. */
export function saveEdit(
  regionId: string,
  anchor: string,
  transform: StructureTransform
): void {
  const map = readAll();
  const region = map[regionId]?.version === REGION_VERSION ? map[regionId] : emptyRegion();

  if (isIdentity(transform)) {
    if (!region.entries[anchor]) return;
    delete region.entries[anchor];
  } else {
    region.entries[anchor] = {
      offsetX: transform.offsetX,
      offsetY: transform.offsetY,
      offsetZ: transform.offsetZ,
      rotX: transform.rotX,
      rotY: transform.rotY,
      rotZ: transform.rotZ,
      scaleX: transform.scaleX,
      scaleY: transform.scaleY,
      scaleZ: transform.scaleZ,
    };
  }

  if (Object.keys(region.entries).length === 0) delete map[regionId];
  else map[regionId] = region;
  writeAll(map);
}

/** Devolve uma construção ao estado original e apaga a edição salva. */
export function clearEdit(regionId: string, anchor: string): void {
  saveEdit(regionId, anchor, IDENTITY_TRANSFORM);
}

/** Quantas construções da região têm edição salva. */
export function countEdits(regionId: string): number {
  return Object.keys(loadEdits(regionId).entries).length;
}
