import * as THREE from 'three';
import {
  AcousticZone,
  ArchitecturalPortal,
  RegionId,
  ResonancePoint,
  SurfaceMaterialType,
  WalkableBox,
} from '../types/world';
import { WorldMaterialLibrary } from './ProceduralTextures';

export interface FuturisticAnimationController {
  update: (elapsed: number, dt: number, playerPos: THREE.Vector3) => void;
  dispose: () => void;
}

interface AerialVehicleInstance {
  x: number;
  y: number;
  z: number;
  vx: number;
  vz: number;
  scaleX: number;
  scaleY: number;
  scaleZ: number;
  yaw: number;
  boundsHalfSpan: number;
}

interface RoboticArmRig {
  baseTurret: THREE.Group;
  lowerBoom: THREE.Group;
  upperArm: THREE.Group;
  wristHead: THREE.Group;
  phaseOffset: number;
  speed: number;
}

interface SlidingDoorPair {
  leftWing: THREE.Mesh;
  rightWing: THREE.Mesh;
  centerZ: number;
  centerX: number;
  baseOffsetX: number;
  slideDistance: number;
  triggerRadius: number;
  currentOpenRatio: number;
}

/**
 * Generates a subtle procedural illuminated skyscraper facade texture
 * for the colossal megatowers in Mapa 10 (Cidade do Céu) and Mapa 13 (Megacidade Horizonte).
 */
function createFuturisticFacadeMaterial(): {
  facadeMat: THREE.MeshStandardMaterial;
  luminousPanelMat: THREE.MeshBasicMaterial;
  hologramMat: THREE.MeshBasicMaterial;
  quantumCyanMat: THREE.MeshBasicMaterial;
  moltenPlasmaMat: THREE.MeshBasicMaterial;
  hologramMagentaMat: THREE.MeshBasicMaterial;
  translucentDomeMat: THREE.MeshStandardMaterial;
  glassCurtainMat: THREE.MeshStandardMaterial;
  smoothArchitecturalConcreteMat: THREE.MeshStandardMaterial;
  linearLightStripMat: THREE.MeshBasicMaterial;
  billboardAetherMat: THREE.MeshBasicMaterial;
  billboardNeoTechMat: THREE.MeshBasicMaterial;
  billboardCypherionMat: THREE.MeshBasicMaterial;
  billboardStationSignMat: THREE.MeshBasicMaterial;
  monorailBulletMat: THREE.MeshStandardMaterial;
  auroraRibbonMat: THREE.ShaderMaterial;
  horizonCurveMat: THREE.ShaderMaterial;
  disposeMaterials: () => void;
} {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  // Dark architectural metallic-concrete base
  ctx.fillStyle = '#384047';
  ctx.fillRect(0, 0, size, size);

  // Structural vertical mullions & horizontal floor bands (64 floors per tile!)
  const rows = 64;
  const cols = 32;
  const rowH = size / rows;
  const colW = size / cols;

  for (let r = 0; r < rows; r++) {
    ctx.fillStyle = 'rgba(20, 25, 30, 0.75)';
    ctx.fillRect(0, r * rowH, size, 2);

    for (let c = 0; c < cols; c++) {
      // Sparse, elegant architectural window lights (warm ivory & muted pale cyan)
      const seed = Math.sin(r * 12.9898 + c * 78.233) * 43758.5453;
      const frac = seed - Math.floor(seed);
      if (frac > 0.74) {
        ctx.fillStyle =
          frac > 0.91 ? 'rgba(185, 218, 235, 0.75)' : 'rgba(245, 228, 198, 0.68)';
        ctx.fillRect(c * colW + 2, r * rowH + 2, colW - 4, rowH - 4);
      } else {
        ctx.fillStyle = 'rgba(42, 50, 58, 0.65)';
        ctx.fillRect(c * colW + 2, r * rowH + 2, colW - 4, rowH - 4);
      }
    }
  }

  // Heavy mega-truss horizontal transfer floors every 16 floors
  ctx.fillStyle = '#242a30';
  for (let r = 0; r < rows; r += 16) {
    ctx.fillRect(0, r * rowH, size, 6);
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(3, 12);
  tex.colorSpace = THREE.SRGBColorSpace;

  const facadeMat = new THREE.MeshStandardMaterial({
    map: tex,
    roughness: 0.65,
    metalness: 0.35,
    emissive: new THREE.Color('#2a3845'),
    emissiveMap: tex,
    emissiveIntensity: 0.55,
  });

  const luminousPanelMat = new THREE.MeshBasicMaterial({
    color: new THREE.Color('#d4e4f0'),
    transparent: true,
    opacity: 0.72,
  });

  const hologramMat = new THREE.MeshBasicMaterial({
    color: new THREE.Color('#9ec5db'),
    wireframe: true,
    transparent: true,
    opacity: 0.38,
  });

  const quantumCyanMat = new THREE.MeshBasicMaterial({
    color: new THREE.Color('#5ef6ff'),
    transparent: true,
    opacity: 0.85,
    side: THREE.DoubleSide,
  });

  const moltenPlasmaMat = new THREE.MeshBasicMaterial({
    color: new THREE.Color('#ffaa44'),
    transparent: true,
    opacity: 0.9,
  });

  const hologramMagentaMat = new THREE.MeshBasicMaterial({
    color: new THREE.Color('#ff2a85'),
    transparent: true,
    opacity: 0.78,
    side: THREE.DoubleSide,
  });

  const translucentDomeMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#2d637a'),
    roughness: 0.12,
    metalness: 0.45,
    transparent: true,
    opacity: 0.38,
    side: THREE.DoubleSide,
  });

  // 1. Blue Glass Curtain Wall for Sleek Skyscrapers (Images 2 & 4)
  const glassCanvas = document.createElement('canvas');
  glassCanvas.width = 256;
  glassCanvas.height = 256;
  const gCtx = glassCanvas.getContext('2d')!;
  gCtx.fillStyle = '#22384a';
  gCtx.fillRect(0, 0, 256, 256);
  gCtx.fillStyle = '#3a546b';
  for (let y = 0; y < 256; y += 16) gCtx.fillRect(0, y, 256, 2);
  for (let x = 0; x < 256; x += 32) gCtx.fillRect(x, 0, 2, 256);
  const glassTex = new THREE.CanvasTexture(glassCanvas);
  glassTex.wrapS = THREE.RepeatWrapping;
  glassTex.wrapT = THREE.RepeatWrapping;
  glassTex.repeat.set(4, 16);
  const glassCurtainMat = new THREE.MeshStandardMaterial({
    map: glassTex,
    roughness: 0.15,
    metalness: 0.85,
    color: new THREE.Color('#4a7191'),
  });

  // 2. Smooth Modern Cast-in-Place Concrete with Formwork Tie Holes (Image 3)
  const archConcreteCanvas = document.createElement('canvas');
  archConcreteCanvas.width = 256;
  archConcreteCanvas.height = 256;
  const acCtx = archConcreteCanvas.getContext('2d')!;
  acCtx.fillStyle = '#8f969b';
  acCtx.fillRect(0, 0, 256, 256);
  acCtx.fillStyle = '#7a8187';
  acCtx.fillRect(0, 126, 256, 3);
  acCtx.fillRect(126, 0, 3, 256);
  acCtx.fillStyle = '#505457';
  [32, 224].forEach((cx) => {
    [32, 224].forEach((cy) => {
      acCtx.beginPath();
      acCtx.arc(cx, cy, 3.5, 0, Math.PI * 2);
      acCtx.fill();
    });
  });
  const archConcreteTex = new THREE.CanvasTexture(archConcreteCanvas);
  archConcreteTex.wrapS = THREE.RepeatWrapping;
  archConcreteTex.wrapT = THREE.RepeatWrapping;
  const smoothArchitecturalConcreteMat = new THREE.MeshStandardMaterial({
    map: archConcreteTex,
    roughness: 0.38,
    metalness: 0.18,
  });

  // 3. Emissive Linear LED Light Strip (Image 3 & 4)
  const linearLightStripMat = new THREE.MeshBasicMaterial({
    color: new THREE.Color('#f0f7ff'),
  });

  // Helper for crisp high-resolution corporate billboard textures (Image 4)
  const makeBillboard = (
    title: string,
    sub: string,
    accColor: string,
    bgHex: string
  ): THREE.MeshBasicMaterial => {
    const c = document.createElement('canvas');
    c.width = 512;
    c.height = 512;
    const bCtx = c.getContext('2d')!;
    bCtx.fillStyle = bgHex;
    bCtx.fillRect(0, 0, 512, 512);

    bCtx.strokeStyle = accColor;
    bCtx.lineWidth = 10;
    bCtx.strokeRect(16, 16, 480, 480);
    bCtx.strokeRect(26, 26, 460, 460);

    // Glowing logo geometry
    bCtx.fillStyle = accColor;
    bCtx.beginPath();
    bCtx.arc(256, 140, 52, 0, Math.PI * 2);
    bCtx.fill();
    bCtx.fillStyle = bgHex;
    bCtx.beginPath();
    bCtx.arc(256, 140, 26, 0, Math.PI * 2);
    bCtx.fill();

    bCtx.fillStyle = '#ffffff';
    bCtx.font = '900 46px system-ui, sans-serif';
    bCtx.textAlign = 'center';
    bCtx.fillText(title, 256, 280);

    bCtx.fillStyle = accColor;
    bCtx.font = '700 24px system-ui, sans-serif';
    bCtx.fillText(sub, 256, 335);

    bCtx.strokeStyle = 'rgba(255,255,255,0.22)';
    bCtx.lineWidth = 3;
    for (let y = 385; y < 470; y += 20) {
      bCtx.beginPath();
      bCtx.moveTo(55, y);
      bCtx.lineTo(457, y);
      bCtx.stroke();
    }
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    return new THREE.MeshBasicMaterial({ map: t });
  };

  const billboardAetherMat = makeBillboard('AETHER CORP', 'NEXT-GEN AEROSPACE', '#00b4d8', '#071626');
  const billboardNeoTechMat = makeBillboard('NEO-TECH SERVICES', 'QUANTUM LOGISTICS', '#48cae4', '#0d1b2a');
  const billboardCypherionMat = makeBillboard('CYPHERION CITY', 'CENTRAL RIDE HUB', '#ffb703', '#1b1b1b');
  const billboardStationSignMat = makeBillboard('17 CENTRAL STATION', 'APPROACHING DOCK 04', '#00f5d4', '#111923');

  // 4. Sleek Aerodynamic Bullet Ceramic Material (Images 2 & 3)
  const monorailBulletMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#f5f7fa'),
    roughness: 0.12,
    metalness: 0.35,
  });

  // Aurora Ribbons Shader for Citadela Hiperbórea
  const auroraRibbonMat = new THREE.ShaderMaterial({
    uniforms: {
      uTime: { value: 0 },
    },
    vertexShader: `
      varying vec2 vUv;
      varying vec3 vWorldPos;
      void main() {
        vUv = uv;
        vec4 wp = modelMatrix * vec4(position, 1.0);
        vWorldPos = wp.xyz;
        gl_Position = projectionMatrix * viewMatrix * wp;
      }
    `,
    fragmentShader: `
      uniform float uTime;
      varying vec2 vUv;
      varying vec3 vWorldPos;
      void main() {
        float wave = sin(vUv.x * 6.28 + uTime * 0.45) * 0.18 + cos(vUv.x * 12.56 - uTime * 0.3) * 0.08;
        float dist = abs(vUv.y - (0.5 + wave));
        float glow = smoothstep(0.45, 0.0, dist);
        vec3 col1 = vec3(0.18, 0.95, 0.65); // Emerald Aurora
        vec3 col2 = vec3(0.55, 0.22, 0.92); // Violet Aurora
        vec3 aurora = mix(col1, col2, sin(vUv.x * 3.14 + uTime * 0.2) * 0.5 + 0.5);
        gl_FragColor = vec4(aurora, glow * 0.48 * smoothstep(0.0, 0.15, vUv.x) * smoothstep(1.0, 0.85, vUv.x));
      }
    `,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    side: THREE.DoubleSide,
  });

  // Planetary Horizon Curvature Shader for Mapa 12 (O Elevador Planetário)
  const horizonCurveMat = new THREE.ShaderMaterial({
    uniforms: {
      uAtmosphereColor: { value: new THREE.Color('#9ec0d9') },
    },
    vertexShader: `
      varying vec2 vUv;
      void main() {
        vUv = uv;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,
    fragmentShader: `
      uniform vec3 uAtmosphereColor;
      varying vec2 vUv;
      void main() {
        // Gentle planetary curvature arc across the horizon
        float arch = sin(vUv.x * 3.14159265) * 0.18;
        float dist = abs(vUv.y - (0.35 + arch));
        float glow = smoothstep(0.22, 0.0, dist) * smoothstep(0.0, 0.15, vUv.x) * smoothstep(1.0, 0.85, vUv.x);
        gl_FragColor = vec4(uAtmosphereColor, glow * 0.55);
      }
    `,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    side: THREE.DoubleSide,
  });

  const disposeMaterials = () => {
    tex.dispose();
    facadeMat.dispose();
    luminousPanelMat.dispose();
    hologramMat.dispose();
    quantumCyanMat.dispose();
    moltenPlasmaMat.dispose();
    hologramMagentaMat.dispose();
    translucentDomeMat.dispose();
    glassTex.dispose();
    glassCurtainMat.dispose();
    archConcreteTex.dispose();
    smoothArchitecturalConcreteMat.dispose();
    linearLightStripMat.dispose();
    (billboardAetherMat.map as THREE.Texture)?.dispose();
    billboardAetherMat.dispose();
    (billboardNeoTechMat.map as THREE.Texture)?.dispose();
    billboardNeoTechMat.dispose();
    (billboardCypherionMat.map as THREE.Texture)?.dispose();
    billboardCypherionMat.dispose();
    (billboardStationSignMat.map as THREE.Texture)?.dispose();
    billboardStationSignMat.dispose();
    monorailBulletMat.dispose();
    auroraRibbonMat.dispose();
    horizonCurveMat.dispose();
  };

  return {
    facadeMat,
    luminousPanelMat,
    hologramMat,
    quantumCyanMat,
    moltenPlasmaMat,
    hologramMagentaMat,
    translucentDomeMat,
    glassCurtainMat,
    smoothArchitecturalConcreteMat,
    linearLightStripMat,
    billboardAetherMat,
    billboardNeoTechMat,
    billboardCypherionMat,
    billboardStationSignMat,
    monorailBulletMat,
    auroraRibbonMat,
    horizonCurveMat,
    disposeMaterials,
  };
}

export function populateFuturisticRegion(
  regionId: RegionId,
  sceneGroup: THREE.Group,
  materials: WorldMaterialLibrary,
  colliders: WalkableBox[],
  resonancePoints: ResonancePoint[],
  portals: ArchitecturalPortal[],
  trackGeo: <T extends THREE.BufferGeometry>(geo: T) => T,
  addBox: (
    w: number,
    h: number,
    d: number,
    x: number,
    yBottom: number,
    z: number,
    mat: THREE.Material,
    options?: {
      isWall?: boolean;
      walkableTop?: boolean;
      surface?: SurfaceMaterialType;
      zone?: AcousticZone;
      castShadow?: boolean;
      receiveShadow?: boolean;
      rotY?: number;
      rotZ?: number;
      noCollision?: boolean;
    }
  ) => THREE.Mesh,
  addHumanDoor: (x: number, yBottom: number, z: number, rotY?: number) => void,
  addHumanBench: (x: number, yBottom: number, z: number, rotY?: number) => void,
  addSolitaryTree: (x: number, yBottom: number, z: number, scale?: number) => void,
  addArchitecturalPortal: (portal: ArchitecturalPortal) => void
): {
  worldBounds: { minX: number; maxX: number; minZ: number; maxZ: number };
  defaultGroundSurface: SurfaceMaterialType;
  defaultZone: AcousticZone;
  controller: FuturisticAnimationController;
} {
  const {
    facadeMat,
    luminousPanelMat,
    hologramMat,
    quantumCyanMat,
    moltenPlasmaMat,
    hologramMagentaMat,
    translucentDomeMat,
    glassCurtainMat,
    smoothArchitecturalConcreteMat,
    linearLightStripMat,
    billboardAetherMat,
    billboardNeoTechMat,
    billboardCypherionMat,
    billboardStationSignMat,
    monorailBulletMat,
    auroraRibbonMat,
    horizonCurveMat,
    disposeMaterials,
  } = createFuturisticFacadeMaterial();

  const dummy = new THREE.Object3D();

  // Animated collections
  const skyRings: Array<{ mesh: THREE.Object3D; speedZ: number; speedY: number }> = [];
  const colossalCruisers: Array<{
    group: THREE.Group;
    speedZ: number;
    startZ: number;
    endZ: number;
  }> = [];
  const roboticArms: RoboticArmRig[] = [];
  const conveyorBlocks: THREE.Mesh[] = [];
  const verticalElevators: Array<{
    mesh: THREE.Object3D;
    minY: number;
    maxY: number;
    speed: number;
    phase: number;
  }> = [];
  const maglevTrains: Array<{
    mesh: THREE.Mesh;
    startX: number;
    endX: number;
    speedX: number;
  }> = [];
  const slidingDoors: SlidingDoorPair[] = [];
  const rotatingHolograms: THREE.Object3D[] = [];
  const floatingIslands: Array<{ group: THREE.Group; baseY: number; amp: number; speed: number; phase: number }> = [];
  const solarMirrors: Array<{ mesh: THREE.Object3D; rotSpeedY: number }> = [];
  const synchrotronBeams: Array<{ mesh: THREE.Mesh; centerZ: number; radius: number; speed: number; currentAngle: number }> = [];
  const deepSeaCruisers: Array<{ group: THREE.Group; speedZ: number; startZ: number; endZ: number; baseY: number; bobPhase: number }> = [];
  const auroraMeshRefs: THREE.Mesh[] = [];

  const addMonumentalAndHumanDoorPair = (x: number, yBottom: number, z: number, rotY = 0) => {
    const group = new THREE.Group();
    group.position.set(x, yBottom, z);
    group.rotation.y = rotY;

    const frame = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(9.6, 16.5, 1.2)),
      materials.concreteDarkRib
    );
    frame.position.y = 8.25;
    group.add(frame);

    const innerPanel = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(8.2, 15.6, 1.4)),
      materials.rustedSteel
    );
    innerPanel.position.y = 7.8;
    group.add(innerPanel);

    const statusLight = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(7.6, 0.28, 1.5)),
      materials.distantBeaconLight
    );
    statusLight.position.y = 15.8;
    group.add(statusLight);

    sceneGroup.add(group);

    const cos = Math.cos(rotY);
    const sin = Math.sin(rotY);
    addHumanDoor(x + cos * 6.8, yBottom, z - sin * 6.8, rotY);
  };

  const addParkedFuturisticVehicle = (x: number, yBottom: number, z: number, rotY = 0) => {
    const vGroup = new THREE.Group();
    vGroup.position.set(x, yBottom, z);
    vGroup.rotation.y = rotY;

    const chassis = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(2.1, 0.85, 4.5)),
      materials.rustedSteel
    );
    chassis.position.y = 0.62;
    chassis.castShadow = true;
    vGroup.add(chassis);

    const cabin = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(1.85, 0.68, 2.5)),
      materials.concreteDarkRib
    );
    cabin.position.set(0, 1.32, -0.2);
    vGroup.add(cabin);

    const lightStrip = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(1.9, 0.12, 4.56)),
      materials.distantBeaconLight
    );
    lightStrip.position.y = 0.65;
    vGroup.add(lightStrip);

    sceneGroup.add(vGroup);
  };

  const setupAerialTraffic = (
    droneCount: number,
    civilCount: number,
    colossalCount: number,
    minAltitude: number
  ) => {
    const totalSmall = droneCount + civilCount;
    const craftGeo = trackGeo(new THREE.BoxGeometry(1.0, 0.35, 2.4));
    const craftInst = new THREE.InstancedMesh(craftGeo, materials.rustedSteel, totalSmall);
    craftInst.frustumCulled = false;
    sceneGroup.add(craftInst);

    const beaconGeo = trackGeo(new THREE.BoxGeometry(0.85, 0.16, 0.4));
    const beaconInst = new THREE.InstancedMesh(
      beaconGeo,
      materials.distantBeaconLight,
      totalSmall
    );
    beaconInst.frustumCulled = false;
    sceneGroup.add(beaconInst);

    const vehicles: AerialVehicleInstance[] = [];

    for (let i = 0; i < totalSmall; i++) {
      const isCargoOrCivil = i >= droneCount;
      const isGiantCargo = i >= totalSmall - 6;
      const span = isGiantCargo ? 950 : 650;
      const alongX = i % 2 === 0;
      const dir = i % 4 < 2 ? 1 : -1;
      const speed = isGiantCargo
        ? 9 + Math.random() * 5
        : isCargoOrCivil
        ? 22 + Math.random() * 18
        : 6 + Math.random() * 6;
      const scaleX = isGiantCargo ? 14.0 : isCargoOrCivil ? 2.4 : 1.1;
      const scaleY = isGiantCargo ? 8.5 : isCargoOrCivil ? 1.2 : 0.6;
      const scaleZ = isGiantCargo ? 24.0 : isCargoOrCivil ? 3.2 : 1.1;

      vehicles.push({
        x: (Math.random() - 0.5) * span * 2,
        y: minAltitude + (isGiantCargo ? 120 + Math.random() * 140 : 28 + Math.random() * 165),
        z: -140 + (Math.random() - 0.5) * span * 2,
        vx: alongX ? dir * speed : 0,
        vz: alongX ? 0 : dir * speed,
        scaleX,
        scaleY,
        scaleZ,
        yaw: alongX ? (dir > 0 ? Math.PI / 2 : -Math.PI / 2) : dir > 0 ? 0 : Math.PI,
        boundsHalfSpan: span,
      });
    }

    for (let c = 0; c < colossalCount; c++) {
      const cruiserGroup = new THREE.Group();
      const alt = 220 + c * 115;
      const xOffset = c === 0 ? -35 : 85;
      const startZ = -1250 - c * 400;
      cruiserGroup.position.set(xOffset, alt, startZ);

      const mainHull = new THREE.Mesh(
        trackGeo(new THREE.BoxGeometry(96, 28, 410)),
        materials.concreteDarkRib
      );
      cruiserGroup.add(mainHull);

      const wingHull = new THREE.Mesh(
        trackGeo(new THREE.BoxGeometry(168, 12, 240)),
        materials.concreteColossal
      );
      wingHull.position.set(0, -4, -20);
      cruiserGroup.add(wingHull);

      for (let r = -160; r <= 160; r += 40) {
        const rib = new THREE.Mesh(
          trackGeo(new THREE.BoxGeometry(92, 6, 8)),
          materials.rustedSteel
        );
        rib.position.set(0, -16, r);
        cruiserGroup.add(rib);
      }

      const ventralCoreLight = new THREE.Mesh(
        trackGeo(new THREE.BoxGeometry(14, 1.5, 320)),
        luminousPanelMat
      );
      ventralCoreLight.position.set(0, -15, 0);
      cruiserGroup.add(ventralCoreLight);

      sceneGroup.add(cruiserGroup);

      colossalCruisers.push({
        group: cruiserGroup,
        speedZ: 8.5 + c * 2.0,
        startZ: -1300,
        endZ: 950,
      });
    }

    return { craftInst, beaconInst, vehicles };
  };

  let aerialData: ReturnType<typeof setupAerialTraffic> | null = null;
  let worldBounds = { minX: -240, maxX: 240, minZ: -480, maxZ: 110 };
  let defaultGroundSurface: SurfaceMaterialType = 'concrete';
  let defaultZone: AcousticZone = 'sky_platform';

  if (regionId === 'cidade_ceu') {
    defaultZone = 'sky_platform';
    worldBounds = { minX: -95, maxX: 95, minZ: -360, maxZ: 95 };

    addBox(96, 18, 160, 0, -18, 25, materials.concreteFissuredOcean, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'sky_platform',
    });

    addBox(24, 6, 240, 0, -6, -155, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'elevated_bridge',
    });

    addBox(4.2, 6.06, 230, 0, -6, -155, materials.rustedSteel, {
      walkableTop: true,
      surface: 'metal',
      zone: 'elevated_bridge',
      castShadow: false,
    });

    addBox(150, 24, 140, 0, -24, -280, materials.concreteFissuredOcean, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'sky_platform',
    });

    addBox(22, 0.35, 42, -26, 0, 20, materials.meadowGround, {
      walkableTop: true,
      surface: 'grass',
      zone: 'sky_platform',
    });
    addBox(22, 0.35, 42, 26, 0, 20, materials.meadowGround, {
      walkableTop: true,
      surface: 'grass',
      zone: 'sky_platform',
    });
    addSolitaryTree(-26, 0.35, 32, 1.05);
    addSolitaryTree(-24, 0.35, 12, 0.9);
    addSolitaryTree(26, 0.35, 28, 1.1);
    addSolitaryTree(25, 0.35, 8, 0.95);
    addHumanBench(-13.5, 0, 20, Math.PI / 2);
    addHumanBench(13.5, 0, 20, -Math.PI / 2);

    addBox(34, 8, 38, -62, -8, 15, materials.concreteDarkRib, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'sky_platform',
    });
    addParkedFuturisticVehicle(-58, 0, 22, 0.35);
    addParkedFuturisticVehicle(-66, 0, 8, -0.2);

    addBox(18, 4, 24, 20, -4, -95, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
    });
    colliders.push({
      minX: 28,
      maxX: 42,
      minZ: -165,
      maxZ: -95,
      minY: -1,
      maxY: 18,
      isRamp: true,
      rampAxis: 'z',
      rampStartY: 16,
      rampEndY: 0,
      surface: 'concrete',
      zone: 'colossal_staircase',
    });

    const skyRamp = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(14, 1.5, 72)),
      materials.concreteDarkRib
    );
    skyRamp.position.set(35, 7.6, -130);
    skyRamp.rotation.x = Math.atan2(16, 70);
    sceneGroup.add(skyRamp);

    addBox(34, 4, 40, 41, 12, -185, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'sky_platform',
    });
    addBox(12, 0.4, 16, 46, 16, -185, materials.meadowGround, {
      walkableTop: true,
      surface: 'grass',
    });
    addSolitaryTree(46, 16.4, -185, 1.15);
    addHumanBench(32, 16, -185, -Math.PI / 2);

    const skyTowers: Array<{ x: number; y: number; z: number; w: number; h: number; d: number }> = [
      { x: -58, y: -60, z: -280, w: 42, h: 780, d: 42 },
      { x: 58, y: -60, z: -280, w: 42, h: 840, d: 42 },
      { x: 0, y: -40, z: -385, w: 68, h: 920, d: 58 },
      { x: -165, y: 145, z: -140, w: 110, h: 28, d: 110 },
      { x: -165, y: 173, z: -140, w: 48, h: 520, d: 48 },
      { x: 175, y: 185, z: -190, w: 120, h: 32, d: 120 },
      { x: 175, y: 217, z: -190, w: 52, h: 560, d: 52 },
    ];
    skyTowers.forEach((st, i) => {
      const mat = i % 2 === 0 ? facadeMat : materials.concreteColossal;
      const isNearWalkable = st.y < 0 && Math.abs(st.x) < 80 && st.z > -340;
      addBox(st.w, st.h, st.d, st.x, st.y, st.z, mat, { isWall: isNearWalkable });
    });

    addMonumentalAndHumanDoorPair(-36.8, 0, -280, Math.PI / 2);
    addMonumentalAndHumanDoorPair(36.8, 0, -280, -Math.PI / 2);

    const ring1 = new THREE.Mesh(
      trackGeo(new THREE.TorusGeometry(185, 6.5, 8, 48)),
      materials.concreteDarkRib
    );
    ring1.position.set(0, 210, -240);
    ring1.rotation.x = Math.PI * 0.42;
    sceneGroup.add(ring1);
    skyRings.push({ mesh: ring1, speedZ: 0.018, speedY: 0.005 });

    const ring2 = new THREE.Mesh(
      trackGeo(new THREE.TorusGeometry(290, 9.0, 8, 56)),
      materials.concreteColossal
    );
    ring2.position.set(0, 320, -280);
    ring2.rotation.x = -Math.PI * 0.36;
    sceneGroup.add(ring2);
    skyRings.push({ mesh: ring2, speedZ: -0.012, speedY: 0.008 });

    const lowerCloudGeo = trackGeo(new THREE.PlaneGeometry(540, 540));
    lowerCloudGeo.rotateX(-Math.PI / 2);
    for (let i = 0; i < 24; i++) {
      const cm = new THREE.Mesh(lowerCloudGeo, materials.cloudLayerMaterial);
      cm.position.set(
        (Math.random() - 0.5) * 1600,
        -48 - (i % 2) * 35,
        (Math.random() - 0.5) * 1400
      );
      sceneGroup.add(cm);
    }

    aerialData = setupAerialTraffic(18, 32, 2, 25);

    resonancePoints.push(
      {
        id: 'ceu_plaza',
        position: [0, 0, 15],
        radius: 18,
        title: 'Plataforma Suspensa Sul',
        scaleNote: 'Cidadelas flutuantes, anéis orbitais de 580 m e cruzadores colossais cruzando o zênite',
        lookTarget: [0, 230, -240],
        fundamentalFreq: 41.2,
      },
      {
        id: 'ceu_mirante',
        position: [41, 16, -185],
        radius: 16,
        title: 'Jardim Suspenso de Observação (+16 m)',
        scaleNote: 'Árvores de escala humana diante de torres de 920 m parcialmente ocultas pelas nuvens',
        lookTarget: [0, 260, -320],
        fundamentalFreq: 36.71,
      }
    );

    addArchitecturalPortal({
      id: 'portal_to_maquinas',
      position: [0, 0, -315],
      radius: 10,
      targetRegion: 'complexo_maquinas',
      passageType: 'Pórtico Orbital Norte',
      label: 'O Complexo das Máquinas',
    });
  } else if (regionId === 'complexo_maquinas') {
    defaultZone = 'machine_foundry';
    worldBounds = { minX: -120, maxX: 120, minZ: -390, maxZ: 95 };

    const floorGeo = trackGeo(new THREE.PlaneGeometry(4600, 4600));
    floorGeo.rotateX(-Math.PI / 2);
    const floorMesh = new THREE.Mesh(floorGeo, materials.concreteFissuredOcean);
    floorMesh.receiveShadow = true;
    floorMesh.position.y = -0.05;
    sceneGroup.add(floorMesh);

    addBox(18, 0.25, 460, 0, -0.1, -150, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'machine_foundry',
    });
    addBox(4.5, 0.28, 440, 0, -0.1, -150, materials.rustedSteel, {
      walkableTop: true,
      surface: 'metal',
      zone: 'machine_foundry',
      castShadow: false,
    });

    addBox(32, 4.5, 900, -48, 0, -220, materials.concreteDarkRib, { isWall: true });
    addBox(26, 4.8, 900, -48, 0, -220, materials.rustedSteel);

    const oreGeo = trackGeo(new THREE.BoxGeometry(18, 16, 22));
    for (let i = 0; i < 10; i++) {
      const block = new THREE.Mesh(oreGeo, materials.concreteColossal);
      block.position.set(-48, 12.8, 120 - i * 68);
      block.castShadow = true;
      sceneGroup.add(block);
      conveyorBlocks.push(block);
    }

    const armLocations: Array<{ x: number; z: number; phase: number }> = [
      { x: -48, z: -30, phase: 0.0 },
      { x: -48, z: -145, phase: 1.6 },
      { x: 52, z: -85, phase: 3.1 },
      { x: 52, z: -210, phase: 4.7 },
    ];
    armLocations.forEach((loc) => {
      addBox(28, 18, 28, loc.x, 0, loc.z, materials.concreteDarkRib, { isWall: true });
      const baseTurret = new THREE.Group();
      baseTurret.position.set(loc.x, 18, loc.z);

      const turretMesh = new THREE.Mesh(
        trackGeo(new THREE.CylinderGeometry(10, 12, 14, 8)),
        materials.rustedSteel
      );
      turretMesh.position.y = 7;
      baseTurret.add(turretMesh);

      const lowerBoom = new THREE.Group();
      lowerBoom.position.set(0, 12, 0);
      const boomMesh = new THREE.Mesh(
        trackGeo(new THREE.BoxGeometry(6.5, 68, 8.5)),
        materials.concreteColossal
      );
      boomMesh.position.y = 34;
      lowerBoom.add(boomMesh);

      const upperArm = new THREE.Group();
      upperArm.position.set(0, 66, 0);
      const upperMesh = new THREE.Mesh(
        trackGeo(new THREE.BoxGeometry(5.2, 56, 6.5)),
        materials.concreteDarkRib
      );
      upperMesh.position.y = 28;
      upperArm.add(upperMesh);

      const wristHead = new THREE.Group();
      wristHead.position.set(0, 54, 0);
      const clawMesh = new THREE.Mesh(
        trackGeo(new THREE.BoxGeometry(12, 14, 12)),
        materials.humanScaleAccent
      );
      wristHead.add(clawMesh);

      upperArm.add(wristHead);
      lowerBoom.add(upperArm);
      baseTurret.add(lowerBoom);
      sceneGroup.add(baseTurret);

      roboticArms.push({
        baseTurret,
        lowerBoom,
        upperArm,
        wristHead,
        phaseOffset: loc.phase,
        speed: 0.14,
      });
    });

    const reactorGeo = trackGeo(new THREE.CylinderGeometry(48, 68, 760, 16));
    const reactor1 = new THREE.Mesh(reactorGeo, materials.concreteColossal);
    reactor1.position.set(-135, 380, -340);
    const reactor2 = new THREE.Mesh(reactorGeo, materials.concreteColossal);
    reactor2.position.set(135, 380, -340);
    sceneGroup.add(reactor1, reactor2);

    addBox(160, 680, 120, 0, 0, -440, materials.concreteDarkRib);

    for (let z = 10; z >= -320; z -= 75) {
      addBox(260, 10, 10, 0, 115, z, materials.rustedSteel);
      const pipe = new THREE.Mesh(
        trackGeo(new THREE.CylinderGeometry(5.5, 5.5, 280, 10)),
        materials.concreteDarkRib
      );
      pipe.rotation.z = Math.PI / 2;
      pipe.position.set(0, 88, z - 25);
      sceneGroup.add(pipe);
    }

    [-95, 95].forEach((ex, idx) => {
      addBox(18, 520, 18, ex, 0, -175, materials.concreteDarkRib);
      const carriage = new THREE.Mesh(
        trackGeo(new THREE.BoxGeometry(24, 16, 24)),
        materials.rustedSteel
      );
      carriage.position.set(ex, 60, -175);
      sceneGroup.add(carriage);
      verticalElevators.push({
        mesh: carriage,
        minY: 16,
        maxY: 290,
        speed: 0.18,
        phase: idx * 2.5,
      });
    });

    addBox(16, 0.4, 30, 18, 0, -25, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
    });
    colliders.push({
      minX: 22,
      maxX: 34,
      minZ: -105,
      maxZ: -35,
      minY: -1,
      maxY: 20,
      isRamp: true,
      rampAxis: 'z',
      rampStartY: 18,
      rampEndY: 0,
      surface: 'metal',
      zone: 'machine_foundry',
    });
    const catwalkRamp = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(12, 1.2, 72)),
      materials.rustedSteel
    );
    catwalkRamp.position.set(28, 8.8, -70);
    catwalkRamp.rotation.x = Math.atan2(18, 70);
    sceneGroup.add(catwalkRamp);

    addBox(26, 2.0, 68, 26, 16, -138, materials.rustedSteel, {
      walkableTop: true,
      surface: 'metal',
      zone: 'elevated_bridge',
    });

    addParkedFuturisticVehicle(12, 0, 28, -0.4);
    addParkedFuturisticVehicle(-12, 0, -5, 0.15);
    addMonumentalAndHumanDoorPair(37.5, 0, -85, -Math.PI / 2);
    addHumanBench(16, 18, -135, -Math.PI / 2);

    aerialData = setupAerialTraffic(14, 12, 1, 65);

    resonancePoints.push(
      {
        id: 'maq_arms',
        position: [0, 0, -45],
        radius: 18,
        title: 'Corredor dos Braços Robóticos Ciclópicos',
        scaleNote: 'Manipuladores articulados de 140 m e esteira transportando blocos monolíticos de 18 m',
        lookTarget: [-48, 85, -90],
        fundamentalFreq: 34.65,
      },
      {
        id: 'maq_catwalk',
        position: [26, 18, -138],
        radius: 16,
        title: 'Passarela de Observação Técnica (+18 m)',
        scaleNote: 'Vista elevada das esteiras industriais e dos reatores térmicos de 760 m no horizonte',
        lookTarget: [-48, 65, -180],
        fundamentalFreq: 29.14,
      }
    );

    addArchitecturalPortal({
      id: 'portal_to_elevador',
      position: [0, 0, -285],
      radius: 10,
      targetRegion: 'elevador_planetario',
      passageType: 'Eclusa Axial das Máquinas',
      label: 'O Elevador Planetário',
    });
  } else if (regionId === 'elevador_planetario') {
    defaultZone = 'planetary_tether';
    worldBounds = { minX: -160, maxX: 160, minZ: -440, maxZ: 120 };

    const groundGeo = trackGeo(new THREE.PlaneGeometry(5200, 5200));
    groundGeo.rotateX(-Math.PI / 2);
    const ground = new THREE.Mesh(groundGeo, materials.concreteFissuredOcean);
    ground.receiveShadow = true;
    ground.position.y = -0.05;
    sceneGroup.add(ground);

    addBox(24, 0.3, 460, 0, -0.1, -120, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'planetary_tether',
    });
    addBox(240, 0.4, 240, 0, -0.15, -240, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'planetary_tether',
    });

    addBox(75, 82, 110, -88, 0, -35, materials.concreteDarkRib, { isWall: true });
    addBox(75, 82, 110, 88, 0, -35, materials.concreteDarkRib, { isWall: true });
    addMonumentalAndHumanDoorPair(-50.2, 0, -35, Math.PI / 2);
    addMonumentalAndHumanDoorPair(50.2, 0, -35, -Math.PI / 2);

    addParkedFuturisticVehicle(-32, 0, -15, 0.5);
    addParkedFuturisticVehicle(-35, 0, -48, 0.2);
    addParkedFuturisticVehicle(32, 0, -28, -0.35);

    addBox(110, 65, 110, 0, 0, -240, materials.concreteDarkRib, { isWall: true });
    addMonumentalAndHumanDoorPair(0, 0, -184.8, 0);

    const tetherCore = new THREE.Mesh(
      trackGeo(new THREE.CylinderGeometry(24, 28, 2200, 12)),
      materials.concreteColossal
    );
    tetherCore.position.set(0, 1100, -240);
    sceneGroup.add(tetherCore);

    const guideOffsets: [number, number][] = [
      [-42, -240],
      [42, -240],
      [0, -282],
      [0, -198],
    ];
    guideOffsets.forEach(([gx, gz]) => {
      addBox(14, 2200, 14, gx, 0, gz, materials.rustedSteel);
    });

    const climberGroup = new THREE.Group();
    climberGroup.position.set(0, 140, -240);
    const climberRing = new THREE.Mesh(
      trackGeo(new THREE.CylinderGeometry(64, 64, 38, 12)),
      materials.concreteColossal
    );
    climberGroup.add(climberRing);
    const climberLightBand = new THREE.Mesh(
      trackGeo(new THREE.CylinderGeometry(65, 65, 4.5, 12)),
      luminousPanelMat
    );
    climberGroup.add(climberLightBand);
    sceneGroup.add(climberGroup);

    verticalElevators.push({
      mesh: climberGroup,
      minY: 88,
      maxY: 680,
      speed: 0.08,
      phase: 0,
    });

    addBox(22, 0.4, 26, 36, 0, -115, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
    });
    colliders.push({
      minX: 46,
      maxX: 62,
      minZ: -255,
      maxZ: -115,
      minY: -1,
      maxY: 48,
      isRamp: true,
      rampAxis: 'z',
      rampStartY: 44,
      rampEndY: 0,
      surface: 'concrete',
      zone: 'colossal_staircase',
    });

    const tetherRamp = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(16, 2.2, 144)),
      materials.concreteDarkRib
    );
    tetherRamp.position.set(54, 21.5, -185);
    tetherRamp.rotation.x = Math.atan2(44, 140);
    sceneGroup.add(tetherRamp);

    addBox(44, 4.0, 40, 64, 40, -275, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'elevated_bridge',
    });
    addHumanBench(64, 44, -290, 0);

    const curvatureMesh = new THREE.Mesh(
      trackGeo(new THREE.PlaneGeometry(3400, 750)),
      horizonCurveMat
    );
    curvatureMesh.position.set(0, 260, -1750);
    sceneGroup.add(curvatureMesh);

    aerialData = setupAerialTraffic(22, 28, 1, 45);

    resonancePoints.push(
      {
        id: 'elev_base',
        position: [0, 0, -155],
        radius: 20,
        title: 'Ancoragem Basal do Elevador Planetário',
        scaleNote: 'Coluna orbital de 2.200 m subindo verticalmente além das nuvens · Portas humanas de 2,1 m na base',
        lookTarget: [0, 320, -240],
        fundamentalFreq: 30.87,
      },
      {
        id: 'elev_curvature',
        position: [64, 44, -275],
        radius: 18,
        title: 'Observatório da Curvatura do Horizonte (+44 m)',
        scaleNote: 'Vista panorâmica da gôndola ascendente e do arco atmosférico no limite do horizonte',
        lookTarget: [0, 240, -1200],
        fundamentalFreq: 27.5,
      }
    );

    addArchitecturalPortal({
      id: 'portal_to_megacidade',
      position: [0, 0, -345],
      radius: 10,
      targetRegion: 'megacidade_horizonte',
      passageType: 'Terminal de Trânsito Orbital',
      label: 'A Megacidade Horizonte',
    });
  } else if (regionId === 'megacidade_horizonte') {
    defaultZone = 'horizon_megacity';
    worldBounds = { minX: -145, maxX: 145, minZ: -420, maxZ: 105 };

    const cityFloor = trackGeo(new THREE.PlaneGeometry(5200, 5200));
    cityFloor.rotateX(-Math.PI / 2);
    const floorMesh = new THREE.Mesh(cityFloor, materials.concreteFissuredOcean);
    floorMesh.receiveShadow = true;
    floorMesh.position.y = -0.05;
    sceneGroup.add(floorMesh);

    addBox(28, 0.22, 540, 0, -0.18, -170, materials.reflectiveWater, {
      walkableTop: true,
      surface: 'water',
      zone: 'horizon_megacity',
      castShadow: false,
    });

    addBox(26, 0.35, 540, -27, -0.1, -170, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'horizon_megacity',
    });
    addBox(26, 0.35, 540, 27, -0.1, -170, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'horizon_megacity',
    });

    [45, -25, -115, -210, -310].forEach((bz) => {
      addBox(36, 0.55, 18, 0, -0.05, bz, materials.concreteWeatheredPath, {
        walkableTop: true,
        surface: 'concrete',
        zone: 'horizon_megacity',
      });
    });

    for (let z = 30; z >= -270; z -= 45) {
      addSolitaryTree(-18, 0.25, z, 1.05);
      addSolitaryTree(18, 0.25, z, 1.05);
      addHumanBench(-20, 0.25, z - 10, Math.PI / 2);
      addHumanBench(20, 0.25, z - 10, -Math.PI / 2);
    }

    const megatowers: Array<{ x: number; z: number; w: number; d: number; h: number }> = [
      { x: -72, z: 10, w: 48, d: 48, h: 620 },
      { x: 72, z: 10, w: 48, d: 48, h: 680 },
      { x: -78, z: -75, w: 54, d: 54, h: 840 },
      { x: 78, z: -75, w: 54, d: 54, h: 790 },
      { x: -82, z: -170, w: 58, d: 58, h: 980 },
      { x: 82, z: -170, w: 58, d: 58, h: 1040 },
      { x: -76, z: -270, w: 56, d: 56, h: 890 },
      { x: 76, z: -270, w: 56, d: 56, h: 920 },
      { x: 0, z: -430, w: 130, d: 85, h: 1180 },
      { x: -210, z: -120, w: 78, d: 78, h: 950 },
      { x: 210, z: -120, w: 78, d: 78, h: 1020 },
      { x: -240, z: -290, w: 88, d: 88, h: 1120 },
      { x: 240, z: -290, w: 88, d: 88, h: 1080 },
    ];

    megatowers.forEach((mt) => {
      const isNear = Math.abs(mt.x) < 120 && mt.z > -360;
      addBox(mt.w, mt.h, mt.d, mt.x, 0, mt.z, facadeMat, { isWall: isNear });

      if (isNear) {
        const signX = mt.x < 0 ? 1 : -1;
        const panel = new THREE.Mesh(
          trackGeo(new THREE.PlaneGeometry(14, 95)),
          luminousPanelMat
        );
        panel.position.set(mt.x + signX * (mt.w / 2 + 0.3), 110, mt.z);
        panel.rotation.y = signX > 0 ? Math.PI / 2 : -Math.PI / 2;
        sceneGroup.add(panel);

        addBox(6, 45, mt.d * 0.7, mt.x + signX * (mt.w / 2 + 2), 32, mt.z, materials.foliageDark);
        addMonumentalAndHumanDoorPair(
          mt.x + signX * (mt.w / 2 + 0.2),
          0,
          mt.z,
          signX > 0 ? Math.PI / 2 : -Math.PI / 2
        );
      }
    });

    const viaductSpecs = [
      { z: -55, y: 42, speed: 46 },
      { z: -145, y: 88, speed: -54 },
      { z: -245, y: 145, speed: 62 },
    ];
    viaductSpecs.forEach((vs) => {
      addBox(960, 4.5, 8.5, 0, vs.y, vs.z, materials.concreteDarkRib);
      const trainMesh = new THREE.Mesh(
        trackGeo(new THREE.BoxGeometry(92, 4.2, 5.2)),
        luminousPanelMat
      );
      trainMesh.position.set(-380, vs.y + 5.0, vs.z);
      sceneGroup.add(trainMesh);
      maglevTrains.push({
        mesh: trainMesh,
        startX: vs.speed > 0 ? -480 : 480,
        endX: vs.speed > 0 ? 480 : -480,
        speedX: vs.speed,
      });
    });

    [-25, -115, -210].forEach((gateZ) => {
      addBox(22, 16, 2.2, 0, 0, gateZ - 7, materials.concreteDarkRib);
      const leftWing = new THREE.Mesh(
        trackGeo(new THREE.BoxGeometry(7.5, 11.5, 1.2)),
        materials.rustedSteel
      );
      leftWing.position.set(-3.8, 5.75, gateZ - 7);
      const rightWing = new THREE.Mesh(
        trackGeo(new THREE.BoxGeometry(7.5, 11.5, 1.2)),
        materials.rustedSteel
      );
      rightWing.position.set(3.8, 5.75, gateZ - 7);
      sceneGroup.add(leftWing, rightWing);
      slidingDoors.push({
        leftWing,
        rightWing,
        centerX: 0,
        centerZ: gateZ - 7,
        baseOffsetX: 3.8,
        slideDistance: 6.2,
        triggerRadius: 24,
        currentOpenRatio: 0,
      });
    });

    [-70, -165].forEach((hz) => {
      const holoGroup = new THREE.Group();
      holoGroup.position.set(0, 14, hz);
      const sphere = new THREE.Mesh(
        trackGeo(new THREE.IcosahedronGeometry(6.5, 1)),
        hologramMat
      );
      const outerRing = new THREE.Mesh(
        trackGeo(new THREE.TorusGeometry(10.5, 0.22, 6, 32)),
        hologramMat
      );
      outerRing.rotation.x = Math.PI / 3;
      holoGroup.add(sphere, outerRing);
      sceneGroup.add(holoGroup);
      rotatingHolograms.push(holoGroup);
    });

    colliders.push({
      minX: 34,
      maxX: 46,
      minZ: -135,
      maxZ: -65,
      minY: -1,
      maxY: 17,
      isRamp: true,
      rampAxis: 'z',
      rampStartY: 15,
      rampEndY: 0,
      surface: 'concrete',
      zone: 'horizon_megacity',
    });
    const cityRamp = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(12, 1.2, 72)),
      materials.concreteDarkRib
    );
    cityRamp.position.set(40, 7.2, -100);
    cityRamp.rotation.x = Math.atan2(15, 70);
    sceneGroup.add(cityRamp);

    addBox(24, 2.5, 85, 40, 12.5, -175, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'elevated_bridge',
    });
    addSolitaryTree(44, 15, -160, 1.0);
    addSolitaryTree(44, 15, -190, 1.1);
    addHumanBench(34, 15, -175, -Math.PI / 2);

    aerialData = setupAerialTraffic(24, 42, 2, 32);

    resonancePoints.push(
      {
        id: 'mega_canal',
        position: [0, 0, -25],
        radius: 18,
        title: 'Esplanada Central e Canal Artificial',
        scaleNote: 'Megatorres de 1.180 m, metrôs magnéticos suspensos e portas automáticas monumentais',
        lookTarget: [0, 240, -245],
        fundamentalFreq: 38.89,
      },
      {
        id: 'mega_terrace',
        position: [40, 15, -175],
        radius: 16,
        title: 'Terraço do Jardim Vertical (+15 m)',
        scaleNote: 'Vista elevada do tráfego aéreo contínuo e dos painéis luminosos nas fachadas colossais',
        lookTarget: [-78, 220, -170],
        fundamentalFreq: 32.7,
      }
    );

    addArchitecturalPortal({
      id: 'portal_to_dyson',
      position: [0, 0, -310],
      radius: 10,
      targetRegion: 'colonia_dyson_anel',
      passageType: 'Terminal de Embarque Orbital',
      label: 'O Anel de Dyson e a Esfera Orbital',
    });
  }

  // ============================================================================
  // MAPA 14 — O ANEL DE DYSON E A ESFERA ORBITAL (colonia_dyson_anel)
  // Curvature: 3,400 meters arching upward into the stellar void
  // ============================================================================
  else if (regionId === 'colonia_dyson_anel') {
    defaultZone = 'dyson_ring';
    worldBounds = { minX: -190, maxX: 190, minZ: -460, maxZ: 110 };

    // Habitat floor with metallic expansion plates & dark solar bedrock
    const floorGeo = trackGeo(new THREE.PlaneGeometry(5400, 5400));
    floorGeo.rotateX(-Math.PI / 2);
    const floorMesh = new THREE.Mesh(floorGeo, materials.concreteDarkRib);
    floorMesh.receiveShadow = true;
    floorMesh.position.y = -0.05;
    sceneGroup.add(floorMesh);

    // Central Megaring Promenade (X = -18 to +18)
    addBox(36, 0.3, 520, 0, -0.1, -160, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'dyson_ring',
    });

    // Central High-Speed Maglev Rail along the Ring Axis
    addBox(6.0, 0.45, 500, 0, -0.05, -160, materials.rustedSteel, {
      walkableTop: true,
      surface: 'metal',
      zone: 'dyson_ring',
      castShadow: false,
    });

    // TITANIC DYSON ARCH: 3,400-METER CURVING MEGASTRUCTURE ARCHING TO ZENITH!
    // Trusses rise along Z = +40 to Z = -1600, reaching Y = +3,400m
    const archSegmentCount = 48;
    const archGeo = trackGeo(new THREE.BoxGeometry(32, 24, 75));
    const archInstLeft = new THREE.InstancedMesh(archGeo, materials.concreteColossal, archSegmentCount);
    const archInstRight = new THREE.InstancedMesh(archGeo, materials.concreteColossal, archSegmentCount);
    const plasmaConduitInst = new THREE.InstancedMesh(
      trackGeo(new THREE.CylinderGeometry(3.5, 3.5, 75, 8)),
      moltenPlasmaMat,
      archSegmentCount
    );

    archInstLeft.frustumCulled = false;
    archInstRight.frustumCulled = false;
    plasmaConduitInst.frustumCulled = false;

    for (let i = 0; i < archSegmentCount; i++) {
      const t = i / archSegmentCount;
      const az = 40 - i * 36;
      // Parabolic curvature upward into space
      const ay = Math.pow(t, 1.85) * 3400 + (i > 0 ? 12 : 0);
      const pitchAngle = Math.atan2(Math.pow(t, 0.85) * 3.2, 1.0);

      dummy.position.set(-68, ay, az);
      dummy.rotation.set(-pitchAngle, 0, 0);
      dummy.scale.set(1, 1, 1);
      dummy.updateMatrix();
      archInstLeft.setMatrixAt(i, dummy.matrix);

      dummy.position.set(68, ay, az);
      dummy.updateMatrix();
      archInstRight.setMatrixAt(i, dummy.matrix);

      dummy.position.set(0, ay + 6, az);
      dummy.rotation.set(-pitchAngle + Math.PI / 2, 0, 0);
      dummy.updateMatrix();
      plasmaConduitInst.setMatrixAt(i, dummy.matrix);

      // Transverse mega-braces every 3 segments
      if (i % 3 === 0) {
        addBox(140, 16, 18, 0, ay, az, materials.concreteDarkRib);
      }
    }
    archInstLeft.instanceMatrix.needsUpdate = true;
    archInstRight.instanceMatrix.needsUpdate = true;
    plasmaConduitInst.instanceMatrix.needsUpdate = true;
    sceneGroup.add(archInstLeft, archInstRight, plasmaConduitInst);

    // 6 ORBITAL SOLAR CONCENTRATOR MIRRORS (Floating in geostationary orbit)
    for (let m = 0; m < 6; m++) {
      const mirrorGroup = new THREE.Group();
      const my = 280 + m * 140;
      const mx = (m % 2 === 0 ? -1 : 1) * (180 + m * 35);
      const mz = -180 - m * 80;
      mirrorGroup.position.set(mx, my, mz);

      const frame = new THREE.Mesh(
        trackGeo(new THREE.BoxGeometry(90, 140, 4.5)),
        materials.rustedSteel
      );
      mirrorGroup.add(frame);

      const mirrorFace = new THREE.Mesh(
        trackGeo(new THREE.PlaneGeometry(84, 134)),
        materials.reflectiveWater
      );
      mirrorFace.position.z = 2.4;
      mirrorGroup.add(mirrorFace);

      const gimbalRing = new THREE.Mesh(
        trackGeo(new THREE.TorusGeometry(85, 3.2, 6, 24)),
        materials.concreteDarkRib
      );
      mirrorGroup.add(gimbalRing);

      sceneGroup.add(mirrorGroup);
      solarMirrors.push({
        mesh: mirrorGroup,
        rotSpeedY: 0.04 + m * 0.015,
      });
    }

    // Biotowers and Habitation Cylinders along flanks (Y = 0 to 480m)
    [-85, 85].forEach((bx) => {
      for (let z = 20; z >= -240; z -= 65) {
        addBox(38, 480, 38, bx, 0, z, facadeMat, { isWall: true });
        addMonumentalAndHumanDoorPair(bx > 0 ? bx - 19.2 : bx + 19.2, 0, z, bx > 0 ? -Math.PI / 2 : Math.PI / 2);
      }
    });

    // Walkable High-Altitude Observation Overlook (+22m)
    colliders.push({
      minX: 24,
      maxX: 40,
      minZ: -125,
      maxZ: -55,
      minY: -1,
      maxY: 24,
      isRamp: true,
      rampAxis: 'z',
      rampStartY: 22,
      rampEndY: 0,
      surface: 'concrete',
      zone: 'colossal_staircase',
    });
    const dysonRamp = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(14, 1.4, 72)),
      materials.concreteDarkRib
    );
    dysonRamp.position.set(32, 11, -90);
    dysonRamp.rotation.x = Math.atan2(22, 70);
    sceneGroup.add(dysonRamp);

    addBox(36, 3.0, 45, 32, 19, -150, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'elevated_bridge',
    });
    addHumanBench(32, 22, -155, 0);

    // Human-scale contrasts: benches & observation railings overlooking the cosmic drop
    for (let z = 10; z >= -180; z -= 30) {
      addHumanBench(-14, 0, z, Math.PI / 2);
      addHumanBench(14, 0, z, -Math.PI / 2);
    }

    aerialData = setupAerialTraffic(16, 24, 2, 45);

    resonancePoints.push(
      {
        id: 'dyson_nadir',
        position: [0, 0, -25],
        radius: 18,
        title: 'Nadir da Curvatura do Anel de Dyson',
        scaleNote: 'Espinha monumental de 3.400 m curvando-se para o zênite estelar com espelhos solares',
        lookTarget: [0, 680, -320],
        fundamentalFreq: 48.99,
      },
      {
        id: 'dyson_zenith_view',
        position: [32, 22, -150],
        radius: 16,
        title: 'Mirante dos Espelhos Solares (+22 m)',
        scaleNote: 'Visão dos concentradores solares orbitais de 140 m girando em alinhamento cósmico',
        lookTarget: [-180, 320, -180],
        fundamentalFreq: 41.2,
      }
    );

    addArchitecturalPortal({
      id: 'portal_to_aquapolis',
      position: [0, 0, -310],
      radius: 10,
      targetRegion: 'aquapolis_abissal',
      passageType: 'Eclusa de Descida Planetária',
      label: 'Aquapolis: A Megacidade Abissal',
    });
    addArchitecturalPortal({
      id: 'portal_back_to_megacidade',
      position: [0, 0, 75],
      radius: 10,
      targetRegion: 'megacidade_horizonte',
      passageType: 'Pórtico de Retorno Planetário',
      label: 'A Megacidade Horizonte',
    });
  }

  // ============================================================================
  // MAPA 15 — AQUAPOLIS: A MEGACIDADE ABISSAL (aquapolis_abissal)
  // Transparent Geodesic Pressure Dome: 1,450 meters tall holding back the ocean
  // ============================================================================
  else if (regionId === 'aquapolis_abissal') {
    defaultZone = 'abyssal_aquapolis';
    worldBounds = { minX: -160, maxX: 160, minZ: -420, maxZ: 110 };

    // Oceanic seabed floor with basalt slabs and hydrothermal channels
    const floorGeo = trackGeo(new THREE.PlaneGeometry(5200, 5200));
    floorGeo.rotateX(-Math.PI / 2);
    const floorMesh = new THREE.Mesh(floorGeo, materials.concreteFissuredOcean);
    floorMesh.receiveShadow = true;
    floorMesh.position.y = -0.05;
    sceneGroup.add(floorMesh);

    // Deep Oceanic Reflecting Pool / Submerged Canals (X = -22 to +22)
    addBox(44, 0.2, 540, 0, -0.16, -170, materials.reflectiveWater, {
      walkableTop: true,
      surface: 'water',
      zone: 'abyssal_aquapolis',
      castShadow: false,
    });

    // Walkable Titanium Esplanades flanking the canal
    addBox(24, 0.35, 540, -28, -0.1, -170, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'abyssal_aquapolis',
    });
    addBox(24, 0.35, 540, 28, -0.1, -170, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'abyssal_aquapolis',
    });

    // Monumental Bridges crossing the deep canals
    [30, -50, -140, -230, -320].forEach((bz) => {
      addBox(38, 0.5, 18, 0, -0.04, bz, materials.concreteWeatheredPath, {
        walkableTop: true,
        surface: 'concrete',
        zone: 'abyssal_aquapolis',
      });
    });

    // COLOSSAL 1,450-METER GEODESIC SUBSEA PRESSURE DOME!
    // Giant translucent hemisphere holding back millions of tons of ocean water
    const domeGeo = trackGeo(new THREE.SphereGeometry(1450, 32, 16, 0, Math.PI * 2, 0, Math.PI * 0.48));
    const domeMesh = new THREE.Mesh(domeGeo, translucentDomeMat);
    domeMesh.position.set(0, -20, -180);
    sceneGroup.add(domeMesh);

    // Structural Titanic Geodesic Ribs (12 monumental arches)
    for (let r = 0; r < 6; r++) {
      const archRing = new THREE.Mesh(
        trackGeo(new THREE.TorusGeometry(1450, 8.5, 8, 36, Math.PI)),
        materials.concreteDarkRib
      );
      archRing.position.set(0, -20, -180);
      archRing.rotation.y = (r * Math.PI) / 6;
      archRing.rotation.x = Math.PI / 2;
      sceneGroup.add(archRing);
    }

    // Spiraling Algae Hydroponic Biotowers & Titanium Citadels (280m to 720m)
    const subTowers = [
      { x: -75, z: 0, w: 42, h: 480, d: 42 },
      { x: 75, z: 0, w: 42, h: 520, d: 42 },
      { x: -85, z: -100, w: 52, h: 720, d: 52 },
      { x: 85, z: -100, w: 52, h: 680, d: 52 },
      { x: -78, z: -210, w: 48, h: 580, d: 48 },
      { x: 78, z: -210, w: 48, h: 610, d: 48 },
      { x: 0, z: -380, w: 90, h: 840, d: 65 },
    ];
    subTowers.forEach((st) => {
      addBox(st.w, st.h, st.d, st.x, 0, st.z, facadeMat, { isWall: true });
      addMonumentalAndHumanDoorPair(
        st.x < 0 ? st.x + st.w / 2 + 0.2 : st.x - st.w / 2 - 0.2,
        0,
        st.z,
        st.x < 0 ? Math.PI / 2 : -Math.PI / 2
      );
    });

    // 4 DEEP-SEA EXPLORATORY SUBMARINE CRUISERS outside the dome in the ocean abyss!
    for (let s = 0; s < 4; s++) {
      const subGroup = new THREE.Group();
      const subZ = -1100 + s * 380;
      const subX = (s % 2 === 0 ? -1 : 1) * (420 + s * 95);
      const subY = 240 + s * 160;
      subGroup.position.set(subX, subY, subZ);

      // Submarine hull (160m long)
      const hull = new THREE.Mesh(
        trackGeo(new THREE.CylinderGeometry(18, 22, 160, 12)),
        materials.concreteDarkRib
      );
      hull.rotation.x = Math.PI / 2;
      subGroup.add(hull);

      // Searchlight beams piercing through the dark water
      const lightCone = new THREE.Mesh(
        trackGeo(new THREE.ConeGeometry(45, 280, 16)),
        materials.lightShaftMaterial
      );
      lightCone.position.set(0, -20, 160);
      lightCone.rotation.x = -Math.PI / 2;
      subGroup.add(lightCone);

      sceneGroup.add(subGroup);
      deepSeaCruisers.push({
        group: subGroup,
        speedZ: 6.5 + s * 1.5,
        startZ: -1400,
        endZ: 850,
        baseY: subY,
        bobPhase: s * 1.4,
      });
    }

    // Geothermal Vent Chimneys with thermal glow
    [-45, 45].forEach((vx) => {
      const vent = new THREE.Mesh(
        trackGeo(new THREE.CylinderGeometry(4.5, 9.0, 36, 8)),
        materials.concreteDarkRib
      );
      vent.position.set(vx, 18, -140);
      sceneGroup.add(vent);

      const ventGlow = new THREE.Mesh(
        trackGeo(new THREE.CylinderGeometry(5.0, 5.0, 2.0, 8)),
        moltenPlasmaMat
      );
      ventGlow.position.set(vx, 36, -140);
      sceneGroup.add(ventGlow);
    });

    // High Tier Promenade (+16m)
    colliders.push({
      minX: 32,
      maxX: 46,
      minZ: -120,
      maxZ: -50,
      minY: -1,
      maxY: 18,
      isRamp: true,
      rampAxis: 'z',
      rampStartY: 16,
      rampEndY: 0,
      surface: 'concrete',
      zone: 'abyssal_aquapolis',
    });
    const seaRamp = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(12, 1.2, 72)),
      materials.concreteDarkRib
    );
    seaRamp.position.set(39, 8, -85);
    seaRamp.rotation.x = Math.atan2(16, 70);
    sceneGroup.add(seaRamp);

    addBox(28, 2.5, 75, 39, 13.5, -160, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'elevated_bridge',
    });
    addHumanBench(39, 16, -165, 0);

    // Airlock doors and human benches
    for (let z = 20; z >= -180; z -= 35) {
      addHumanBench(-20, 0, z, Math.PI / 2);
      addHumanBench(20, 0, z, -Math.PI / 2);
    }

    aerialData = setupAerialTraffic(18, 28, 1, 35);

    resonancePoints.push(
      {
        id: 'aqua_dome',
        position: [0, 0, -30],
        radius: 18,
        title: 'Cúpula Geodésica Abissal (1.450 m)',
        scaleNote: 'Casca translúcida suportando o oceano profundo com submarinos colossais visíveis no abismo',
        lookTarget: [0, 480, -180],
        fundamentalFreq: 27.5,
      },
      {
        id: 'aqua_promenade',
        position: [39, 16, -160],
        radius: 16,
        title: 'Esplanada Superior das Águas Termais (+16 m)',
        scaleNote: 'Vista das chaminés geotérmicas e dos canais de marés que alimentam a megacidade',
        lookTarget: [-75, 180, -100],
        fundamentalFreq: 32.7,
      }
    );

    addArchitecturalPortal({
      id: 'portal_to_antigravidade',
      position: [0, 0, -295],
      radius: 10,
      targetRegion: 'metropole_antigravidade',
      passageType: 'Elevador de Pressão Antigravitacional',
      label: 'A Metrópole dos Monólitos Flutuantes',
    });
    addArchitecturalPortal({
      id: 'portal_back_to_dyson',
      position: [0, 0, 85],
      radius: 10,
      targetRegion: 'colonia_dyson_anel',
      passageType: 'Pórtico de Ascensão Orbital',
      label: 'O Anel de Dyson e a Esfera Orbital',
    });
  }

  // ============================================================================
  // MAPA 16 — A METRÓPOLE DOS MONÓLITOS FLUTUANTES (metropole_antigravidade)
  // Suspended Archipelago: Floating City Islands with Quantum Levitation (1,600m)
  // ============================================================================
  else if (regionId === 'metropole_antigravidade') {
    defaultZone = 'antigravity_skyline';
    worldBounds = { minX: -180, maxX: 180, minZ: -440, maxZ: 105 };

    // Deep Cloud Bedrock far below (Y = -90m)
    const cloudFloorGeo = trackGeo(new THREE.PlaneGeometry(5400, 5400));
    cloudFloorGeo.rotateX(-Math.PI / 2);
    const cloudFloorMesh = new THREE.Mesh(cloudFloorGeo, materials.cloudLayerMaterial);
    cloudFloorMesh.position.y = -85;
    sceneGroup.add(cloudFloorMesh);

    // Main Spawn Anchor Platform (Floating at Y = 0)
    addBox(120, 16, 140, 0, -16, 25, materials.concreteFissuredOcean, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'antigravity_skyline',
    });

    // 6 FLOATING ISLAND MEGALITHS (Independently hovering with levitation rings!)
    const islandsSpec = [
      { id: 'island_1', x: 0, baseY: 24, z: -140, w: 95, d: 110, h: 22, amp: 2.2, speed: 0.35, phase: 0 },
      { id: 'island_2', x: -85, baseY: 95, z: -210, w: 110, d: 90, h: 28, amp: 3.5, speed: 0.28, phase: 1.2 },
      { id: 'island_3', x: 85, baseY: 120, z: -180, w: 125, d: 100, h: 32, amp: 4.0, speed: 0.22, phase: 2.5 },
      { id: 'island_4', x: 0, baseY: 220, z: -290, w: 140, d: 130, h: 36, amp: 4.8, speed: 0.18, phase: 3.8 },
      { id: 'island_5', x: -140, baseY: 420, z: -160, w: 160, d: 140, h: 42, amp: 6.0, speed: 0.14, phase: 4.5 },
      { id: 'island_6', x: 140, baseY: 780, z: -250, w: 180, d: 160, h: 48, amp: 7.5, speed: 0.11, phase: 5.2 },
    ];

    islandsSpec.forEach((isl) => {
      const islGroup = new THREE.Group();
      islGroup.position.set(isl.x, isl.baseY, isl.z);

      // Inverted monolithic bedrock pyramid base
      const slabMesh = new THREE.Mesh(
        trackGeo(new THREE.BoxGeometry(isl.w, isl.h, isl.d)),
        materials.concreteColossal
      );
      slabMesh.position.y = -isl.h / 2;
      islGroup.add(slabMesh);

      // Quantum Levitation Emitter Ring below the island
      const ringGeo = trackGeo(new THREE.TorusGeometry(isl.w * 0.45, 3.8, 8, 32));
      ringGeo.rotateX(Math.PI / 2);
      const levRing = new THREE.Mesh(ringGeo, quantumCyanMat);
      levRing.position.y = -isl.h - 8;
      islGroup.add(levRing);

      // Sky-Towers built on top of the floating island
      const towerCount = Math.floor(isl.w / 40);
      for (let t = 0; t < towerCount; t++) {
        const tx = (t - (towerCount - 1) / 2) * 36;
        const th = 180 + t * 90;
        const tower = new THREE.Mesh(
          trackGeo(new THREE.BoxGeometry(26, th, 26)),
          facadeMat
        );
        tower.position.set(tx, th / 2, 0);
        islGroup.add(tower);
      }

      sceneGroup.add(islGroup);
      floatingIslands.push({
        group: islGroup,
        baseY: isl.baseY,
        amp: isl.amp,
        speed: isl.speed,
        phase: isl.phase,
      });

      // Walkable collider on the nearest island (+24m)
      if (isl.id === 'island_1') {
        colliders.push({
          minX: isl.x - isl.w / 2,
          maxX: isl.x + isl.w / 2,
          minZ: isl.z - isl.d / 2,
          maxZ: isl.z + isl.d / 2,
          minY: isl.baseY - 1,
          maxY: isl.baseY + 1,
          surface: 'concrete',
          zone: 'antigravity_skyline',
        });
      }
    });

    // SUSPENDED TRANSPARENT SKYBRIDGE from Spawn Platform (Y = 0) to Island 1 (+24m)
    colliders.push({
      minX: -10,
      maxX: 10,
      minZ: -85,
      maxZ: -45,
      minY: -1,
      maxY: 26,
      isRamp: true,
      rampAxis: 'z',
      rampStartY: 24,
      rampEndY: 0,
      surface: 'metal',
      zone: 'elevated_bridge',
    });
    const skyBridge = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(16, 1.8, 62)),
      materials.rustedSteel
    );
    skyBridge.position.set(0, 11, -65);
    skyBridge.rotation.x = Math.atan2(24, 60);
    sceneGroup.add(skyBridge);

    // Steel Safety Railings along the skybridge over the abyss
    addBox(0.35, 1.18, 140, -14, 0, 25, materials.rustedSteel, { isWall: true });
    addBox(0.35, 1.18, 140, 14, 0, 25, materials.rustedSteel, { isWall: true });

    // High Observation Balcony at Y = +24m looking over the floating district
    addHumanBench(-8, 24, -140, Math.PI / 2);
    addHumanBench(8, 24, -140, -Math.PI / 2);

    aerialData = setupAerialTraffic(28, 36, 2, 40);

    resonancePoints.push(
      {
        id: 'antigrav_platform',
        position: [0, 0, 20],
        radius: 18,
        title: 'Ancoragem Basal do Arquipélago Suspenso',
        scaleNote: 'Monólitos urbanos de centenas de metros flutuando sem suportes mecânicos sobre o abismo',
        lookTarget: [0, 180, -180],
        fundamentalFreq: 43.65,
      },
      {
        id: 'antigrav_island1',
        position: [0, 24, -140],
        radius: 16,
        title: 'Primeiro Bloco Flutuante (+24 m)',
        scaleNote: 'Passarela de aço estendida no vazio ligando o solo às ilhas de levitação quântica',
        lookTarget: [-85, 95, -210],
        fundamentalFreq: 36.71,
      }
    );

    addArchitecturalPortal({
      id: 'portal_to_hiperboreia',
      position: [0, 24, -190],
      radius: 10,
      targetRegion: 'citadela_hiperboreia',
      passageType: 'Corredor Magnético Polar',
      label: 'A Citadela Hiperbórea e o Reator Quântico',
    });
    addArchitecturalPortal({
      id: 'portal_back_to_aquapolis',
      position: [0, 0, 80],
      radius: 10,
      targetRegion: 'aquapolis_abissal',
      passageType: 'Eclusa Submersa de Retorno',
      label: 'Aquapolis: A Megacidade Abissal',
    });
  }

  // ============================================================================
  // MAPA 17 — A CITADELA HIPERBÓREA E O REATOR QUÂNTICO (citadela_hiperboreia)
  // Quantum Singularity Containment Spire: 2,800 meters tall under Aurora Borealis
  // ============================================================================
  else if (regionId === 'citadela_hiperboreia') {
    defaultZone = 'hyperborean_quantum';
    worldBounds = { minX: -160, maxX: 160, minZ: -460, maxZ: 110 };

    // Glacial frozen lake and fissured ice-canyon floor
    const iceGeo = trackGeo(new THREE.PlaneGeometry(5400, 5400));
    iceGeo.rotateX(-Math.PI / 2);
    const iceMesh = new THREE.Mesh(iceGeo, materials.concreteFissuredOcean);
    iceMesh.receiveShadow = true;
    iceMesh.position.y = -0.05;
    sceneGroup.add(iceMesh);

    // Heated Central Titanium Boulevard (melting snow and ice along the axis)
    addBox(18, 0.25, 480, 0, -0.08, -140, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'hyperborean_quantum',
    });
    addBox(4.5, 0.28, 460, 0, -0.07, -140, materials.rustedSteel, {
      walkableTop: true,
      surface: 'metal',
      zone: 'hyperborean_quantum',
      castShadow: false,
    });

    // TITANIC 2,800-METER QUANTUM SINGULARITY CONTAINMENT SPIRE!
    // Centered at X = 0, Z = -260
    // Base Fortified Bastion (120m x 70m x 120m)
    addBox(120, 70, 120, 0, 0, -260, materials.concreteDarkRib, { isWall: true });
    addMonumentalAndHumanDoorPair(0, 0, -199.8, 0);
    addMonumentalAndHumanDoorPair(60.2, 0, -260, Math.PI / 2);
    addMonumentalAndHumanDoorPair(-60.2, 0, -260, -Math.PI / 2);

    // Main 2,800m Containment Needle
    const spireGeo = trackGeo(new THREE.CylinderGeometry(14, 28, 2800, 16));
    const spireMesh = new THREE.Mesh(spireGeo, materials.concreteColossal);
    spireMesh.position.set(0, 1400, -260);
    sceneGroup.add(spireMesh);

    // Dual Magnetic Containment Torus Rings at Y = 280m and Y = 620m
    const torus1 = new THREE.Mesh(
      trackGeo(new THREE.TorusGeometry(85, 6.5, 8, 36)),
      materials.concreteDarkRib
    );
    torus1.position.set(0, 280, -260);
    torus1.rotation.x = Math.PI / 2;
    sceneGroup.add(torus1);
    skyRings.push({ mesh: torus1, speedZ: 0.024, speedY: 0.008 });

    const torus2 = new THREE.Mesh(
      trackGeo(new THREE.TorusGeometry(130, 8.0, 8, 42)),
      materials.concreteColossal
    );
    torus2.position.set(0, 620, -260);
    torus2.rotation.x = Math.PI / 2;
    sceneGroup.add(torus2);
    skyRings.push({ mesh: torus2, speedZ: -0.018, speedY: 0.012 });

    // SYNCHROTRON PARTICLE ACCELERATOR RING (Diameter 240m) on East Flank
    const synchRing = new THREE.Mesh(
      trackGeo(new THREE.TorusGeometry(120, 5.5, 8, 48)),
      materials.concreteDarkRib
    );
    synchRing.position.set(95, 45, -150);
    synchRing.rotation.x = Math.PI / 2;
    sceneGroup.add(synchRing);

    // Glowing Particle Pulse Beam circling inside the accelerator
    const pulseBeam = new THREE.Mesh(
      trackGeo(new THREE.SphereGeometry(6.5, 12, 12)),
      quantumCyanMat
    );
    pulseBeam.position.set(95 + 120, 45, -150);
    sceneGroup.add(pulseBeam);
    synchrotronBeams.push({
      mesh: pulseBeam,
      centerZ: -150,
      radius: 120,
      speed: 2.8,
      currentAngle: 0,
    });

    // AURORA BOREALIS RIBBONS SHADER (Overhead at Y = 450m)
    for (let a = 0; a < 3; a++) {
      const auroraPlane = new THREE.Mesh(
        trackGeo(new THREE.PlaneGeometry(3600, 480)),
        auroraRibbonMat
      );
      auroraPlane.position.set(0, 420 + a * 65, -300 - a * 200);
      auroraPlane.rotation.x = -Math.PI / 4;
      sceneGroup.add(auroraPlane);
      auroraMeshRefs.push(auroraPlane);
    }

    // Thermal Exhaust Conduits melting snow around walkways
    [-32, 32].forEach((tx) => {
      for (let z = 10; z >= -180; z -= 45) {
        addBox(0.8, 4.5, 0.8, tx, 0, z, materials.rustedSteel);
      }
    });

    // Elevated Glacial Observation Bunker (+28m)
    colliders.push({
      minX: -48,
      maxX: -32,
      minZ: -140,
      maxZ: -60,
      minY: -1,
      maxY: 30,
      isRamp: true,
      rampAxis: 'z',
      rampStartY: 28,
      rampEndY: 0,
      surface: 'metal',
      zone: 'colossal_staircase',
    });
    const iceRamp = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(14, 1.5, 84)),
      materials.concreteDarkRib
    );
    iceRamp.position.set(-40, 14, -100);
    iceRamp.rotation.x = Math.atan2(28, 80);
    sceneGroup.add(iceRamp);

    addBox(32, 4.0, 40, -40, 24, -165, materials.concreteDarkRib, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'elevated_bridge',
    });
    addHumanBench(-40, 28, -170, 0);

    aerialData = setupAerialTraffic(16, 22, 1, 55);

    resonancePoints.push(
      {
        id: 'hiperborea_spire',
        position: [0, 0, -170],
        radius: 20,
        title: 'Torre de Contenção Quântica (2.800 m)',
        scaleNote: 'Agulha ciclópea contendo singularidade gravitacional sob os anéis magnéticos de 130 m',
        lookTarget: [0, 620, -260],
        fundamentalFreq: 32.7,
      },
      {
        id: 'hiperborea_aurora',
        position: [-40, 28, -165],
        radius: 18,
        title: 'Bunker Polar de Observação (+28 m)',
        scaleNote: 'Vista da aurora hiperbórea e do anel acelerador de partículas pulsando em velocidade relativística',
        lookTarget: [95, 45, -150],
        fundamentalFreq: 27.5,
      }
    );

    addArchitecturalPortal({
      id: 'portal_to_vale_cycle',
      position: [0, 0, -330],
      radius: 10,
      targetRegion: 'vale_pilares',
      passageType: 'Pórtico de Retorno Canônico',
      label: 'Vale dos Pilares Colossais',
    });
    addArchitecturalPortal({
      id: 'portal_back_to_antigrav',
      position: [0, 0, 80],
      radius: 10,
      targetRegion: 'metropole_antigravidade',
      passageType: 'Pórtico Quântico de Retorno',
      label: 'A Metrópole dos Monólitos Flutuantes',
    });
  } else if (regionId === 'blade_runner_2049') {
    defaultZone = 'blade_runner_monolith';
    worldBounds = { minX: -420, maxX: 420, minZ: -680, maxZ: 160 };

    // 1. Vast Asphalt & Wet Concrete Metropolitan Foundation
    addBox(1200, 14, 1400, 0, -14, -260, materials.concreteDarkRib, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'blade_runner_monolith',
    });

    // 2. Comprehensive Multi-Avenue Urban Road Network
    // Central Spine (Avenue of the Spinners, leading to Wallace Pyramid)
    addBox(36, 0.28, 720, 0, -0.04, -200, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'blade_runner_monolith',
    });
    // West Avenue (Commercial / Residential High-Rise Canyon)
    addBox(24, 0.28, 720, -175, -0.04, -200, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'blade_runner_monolith',
    });
    // East Avenue (Industrial / Las Vegas Transition Canyon)
    addBox(24, 0.28, 720, 175, -0.04, -200, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'blade_runner_monolith',
    });

    // Cross Boulevards (Transverse Boulevards connecting the districts)
    // South Boulevard
    addBox(760, 0.28, 26, 0, -0.03, 50, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'blade_runner_monolith',
    });
    // Central Monumental Crossroads Boulevard (Neon & Joi Billboard Row)
    addBox(760, 0.28, 34, 0, -0.03, -80, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'blade_runner_monolith',
    });
    // North Refinery Boulevard
    addBox(760, 0.28, 26, 0, -0.03, -210, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'blade_runner_monolith',
    });
    // Wallace Promenade Boulevard
    addBox(760, 0.28, 28, 0, -0.03, -330, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'blade_runner_monolith',
    });

    // Sidewalk Curbs along central intersections
    addBox(88, 0.44, 88, 0, 0, -80, materials.concreteDarkRib, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'blade_runner_monolith',
    });
    // Central Monolithic Traffic Obelisk / Spinner Beacon
    addBox(3.4, 32, 3.4, 0, 0.44, -80, materials.concreteDarkRib, { isWall: true });
    addBox(4.2, 1.4, 4.2, 0, 28, -80, moltenPlasmaMat, { isWall: true });

    // 3. ARTICULATED ARCHITECTURAL CITY BLOCKS WITH MULTI-TIER PEDESTRIAN CONCOURSE (+16m)
    // A true explorative metropolis: wide colonnaded podium plinths, accessible ramps,
    // stepped ziggurats, twin gateway towers with triple skybridges, and 3-tier setback skyscrapers.

    // 3.1 FOUR MONUMENTAL URBAN PODIUM PLINTHS WITH WALKABLE SKY-TERRACES (+16m)
    interface UrbanPodiumDef {
      id: string;
      cx: number;
      cz: number;
      w: number;
      d: number;
      rampFrom: [number, number, number]; // Street start
      rampTo: [number, number, number];   // Podium top
      rampAxis: 'x' | 'z';
    }

    const podiums: UrbanPodiumDef[] = [
      // Southwest Block Podium (Retail / Arcades)
      { id: 'podium_sw', cx: -155, cz: 45, w: 175, d: 155, rampFrom: [-70, 0, 45], rampTo: [-95, 16, 45], rampAxis: 'x' },
      // Southeast Block Podium (Cypherion Transit Promenade)
      { id: 'podium_se', cx: 155, cz: 45, w: 175, d: 155, rampFrom: [70, 0, 45], rampTo: [95, 16, 45], rampAxis: 'x' },
      // Northwest Block Podium (High-Rise Corporate Citadel)
      { id: 'podium_nw', cx: -155, cz: -205, w: 175, d: 175, rampFrom: [-70, 0, -205], rampTo: [-95, 16, -205], rampAxis: 'x' },
      // Northeast Block Podium (Megatech & Industrial Sector)
      { id: 'podium_ne', cx: 155, cz: -205, w: 175, d: 175, rampFrom: [70, 0, -205], rampTo: [95, 16, -205], rampAxis: 'x' },
    ];

    podiums.forEach((pod) => {
      // Solid core building plinth
      addBox(pod.w, 16, pod.d, pod.cx, 8, pod.cz, materials.concreteDarkRib, {
        isWall: true,
      });

      // Walkable Rooftop Promenade Deck (+16m)
      addBox(pod.w + 1.2, 0.4, pod.d + 1.2, pod.cx, 16, pod.cz, materials.concreteWeatheredPath, {
        walkableTop: true,
        surface: 'concrete',
        zone: 'sky_platform',
      });

      // Glowing Perimeter Protective Balustrade (+16m)
      addBox(pod.w, 1.2, 0.6, pod.cx, 16.6, pod.cz + pod.d / 2, linearLightStripMat, { isWall: true });
      addBox(pod.w, 1.2, 0.6, pod.cx, 16.6, pod.cz - pod.d / 2, linearLightStripMat, { isWall: true });
      addBox(0.6, 1.2, pod.d, pod.cx + pod.w / 2, 16.6, pod.cz, linearLightStripMat, { isWall: true });
      addBox(0.6, 1.2, pod.d, pod.cx - pod.w / 2, 16.6, pod.cz, linearLightStripMat, { isWall: true });

      // Ground-Level Colonnaded Pedestrian Arcades along the Avenue faces
      const colStep = 18;
      const frontZ = pod.cz + (pod.cz > 0 ? -pod.d / 2 : pod.d / 2);
      for (let px = pod.cx - pod.w / 2 + 12; px <= pod.cx + pod.w / 2 - 12; px += colStep) {
        // Colonnade Pillars
        addBox(2.2, 16, 2.2, px, 8, frontZ, materials.concreteColossal, { isWall: true });
        // Recessed storefront doors behind colonnade
        addHumanDoor(px, 0, frontZ + (pod.cz > 0 ? 6 : -6), pod.cz > 0 ? 0 : Math.PI);
      }

      // Monumental Pedestrian Access Ramp ascending from Street Level to +16m Promenade
      const rampLen = Math.hypot(pod.rampTo[0] - pod.rampFrom[0], pod.rampTo[2] - pod.rampFrom[2]);
      const rMidX = (pod.rampFrom[0] + pod.rampTo[0]) / 2;
      const rMidZ = (pod.rampFrom[2] + pod.rampTo[2]) / 2;
      const rYaw = Math.atan2(pod.rampTo[0] - pod.rampFrom[0], pod.rampTo[2] - pod.rampFrom[2]);

      colliders.push({
        minX: rMidX - 6,
        maxX: rMidX + 6,
        minZ: rMidZ - rampLen / 2 - 2,
        maxZ: rMidZ + rampLen / 2 + 2,
        minY: -1,
        maxY: 18,
        isRamp: true,
        rampAxis: pod.rampAxis,
        rampStartY: 0,
        rampEndY: 16,
        surface: 'concrete',
        zone: 'colossal_staircase',
      });

      const rampMesh = new THREE.Mesh(
        trackGeo(new THREE.BoxGeometry(10, 1.2, rampLen)),
        materials.concreteDarkRib
      );
      rampMesh.position.set(rMidX, 8, rMidZ);
      rampMesh.rotation.y = rYaw;
      rampMesh.rotation.x = Math.atan2(16, rampLen);
      sceneGroup.add(rampMesh);

      // Resting benches and viewpoints on the +16m terrace
      addHumanBench(pod.cx - 24, 16.2, pod.cz + 24, 0);
      addHumanBench(pod.cx + 24, 16.2, pod.cz - 24, Math.PI);
    });

    // 3.2 CONNECTING SKYWALKS AT PODIUM LEVEL (+16m) BRIDGING THE CANYONS
    // Seamlessly allowing player to walk continuously from Southwest to Southeast, and Northwest to Northeast!
    // South Transverse Skywalk bridging across Avenue at Z = 45
    addBox(56, 1.8, 12, 0, 16, 45, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'elevated_bridge',
    });
    addBox(56, 1.3, 0.6, 0, 17.2, 45 + 5.7, linearLightStripMat, { isWall: true });
    addBox(56, 1.3, 0.6, 0, 17.2, 45 - 5.7, linearLightStripMat, { isWall: true });

    // North Transverse Skywalk bridging across Avenue at Z = -205
    addBox(56, 1.8, 12, 0, 16, -205, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'elevated_bridge',
    });
    addBox(56, 1.3, 0.6, 0, 17.2, -205 + 5.7, linearLightStripMat, { isWall: true });
    addBox(56, 1.3, 0.6, 0, 17.2, -205 - 5.7, linearLightStripMat, { isWall: true });

    // Longitudinal Skywalks connecting South to North blocks at X = -155 and X = 155
    addBox(12, 1.8, 80, -155, 16, -80, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'elevated_bridge',
    });
    addBox(0.6, 1.3, 80, -155 + 5.7, 17.2, -80, linearLightStripMat, { isWall: true });
    addBox(0.6, 1.3, 80, -155 - 5.7, 17.2, -80, linearLightStripMat, { isWall: true });

    addBox(12, 1.8, 80, 155, 16, -80, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'elevated_bridge',
    });
    addBox(0.6, 1.3, 80, 155 + 5.7, 17.2, -80, linearLightStripMat, { isWall: true });
    addBox(0.6, 1.3, 80, 155 - 5.7, 17.2, -80, linearLightStripMat, { isWall: true });

    // Staircase linking +16m Podium Skywalk directly to +38m Spinner Viaduct at (X = 24, Z = -85)
    colliders.push({
      minX: 18,
      maxX: 30,
      minZ: -85,
      maxZ: -45,
      minY: 15,
      maxY: 40,
      isRamp: true,
      rampAxis: 'z',
      rampStartY: 38,
      rampEndY: 16,
      surface: 'concrete',
      zone: 'colossal_staircase',
    });
    const viaductPodiumStairs = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(8, 1.2, 42)),
      materials.concreteDarkRib
    );
    viaductPodiumStairs.position.set(24, 27, -65);
    viaductPodiumStairs.rotation.x = Math.atan2(22, 40);
    sceneGroup.add(viaductPodiumStairs);

    // 3.3 ARTICULATED MULTI-TIER SKYSCRAPERS & MEGAMONOLITHS
    // Each tower has 3 distinct architectural setback tiers + antenna pinnacle
    interface ArticulatedSkyscraper {
      x: number;
      z: number;
      baseW: number;
      baseD: number;
      midW: number;
      midD: number;
      crownW: number;
      crownD: number;
      h1: number; // Tier 1 top
      h2: number; // Tier 2 top
      hTotal: number; // Crown top
      spireH: number; // Spire needle height
      matTier1: THREE.Material;
      matTier2: THREE.Material;
    }

    const skyscrapers: ArticulatedSkyscraper[] = [
      // Northwest Citadel Cluster
      { x: -185, z: -235, baseW: 42, baseD: 42, midW: 34, midD: 34, crownW: 24, crownD: 24, h1: 180, h2: 380, hTotal: 720, spireH: 820, matTier1: facadeMat, matTier2: materials.concreteDarkRib },
      { x: -125, z: -235, baseW: 44, baseD: 40, midW: 36, midD: 32, crownW: 26, crownD: 24, h1: 160, h2: 420, hTotal: 840, spireH: 940, matTier1: glassCurtainMat, matTier2: facadeMat },
      { x: -185, z: -175, baseW: 40, baseD: 44, midW: 32, midD: 36, crownW: 22, crownD: 26, h1: 140, h2: 340, hTotal: 650, spireH: 740, matTier1: materials.concreteDarkRib, matTier2: facadeMat },
      { x: -125, z: -175, baseW: 46, baseD: 46, midW: 38, midD: 38, crownW: 28, crownD: 28, h1: 210, h2: 480, hTotal: 910, spireH: 1020, matTier1: facadeMat, matTier2: glassCurtainMat },

      // Northeast Megatech Cluster
      { x: 185, z: -235, baseW: 44, baseD: 44, midW: 36, midD: 36, crownW: 26, crownD: 26, h1: 190, h2: 410, hTotal: 780, spireH: 880, matTier1: facadeMat, matTier2: materials.concreteDarkRib },
      { x: 125, z: -235, baseW: 42, baseD: 38, midW: 34, midD: 30, crownW: 24, crownD: 22, h1: 150, h2: 360, hTotal: 690, spireH: 790, matTier1: glassCurtainMat, matTier2: facadeMat },
      { x: 185, z: -175, baseW: 46, baseD: 42, midW: 38, midD: 34, crownW: 28, crownD: 24, h1: 170, h2: 440, hTotal: 860, spireH: 960, matTier1: materials.concreteDarkRib, matTier2: glassCurtainMat },
      { x: 125, z: -175, baseW: 40, baseD: 40, midW: 32, midD: 32, crownW: 24, crownD: 24, h1: 200, h2: 460, hTotal: 890, spireH: 990, matTier1: facadeMat, matTier2: materials.concreteDarkRib },

      // Southwest Commercial / Residential Canyons
      { x: -185, z: 75, baseW: 42, baseD: 42, midW: 34, midD: 34, crownW: 24, crownD: 24, h1: 160, h2: 350, hTotal: 670, spireH: 760, matTier1: facadeMat, matTier2: facadeMat },
      { x: -125, z: 75, baseW: 44, baseD: 46, midW: 36, midD: 38, crownW: 26, crownD: 28, h1: 180, h2: 390, hTotal: 750, spireH: 850, matTier1: materials.concreteDarkRib, matTier2: glassCurtainMat },
      { x: -185, z: 15, baseW: 40, baseD: 38, midW: 32, midD: 30, crownW: 22, crownD: 22, h1: 140, h2: 310, hTotal: 590, spireH: 680, matTier1: glassCurtainMat, matTier2: facadeMat },
      { x: -125, z: 15, baseW: 46, baseD: 44, midW: 38, midD: 36, crownW: 28, crownD: 26, h1: 220, h2: 470, hTotal: 880, spireH: 980, matTier1: facadeMat, matTier2: materials.concreteDarkRib },

      // Southeast Industrial / Neon Horizon
      { x: 185, z: 75, baseW: 44, baseD: 44, midW: 36, midD: 36, crownW: 26, crownD: 26, h1: 170, h2: 370, hTotal: 710, spireH: 810, matTier1: materials.concreteDarkRib, matTier2: facadeMat },
      { x: 125, z: 75, baseW: 42, baseD: 40, midW: 34, midD: 32, crownW: 24, crownD: 24, h1: 190, h2: 430, hTotal: 820, spireH: 920, matTier1: facadeMat, matTier2: glassCurtainMat },
      { x: 185, z: 15, baseW: 40, baseD: 42, midW: 32, midD: 34, crownW: 22, crownD: 24, h1: 150, h2: 330, hTotal: 630, spireH: 720, matTier1: glassCurtainMat, matTier2: facadeMat },
      { x: 125, z: 15, baseW: 46, baseD: 46, midW: 38, midD: 38, crownW: 28, crownD: 28, h1: 210, h2: 450, hTotal: 850, spireH: 950, matTier1: facadeMat, matTier2: materials.concreteDarkRib },
    ];

    skyscrapers.forEach((s) => {
      // Tier 1: Lower Body (Y = 16 to h1)
      const t1H = s.h1 - 16;
      addBox(s.baseW, t1H, s.baseD, s.x, 16 + t1H / 2, s.z, s.matTier1, { isWall: true });

      // Cantilevered bay observation balcony at setback ledge (h1)
      addBox(s.baseW + 4, 1.4, s.baseD + 4, s.x, s.h1, s.z, materials.concreteDarkRib, {
        walkableTop: true,
        surface: 'concrete',
        zone: 'sky_platform',
      });
      addBox(s.baseW + 3.8, 1.2, 0.4, s.x, s.h1 + 0.6, s.z + s.baseD / 2 + 1.8, linearLightStripMat, { isWall: true });
      addBox(s.baseW + 3.8, 1.2, 0.4, s.x, s.h1 + 0.6, s.z - s.baseD / 2 - 1.8, linearLightStripMat, { isWall: true });

      // Tier 2: Mid Tower (Setback, Y = h1 to h2)
      const t2H = s.h2 - s.h1;
      addBox(s.midW, t2H, s.midD, s.x, s.h1 + t2H / 2, s.z, s.matTier2, { isWall: true });

      // Second setback ledge (h2)
      addBox(s.midW + 3, 1.4, s.midD + 3, s.x, s.h2, s.z, materials.concreteDarkRib, { isWall: true });

      // Tier 3: Upper Pinnacle (Y = h2 to hTotal)
      const t3H = s.hTotal - s.h2;
      addBox(s.crownW, t3H, s.crownD, s.x, s.h2 + t3H / 2, s.z, materials.concreteDarkRib, { isWall: true });

      // High-Altitude Communications Mast / Needle (reaching to spireH)
      const mastH = s.spireH - s.hTotal;
      const mastGeo = trackGeo(new THREE.CylinderGeometry(0.8, 2.4, mastH, 8));
      const mastMesh = new THREE.Mesh(mastGeo, materials.rustedSteel);
      mastMesh.position.set(s.x, s.hTotal + mastH / 2, s.z);
      sceneGroup.add(mastMesh);

      // Warning beacon light on apex
      const beaconLight = new THREE.Mesh(trackGeo(new THREE.SphereGeometry(1.8, 8, 8)), moltenPlasmaMat);
      beaconLight.position.set(s.x, s.spireH, s.z);
      sceneGroup.add(beaconLight);

      // Anti-Collision Rule for each skyscraper
      colliders.push({
        minX: s.x - s.baseW / 2,
        maxX: s.x + s.baseW / 2,
        minZ: s.z - s.baseD / 2,
        maxZ: s.z + s.baseD / 2,
        minY: 0,
        maxY: s.hTotal,
        isWall: true,
      });
    });

    // 3.4 SPECIAL ARCHITECTURAL MASTERPIECE: THE TYRELL STEPPED ZIGGURAT (5 RECEDING TIERS)
    // Located at (X = -275, Z = -80) - A colossal 480m brutalist terraced monument
    const zigX = -275;
    const zigZ = -80;
    const zigguratTiers = [
      { w: 96, d: 96, h: 48, yStart: 0 },
      { w: 78, d: 78, h: 64, yStart: 48 },
      { w: 60, d: 60, h: 84, yStart: 112 },
      { w: 44, d: 44, h: 110, yStart: 196 },
      { w: 28, d: 28, h: 174, yStart: 306 },
    ];

    zigguratTiers.forEach((zt, idx) => {
      addBox(zt.w, zt.h, zt.d, zigX, zt.yStart + zt.h / 2, zigZ, materials.concreteDarkRib, { isWall: true });

      // Walkable Perimeter Balconies on each ziggurat tier!
      if (idx < zigguratTiers.length - 1) {
        colliders.push({
          minX: zigX - zt.w / 2,
          maxX: zigX + zt.w / 2,
          minZ: zigZ - zt.d / 2,
          maxZ: zigZ + zt.d / 2,
          minY: zt.yStart + zt.h - 1,
          maxY: zt.yStart + zt.h + 1.2,
          walkableTop: true,
          surface: 'concrete',
          zone: 'sky_platform',
        });
        // Luminous perimeter rim
        addBox(zt.w + 0.8, 1.0, zt.d + 0.8, zigX, zt.yStart + zt.h, zigZ, linearLightStripMat, {
          isWall: false,
          noCollision: true,
        });
      }
    });

    colliders.push({
      minX: zigX - 48,
      maxX: zigX + 48,
      minZ: zigZ - 48,
      maxZ: zigZ + 48,
      minY: 0,
      maxY: 480,
      isWall: true,
    });

    // 3.5 SPECIAL ARCHITECTURAL MASTERPIECE: CANTILEVERED INVERTED WEDGE TOWER (EAST FLANK)
    // Located at (X = 275, Z = -80) - Cantilevered wings jutting over the district
    const ctlX = 275;
    const ctlZ = -80;
    addBox(48, 120, 48, ctlX, 60, ctlZ, materials.concreteDarkRib, { isWall: true });
    // Overhanging Cantilever Section extending 18m outward
    addBox(76, 140, 56, ctlX, 190, ctlZ, facadeMat, { isWall: true });
    // Diagonal mega-struts supporting the overhang
    addBox(4.5, 42, 4.5, ctlX - 26, 120, ctlZ + 18, materials.rustedSteel, { isWall: true, rotZ: 0.42 });
    addBox(4.5, 42, 4.5, ctlX + 26, 120, ctlZ + 18, materials.rustedSteel, { isWall: true, rotZ: -0.42 });
    addBox(4.5, 42, 4.5, ctlX - 26, 120, ctlZ - 18, materials.rustedSteel, { isWall: true, rotZ: 0.42 });
    addBox(4.5, 42, 4.5, ctlX + 26, 120, ctlZ - 18, materials.rustedSteel, { isWall: true, rotZ: -0.42 });
    // Upper Tower Core
    addBox(38, 320, 38, ctlX, 420, ctlZ, glassCurtainMat, { isWall: true });
    colliders.push({
      minX: ctlX - 38,
      maxX: ctlX + 38,
      minZ: ctlZ - 28,
      maxZ: ctlZ + 28,
      minY: 0,
      maxY: 580,
      isWall: true,
    });

    // 4. SUSPENDED SKYBRIDGES CONNECTING SKYSCRAPERS ACROSS STREET CANYONS
    // Skybridges crossing Central Avenue and West/East Canyons at multiple heights
    const skybridgeSpecs = [
      // Level 1 (+42m): Pedestrian tubes crossing the streets
      { x: 0, y: 42, z: -15, w: 42, h: 5.5, d: 9, mat: materials.concreteDarkRib },
      { x: 0, y: 42, z: -145, w: 42, h: 5.5, d: 9, mat: materials.concreteDarkRib },
      { x: -175, y: 38, z: -80, w: 9, h: 5.5, d: 38, mat: materials.concreteDarkRib },
      { x: 175, y: 38, z: -80, w: 9, h: 5.5, d: 38, mat: materials.concreteDarkRib },
      // Level 2 (+85m): Intermediate architectural walkways
      { x: 0, y: 85, z: 105, w: 44, h: 6.8, d: 11, mat: materials.concreteColossal },
      { x: 0, y: 85, z: -80, w: 46, h: 7.2, d: 12, mat: materials.concreteColossal },
      // Level 3 (+140m): High-altitude mega-trusses
      { x: -90, y: 140, z: -80, w: 12, h: 8.5, d: 48, mat: materials.concreteDarkRib },
      { x: 90, y: 140, z: -80, w: 12, h: 8.5, d: 48, mat: materials.concreteDarkRib },
      // Level 4 (+210m): Stratospheric skyway bridge
      { x: 0, y: 210, z: -200, w: 54, h: 9.5, d: 14, mat: materials.concreteDarkRib },
    ];

    skybridgeSpecs.forEach((sb) => {
      addBox(sb.w, sb.h, sb.d, sb.x, sb.y, sb.z, sb.mat, {
        walkableTop: true,
        surface: 'concrete',
        zone: 'elevated_bridge',
        isWall: true,
      });
      // Safety handrails / parapets on skybridges
      addBox(sb.w, 1.2, 0.75, sb.x, sb.y + sb.h, sb.z + sb.d / 2, materials.concreteDarkRib, { isWall: true });
      addBox(sb.w, 1.2, 0.75, sb.x, sb.y + sb.h, sb.z - sb.d / 2, materials.concreteDarkRib, { isWall: true });
    });

    // 5. GIGANTIC NEON HOLOGRAPHIC BILLBOARDS ("JOI", CYBER ADVERTS)
    // Multiple billboards pulsing at street corners and skyscraper facades
    const holoDefs = [
      // Joi Pink/Magenta Holograms
      { x: -68, y: 52, z: -80, w: 32, h: 78, rotY: Math.PI / 4, mat: hologramMagentaMat },
      { x: 68, y: 52, z: -80, w: 32, h: 78, rotY: -Math.PI / 4, mat: hologramMagentaMat },
      { x: -145, y: 64, z: -15, w: 28, h: 84, rotY: Math.PI / 2, mat: hologramMagentaMat },
      { x: 145, y: 64, z: -145, w: 28, h: 84, rotY: -Math.PI / 2, mat: hologramMagentaMat },
      // Cyber Cyan Holograms
      { x: 0, y: 68, z: -48, w: 42, h: 26, rotY: 0, mat: quantumCyanMat },
      { x: -68, y: 92, z: -210, w: 36, h: 64, rotY: Math.PI / 3, mat: quantumCyanMat },
      { x: 68, y: 92, z: -210, w: 36, h: 64, rotY: -Math.PI / 3, mat: quantumCyanMat },
      // Amber Corporate Holograms
      { x: -145, y: 48, z: -210, w: 26, h: 58, rotY: Math.PI / 2, mat: moltenPlasmaMat },
      { x: 145, y: 48, z: -15, w: 26, h: 58, rotY: -Math.PI / 2, mat: moltenPlasmaMat },
    ];

    holoDefs.forEach((hd) => {
      const hm = new THREE.Mesh(trackGeo(new THREE.PlaneGeometry(hd.w, hd.h)), hd.mat);
      hm.position.set(hd.x, hd.y, hd.z);
      hm.rotation.y = hd.rotY;
      sceneGroup.add(hm);
      rotatingHolograms.push(hm);
    });

    // 6. MULTI-LEVEL ELEVATED SPINNER VIADUCT (+38m)
    addBox(620, 2.8, 22, 0, 38, -135, materials.concreteColossal, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'elevated_bridge',
    });
    // Viaduct safety guardrails with collision
    addBox(620, 1.4, 0.9, 0, 39.5, -124, materials.concreteDarkRib, { isWall: true });
    addBox(620, 1.4, 0.9, 0, 39.5, -146, materials.concreteDarkRib, { isWall: true });
    // Supporting massive viaduct piers every 75m
    for (let px = -280; px <= 280; px += 75) {
      if (Math.abs(px) < 22) continue; // Clear central boulevard
      addBox(8.5, 38, 8.5, px, 0, -135, materials.concreteDarkRib, { isWall: true });
    }
    // Pedestrian access ramp to Viaduct
    colliders.push({
      minX: 18,
      maxX: 30,
      minZ: -135,
      maxZ: -35,
      minY: -1,
      maxY: 40,
      isRamp: true,
      rampAxis: 'z',
      rampStartY: 38,
      rampEndY: 0,
      surface: 'concrete',
      zone: 'colossal_staircase',
    });
    const viaductRamp = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(11, 1.4, 102)),
      materials.concreteDarkRib
    );
    viaductRamp.position.set(24, 19, -85);
    viaductRamp.rotation.x = Math.atan2(38, 100);
    sceneGroup.add(viaductRamp);

    // 6.1 INCEPTION SWEEPING CURVED HIGHWAY & ASCENDING FLYOVER (IMAGE 1)
    // Curving upwards in a dramatic sweeping arc from street level to 68m altitude
    const highwaySegments = 28;
    const curveP0 = new THREE.Vector3(38, 0.4, 85);
    const curveP1 = new THREE.Vector3(125, 32, -15);
    const curveP2 = new THREE.Vector3(-25, 68, -170);
    const hwCurve = new THREE.QuadraticBezierCurve3(curveP0, curveP1, curveP2);
    const hwPoints = hwCurve.getPoints(highwaySegments);

    for (let s = 0; s < highwaySegments; s++) {
      const pA = hwPoints[s];
      const pB = hwPoints[s + 1];
      const sDx = pB.x - pA.x;
      const sDy = pB.y - pA.y;
      const sDz = pB.z - pA.z;
      const sLen = Math.hypot(sDx, sDz);
      const sMidX = (pA.x + pB.x) / 2;
      const sMidY = (pA.y + pB.y) / 2;
      const sMidZ = (pA.z + pB.z) / 2;
      const sYaw = Math.atan2(sDx, sDz);
      const sPitch = -Math.atan2(sDy, sLen);

      // Curved road slab (18m wide)
      const slabGeo = trackGeo(new THREE.BoxGeometry(18, 2.2, sLen + 0.6));
      const slabMesh = new THREE.Mesh(slabGeo, materials.concreteColossal);
      slabMesh.position.set(sMidX, sMidY, sMidZ);
      slabMesh.rotation.y = sYaw;
      slabMesh.rotation.x = sPitch;
      slabMesh.castShadow = true;
      slabMesh.receiveShadow = true;
      sceneGroup.add(slabMesh);

      // Walkable collision
      const boxSpan = Math.max(18, sLen) / 2 + 1.2;
      colliders.push({
        minX: sMidX - boxSpan,
        maxX: sMidX + boxSpan,
        minZ: sMidZ - boxSpan,
        maxZ: sMidZ + boxSpan,
        minY: sMidY - 2.2,
        maxY: sMidY + 1.2,
        walkableTop: true,
        surface: 'concrete',
        zone: 'elevated_bridge',
      });

      // Outer & inner safety guardrails with solid collision
      const halfW = 9;
      const railNormX = Math.cos(sYaw);
      const railNormZ = -Math.sin(sYaw);
      const railGeo = trackGeo(new THREE.BoxGeometry(0.8, 1.4, sLen + 0.6));

      const rail1 = new THREE.Mesh(railGeo, materials.concreteDarkRib);
      rail1.position.set(sMidX + railNormX * halfW, sMidY + 1.6, sMidZ + railNormZ * halfW);
      rail1.rotation.y = sYaw;
      rail1.rotation.x = sPitch;
      sceneGroup.add(rail1);

      const rail2 = new THREE.Mesh(railGeo, materials.concreteDarkRib);
      rail2.position.set(sMidX - railNormX * halfW, sMidY + 1.6, sMidZ - railNormZ * halfW);
      rail2.rotation.y = sYaw;
      rail2.rotation.x = sPitch;
      sceneGroup.add(rail2);

      // Support piers under sweeping highway
      if (s % 4 === 0 && sMidY > 5.5) {
        addBox(5.5, sMidY, 5.5, sMidX, 0, sMidZ, materials.concreteDarkRib, { isWall: true });
      }
    }

    // 6.2 THE CYLINDRICAL BALCONY SKYSCRAPER (IMAGE 1)
    // Tower wrapped by circular cantilevered observation decks
    const cylX = 135;
    const cylZ = -15;
    const cylH = 460;
    const cylR = 27;

    const cylGeo = trackGeo(new THREE.CylinderGeometry(cylR, cylR, cylH, 32));
    const cylMesh = new THREE.Mesh(cylGeo, smoothArchitecturalConcreteMat);
    cylMesh.position.set(cylX, cylH / 2, cylZ);
    cylMesh.castShadow = true;
    cylMesh.receiveShadow = true;
    sceneGroup.add(cylMesh);

    // Solid collision for cylindrical tower
    colliders.push({
      minX: cylX - cylR,
      maxX: cylX + cylR,
      minZ: cylZ - cylR,
      maxZ: cylZ + cylR,
      minY: 0,
      maxY: cylH,
      isWall: true,
    });

    // 4 Cantilevered circular ring balcony rings (Image 1)
    [28, 68, 118, 178].forEach((bY) => {
      // Circular walkway slab
      const ringGeo = trackGeo(new THREE.CylinderGeometry(cylR + 7.5, cylR + 7.5, 1.8, 32));
      const ringMesh = new THREE.Mesh(ringGeo, materials.concreteDarkRib);
      ringMesh.position.set(cylX, bY, cylZ);
      ringMesh.receiveShadow = true;
      sceneGroup.add(ringMesh);

      // Outer protective balcony railing
      const railTorus = new THREE.Mesh(
        trackGeo(new THREE.TorusGeometry(cylR + 7.2, 0.45, 8, 32)),
        linearLightStripMat
      );
      railTorus.position.set(cylX, bY + 1.4, cylZ);
      railTorus.rotation.x = Math.PI / 2;
      sceneGroup.add(railTorus);

      // Walkable deck
      colliders.push({
        minX: cylX - cylR - 7.5,
        maxX: cylX + cylR + 7.5,
        minZ: cylZ - cylR - 7.5,
        maxZ: cylZ + cylR + 7.5,
        minY: bY - 1,
        maxY: bY + 1.2,
        walkableTop: true,
        surface: 'concrete',
        zone: 'sky_platform',
      });
    });

    // Connecting Catwalk from Inception Highway right into Cylindrical Balcony (+28m)
    addBox(16, 2.2, 10, cylX - 18, 28, cylZ, materials.concreteDarkRib, {
      walkableTop: true,
      surface: 'concrete',
    });

    // 6.3 CYPHERION CENTRAL RIDE HUB (IMAGE 4)
    // Monumental Transit Gateway spanning the Avenue
    const hubZ = -80;
    // Massive architectural bridge beam with illuminated billboard lettering
    const hubBeam = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(42, 6.5, 12)),
      billboardCypherionMat
    );
    hubBeam.position.set(0, 19, hubZ);
    hubBeam.castShadow = true;
    sceneGroup.add(hubBeam);

    // Street-Level Transit Shelter Canopy (Image 4)
    addBox(28, 0.6, 14, 0, 4.2, hubZ + 12, materials.rustedSteel, { castShadow: true });
    // Glass digital interactive kiosks and benches at the bus stop
    addBox(1.2, 2.4, 0.4, -6, 0, hubZ + 14, linearLightStripMat, { isWall: true });
    addBox(1.2, 2.4, 0.4, 6, 0, hubZ + 14, linearLightStripMat, { isWall: true });
    addHumanBench(-10, 0, hubZ + 12, 0);
    addHumanBench(10, 0, hubZ + 12, 0);

    // 6.4 HIGH-LEVEL PEDESTRIAN GLASS SKYBRIDGE (+48m) (IMAGE 4)
    // Enclosed glass bridge connecting Tower West and Tower East
    const skybridgeGlassMat = glassCurtainMat;
    const glassBridgeGeo = trackGeo(new THREE.BoxGeometry(72, 6.8, 9));
    const glassBridge = new THREE.Mesh(glassBridgeGeo, skybridgeGlassMat);
    glassBridge.position.set(0, 48, hubZ);
    glassBridge.castShadow = true;
    sceneGroup.add(glassBridge);
    // Walkable floor inside the skybridge
    addBox(70, 0.8, 7.5, 0, 45, hubZ, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'elevated_bridge',
    });
    // Glass bridge safety handrails
    addBox(70, 1.4, 0.4, 0, 46.2, hubZ + 3.8, materials.concreteDarkRib, { isWall: true });
    addBox(70, 1.4, 0.4, 0, 46.2, hubZ - 3.8, materials.concreteDarkRib, { isWall: true });

    // 6.5 HIGH-SPEED MAGLEV MONORAIL SKY-TRACK (+95m) (IMAGE 2 & 4)
    // Track beam
    addBox(380, 4.2, 5.5, 0, 95, hubZ, materials.concreteDarkRib, { castShadow: true });
    // Sleek bullet monorail train moving smoothly along the track
    const monorailTrainGeo = trackGeo(new THREE.BoxGeometry(52, 5.2, 4.8));
    const monorailTrainMesh = new THREE.Mesh(monorailTrainGeo, monorailBulletMat);
    monorailTrainMesh.position.set(-80, 98.5, hubZ);
    monorailTrainMesh.castShadow = true;
    // Glowing train windows strip
    const windowStrip = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(48, 1.2, 5.0)),
      linearLightStripMat
    );
    windowStrip.position.y = 0.4;
    monorailTrainMesh.add(windowStrip);
    sceneGroup.add(monorailTrainMesh);

    // Register into animated maglev train list so it glides smoothly in real-time
    maglevTrains.push({
      mesh: monorailTrainMesh,
      startX: -190,
      endX: 190,
      speedX: 38,
    });

    // 6.6 AETHER CORP & NEO-TECH FACETED TOWERS (IMAGE 4)
    // Left Tower: AETHER CORP with blue glass and billboard
    const aetherTower = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(54, 780, 54)),
      glassCurtainMat
    );
    aetherTower.position.set(-95, 390, hubZ);
    aetherTower.castShadow = true;
    aetherTower.receiveShadow = true;
    sceneGroup.add(aetherTower);
    colliders.push({
      minX: -95 - 27,
      maxX: -95 + 27,
      minZ: hubZ - 27,
      maxZ: hubZ + 27,
      minY: 0,
      maxY: 780,
      isWall: true,
    });
    // High-res Aether Corp Billboard on facade (Image 4)
    const aetherSign = new THREE.Mesh(
      trackGeo(new THREE.PlaneGeometry(36, 52)),
      billboardAetherMat
    );
    aetherSign.position.set(-67, 72, hubZ);
    aetherSign.rotation.y = Math.PI / 2;
    sceneGroup.add(aetherSign);

    // Right Tower: NEO-TECH SERVICES with billboard
    const neoTower = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(54, 840, 54)),
      glassCurtainMat
    );
    neoTower.position.set(95, 420, hubZ);
    neoTower.castShadow = true;
    neoTower.receiveShadow = true;
    sceneGroup.add(neoTower);
    colliders.push({
      minX: 95 - 27,
      maxX: 95 + 27,
      minZ: hubZ - 27,
      maxZ: hubZ + 27,
      minY: 0,
      maxY: 840,
      isWall: true,
    });
    // Neo-Tech Services Billboard (Image 4)
    const neoSign = new THREE.Mesh(
      trackGeo(new THREE.PlaneGeometry(36, 52)),
      billboardNeoTechMat
    );
    neoSign.position.set(67, 72, hubZ);
    neoSign.rotation.y = -Math.PI / 2;
    sceneGroup.add(neoSign);

    // 6.7 MODERN UNDERGROUND CURVED MAGLEV CONCOURSE (IMAGE 3)
    // Subterranean high-speed terminal station accessible via grand stairwell
    const stnY = -14;
    const stnZ = -45;

    // Grand staircase down from Central Ride Hub plaza (Y = 0 down to Y = -14)
    colliders.push({
      minX: -8,
      maxX: 8,
      minZ: -45,
      maxZ: -20,
      minY: stnY - 1,
      maxY: 2,
      isRamp: true,
      rampAxis: 'z',
      rampStartY: 0,
      rampEndY: stnY,
      surface: 'concrete',
      zone: 'colossal_staircase',
    });
    const subStairs = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(14, 1.4, 28)),
      materials.concreteDarkRib
    );
    subStairs.position.set(0, stnY / 2, -32.5);
    subStairs.rotation.x = Math.atan2(stnY, 25);
    sceneGroup.add(subStairs);

    // Underground Station Hall Floor (+ platform)
    addBox(52, 1.8, 180, 0, stnY - 1.8, -110, smoothArchitecturalConcreteMat, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'industrial_tunnel',
    });

    // Curved Futuristic Arched Concrete Tunnel Ceiling (Image 3)
    for (let rib = -190; rib <= -30; rib += 16) {
      // Flowing arch ribs
      const archRib = new THREE.Mesh(
        trackGeo(new THREE.TorusGeometry(19, 1.4, 12, 28, Math.PI)),
        smoothArchitecturalConcreteMat
      );
      archRib.position.set(0, stnY + 3, rib);
      archRib.rotation.z = Math.PI;
      sceneGroup.add(archRib);

      // Embedded Linear LED Light Strips along the ceiling arches (Image 3)
      const ledStripe = new THREE.Mesh(
        trackGeo(new THREE.TorusGeometry(18.2, 0.22, 6, 28, Math.PI)),
        linearLightStripMat
      );
      ledStripe.position.set(0, stnY + 3, rib);
      ledStripe.rotation.z = Math.PI;
      sceneGroup.add(ledStripe);
    }

    // Overhead illuminated Digital Destination Board ("17 CENTRAL STATION - APPROACHING")
    const stnSign = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(16, 2.8, 0.6)),
      billboardStationSignMat
    );
    stnSign.position.set(0, stnY + 8, -65);
    sceneGroup.add(stnSign);

    // Docked Sleek Aerodynamic Bullet Maglev Train (Image 3)
    const bulletTrainGeo = trackGeo(new THREE.BoxGeometry(12, 6.2, 120));
    const bulletTrain = new THREE.Mesh(bulletTrainGeo, monorailBulletMat);
    bulletTrain.position.set(16, stnY + 3.1, -110);
    bulletTrain.castShadow = true;
    sceneGroup.add(bulletTrain);
    // Aerodynamic cockpit nose cone
    const noseGeo = trackGeo(new THREE.ConeGeometry(6.0, 16, 24));
    const noseMesh = new THREE.Mesh(noseGeo, monorailBulletMat);
    noseMesh.position.set(16, stnY + 3.1, -42);
    noseMesh.rotation.x = Math.PI / 2;
    sceneGroup.add(noseMesh);
    // Front LED headlight bar
    const headlight = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(8, 0.45, 0.4)),
      linearLightStripMat
    );
    headlight.position.set(16, stnY + 1.8, -34);
    sceneGroup.add(headlight);

    // Solid collision for train & walls in the underground station
    colliders.push({
      minX: 10,
      maxX: 22,
      minZ: -170,
      maxZ: -34,
      minY: stnY,
      maxY: stnY + 8,
      isWall: true,
    });
    // Tunnel side walls
    colliders.push({
      minX: -27,
      maxX: -24,
      minZ: -200,
      maxZ: -20,
      minY: stnY,
      maxY: stnY + 18,
      isWall: true,
    });

    // 7. THE WALLACE CORPORATION PYRAMID HEADQUARTERS (1.850 m)
    // Dominating the northern horizon of the megacity
    const wallaceZ = -440;
    addBox(260, 95, 260, 0, 0, wallaceZ, materials.concreteDarkRib, { isWall: true });
    addBox(190, 250, 190, 0, 95, wallaceZ, facadeMat, { isWall: true });
    addBox(130, 540, 130, 0, 345, wallaceZ, materials.concreteDarkRib, { isWall: true });
    addBox(60, 965, 60, 0, 885, wallaceZ, facadeMat, { isWall: true });

    // Luminous Amber Bands on Wallace HQ
    addBox(264, 4.5, 264, 0, 92, wallaceZ, moltenPlasmaMat, { isWall: false, noCollision: true });
    addBox(194, 4.5, 194, 0, 342, wallaceZ, moltenPlasmaMat, { isWall: false, noCollision: true });
    addBox(134, 4.5, 134, 0, 882, wallaceZ, moltenPlasmaMat, { isWall: false, noCollision: true });

    // Wallace Grand Entrance Atrium & Reflective Water Basin
    addBox(76, 1.2, 110, 0, 0, -260, materials.reflectiveWater, { walkableTop: true });
    addBox(10.5, 1.45, 120, 0, 0, -260, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
    });
    addBox(14, 70, 14, -32, 0, -315, materials.concreteDarkRib, { isWall: true });
    addBox(14, 70, 14, 32, 0, -315, materials.concreteDarkRib, { isWall: true });
    addBox(84, 18, 18, 0, 70, -315, materials.concreteDarkRib, { isWall: true });
    addMonumentalAndHumanDoorPair(0, 1.45, -318, 0);

    // 8. LAS VEGAS 2049 RUINS & COLOSSAL GODDESS STATUE (Sector East)
    const statueBaseX = 185;
    const statueBaseZ = -185;
    addBox(32, 40, 28, statueBaseX, 0, statueBaseZ, materials.rustedSteel, {
      isWall: true,
      rotY: 0.35,
      rotZ: 0.18,
    });
    addBox(22, 14, 24, statueBaseX - 24, 0, statueBaseZ + 18, materials.concreteDarkRib, { isWall: true });
    addBox(18, 9, 18, statueBaseX + 26, 0, statueBaseZ - 22, materials.concreteDarkRib, { isWall: true });

    // Abandoned Casino Colonnade
    for (let c = 0; c < 6; c++) {
      const pz = -115 - c * 28;
      addBox(6.8, 54, 6.8, statueBaseX - 42, 0, pz, materials.concreteDarkRib, { isWall: true });
      addBox(6.8, 54, 6.8, statueBaseX + 42, 0, pz, materials.concreteDarkRib, { isWall: true });
      addBox(8.2, 2.6, 8.2, statueBaseX - 42, 52, pz, moltenPlasmaMat, { isWall: true });
      addBox(8.2, 2.6, 8.2, statueBaseX + 42, 52, pz, moltenPlasmaMat, { isWall: true });
    }
    addBox(14, 8.5, 172, statueBaseX - 42, 54, -185, materials.concreteDarkRib, { isWall: true });
    addBox(14, 8.5, 172, statueBaseX + 42, 54, -185, materials.concreteDarkRib, { isWall: true });

    // 9. SEPULVEDA SEA WALL (Sector West - 140m Tall Massive Sea Defense Barrier)
    const wallX = -245;
    addBox(36, 140, 640, wallX, 0, -220, materials.concreteFissuredOcean, { isWall: true });
    for (let b = -500; b <= 40; b += 65) {
      addBox(20, 95, 34, wallX + 26, 0, b, materials.concreteDarkRib, { isWall: true });
    }
    // Walkable observation walkway on top of seawall (+34m tier)
    colliders.push({
      minX: wallX - 10,
      maxX: wallX + 10,
      minZ: -520,
      maxZ: 40,
      minY: 33,
      maxY: 36,
      surface: 'concrete',
      zone: 'elevated_bridge',
    });
    // Access Ramp from ground to Sea Wall tier (+34m)
    colliders.push({
      minX: wallX + 18,
      maxX: wallX + 30,
      minZ: -160,
      maxZ: -60,
      minY: -1,
      maxY: 36,
      isRamp: true,
      rampAxis: 'z',
      rampStartY: 34,
      rampEndY: 0,
      surface: 'concrete',
      zone: 'colossal_staircase',
    });
    const seaWallRamp = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(12, 1.4, 102)),
      materials.concreteDarkRib
    );
    seaWallRamp.position.set(wallX + 24, 17, -110);
    seaWallRamp.rotation.x = Math.atan2(34, 100);
    sceneGroup.add(seaWallRamp);

    // Parked Spinners around crossroads
    addParkedFuturisticVehicle(-22, 0.44, -65, 0.45);
    addParkedFuturisticVehicle(26, 0.44, -62, -0.32);
    addParkedFuturisticVehicle(-22, 0.44, 45, 0.12);
    addParkedFuturisticVehicle(26, 0.44, -205, -0.65);

    // 10. SPINNER AIR TRAFFIC PATROL (32 SPINNERS FLYING IN MULTIPLE TIERS)
    aerialData = setupAerialTraffic(32, 42, 2, 75);

    // 11. RESONANCE POINTS
    resonancePoints.push(
      {
        id: 'wallace_hq_monolith',
        position: [0, 0, -265],
        radius: 26,
        title: 'Quartel-General da Wallace Corporation (1.850 m)',
        scaleNote: 'Pirâmide brutalista colossal dos criadores de Replicantes sob feixes dourados e espelho d\'água',
        lookTarget: [0, 480, wallaceZ],
        fundamentalFreq: 30.8,
      },
      {
        id: 'megacity_canyon_heart',
        position: [0, 0, -80],
        radius: 24,
        title: 'Cânion Urbano Central de Los Angeles 2049',
        scaleNote: 'Cruzamento monumental cercado por 96 arranha-céus, telões holográficos e viaduto de spinners a 38 m',
        lookTarget: [0, 220, -15],
        fundamentalFreq: 36.7,
      },
      {
        id: 'vegas_ruins_basin',
        position: [statueBaseX, 0, -175],
        radius: 20,
        title: 'Ruínas de Las Vegas 2049',
        scaleNote: 'A cabeça da deusa caída, colunatas de mármore e a névoa radioativa ocre de Roger Deakins',
        lookTarget: [statueBaseX, 36, -185],
        fundamentalFreq: 34.6,
      },
      {
        id: 'sepulveda_seawall_crest',
        position: [wallX + 24, 34, -200],
        radius: 22,
        title: 'Muro de Contenção Sepulveda (+34 m)',
        scaleNote: 'Dique colossal de 140 m retendo o oceano contra a megacidade distópica de Los Angeles',
        lookTarget: [-340, 45, -200],
        fundamentalFreq: 28.5,
      },
      {
        id: 'podium_promenade_view',
        position: [-155, 16, 45],
        radius: 22,
        title: 'Esplanada Superior dos Arranha-Céus (+16 m)',
        scaleNote: 'Terraço elevado com bancos, jardins cibernéticos e passarelas suspensas que cruzam as avenidas de Los Angeles 2049',
        lookTarget: [0, 16, 45],
        fundamentalFreq: 41.2,
      },
      {
        id: 'glass_skybridge_view',
        position: [0, 48, -80],
        radius: 20,
        title: 'Passarela de Vidro Suspensa (+48 m)',
        scaleNote: 'Vetor aéreo entre as Torres Aether e Neo-Tech, com vista vertiginosa do tráfego de spinners e dos telões holográficos',
        lookTarget: [0, 19, -80],
        fundamentalFreq: 44.0,
      }
    );

    // 12. PORTAIS ARQUITETÔNICOS
    addArchitecturalPortal({
      id: 'portal_blade_to_vale',
      position: [0, 0, 115],
      radius: 10,
      targetRegion: 'vale_pilares',
      passageType: 'Pórtico Retrô de Retorno Canônico',
      label: 'Vale dos Pilares Colossais',
    });
    addArchitecturalPortal({
      id: 'portal_blade_to_horizonte',
      position: [290, 0, -80],
      radius: 10,
      targetRegion: 'megacidade_horizonte',
      passageType: 'Pórtico da Megacidade Horizonte',
      label: 'Megacidade Horizonte (Tráfego Aéreo)',
    });
    addArchitecturalPortal({
      id: 'portal_blade_to_cidade_ceu',
      position: [-290, 0, -80],
      radius: 10,
      targetRegion: 'cidade_ceu',
      passageType: 'Elevador Orbital para a Cidade do Céu',
      label: 'A Cidade do Céu',
    });
  }

  const controller: FuturisticAnimationController = {
    update: (elapsed: number, dt: number, playerPos: THREE.Vector3) => {
      if (aerialData) {
        const { craftInst, beaconInst, vehicles } = aerialData;
        for (let i = 0; i < vehicles.length; i++) {
          const v = vehicles[i];
          v.x += v.vx * dt;
          v.z += v.vz * dt;
          if (v.x > v.boundsHalfSpan) v.x = -v.boundsHalfSpan;
          if (v.x < -v.boundsHalfSpan) v.x = v.boundsHalfSpan;
          if (v.z > v.boundsHalfSpan) v.z = -v.boundsHalfSpan;
          if (v.z < -v.boundsHalfSpan) v.z = v.boundsHalfSpan;
          const hoverBob = Math.sin(elapsed * 1.5 + i) * 0.35;
          dummy.position.set(v.x, v.y + hoverBob, v.z);
          dummy.rotation.set(0, v.yaw, 0);
          dummy.scale.set(v.scaleX, v.scaleY, v.scaleZ);
          dummy.updateMatrix();
          craftInst.setMatrixAt(i, dummy.matrix);
          dummy.position.set(v.x, v.y + hoverBob - 0.15, v.z);
          dummy.scale.set(v.scaleX * 0.9, v.scaleY * 0.5, v.scaleZ * 0.9);
          dummy.updateMatrix();
          beaconInst.setMatrixAt(i, dummy.matrix);
        }
        craftInst.instanceMatrix.needsUpdate = true;
        beaconInst.instanceMatrix.needsUpdate = true;
      }

      for (const cruiser of colossalCruisers) {
        cruiser.group.position.z += cruiser.speedZ * dt;
        if (cruiser.group.position.z > cruiser.endZ) {
          cruiser.group.position.z = cruiser.startZ;
        }
      }

      for (const sr of skyRings) {
        sr.mesh.rotation.z += sr.speedZ * dt;
        sr.mesh.rotation.y += sr.speedY * dt;
      }

      for (const arm of roboticArms) {
        const t = elapsed * arm.speed + arm.phaseOffset;
        arm.baseTurret.rotation.y = Math.sin(t * 0.65) * 0.55;
        arm.lowerBoom.rotation.z = 0.28 + Math.sin(t) * 0.24;
        arm.upperArm.rotation.z = -0.65 + Math.cos(t * 0.85) * 0.32;
        arm.wristHead.rotation.y = elapsed * 0.25;
      }

      for (const block of conveyorBlocks) {
        block.position.z -= 2.4 * dt;
        if (block.position.z < -490) {
          block.position.z = 190;
        }
      }

      for (const elev of verticalElevators) {
        const norm = 0.5 + 0.5 * Math.sin(elapsed * elev.speed + elev.phase);
        elev.mesh.position.y = elev.minY + norm * (elev.maxY - elev.minY);
      }

      for (const train of maglevTrains) {
        train.mesh.position.x += train.speedX * dt;
        if (train.speedX > 0 && train.mesh.position.x > train.endX) {
          train.mesh.position.x = train.startX;
        } else if (train.speedX < 0 && train.mesh.position.x < train.endX) {
          train.mesh.position.x = train.startX;
        }
      }

      for (const door of slidingDoors) {
        const dist = Math.hypot(playerPos.x - door.centerX, playerPos.z - door.centerZ);
        const targetOpen = dist < door.triggerRadius ? 1.0 : 0.0;
        door.currentOpenRatio = THREE.MathUtils.lerp(
          door.currentOpenRatio,
          targetOpen,
          1.0 - Math.exp(-3.5 * dt)
        );
        const offset = door.baseOffsetX + door.currentOpenRatio * door.slideDistance;
        door.leftWing.position.x = -offset;
        door.rightWing.position.x = offset;
      }

      for (const holo of rotatingHolograms) {
        holo.rotation.y = elapsed * 0.18;
        holo.rotation.z = Math.sin(elapsed * 0.3) * 0.08;
      }

      luminousPanelMat.opacity = 0.68 + Math.sin(elapsed * 0.9) * 0.12;
    },
    dispose: () => {
      disposeMaterials();
    },
  };

  return {
    worldBounds,
    defaultGroundSurface,
    defaultZone,
    controller,
  };
}
