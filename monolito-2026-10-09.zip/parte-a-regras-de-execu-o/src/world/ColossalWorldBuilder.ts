import * as THREE from 'three';
import {
  AcousticZone,
  ArchitecturalPortal,
  RegionId,
  ResonancePoint,
  SurfaceMaterialType,
  WalkableBox,
} from '../types/world';
import { WorldMaterialLibrary } from './ProceduralTextures';
import {
  FuturisticAnimationController,
  populateFuturisticRegion,
} from './FuturisticExpansionBuilder';

export interface AnimatedWorldHandles {
  pendulumGroup: THREE.Group | null;
  upperRingMesh: THREE.Mesh | null;
  lowerRingMesh: THREE.Mesh | null;
  birdFlockInstanced: THREE.InstancedMesh | null;
  futuristicController?: FuturisticAnimationController | null;
  cloudGroup: THREE.Group;
  lowMistGroup: THREE.Group;
  rainLines: THREE.LineSegments;
  rainMaterial: THREE.LineBasicMaterial;
  grassShaderUniforms: { uTime: { value: number }; uWindStrength: { value: number } };
  skyMaterial: THREE.ShaderMaterial;
}

export interface BuiltWorld {
  regionId: RegionId;
  sceneGroup: THREE.Group;
  colliders: WalkableBox[];
  resonancePoints: ResonancePoint[];
  portals: ArchitecturalPortal[];
  handles: AnimatedWorldHandles;
  dispose: () => void;
  resolvePlayerPhysics: (
    prevPos: THREE.Vector3,
    desiredPos: THREE.Vector3,
    playerRadius: number
  ) => {
    position: THREE.Vector3;
    groundY: number;
    surface: SurfaceMaterialType;
    zone: AcousticZone;
  };
}

export function buildRegionWorld(
  regionId: RegionId,
  materials: WorldMaterialLibrary
): BuiltWorld {
  const sceneGroup = new THREE.Group();
  const colliders: WalkableBox[] = [];
  const resonancePoints: ResonancePoint[] = [];
  const portals: ArchitecturalPortal[] = [];
  const geometriesToDispose: THREE.BufferGeometry[] = [];

  const trackGeo = <T extends THREE.BufferGeometry>(geo: T): T => {
    geometriesToDispose.push(geo);
    return geo;
  };

  // 1. Atmospheric Sky Dome Shader
  const skyGeo = trackGeo(new THREE.SphereGeometry(3600, 32, 24));
  const skyMaterial = new THREE.ShaderMaterial({
    uniforms: {
      uTopColor: { value: new THREE.Color('#73828c') },
      uHorizonColor: { value: new THREE.Color('#b8c2c7') },
      uSunDir: { value: new THREE.Vector3(-0.45, 0.38, -0.8) },
      uSunColor: { value: new THREE.Color('#fff6e8') },
    },
    vertexShader: `
      varying vec3 vWorldPosition;
      void main() {
        vec4 worldPosition = modelMatrix * vec4(position, 1.0);
        vWorldPosition = worldPosition.xyz;
        gl_Position = projectionMatrix * viewMatrix * worldPosition;
      }
    `,
    fragmentShader: `
      uniform vec3 uTopColor;
      uniform vec3 uHorizonColor;
      uniform vec3 uSunDir;
      uniform vec3 uSunColor;
      varying vec3 vWorldPosition;
      void main() {
        vec3 dir = normalize(vWorldPosition);
        float h = clamp(dir.y, 0.0, 1.0);
        vec3 sky = mix(uHorizonColor, uTopColor, pow(h, 0.52));
        float sunAmt = max(dot(dir, normalize(uSunDir)), 0.0);
        sky += uSunColor * pow(sunAmt, 18.0) * 0.28;
        sky += uSunColor * smoothstep(0.996, 0.9995, sunAmt) * 0.65;
        gl_FragColor = vec4(sky, 1.0);
      }
    `,
    side: THREE.BackSide,
    depthWrite: false,
  });
  sceneGroup.add(new THREE.Mesh(skyGeo, skyMaterial));

  // Helper to add structural boxes with optional collision
  const addBox = (
    w: number,
    h: number,
    d: number,
    x: number,
    yBottom: number,
    z: number,
    mat: THREE.Material,
    options?: {
      isWall?: boolean;
      walkableTop?: boolean;
      surface?: SurfaceMaterialType;
      zone?: AcousticZone;
      castShadow?: boolean;
      receiveShadow?: boolean;
      rotY?: number;
      rotZ?: number;
      noCollision?: boolean;
    }
  ): THREE.Mesh => {
    const geo = trackGeo(new THREE.BoxGeometry(w, h, d));
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(x, yBottom + h / 2, z);
    if (options?.rotY) mesh.rotation.y = options.rotY;
    if (options?.rotZ) mesh.rotation.z = options.rotZ;
    if (options?.castShadow !== false) mesh.castShadow = true;
    if (options?.receiveShadow !== false) mesh.receiveShadow = true;
    sceneGroup.add(mesh);

    // REGRA UNIVERSAL DE ANTI-COLISÃO (NO CLIPPING):
    // Toda estrutura física criada no alcance do jogador possui colisão sólida obrigatória.
    const isFloorTile = Boolean(options?.walkableTop && h <= 0.6 && yBottom <= 0.2);
    const isHighCeiling = yBottom >= 4.5;
    const shouldHaveWallCollision =
      options?.noCollision !== true &&
      (options?.isWall === true ||
        (options?.isWall !== false && !isHighCeiling && !isFloorTile));

    if (shouldHaveWallCollision) {
      colliders.push({
        minX: x - w / 2,
        maxX: x + w / 2,
        minZ: z - d / 2,
        maxZ: z + d / 2,
        minY: yBottom,
        maxY: yBottom + h,
        isWall: true,
      });
    }

    if (options?.walkableTop) {
      colliders.push({
        minX: x - w / 2,
        maxX: x + w / 2,
        minZ: z - d / 2,
        maxZ: z + d / 2,
        minY: yBottom,
        maxY: yBottom + h,
        surface: options.surface ?? 'concrete',
        zone: options.zone,
      });
    }

    return mesh;
  };

  // Helper to add Human-Scale Reference Door (2.1m high x 1.1m wide)
  const addHumanDoor = (x: number, yBottom: number, z: number, rotY = 0) => {
    const group = new THREE.Group();
    group.position.set(x, yBottom, z);
    group.rotation.y = rotY;

    const frame = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(1.3, 2.25, 0.28)),
      materials.concreteDarkRib
    );
    frame.position.y = 1.125;
    group.add(frame);

    const door = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(1.0, 2.05, 0.34)),
      materials.humanScaleAccent
    );
    door.position.y = 1.025;
    group.add(door);

    const canopy = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(1.6, 0.14, 0.9)),
      materials.concreteDarkRib
    );
    canopy.position.set(0, 2.32, 0.3);
    group.add(canopy);

    sceneGroup.add(group);
  };

  // Helper to add Human-Scale Concrete Bench (0.45m high x 1.8m wide)
  const addHumanBench = (x: number, yBottom: number, z: number, rotY = 0) => {
    const bench = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(1.8, 0.45, 0.55)),
      materials.concreteDarkRib
    );
    bench.position.set(x, yBottom + 0.225, z);
    bench.rotation.y = rotY;
    bench.castShadow = true;
    sceneGroup.add(bench);
  };

  // Helper to add a Solitary Wind-Bent Tree (4.8m tall - human scale nature contrast)
  const addSolitaryTree = (x: number, yBottom: number, z: number, scale = 1.0) => {
    const tree = new THREE.Group();
    tree.position.set(x, yBottom, z);
    tree.scale.setScalar(scale);

    const trunk = new THREE.Mesh(
      trackGeo(new THREE.CylinderGeometry(0.12, 0.22, 2.2, 6)),
      materials.rustedSteel
    );
    trunk.position.y = 1.1;
    trunk.castShadow = true;
    tree.add(trunk);

    const crown1 = new THREE.Mesh(
      trackGeo(new THREE.ConeGeometry(1.35, 3.2, 7)),
      materials.foliageDark
    );
    crown1.position.set(0.15, 3.1, 0);
    crown1.rotation.z = -0.06;
    crown1.castShadow = true;
    tree.add(crown1);

    const crown2 = new THREE.Mesh(
      trackGeo(new THREE.ConeGeometry(0.95, 2.4, 7)),
      materials.foliageDark
    );
    crown2.position.set(0.28, 4.4, 0);
    crown2.rotation.z = -0.09;
    crown2.castShadow = true;
    tree.add(crown2);

    sceneGroup.add(tree);
  };

  // Helper to add an Architectural Portal (Seamless Region Transition Monument)
  const addArchitecturalPortal = (portal: ArchitecturalPortal) => {
    portals.push(portal);
    const [px, py, pz] = portal.position;
    const pGroup = new THREE.Group();
    pGroup.position.set(px, py, pz);

    const leftPillar = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(1.4, 9.5, 2.4)),
      materials.concreteDarkRib
    );
    leftPillar.position.set(-2.1, 4.75, 0);
    leftPillar.castShadow = true;
    pGroup.add(leftPillar);

    const rightPillar = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(1.4, 9.5, 2.4)),
      materials.concreteDarkRib
    );
    rightPillar.position.set(2.1, 4.75, 0);
    rightPillar.castShadow = true;
    pGroup.add(rightPillar);

    const lintel = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(6.2, 2.2, 2.8)),
      materials.concreteColossal
    );
    lintel.position.set(0, 10.2, 0);
    lintel.castShadow = true;
    pGroup.add(lintel);

    const veil = new THREE.Mesh(
      trackGeo(new THREE.PlaneGeometry(2.8, 9.2)),
      materials.portalGlowMaterial
    );
    veil.position.set(0, 4.6, 0);
    pGroup.add(veil);

    const beacon = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(2.4, 0.18, 0.25)),
      materials.distantBeaconLight
    );
    beacon.position.set(0, 8.9, 1.25);
    pGroup.add(beacon);

    sceneGroup.add(pGroup);
  };

  const dummy = new THREE.Object3D();
  let pendulumGroup: THREE.Group | null = null;
  let upperRingMesh: THREE.Mesh | null = null;
  let lowerRingMesh: THREE.Mesh | null = null;
  let birdFlockInstanced: THREE.InstancedMesh | null = null;
  let futuristicController: FuturisticAnimationController | null = null;

  // Grass wind shader uniforms
  const grassShaderUniforms = {
    uTime: { value: 0 },
    uWindStrength: { value: 1.0 },
  };

  const buildInstancedMeadowGrass = (count: number, spreadX: number, minZ: number, maxZ: number, clearCenterHalfWidth = 5.0) => {
    const grassBladeGeo = trackGeo(new THREE.ConeGeometry(0.18, 0.85, 3));
    grassBladeGeo.translate(0, 0.42, 0);
    const grassMat = new THREE.MeshLambertMaterial({
      color: new THREE.Color('#586952'),
    });
    grassMat.onBeforeCompile = (shader) => {
      shader.uniforms.uTime = grassShaderUniforms.uTime;
      shader.uniforms.uWindStrength = grassShaderUniforms.uWindStrength;
      shader.vertexShader = `
        uniform float uTime;
        uniform float uWindStrength;
        ${shader.vertexShader}
      `.replace(
        '#include <begin_vertex>',
        `
        #include <begin_vertex>
        vec4 instWorld = instanceMatrix * vec4(0.0, 0.0, 0.0, 1.0);
        float sway = sin(uTime * 1.7 + instWorld.x * 0.18 + instWorld.z * 0.14) * 0.18 * uWindStrength * position.y;
        transformed.x += sway;
        `
      );
    };

    const grassInstanced = new THREE.InstancedMesh(grassBladeGeo, grassMat, count);
    grassInstanced.frustumCulled = false;
    let gIdx = 0;
    for (let i = 0; i < count; i++) {
      const gx = (Math.random() - 0.5) * spreadX;
      const gz = minZ + Math.random() * (maxZ - minZ);
      if (Math.abs(gx) < clearCenterHalfWidth) continue;

      dummy.position.set(gx, 0, gz);
      dummy.rotation.y = Math.random() * Math.PI;
      const sc = 0.65 + Math.random() * 0.95;
      dummy.scale.set(sc, sc, sc);
      dummy.updateMatrix();
      grassInstanced.setMatrixAt(gIdx++, dummy.matrix);
    }
    grassInstanced.count = gIdx;
    grassInstanced.instanceMatrix.needsUpdate = true;
    sceneGroup.add(grassInstanced);
  };

  let worldBounds = { minX: -240, maxX: 240, minZ: -480, maxZ: 90 };
  let defaultGroundSurface: SurfaceMaterialType = 'grass';
  let defaultZone: AcousticZone = 'open_meadow';

  if (regionId === 'vale_pilares') {
    const groundGeo = trackGeo(new THREE.PlaneGeometry(4400, 4400));
    groundGeo.rotateX(-Math.PI / 2);
    const ground = new THREE.Mesh(groundGeo, materials.meadowGround);
    ground.receiveShadow = true;
    ground.position.y = -0.05;
    sceneGroup.add(ground);

    addBox(9.0, 0.15, 360, 0, -0.08, -120, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'open_meadow',
      castShadow: false,
    });

    const pillarCols = 6;
    const pillarRows = 24;
    const totalPillars = pillarCols * pillarRows;
    const pillarGeo = trackGeo(new THREE.BoxGeometry(28, 520, 28));
    const pillarInst = new THREE.InstancedMesh(pillarGeo, materials.concreteColossal, totalPillars);
    pillarInst.castShadow = true;
    pillarInst.receiveShadow = true;
    pillarInst.frustumCulled = false;

    let pIdx = 0;
    for (let r = 0; r < pillarRows; r++) {
      const pz = 20 - r * 52;
      for (let c = 0; c < pillarCols; c++) {
        const offsetIndex = c - (pillarCols - 1) / 2;
        const px = offsetIndex * 64;
        dummy.position.set(px, 260, pz);
        dummy.rotation.set(0, 0, 0);
        dummy.scale.set(1, 1, 1);
        dummy.updateMatrix();
        pillarInst.setMatrixAt(pIdx++, dummy.matrix);

        if (Math.abs(px) < 150 && pz > -360) {
          colliders.push({
            minX: px - 14,
            maxX: px + 14,
            minZ: pz - 14,
            maxZ: pz + 14,
            minY: 0,
            maxY: 520,
            isWall: true,
          });
        }
      }
    }
    pillarInst.instanceMatrix.needsUpdate = true;
    sceneGroup.add(pillarInst);

    for (let r = 1; r < 14; r += 3) {
      addBox(360, 18, 22, 0, 220, 20 - r * 52, materials.concreteDarkRib);
    }

    addHumanBench(-5.5, 0, 18, Math.PI / 2);
    addHumanBench(-5.5, 0, -32, Math.PI / 2);
    addSolitaryTree(-14, 0, 8, 1.0);
    addSolitaryTree(16, 0, -18, 1.15);
    addSolitaryTree(-15, 0, -75, 0.9);
    addSolitaryTree(18, 0, -140, 1.1);
    addHumanDoor(-17.8, 0, -32, Math.PI / 2);
    addHumanDoor(17.8, 0, -84, -Math.PI / 2);

    addBox(12, 0.3, 40, 28, -0.1, -90, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
    });

    colliders.push({
      minX: 22,
      maxX: 34,
      minZ: -150,
      maxZ: -110,
      minY: -1,
      maxY: 16,
      isRamp: true,
      rampAxis: 'z',
      rampStartY: 14,
      rampEndY: 0,
      surface: 'concrete',
      zone: 'colossal_staircase',
    });

    const rampMesh = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(12, 1.2, 42)),
      materials.concreteDarkRib
    );
    rampMesh.position.set(28, 6.8, -130);
    rampMesh.rotation.x = Math.atan2(14, 40);
    sceneGroup.add(rampMesh);

    addBox(22, 14, 22, 28, 0, -161, materials.concreteDarkRib, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'elevated_bridge',
    });
    addHumanBench(24, 14, -161, -Math.PI / 2);

    const birdGeo = trackGeo(new THREE.ConeGeometry(0.65, 2.1, 3));
    birdGeo.rotateX(Math.PI / 2);
    birdFlockInstanced = new THREE.InstancedMesh(birdGeo, materials.rustedSteel, 18);
    birdFlockInstanced.frustumCulled = false;
    sceneGroup.add(birdFlockInstanced);

    buildInstancedMeadowGrass(1800, 220, -320, 60, 5.5);

    resonancePoints.push(
      {
        id: 'vp_1',
        position: [0, 0, -32],
        radius: 14,
        title: 'Corredor das Colunas Alinhadas',
        scaleNote: 'Pilares de 520 m de altura com porta de manutenção humana (2,1 m) na base',
        lookTarget: [-32, 220, -84],
        fundamentalFreq: 43.65,
      },
      {
        id: 'vp_mirante',
        position: [28, 14, -161],
        radius: 14,
        title: 'Mirante Lateral do Vale (+14 m)',
        scaleNote: 'Perspectiva diagonal de centenas de pilares desaparecendo na cerração',
        lookTarget: [-32, 160, -240],
        fundamentalFreq: 36.71,
      }
    );

    addArchitecturalPortal({
      id: 'portal_to_viaduto',
      position: [0, 0, -245],
      radius: 9,
      targetRegion: 'viaduto_infinito',
      passageType: 'Pórtico de Transição Norte',
      label: 'O Viaduto Infinito',
    });
  } else if (regionId === 'viaduto_infinito') {
    const groundGeo = trackGeo(new THREE.PlaneGeometry(4400, 4400));
    groundGeo.rotateX(-Math.PI / 2);
    const ground = new THREE.Mesh(groundGeo, materials.meadowGround);
    ground.receiveShadow = true;
    ground.position.y = -0.05;
    sceneGroup.add(ground);

    addBox(14, 0.2, 460, 0, -0.08, -150, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'monolith_basin',
      castShadow: false,
    });

    addBox(92, 16, 3600, 0, 160, -400, materials.concreteColossal);
    addBox(8, 9, 3600, -34, 151, -400, materials.concreteDarkRib);
    addBox(8, 9, 3600, 34, 151, -400, materials.concreteDarkRib);

    const crossRibGeo = trackGeo(new THREE.BoxGeometry(96, 6, 4.5));
    const crossRibInst = new THREE.InstancedMesh(crossRibGeo, materials.concreteDarkRib, 48);
    crossRibInst.frustumCulled = false;
    for (let i = 0; i < 48; i++) {
      dummy.position.set(0, 154, 300 - i * 42);
      dummy.rotation.set(0, 0, 0);
      dummy.scale.set(1, 1, 1);
      dummy.updateMatrix();
      crossRibInst.setMatrixAt(i, dummy.matrix);
    }
    crossRibInst.instanceMatrix.needsUpdate = true;
    sceneGroup.add(crossRibInst);

    for (let pz = 110; pz >= -1200; pz -= 110) {
      addBox(18, 160, 14, -28, 0, pz, materials.concreteColossal, { isWall: pz > -400 });
      addBox(18, 160, 14, 28, 0, pz, materials.concreteColossal, { isWall: pz > -400 });
      addBox(74, 12, 12, 0, 78, pz, materials.concreteDarkRib);
    }

    addBox(22, 0.3, 30, 24, -0.1, -20, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
    });

    colliders.push({
      minX: 44,
      maxX: 60,
      minZ: -155,
      maxZ: -35,
      minY: -1,
      maxY: 38,
      isRamp: true,
      rampAxis: 'z',
      rampStartY: 34,
      rampEndY: 0,
      surface: 'concrete',
      zone: 'colossal_staircase',
    });

    const accessRamp = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(16, 2.2, 124)),
      materials.concreteWeatheredPath
    );
    accessRamp.position.set(52, 16.5, -95);
    accessRamp.rotation.x = Math.atan2(34, 120);
    sceneGroup.add(accessRamp);

    addBox(76, 3.0, 24, 22, 31.0, -167, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'elevated_bridge',
    });
    addBox(24, 3.0, 260, 0, 31.0, -290, materials.concreteFissuredOcean, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'elevated_bridge',
    });
    addBox(24, 3.0, 1800, 0, 31.0, -1300, materials.concreteDarkRib);

    addHumanDoor(-18.8, 0, 0, Math.PI / 2);
    addHumanBench(-8, 0, 12, Math.PI / 2);
    for (let z = -165; z >= -360; z -= 24) {
      addBox(0.3, 4.8, 0.3, -11.2, 34, z, materials.rustedSteel);
      addBox(0.3, 4.8, 0.3, 11.2, 34, z, materials.rustedSteel);
    }

    buildInstancedMeadowGrass(1400, 240, -300, 70, 12);

    resonancePoints.push(
      {
        id: 'viaduto_under',
        position: [0, 0, -5],
        radius: 16,
        title: 'Sombra do Tabuleiro Principal',
        scaleNote: 'Estrutura suspensa a 160 m de altura ocupando todo o zênite · Acesso à rampa a leste',
        lookTarget: [0, 155, -80],
        fundamentalFreq: 41.2,
      },
      {
        id: 'viaduto_deck',
        position: [0, 34, -200],
        radius: 18,
        title: 'Autoestrada Superior Abandonada (+34 m)',
        scaleNote: 'Pista deserta sob o segundo nível colossal a 160 m de altitude',
        lookTarget: [0, 120, -420],
        fundamentalFreq: 32.7,
      }
    );

    addArchitecturalPortal({
      id: 'portal_to_catedral',
      position: [0, 34, -310],
      radius: 10,
      targetRegion: 'catedral_industrial',
      passageType: 'Túnel do Viaduto Superior',
      label: 'A Catedral Industrial',
    });
    addArchitecturalPortal({
      id: 'portal_to_catedral_ground',
      position: [0, 0, -260],
      radius: 10,
      targetRegion: 'catedral_industrial',
      passageType: 'Galeria Basal do Pilar',
      label: 'A Catedral Industrial',
    });
  } else if (regionId === 'catedral_industrial') {
    defaultGroundSurface = 'concrete';
    defaultZone = 'cathedral_nave';
    worldBounds = { minX: -72, maxX: 72, minZ: -380, maxZ: 95 };

    addBox(180, 1.0, 620, 0, -1.0, -150, materials.concreteFissuredOcean, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'cathedral_nave',
      castShadow: false,
    });

    addBox(8.5, 0.96, 340, 0, -0.94, -120, materials.reflectiveWater, {
      walkableTop: true,
      surface: 'water',
      zone: 'cathedral_nave',
      castShadow: false,
    });

    addBox(12, 320, 620, -82, 0, -150, materials.concreteDarkRib, { isWall: true });
    addBox(12, 320, 620, 82, 0, -150, materials.concreteDarkRib, { isWall: true });
    addBox(180, 320, 14, 0, 0, 105, materials.concreteColossal, { isWall: true });
    addBox(180, 320, 14, 0, 0, -420, materials.concreteColossal, { isWall: true });

    addBox(180, 18, 620, 0, 310, -150, materials.concreteDarkRib);

    const colGeo = trackGeo(new THREE.BoxGeometry(14, 310, 14));
    const colInst = new THREE.InstancedMesh(colGeo, materials.concreteColossal, 32);
    colInst.castShadow = true;
    colInst.frustumCulled = false;
    let cIdx = 0;
    for (let r = 0; r < 16; r++) {
      const cz = 70 - r * 30;
      [-28, 28].forEach((cx) => {
        dummy.position.set(cx, 155, cz);
        dummy.rotation.set(0, 0, 0);
        dummy.scale.set(1, 1, 1);
        dummy.updateMatrix();
        colInst.setMatrixAt(cIdx++, dummy.matrix);
        colliders.push({
          minX: cx - 7,
          maxX: cx + 7,
          minZ: cz - 7,
          maxZ: cz + 7,
          minY: 0,
          maxY: 310,
          isWall: true,
        });
      });
      if (r % 2 === 0) {
        addBox(160, 12, 6, 0, 145, cz, materials.concreteDarkRib);
        addBox(160, 16, 8, 0, 235, cz, materials.concreteColossal);
      }
    }
    colInst.instanceMatrix.needsUpdate = true;
    sceneGroup.add(colInst);

    const shaftGeo = trackGeo(new THREE.PlaneGeometry(18, 165));
    for (let r = 1; r < 14; r += 2) {
      const sz = 55 - r * 30;
      const shaft = new THREE.Mesh(shaftGeo, materials.lightShaftMaterial);
      shaft.position.set(-12, 72, sz);
      shaft.rotation.z = -0.32;
      shaft.rotation.y = Math.PI / 5;
      const shaftCross = shaft.clone();
      shaftCross.rotation.y = -Math.PI / 5;
      sceneGroup.add(shaft, shaftCross);
    }

    for (let z = 30; z >= -90; z -= 14) {
      addHumanBench(-9, 0, z, 0);
      addHumanBench(9, 0, z, 0);
    }
    addHumanDoor(-20.9, 0, -20, Math.PI / 2);
    addHumanDoor(20.9, 0, -80, -Math.PI / 2);

    colliders.push({
      minX: -16,
      maxX: 16,
      minZ: -250,
      maxZ: -225,
      minY: -1,
      maxY: 8,
      isRamp: true,
      rampAxis: 'z',
      rampStartY: 6,
      rampEndY: 0,
      surface: 'concrete',
      zone: 'cathedral_nave',
    });
    const altarSteps = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(32, 1.5, 26)),
      materials.concreteDarkRib
    );
    altarSteps.position.set(0, 2.8, -237.5);
    altarSteps.rotation.x = Math.atan2(6, 25);
    sceneGroup.add(altarSteps);

    addBox(48, 6.0, 55, 0, 0, -275, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'cathedral_nave',
    });

    resonancePoints.push(
      {
        id: 'cat_center',
        position: [0, 0, -35],
        radius: 18,
        title: 'Centro da Nave Brutalista',
        scaleNote: 'Abóbada superior a 310 m de altura oculta na neblina interna · Reverberação de 6 s',
        lookTarget: [0, 240, -110],
        fundamentalFreq: 32.7,
      },
      {
        id: 'cat_altar',
        position: [0, 6, -265],
        radius: 16,
        title: 'Altar Industrial Elevado (+6 m)',
        scaleNote: 'Feixes de luz cortando o pó em suspensão ao longo das 32 colunas ciclópicas',
        lookTarget: [0, 180, -20],
        fundamentalFreq: 27.5,
      }
    );

    addArchitecturalPortal({
      id: 'portal_to_oceano',
      position: [0, 6, -295],
      radius: 10,
      targetRegion: 'oceano_concreto',
      passageType: 'Porta Monumental da Ábside',
      label: 'O Oceano de Concreto',
    });
  } else if (regionId === 'oceano_concreto') {
    defaultGroundSurface = 'concrete';
    defaultZone = 'concrete_ocean';
    worldBounds = { minX: -350, maxX: 350, minZ: -450, maxZ: 120 };

    const oceanGeo = trackGeo(new THREE.PlaneGeometry(5200, 5200));
    oceanGeo.rotateX(-Math.PI / 2);
    const oceanMesh = new THREE.Mesh(oceanGeo, materials.concreteFissuredOcean);
    oceanMesh.receiveShadow = true;
    oceanMesh.position.y = -0.02;
    sceneGroup.add(oceanMesh);

    addBox(38, 0.04, 65, -24, -0.03, -65, materials.reflectiveWater, {
      walkableTop: true,
      surface: 'water',
      zone: 'concrete_ocean',
      castShadow: false,
    });
    addBox(52, 0.04, 85, 32, -0.03, -155, materials.reflectiveWater, {
      walkableTop: true,
      surface: 'water',
      zone: 'concrete_ocean',
      castShadow: false,
    });

    addHumanBench(-3.8, 0, -18, 0.2);
    for (let i = 0; i < 12; i++) {
      addBox(0.26, 0.95, 0.26, -6.5, 0, 10 - i * 22, materials.concreteDarkRib);
    }

    addBox(220, 640, 80, -420, 0, -1150, materials.concreteColossal, { rotZ: 0.14 });
    addBox(180, 720, 180, 380, 0, -1280, materials.concreteColossal);
    addBox(950, 95, 90, 0, 390, -1350, materials.concreteDarkRib);
    addBox(340, 580, 120, -780, 0, -820, materials.concreteDarkRib);
    addBox(340, 580, 120, 820, 0, -760, materials.concreteDarkRib);

    resonancePoints.push({
      id: 'oceano_vazio',
      position: [0, 0, -60],
      radius: 22,
      title: 'Marco Zero da Planície Infinita',
      scaleNote: 'Quilômetros de lajes fissuradas sem obstáculos · Silhuetas de 640 m no horizonte',
      lookTarget: [0, 140, -1200],
      fundamentalFreq: 34.65,
    });

    addArchitecturalPortal({
      id: 'portal_to_cidade',
      position: [0, 0, -220],
      radius: 10,
      targetRegion: 'cidade_sem_cidade',
      passageType: 'Passagem Liminar na Planície',
      label: 'A Cidade Sem Cidade',
    });
  } else if (regionId === 'cidade_sem_cidade') {
    defaultGroundSurface = 'concrete';
    defaultZone = 'urban_canyon';

    const cityFloor = trackGeo(new THREE.PlaneGeometry(4400, 4400));
    cityFloor.rotateX(-Math.PI / 2);
    const floorMesh = new THREE.Mesh(cityFloor, materials.concreteFissuredOcean);
    floorMesh.receiveShadow = true;
    floorMesh.position.y = -0.04;
    sceneGroup.add(floorMesh);

    const towerLayouts: Array<{ x: number; z: number; w: number; d: number; h: number }> = [
      { x: -42, z: 20, w: 38, d: 42, h: 380 },
      { x: 42, z: 20, w: 38, d: 42, h: 440 },
      { x: -46, z: -45, w: 44, d: 48, h: 560 },
      { x: 48, z: -45, w: 42, d: 44, h: 510 },
      { x: -44, z: -115, w: 40, d: 48, h: 610 },
      { x: 46, z: -115, w: 44, d: 44, h: 490 },
      { x: -48, z: -185, w: 48, d: 52, h: 580 },
      { x: 48, z: -185, w: 48, d: 52, h: 620 },
      { x: -45, z: -260, w: 44, d: 44, h: 540 },
      { x: 45, z: -260, w: 44, d: 44, h: 540 },
      { x: -125, z: -20, w: 58, d: 58, h: 520 },
      { x: 125, z: -20, w: 58, d: 58, h: 480 },
      { x: -135, z: -110, w: 64, d: 64, h: 640 },
      { x: 135, z: -110, w: 64, d: 64, h: 590 },
      { x: -120, z: -210, w: 56, d: 56, h: 550 },
      { x: 120, z: -210, w: 56, d: 56, h: 610 },
      { x: 0, z: -360, w: 95, d: 65, h: 680 },
    ];

    towerLayouts.forEach((t, idx) => {
      addBox(t.w, t.h, t.d, t.x, 0, t.z, idx % 2 === 0 ? materials.concreteColossal : materials.concreteDarkRib, {
        isWall: true,
      });

      if (Math.abs(t.x) < 60 && t.z > -220) {
        const doorX = t.x < 0 ? t.x + t.w / 2 + 0.1 : t.x - t.w / 2 - 0.1;
        const rot = t.x < 0 ? Math.PI / 2 : -Math.PI / 2;
        addHumanDoor(doorX, 0, t.z, rot);
      }
    });

    for (let z = -10; z >= -240; z -= 55) {
      addBox(80, 5.5, 6.5, 0, 42, z, materials.concreteDarkRib);
      addBox(80, 7.5, 8.5, 0, 108, z - 25, materials.concreteColossal);
      addBox(80, 11.0, 10.0, 0, 185, z - 10, materials.concreteDarkRib);
    }

    addBox(16, 0.3, 35, 18, -0.1, -60, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
    });

    colliders.push({
      minX: 14,
      maxX: 24,
      minZ: -115,
      maxZ: -80,
      minY: -1,
      maxY: 12,
      isRamp: true,
      rampAxis: 'z',
      rampStartY: 10,
      rampEndY: 0,
      surface: 'concrete',
      zone: 'urban_canyon',
    });

    const parkRamp = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(10, 1.2, 36)),
      materials.concreteDarkRib
    );
    parkRamp.position.set(19, 4.8, -97.5);
    parkRamp.rotation.x = Math.atan2(10, 35);
    sceneGroup.add(parkRamp);

    addBox(42, 1.5, 50, 3, 8.5, -140, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'elevated_bridge',
    });

    for (let z = 35; z >= -210; z -= 28) {
      addBox(0.22, 4.2, 0.22, -12, 0, z, materials.rustedSteel);
      addBox(0.22, 4.2, 0.22, 12, 0, z, materials.rustedSteel);
    }
    addHumanBench(-11, 0, -15, Math.PI / 2);
    addHumanBench(11, 0, -75, -Math.PI / 2);

    resonancePoints.push(
      {
        id: 'city_canyon',
        position: [0, 0, -45],
        radius: 16,
        title: 'Cânion dos Edifícios Cegos',
        scaleNote: 'Torres de 580 m sem janelas construídas para uma população desaparecida',
        lookTarget: [-45, 220, -115],
        fundamentalFreq: 38.89,
      },
      {
        id: 'city_deck',
        position: [3, 10, -140],
        radius: 16,
        title: 'Pátio Superior Deserto (+10 m)',
        scaleNote: 'Passarela elevada entre monólitos urbanos e corredores suspensos',
        lookTarget: [0, 140, -220],
        fundamentalFreq: 32.7,
      }
    );

    addArchitecturalPortal({
      id: 'portal_to_ponte',
      position: [0, 0, -235],
      radius: 10,
      targetRegion: 'ponte_nuvens',
      passageType: 'Elevador Monolítico Norte',
      label: 'A Ponte Sobre as Nuvens',
    });
  } else if (regionId === 'ponte_nuvens') {
    defaultGroundSurface = 'concrete';
    defaultZone = 'elevated_bridge';
    worldBounds = { minX: -18.5, maxX: 18.5, minZ: -420, maxZ: 95 };

    addBox(24, 4.5, 560, 0, -4.5, -160, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'elevated_bridge',
    });

    addBox(24, 4.5, 2400, 0, -4.5, -1600, materials.concreteDarkRib);
    addBox(24, 4.5, 1200, 0, -4.5, 700, materials.concreteDarkRib);

    addBox(3.6, 4.54, 520, 0, -4.5, -160, materials.rustedSteel, {
      walkableTop: true,
      surface: 'metal',
      zone: 'elevated_bridge',
      castShadow: false,
    });

    addBox(0.35, 1.18, 560, -11.6, 0, -160, materials.rustedSteel, { isWall: true });
    addBox(0.35, 1.18, 560, 11.6, 0, -160, materials.rustedSteel, { isWall: true });

    addBox(12, 3.5, 22, 16, -3.5, -125, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'elevated_bridge',
    });
    addHumanBench(18.5, 0, -125, -Math.PI / 2);

    const towerZs = [-35, -215, -460, -780];
    towerZs.forEach((tz) => {
      addBox(16, 680, 22, -22, -240, tz, materials.concreteColossal);
      addBox(16, 680, 22, 22, -240, tz, materials.concreteColossal);
      addBox(64, 14, 18, 0, 95, tz, materials.concreteDarkRib);
      addBox(64, 16, 18, 0, 220, tz, materials.concreteColossal);
      addBox(68, 22, 20, 0, 360, tz, materials.concreteDarkRib);

      for (let c = 1; c <= 5; c++) {
        const cable = new THREE.Mesh(
          trackGeo(new THREE.CylinderGeometry(0.35, 0.35, 195, 6)),
          materials.rustedSteel
        );
        cable.position.set(-13.5, 82, tz + c * 14);
        cable.rotation.x = 0.52;
        const cableR = cable.clone();
        cableR.position.x = 13.5;
        sceneGroup.add(cable, cableR);
      }
    });

    addBox(3.2, 2.25, 2.8, -8.5, 0, 35, materials.concreteDarkRib, { isWall: true });
    addHumanDoor(-6.85, 0, 35, Math.PI / 2);

    const abyssCloudGeo = trackGeo(new THREE.PlaneGeometry(520, 520));
    abyssCloudGeo.rotateX(-Math.PI / 2);
    for (let i = 0; i < 36; i++) {
      const cMesh = new THREE.Mesh(abyssCloudGeo, materials.cloudLayerMaterial);
      cMesh.position.set(
        (Math.random() - 0.5) * 1600,
        -42 - (i % 3) * 38,
        50 - Math.random() * 1400
      );
      cMesh.rotation.y = Math.PI * 2 * Math.random();
      sceneGroup.add(cMesh);
    }

    resonancePoints.push(
      {
        id: 'ponte_tower1',
        position: [0, 0, -35],
        radius: 16,
        title: 'Primeiro Pilone de Sustentação (540 m)',
        scaleNote: 'Torres emergindo do mar de nuvens abaixo e desaparecendo na estratosfera',
        lookTarget: [0, 220, -215],
        fundamentalFreq: 38.89,
      },
      {
        id: 'ponte_abyss',
        position: [14, 0, -125],
        radius: 14,
        title: 'Mirante Sobre o Abismo de Nuvens',
        scaleNote: 'Abaixo do guarda-corpo de 1,18 m existe apenas cerração e vento de altitude',
        lookTarget: [45, -45, -160],
        fundamentalFreq: 30.87,
      }
    );

    addArchitecturalPortal({
      id: 'portal_to_tunel',
      position: [0, 0, -255],
      radius: 10,
      targetRegion: 'tunel_colossal',
      passageType: 'Ancoragem Subterrânea Norte',
      label: 'O Túnel Colossal',
    });
  } else if (regionId === 'tunel_colossal') {
    defaultGroundSurface = 'concrete';
    defaultZone = 'industrial_tunnel';
    worldBounds = { minX: -55, maxX: 55, minZ: -440, maxZ: 85 };

    addBox(140, 1.0, 620, 0, -1.0, -190, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'industrial_tunnel',
      castShadow: false,
    });

    addBox(45, 0.96, 540, -32, -0.94, -210, materials.reflectiveWater, {
      walkableTop: true,
      surface: 'water',
      zone: 'industrial_tunnel',
      castShadow: false,
    });
    addBox(45, 0.96, 540, 32, -0.94, -210, materials.reflectiveWater, {
      walkableTop: true,
      surface: 'water',
      zone: 'industrial_tunnel',
      castShadow: false,
    });

    addBox(65, 160, 40, -44, 0, -10, materials.concreteColossal, { isWall: true });
    addBox(65, 160, 40, 44, 0, -10, materials.concreteColossal, { isWall: true });
    addBox(24, 118, 40, 0, 42, -10, materials.concreteDarkRib);
    addHumanDoor(11.8, 0, 8, -Math.PI / 2);

    addBox(16, 160, 1800, -82, 0, -930, materials.concreteDarkRib, { isWall: true });
    addBox(16, 160, 1800, 82, 0, -930, materials.concreteDarkRib, { isWall: true });
    addBox(180, 24, 1800, 0, 145, -930, materials.concreteColossal);

    const ribGeo = trackGeo(new THREE.BoxGeometry(8, 145, 4.5));
    const leftRibs = new THREE.InstancedMesh(ribGeo, materials.concreteColossal, 34);
    const rightRibs = new THREE.InstancedMesh(ribGeo, materials.concreteColossal, 34);
    const beaconGeo = trackGeo(new THREE.BoxGeometry(0.9, 0.9, 0.9));
    const beacons = new THREE.InstancedMesh(beaconGeo, materials.distantBeaconLight, 68);

    leftRibs.frustumCulled = false;
    rightRibs.frustumCulled = false;
    beacons.frustumCulled = false;

    for (let i = 0; i < 34; i++) {
      const rz = -42 - i * 36;
      dummy.position.set(-70, 72.5, rz);
      dummy.updateMatrix();
      leftRibs.setMatrixAt(i, dummy.matrix);

      dummy.position.set(70, 72.5, rz);
      dummy.updateMatrix();
      rightRibs.setMatrixAt(i, dummy.matrix);

      dummy.position.set(-14, 3.6, rz);
      dummy.updateMatrix();
      beacons.setMatrixAt(i * 2, dummy.matrix);

      dummy.position.set(14, 3.6, rz);
      dummy.updateMatrix();
      beacons.setMatrixAt(i * 2 + 1, dummy.matrix);
    }
    leftRibs.instanceMatrix.needsUpdate = true;
    rightRibs.instanceMatrix.needsUpdate = true;
    beacons.instanceMatrix.needsUpdate = true;
    sceneGroup.add(leftRibs, rightRibs, beacons);

    for (let sz = -140; sz >= -560; sz -= 140) {
      addBox(3.6, 2.5, 4.2, -18, 0, sz, materials.concreteDarkRib);
      addHumanDoor(-16.1, 0, sz, Math.PI / 2);
      addBox(150, 2.2, 3.0, 0, 68, sz - 35, materials.rustedSteel);
    }

    resonancePoints.push(
      {
        id: 'tunel_expansion',
        position: [0, 0, -48],
        radius: 18,
        title: 'Câmara de Expansão Subterrânea',
        scaleNote: 'Após o pórtico de 42 m, a abóbada interna se abre para 160 m de largura e 145 m de altura',
        lookTarget: [0, 75, -280],
        fundamentalFreq: 34.65,
      },
      {
        id: 'tunel_depths',
        position: [0, 0, -180],
        radius: 18,
        title: 'Galeria das Luzes Distantes',
        scaleNote: 'Pequenos abrigos técnicos de 2,5 m revelam a profundidade quilométrica do túnel',
        lookTarget: [0, 45, -450],
        fundamentalFreq: 29.14,
      }
    );

    addArchitecturalPortal({
      id: 'portal_to_impossivel',
      position: [0, 0, -265],
      radius: 10,
      targetRegion: 'estrutura_impossivel',
      passageType: 'Eclusa Subterrânea Profunda',
      label: 'A Estrutura Impossível',
    });
  } else if (regionId === 'estrutura_impossivel') {
    const groundGeo = trackGeo(new THREE.PlaneGeometry(4400, 4400));
    groundGeo.rotateX(-Math.PI / 2);
    const ground = new THREE.Mesh(groundGeo, materials.meadowGround);
    ground.receiveShadow = true;
    ground.position.y = -0.05;
    sceneGroup.add(ground);

    addBox(16, 0.25, 420, 0, -0.12, -160, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'monolith_basin',
      castShadow: false,
    });
    addBox(140, 0.35, 140, 0, -0.18, -280, materials.concreteFissuredOcean, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'monolith_basin',
      castShadow: false,
    });
    addBox(42, 0.38, 42, 0, -0.17, -280, materials.reflectiveWater, {
      walkableTop: true,
      surface: 'water',
      zone: 'monolith_basin',
      castShadow: false,
    });

    addBox(1400, 190, 18, -709, 0, -55, materials.concreteColossal, { isWall: true });
    addBox(1400, 190, 18, 709, 0, -55, materials.concreteColossal, { isWall: true });
    addBox(22, 122, 20, 0, 68, -55, materials.concreteColossal);
    addHumanDoor(12.2, 0, -45.9, 0);

    const pillarCoords: [number, number][] = [
      [-56, -222],
      [56, -222],
      [-56, -338],
      [56, -338],
    ];
    pillarCoords.forEach(([px, pz]) => {
      addBox(34, 480, 34, px, 0, pz, materials.concreteColossal, { isWall: true });
    });

    pendulumGroup = new THREE.Group();
    pendulumGroup.position.set(0, 310, -280);
    const coreMesh = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(28, 210, 28)),
      materials.concreteColossal
    );
    coreMesh.position.set(0, -125, 0);
    pendulumGroup.add(coreMesh);

    const tipGeo = trackGeo(new THREE.CylinderGeometry(19, 3.2, 28, 4));
    tipGeo.rotateY(Math.PI / 4);
    const tipMesh = new THREE.Mesh(tipGeo, materials.concreteDarkRib);
    tipMesh.position.set(0, -244, 0);
    pendulumGroup.add(tipMesh);
    sceneGroup.add(pendulumGroup);

    const upperRingGeo = trackGeo(new THREE.TorusGeometry(48, 4.2, 8, 24));
    upperRingGeo.rotateX(Math.PI / 2);
    upperRingMesh = new THREE.Mesh(upperRingGeo, materials.concreteDarkRib);
    upperRingMesh.position.set(0, 185, -280);
    sceneGroup.add(upperRingMesh);

    const lowerRingGeo = trackGeo(new THREE.TorusGeometry(34, 3.0, 8, 16));
    lowerRingGeo.rotateX(Math.PI / 2);
    lowerRingMesh = new THREE.Mesh(lowerRingGeo, materials.rustedSteel);
    lowerRingMesh.position.set(0, 118, -280);
    sceneGroup.add(lowerRingMesh);

    addBox(95, 24, 24, -42, 92, -145, materials.concreteDarkRib);
    addBox(24, 85, 24, -82, 55, -145, materials.concreteColossal);
    addBox(120, 18, 22, 48, 135, -175, materials.concreteColossal);

    addBox(24, 0.3, 20, 24, -0.1, -110, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
    });
    colliders.push({
      minX: 28,
      maxX: 42,
      minZ: -240,
      maxZ: -120,
      minY: -1,
      maxY: 42,
      isRamp: true,
      rampAxis: 'z',
      rampStartY: 38,
      rampEndY: 0,
      surface: 'concrete',
      zone: 'colossal_staircase',
    });

    const skyBridgeVisual = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(14, 3.5, 780)),
      materials.concreteColossal
    );
    skyBridgeVisual.position.set(35, 122, -490);
    skyBridgeVisual.rotation.x = Math.atan2(38, 120);
    sceneGroup.add(skyBridgeVisual);

    addBox(20, 2.5, 26, 35, 35.5, -252, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'elevated_bridge',
    });

    buildInstancedMeadowGrass(1400, 220, -210, 45, 9);

    resonancePoints.push(
      {
        id: 'imp_portal',
        position: [0, 0, -35],
        radius: 14,
        title: 'Pórtico da Escala (68 m)',
        scaleNote: 'Porta humana de 2,1 m ao lado da fenda de 68 m na muralha do horizonte',
        lookTarget: [0, 42, -55],
        fundamentalFreq: 43.65,
      },
      {
        id: 'imp_nadir',
        position: [0, 0, -280],
        radius: 22,
        title: 'Nadir do Pêndulo Invertido',
        scaleNote: 'Bloco monolítico de 210 m suspenso sobre o espelho d’água e ponte subindo às nuvens',
        lookTarget: [0, 185, -280],
        fundamentalFreq: 27.5,
      }
    );

    addArchitecturalPortal({
      id: 'portal_to_torre',
      position: [0, 0, -355],
      radius: 10,
      targetRegion: 'campo_torre',
      passageType: 'Pórtico do Horizonte Norte',
      label: 'O Campo e a Torre',
    });
  } else if (regionId === 'campo_torre') {
    const groundGeo = trackGeo(new THREE.PlaneGeometry(5200, 5200));
    groundGeo.rotateX(-Math.PI / 2);
    const ground = new THREE.Mesh(groundGeo, materials.meadowGround);
    ground.receiveShadow = true;
    ground.position.y = -0.05;
    sceneGroup.add(ground);

    addBox(4.8, 0.12, 340, 0, -0.06, -30, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'open_meadow',
      castShadow: false,
    });

    addBox(210, 0.35, 210, 0, -0.18, -260, materials.concreteWeatheredPath, {
      walkableTop: true,
      surface: 'concrete',
      zone: 'monolith_basin',
      castShadow: false,
    });

    addBox(116, 42, 116, 0, 0, -260, materials.concreteDarkRib, { isWall: true });
    addBox(88, 880, 88, 0, 42, -260, materials.concreteColossal, { isWall: true });

    addBox(12, 820, 102, -32, 42, -260, materials.concreteDarkRib);
    addBox(12, 820, 102, 32, 42, -260, materials.concreteDarkRib);
    addBox(102, 820, 12, 0, 42, -260 - 32, materials.concreteDarkRib);
    addBox(102, 820, 12, 0, 42, -260 + 32, materials.concreteDarkRib);

    addHumanDoor(0, 0, -201.8, 0);
    addHumanDoor(-18, 0, -201.8, 0);
    addHumanDoor(18, 0, -201.8, 0);
    addHumanDoor(58.2, 0, -260, Math.PI / 2);
    addHumanDoor(-58.2, 0, -260, -Math.PI / 2);

    addHumanBench(-8, 0, -188, 0);
    addHumanBench(8, 0, -188, 0);
    addSolitaryTree(-18, 0, 45, 1.0);
    addSolitaryTree(24, 0, -40, 1.1);
    addSolitaryTree(-32, 0, -135, 0.95);

    buildInstancedMeadowGrass(2200, 320, -160, 140, 3.5);

    resonancePoints.push(
      {
        id: 'torre_approach',
        position: [0, 0, 15],
        radius: 18,
        title: 'Planície da Torre Solitária',
        scaleNote: 'Uma única estrutura de 880 m de altura dominando o horizonte vazio',
        lookTarget: [0, 260, -260],
        fundamentalFreq: 32.7,
      },
      {
        id: 'torre_base',
        position: [0, 0, -190],
        radius: 20,
        title: 'Base Monumental da Torre (880 m)',
        scaleNote: 'Três portas humanas de 2,1 m cravadas no sopé de uma parede vertical de quase um quilômetro',
        lookTarget: [0, 340, -255],
        fundamentalFreq: 27.5,
      }
    );

    addArchitecturalPortal({
      id: 'portal_to_vale',
      position: [0, 0, -372],
      radius: 10,
      targetRegion: 'vale_pilares',
      passageType: 'Pórtico Posterior da Torre',
      label: 'Vale dos Pilares Colossais',
    });
    addArchitecturalPortal({
      id: 'portal_to_cidade_ceu',
      position: [76, 0, -260],
      radius: 10,
      targetRegion: 'cidade_ceu',
      passageType: 'Ascensor Orbital Leste',
      label: 'A Cidade do Céu',
    });
  } else if (
    regionId === 'cidade_ceu' ||
    regionId === 'complexo_maquinas' ||
    regionId === 'elevador_planetario' ||
    regionId === 'megacidade_horizonte' ||
    regionId === 'colonia_dyson_anel' ||
    regionId === 'aquapolis_abissal' ||
    regionId === 'metropole_antigravidade' ||
    regionId === 'citadela_hiperboreia' ||
    regionId === 'blade_runner_2049'
  ) {
    const futResult = populateFuturisticRegion(
      regionId,
      sceneGroup,
      materials,
      colliders,
      resonancePoints,
      portals,
      trackGeo,
      addBox,
      addHumanDoor,
      addHumanBench,
      addSolitaryTree,
      addArchitecturalPortal
    );
    worldBounds = futResult.worldBounds;
    defaultGroundSurface = futResult.defaultGroundSurface;
    defaultZone = futResult.defaultZone;
    futuristicController = futResult.controller;
  }

  // 1. High Cloud Deck at Y = 235m - 360m
  const cloudGroup = new THREE.Group();
  const cloudPlaneGeo = trackGeo(new THREE.PlaneGeometry(480, 480));
  cloudPlaneGeo.rotateX(-Math.PI / 2);
  for (let i = 0; i < 26; i++) {
    const cloudMesh = new THREE.Mesh(cloudPlaneGeo, materials.cloudLayerMaterial);
    cloudMesh.position.set(
      (Math.random() - 0.5) * 2200,
      235 + (i % 4) * 32,
      -150 + (Math.random() - 0.5) * 2000
    );
    cloudMesh.rotation.y = Math.random() * Math.PI * 2;
    const cScale = 0.8 + Math.random() * 1.4;
    cloudMesh.scale.set(cScale, 1, cScale);
    cloudGroup.add(cloudMesh);
  }
  sceneGroup.add(cloudGroup);

  // 2. Low Ground Mist Layer at Y = 2.5m - 7.5m
  const lowMistGroup = new THREE.Group();
  const mistPlaneGeo = trackGeo(new THREE.PlaneGeometry(140, 140));
  mistPlaneGeo.rotateX(-Math.PI / 2);
  for (let i = 0; i < 14; i++) {
    const mistMesh = new THREE.Mesh(mistPlaneGeo, materials.lowMistMaterial);
    mistMesh.position.set(
      (Math.random() - 0.5) * 280,
      2.4 + (i % 3) * 2.2,
      40 - i * 32
    );
    mistMesh.rotation.y = Math.random() * Math.PI * 2;
    lowMistGroup.add(mistMesh);
  }
  sceneGroup.add(lowMistGroup);

  // 3. GPU-Friendly Weather Rain Particle Lines
  const rainCount = 900;
  const rainPositions = new Float32Array(rainCount * 6);
  for (let i = 0; i < rainCount; i++) {
    const rx = (Math.random() - 0.5) * 70;
    const ry = Math.random() * 38;
    const rz = (Math.random() - 0.5) * 70;
    const idx = i * 6;
    rainPositions[idx] = rx;
    rainPositions[idx + 1] = ry;
    rainPositions[idx + 2] = rz;
    rainPositions[idx + 3] = rx - 0.35;
    rainPositions[idx + 4] = ry - 2.4;
    rainPositions[idx + 5] = rz;
  }
  const rainGeo = trackGeo(new THREE.BufferGeometry());
  rainGeo.setAttribute('position', new THREE.BufferAttribute(rainPositions, 3));
  const rainMaterial = new THREE.LineBasicMaterial({
    color: new THREE.Color('#c9d6de'),
    transparent: true,
    opacity: 0.0,
    depthWrite: false,
  });
  const rainLines = new THREE.LineSegments(rainGeo, rainMaterial);
  rainLines.visible = false;
  rainLines.frustumCulled = false;
  sceneGroup.add(rainLines);

  resonancePoints.forEach((rp) => {
    const [rx, ry, rz] = rp.position;
    const markerGroup = new THREE.Group();
    markerGroup.position.set(rx + 3.2, ry, rz);
    const plinth = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(0.65, 1.45, 0.65)),
      materials.concreteDarkRib
    );
    plinth.position.y = 0.725;
    plinth.castShadow = true;
    markerGroup.add(plinth);

    const resonator = new THREE.Mesh(
      trackGeo(new THREE.BoxGeometry(0.28, 0.65, 0.28)),
      materials.humanScaleAccent
    );
    resonator.position.y = 1.68;
    markerGroup.add(resonator);
    sceneGroup.add(markerGroup);
  });

  const resolvePlayerPhysics = (
    prevPos: THREE.Vector3,
    desiredPos: THREE.Vector3,
    playerRadius: number
  ) => {
    const nextPos = desiredPos.clone();
    nextPos.x = Math.max(worldBounds.minX, Math.min(worldBounds.maxX, nextPos.x));
    nextPos.z = Math.max(worldBounds.minZ, Math.min(worldBounds.maxZ, nextPos.z));

    for (const box of colliders) {
      if (!box.isWall) continue;
      // If player is standing safely on top of this structure, don't collide with the wall:
      if (prevPos.y >= box.maxY - 0.1) continue;
      // If player is completely below or above the vertical extents:
      if (prevPos.y + 1.85 < box.minY) continue;

      const minX = box.minX - playerRadius;
      const maxX = box.maxX + playerRadius;
      const minZ = box.minZ - playerRadius;
      const maxZ = box.maxZ + playerRadius;

      if (nextPos.x > minX && nextPos.x < maxX && nextPos.z > minZ && nextPos.z < maxZ) {
        const wasOutsideX = prevPos.x <= minX || prevPos.x >= maxX;
        const wasOutsideZ = prevPos.z <= minZ || prevPos.z >= maxZ;

        if (wasOutsideX && !wasOutsideZ) {
          nextPos.x = prevPos.x <= minX ? minX : maxX;
        } else if (wasOutsideZ && !wasOutsideX) {
          nextPos.z = prevPos.z <= minZ ? minZ : maxZ;
        } else if (wasOutsideX && wasOutsideZ) {
          const penX = prevPos.x <= minX ? (nextPos.x - minX) : (maxX - nextPos.x);
          const penZ = prevPos.z <= minZ ? (nextPos.z - minZ) : (maxZ - nextPos.z);
          if (penX < penZ) {
            nextPos.x = prevPos.x <= minX ? minX : maxX;
          } else {
            nextPos.z = prevPos.z <= minZ ? minZ : maxZ;
          }
        } else {
          // Push out to the nearest surface
          const dLeft = Math.abs(nextPos.x - minX);
          const dRight = Math.abs(maxX - nextPos.x);
          const dBottom = Math.abs(nextPos.z - minZ);
          const dTop = Math.abs(maxZ - nextPos.z);
          const minD = Math.min(dLeft, dRight, dBottom, dTop);
          if (minD === dLeft) nextPos.x = minX;
          else if (minD === dRight) nextPos.x = maxX;
          else if (minD === dBottom) nextPos.z = minZ;
          else nextPos.z = maxZ;
        }
      }
    }

    let groundY = 0.0;
    let surface: SurfaceMaterialType = defaultGroundSurface;
    let zone: AcousticZone = defaultZone;

    for (const box of colliders) {
      if (box.isWall) continue;
      if (
        nextPos.x >= box.minX &&
        nextPos.x <= box.maxX &&
        nextPos.z >= box.minZ &&
        nextPos.z <= box.maxZ
      ) {
        if (
          box.isRamp &&
          box.rampAxis === 'z' &&
          box.rampStartY !== undefined &&
          box.rampEndY !== undefined
        ) {
          const t = (nextPos.z - box.minZ) / (box.maxZ - box.minZ);
          const rampY = box.rampStartY + t * (box.rampEndY - box.rampStartY);
          if (Math.abs(prevPos.y - rampY) < 4.8 && rampY >= groundY) {
            groundY = rampY;
            if (box.surface) surface = box.surface;
            if (box.zone) zone = box.zone;
          }
        } else {
          const topY = box.maxY;
          if (prevPos.y + 1.8 >= topY && topY >= groundY) {
            groundY = topY;
            if (box.surface) surface = box.surface;
            if (box.zone) zone = box.zone;
          }
        }
      }
    }

    nextPos.y = groundY;
    return {
      position: nextPos,
      groundY,
      surface,
      zone,
    };
  };

  const dispose = () => {
    geometriesToDispose.forEach((g) => g.dispose());
    rainMaterial.dispose();
    skyMaterial.dispose();
    if (futuristicController) {
      futuristicController.dispose();
    }
  };

  return {
    regionId,
    sceneGroup,
    colliders,
    resonancePoints,
    portals,
    handles: {
      pendulumGroup,
      upperRingMesh,
      lowerRingMesh,
      birdFlockInstanced,
      futuristicController,
      cloudGroup,
      lowMistGroup,
      rainLines,
      rainMaterial,
      grassShaderUniforms,
      skyMaterial,
    },
    dispose,
    resolvePlayerPhysics,
  };
}
