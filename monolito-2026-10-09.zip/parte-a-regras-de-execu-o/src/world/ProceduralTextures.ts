import * as THREE from 'three';

export interface WorldMaterialLibrary {
  concreteColossal: THREE.MeshStandardMaterial;
  concreteDarkRib: THREE.MeshStandardMaterial;
  concreteWeatheredPath: THREE.MeshStandardMaterial;
  concreteFissuredOcean: THREE.MeshStandardMaterial;
  humanScaleAccent: THREE.MeshStandardMaterial;
  rustedSteel: THREE.MeshStandardMaterial;
  foliageDark: THREE.MeshStandardMaterial;
  meadowGround: THREE.MeshStandardMaterial;
  reflectiveWater: THREE.MeshStandardMaterial;
  distantBeaconLight: THREE.MeshBasicMaterial;
  portalGlowMaterial: THREE.MeshBasicMaterial;
  cloudLayerMaterial: THREE.MeshBasicMaterial;
  lowMistMaterial: THREE.ShaderMaterial;
  lightShaftMaterial: THREE.ShaderMaterial;
}

function createBrutalistConcreteCanvas(): {
  colorMap: THREE.CanvasTexture;
  bumpMap: THREE.CanvasTexture;
} {
  const size = 512;
  const colorCanvas = document.createElement('canvas');
  colorCanvas.width = size;
  colorCanvas.height = size;
  const ctx = colorCanvas.getContext('2d')!;

  const bumpCanvas = document.createElement('canvas');
  bumpCanvas.width = size;
  bumpCanvas.height = size;
  const bCtx = bumpCanvas.getContext('2d')!;

  ctx.fillStyle = '#7b8084';
  ctx.fillRect(0, 0, size, size);

  bCtx.fillStyle = '#808080';
  bCtx.fillRect(0, 0, size, size);

  const plankCount = 16;
  const plankH = size / plankCount;
  for (let i = 0; i < plankCount; i++) {
    const shade = 116 + Math.floor((Math.random() - 0.5) * 14);
    ctx.fillStyle = `rgb(${shade}, ${shade + 3}, ${shade + 6})`;
    ctx.fillRect(0, i * plankH, size, plankH);

    ctx.fillStyle = 'rgba(32, 35, 38, 0.38)';
    ctx.fillRect(0, i * plankH, size, 2);

    bCtx.fillStyle = '#404040';
    bCtx.fillRect(0, i * plankH, size, 2);
  }

  for (let x = 0; x < size; x += 128) {
    ctx.fillStyle = 'rgba(28, 30, 33, 0.32)';
    ctx.fillRect(x, 0, 2, size);

    bCtx.fillStyle = '#363636';
    bCtx.fillRect(x, 0, 2, size);
  }

  for (let y = plankH * 0.5; y < size; y += plankH * 2) {
    for (let x = 32; x < size; x += 64) {
      ctx.fillStyle = 'rgba(25, 28, 30, 0.55)';
      ctx.beginPath();
      ctx.arc(x, y, 3.5, 0, Math.PI * 2);
      ctx.fill();

      bCtx.fillStyle = '#181818';
      ctx.beginPath();
      bCtx.arc(x, y, 4, 0, Math.PI * 2);
      bCtx.fill();
    }
  }

  for (let i = 0; i < 60; i++) {
    const x = Math.random() * size;
    const w = 4 + Math.random() * 18;
    const h = 90 + Math.random() * 340;
    const y = Math.random() * (size - h * 0.3);
    const grad = ctx.createLinearGradient(0, y, 0, y + h);
    grad.addColorStop(0, 'rgba(35, 39, 42, 0.22)');
    grad.addColorStop(0.5, 'rgba(35, 39, 42, 0.08)');
    grad.addColorStop(1, 'rgba(35, 39, 42, 0)');
    ctx.fillStyle = grad;
    ctx.fillRect(x, y, w, h);
  }

  const imgData = ctx.getImageData(0, 0, size, size);
  const bData = bCtx.getImageData(0, 0, size, size);
  for (let i = 0; i < imgData.data.length; i += 4) {
    const grain = (Math.random() - 0.5) * 14;
    imgData.data[i] = Math.min(255, Math.max(0, imgData.data[i] + grain));
    imgData.data[i + 1] = Math.min(255, Math.max(0, imgData.data[i + 1] + grain));
    imgData.data[i + 2] = Math.min(255, Math.max(0, imgData.data[i + 2] + grain));

    const bGrain = (Math.random() - 0.5) * 24;
    bData.data[i] = Math.min(255, Math.max(0, bData.data[i] + bGrain));
    bData.data[i + 1] = bData.data[i];
    bData.data[i + 2] = bData.data[i];
  }
  ctx.putImageData(imgData, 0, 0);
  bCtx.putImageData(bData, 0, 0);

  const colorMap = new THREE.CanvasTexture(colorCanvas);
  colorMap.wrapS = THREE.RepeatWrapping;
  colorMap.wrapT = THREE.RepeatWrapping;
  colorMap.repeat.set(6, 18);
  colorMap.colorSpace = THREE.SRGBColorSpace;

  const bumpMap = new THREE.CanvasTexture(bumpCanvas);
  bumpMap.wrapS = THREE.RepeatWrapping;
  bumpMap.wrapT = THREE.RepeatWrapping;
  bumpMap.repeat.set(6, 18);

  return { colorMap, bumpMap };
}

function createFissuredSlabTexture(): THREE.CanvasTexture {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#73787c';
  ctx.fillRect(0, 0, size, size);

  ctx.strokeStyle = 'rgba(26, 29, 32, 0.58)';
  ctx.lineWidth = 2.5;
  for (let i = 0; i <= 4; i++) {
    const p = (i * size) / 4;
    ctx.beginPath();
    ctx.moveTo(p, 0);
    ctx.lineTo(p, size);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(0, p);
    ctx.lineTo(size, p);
    ctx.stroke();
  }

  ctx.strokeStyle = 'rgba(22, 25, 28, 0.48)';
  ctx.lineWidth = 1.4;
  for (let c = 0; c < 22; c++) {
    let cx = Math.random() * size;
    let cy = Math.random() * size;
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    const segments = 5 + Math.floor(Math.random() * 7);
    for (let s = 0; s < segments; s++) {
      cx += (Math.random() - 0.5) * 38;
      cy += (Math.random() - 0.5) * 38;
      ctx.lineTo(cx, cy);
    }
    ctx.stroke();
  }

  for (let i = 0; i < 1400; i++) {
    ctx.fillStyle =
      Math.random() > 0.5 ? 'rgba(40,44,48,0.18)' : 'rgba(165,172,176,0.14)';
    ctx.fillRect(Math.random() * size, Math.random() * size, 2, 2);
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(160, 160);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createMeadowGroundTexture(): THREE.CanvasTexture {
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#3d4a3a';
  ctx.fillRect(0, 0, size, size);

  for (let i = 0; i < 1800; i++) {
    const x = Math.random() * size;
    const y = Math.random() * size;
    const r = 2 + Math.random() * 8;
    const tone = Math.random();
    if (tone < 0.35) {
      ctx.fillStyle = 'rgba(48, 60, 44, 0.35)';
    } else if (tone < 0.7) {
      ctx.fillStyle = 'rgba(72, 84, 64, 0.28)';
    } else {
      ctx.fillStyle = 'rgba(58, 62, 54, 0.30)';
    }
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(56, 56);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createSoftCloudTexture(): THREE.CanvasTexture {
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  ctx.clearRect(0, 0, size, size);

  const grad = ctx.createRadialGradient(
    size / 2,
    size / 2,
    10,
    size / 2,
    size / 2,
    size / 2
  );
  grad.addColorStop(0, 'rgba(232, 238, 242, 0.85)');
  grad.addColorStop(0.45, 'rgba(210, 218, 224, 0.45)');
  grad.addColorStop(0.78, 'rgba(188, 198, 206, 0.12)');
  grad.addColorStop(1, 'rgba(188, 198, 206, 0.0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, size, size);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export function createWorldMaterials(): WorldMaterialLibrary {
  const { colorMap, bumpMap } = createBrutalistConcreteCanvas();
  const fissuredTex = createFissuredSlabTexture();
  const meadowTex = createMeadowGroundTexture();
  const cloudTex = createSoftCloudTexture();

  const concreteColossal = new THREE.MeshStandardMaterial({
    map: colorMap,
    bumpMap: bumpMap,
    bumpScale: 0.35,
    roughness: 0.88,
    metalness: 0.06,
    color: new THREE.Color('#959b9e'),
  });

  const ribColorMap = colorMap.clone();
  ribColorMap.repeat.set(2, 4);
  ribColorMap.needsUpdate = true;

  const concreteDarkRib = new THREE.MeshStandardMaterial({
    map: ribColorMap,
    bumpMap: bumpMap,
    bumpScale: 0.25,
    roughness: 0.92,
    metalness: 0.12,
    color: new THREE.Color('#646a6e'),
  });

  const concreteWeatheredPath = new THREE.MeshStandardMaterial({
    map: ribColorMap,
    roughness: 0.94,
    metalness: 0.04,
    color: new THREE.Color('#787e80'),
  });

  const concreteFissuredOcean = new THREE.MeshStandardMaterial({
    map: fissuredTex,
    roughness: 0.89,
    metalness: 0.08,
    color: new THREE.Color('#80868a'),
  });

  const humanScaleAccent = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#b06c49'),
    roughness: 0.78,
    metalness: 0.35,
  });

  const rustedSteel = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#3a3f42'),
    roughness: 0.62,
    metalness: 0.68,
  });

  const foliageDark = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#3f4f3c'),
    roughness: 0.95,
    metalness: 0.0,
  });

  const meadowGround = new THREE.MeshStandardMaterial({
    map: meadowTex,
    roughness: 0.96,
    metalness: 0.0,
    color: new THREE.Color('#6c7a65'),
  });

  const reflectiveWater = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#2c353b'),
    roughness: 0.14,
    metalness: 0.75,
  });

  const distantBeaconLight = new THREE.MeshBasicMaterial({
    color: new THREE.Color('#ffcf96'),
    fog: false,
  });

  const portalGlowMaterial = new THREE.MeshBasicMaterial({
    color: new THREE.Color('#d8e2e8'),
    transparent: true,
    opacity: 0.32,
    side: THREE.DoubleSide,
  });

  const cloudLayerMaterial = new THREE.MeshBasicMaterial({
    map: cloudTex,
    transparent: true,
    opacity: 0.75,
    depthWrite: false,
    side: THREE.DoubleSide,
    fog: true,
  });

  const lowMistMaterial = new THREE.ShaderMaterial({
    uniforms: {
      uColor: { value: new THREE.Color('#b5bfc4') },
      uOpacity: { value: 0.16 },
      uFogDensity: { value: 0.0026 },
    },
    vertexShader: `
      varying vec2 vUv;
      varying vec3 vWorldPos;
      void main() {
        vUv = uv;
        vec4 worldPos = modelMatrix * vec4(position, 1.0);
        vWorldPos = worldPos.xyz;
        gl_Position = projectionMatrix * viewMatrix * worldPos;
      }
    `,
    fragmentShader: `
      uniform vec3 uColor;
      uniform float uOpacity;
      uniform float uFogDensity;
      varying vec2 vUv;
      varying vec3 vWorldPos;
      void main() {
        vec2 centered = (vUv - vec2(0.5)) * 2.0;
        float r2 = dot(centered, centered);
        float radialFade = pow(clamp(1.0 - r2, 0.0, 1.0), 2.2);
        vec3 toCam = cameraPosition - vWorldPos;
        float dist = length(toCam);
        float absCosTheta = abs(toCam.y) / max(dist, 0.001);
        float grazingFade = smoothstep(0.015, 0.14, absCosTheta);
        float nearFade = smoothstep(4.5, 22.0, dist);
        float farFade = exp(-uFogDensity * dist * 1.55);
        float alpha = radialFade * grazingFade * nearFade * farFade * uOpacity;
        gl_FragColor = vec4(uColor, alpha);
      }
    `,
    transparent: true,
    depthWrite: false,
    side: THREE.DoubleSide,
  });

  const lightShaftMaterial = new THREE.ShaderMaterial({
    uniforms: {
      uColor: { value: new THREE.Color('#fff5e4') },
      uOpacity: { value: 0.075 },
      uFogDensity: { value: 0.0026 },
    },
    vertexShader: `
      varying vec2 vUv;
      varying vec3 vWorldPos;
      varying vec3 vWorldNormal;
      void main() {
        vUv = uv;
        vec4 worldPos = modelMatrix * vec4(position, 1.0);
        vWorldPos = worldPos.xyz;
        vWorldNormal = normalize(mat3(modelMatrix) * normal);
        gl_Position = projectionMatrix * viewMatrix * worldPos;
      }
    `,
    fragmentShader: `
      uniform vec3 uColor;
      uniform float uOpacity;
      uniform float uFogDensity;
      varying vec2 vUv;
      varying vec3 vWorldPos;
      varying vec3 vWorldNormal;
      void main() {
        float bottomFade = smoothstep(0.0, 0.42, vUv.y);
        float topFade = smoothstep(1.0, 0.08, vUv.y);
        float verticalFade = bottomFade * topFade;
        float hBell = sin(clamp(vUv.x, 0.0, 1.0) * 3.14159265);
        float edgeFade = pow(hBell, 2.8);
        vec3 toCam = cameraPosition - vWorldPos;
        float dist = length(toCam);
        vec3 viewDir = toCam / max(dist, 0.001);
        float viewDot = abs(dot(viewDir, normalize(vWorldNormal)));
        float viewFade = smoothstep(0.08, 0.58, viewDot);
        float distFade = smoothstep(6.0, 24.0, dist) * exp(-uFogDensity * dist * 1.4);
        float alpha = verticalFade * edgeFade * viewFade * distFade * uOpacity;
        gl_FragColor = vec4(uColor, alpha);
      }
    `,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    side: THREE.DoubleSide,
  });

  return {
    concreteColossal,
    concreteDarkRib,
    concreteWeatheredPath,
    concreteFissuredOcean,
    humanScaleAccent,
    rustedSteel,
    foliageDark,
    meadowGround,
    reflectiveWater,
    distantBeaconLight,
    portalGlowMaterial,
    cloudLayerMaterial,
    lowMistMaterial,
    lightShaftMaterial,
  };
}
