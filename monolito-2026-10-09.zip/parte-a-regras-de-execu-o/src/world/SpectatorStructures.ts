import * as THREE from 'three';

/**
 * Modo espectador: permite tocar numa construção existente, mover e reescalar.
 *
 * As construções do mundo nascem como caixas soltas dentro de um único
 * `sceneGroup`. Para selecionar "um prédio" e não "uma caixa", agrupamos as
 * malhas por proximidade: peças vizinhas viram o mesmo bloco editável.
 *
 * REGRA: nada aqui escreve no documento. As edições devolvem um patch que o
 * `App` decide persistir — o espectador é ferramenta de autoria, não dono do
 * estado do mundo.
 */

/**
 * Distância máxima (m) entre duas peças para serem a mesma construção.
 *
 * A regra mede o VAO entre as caixas, não a distância entre centros com um raio
 * somado ao tamanho:pieces grandes inflavam o alcance e engoliam o bairro
 * inteiro, então selecionar uma escada arrastava meio mundo junto.
 */
const CLUSTER_GAP = 3.5;
/** Abaixo disso a peça é ignorada (poeira, brilhos, detritos). */
const MIN_CLUSTER_VOLUME = 12;
/** Largura a partir da qual uma peça baixa deixa de ser "objeto". */
const FLOOR_SPAN = 70;
/** Espessura abaixo da qual uma peça larga é chão, laje ou terraço. */
const FLOOR_THICKNESS = 10;

/** Distância entre duas caixas: 0 quando se tocam ou se sobrepõem. */
function boxGap(a: THREE.Box3, b: THREE.Box3): number {
  const dx = Math.max(0, a.min.x - b.max.x, b.min.x - a.max.x);
  const dy = Math.max(0, a.min.y - b.max.y, b.min.y - a.max.y);
  const dz = Math.max(0, a.min.z - b.max.z, b.min.z - a.max.z);
  return Math.sqrt(dx * dx + dy * dy + dz * dz);
}

export interface SpectatorCluster {
  id: string;
  group: THREE.Group;
  meshes: THREE.Mesh[];
  /** Posição do pivô no espaço do pai, no momento em que o cluster foi montado. */
  origin: THREE.Vector3;
  /** Caixa envolvente local, usada para validar escala e movimento. */
  bounds: THREE.Box3;
}

export interface StructureTransform {
  /** Deslocamento do pivô, em metros (espaço de mundo). */
  offsetX: number;
  offsetY: number;
  offsetZ: number;
  /** Rotação em radianos, em torno do próprio pivô da construção. */
  rotX: number;
  rotY: number;
  rotZ: number;
  /** Multiplicadores por eixo. scaleX = largura, scaleY = altura, scaleZ = profundidade. */
  scaleX: number;
  scaleY: number;
  scaleZ: number;
}

export const IDENTITY_TRANSFORM: StructureTransform = {
  offsetX: 0,
  offsetY: 0,
  offsetZ: 0,
  rotX: 0,
  rotY: 0,
  rotZ: 0,
  scaleX: 1,
  scaleY: 1,
  scaleZ: 1,
};

/**
 * Agrupa as malhas de um `sceneGroup` em construções usando union-find por
 * proximidade. Complexidade ~O(n²) sobre as malhas do mundo, aceitável para as
 * centenas de peças por região, e roda uma única vez ao entrar no modo.
 */
export function clusterStructures(sceneGroup: THREE.Group): SpectatorCluster[] {
  const candidates: THREE.Mesh[] = [];
  sceneGroup.traverse((object) => {
    const mesh = object as THREE.Mesh;
    if (!mesh.isMesh) return;
    // O domo do céu (shader) e vidros translúcidos não são construções.
    if (mesh.material instanceof THREE.ShaderMaterial) return;
    if ((mesh.material as THREE.Material).transparent) return;
    // Campos com InstancedMesh (florestas de pilares, chuva) não são uma
    // construção: são centenas de cópias espalhadas, e agrupá-las esticaria a
    // cadeia de uniões por meio metro. Ficam de fora da edição.
    if ((mesh as THREE.InstancedMesh).isInstancedMesh) return;
    candidates.push(mesh);
  });

  if (candidates.length === 0) return [];

  // Todo cluster volta para o espaço local do sceneGroup — e não para o espaço
  // do pai da primeira peça encontrada. Portais, portas, árvores e o pêndulo
  // nascem dentro de subgrupos posicionados; usar o pai de uma delas jogava fora
  // o offset do subgrupo e trazia a construção para a origem do mundo.
  sceneGroup.updateMatrixWorld(true);
  const sceneInverse = new THREE.Matrix4().copy(sceneGroup.matrixWorld).invert();

  // Caixa envolvente de cada peça no espaço do sceneGroup. O descarte de peça
  // inútil (detrito, laje de chão) é feito aqui, com a caixa real — medir pelo
  // volume da geometriaazia fora as réplicas de um InstancedMesh e deixava de
  // fora peças compridas e finas, que também não são objeto.
  const local = candidates
    .map((mesh) => {
      mesh.updateWorldMatrix(true, false);
      const box = new THREE.Box3().setFromObject(mesh).applyMatrix4(sceneInverse);
      return { mesh, box };
    })
    .filter(({ box }) => {
      const size = box.getSize(new THREE.Vector3());
      if (size.x * size.y * size.z < MIN_CLUSTER_VOLUME) return false;
      // Chão, laje e terraço: largos e finos. São o palco, não a construção —
      // deixá-los no grupo fazia o prédio arrastar o chão junto.
      const span = Math.max(size.x, size.z);
      if (span > FLOOR_SPAN && size.y < FLOOR_THICKNESS) return false;
      return true;
    });

  const meshes = local.map(({ mesh }) => mesh);
  if (meshes.length === 0) return [];

  const count = local.length;
  const leader = new Array<number>(count);
  for (let i = 0; i < count; i += 1) leader[i] = i;

  const find = (index: number): number => {
    let root = index;
    while (leader[root] !== root) root = leader[root];
    let cursor = index;
    while (leader[cursor] !== root) {
      const next = leader[cursor];
      leader[cursor] = root;
      cursor = next;
    }
    return root;
  };
  const union = (a: number, b: number) => {
    const rootA = find(a);
    const rootB = find(b);
    if (rootA !== rootB) leader[rootB] = rootA;
  };

  for (let i = 0; i < count; i += 1) {
    for (let j = i + 1; j < count; j += 1) {
      // Duas peças são a mesma construção quando praticamente se tocam.
      if (boxGap(local[i].box, local[j].box) < CLUSTER_GAP) union(i, j);
    }
  }

  const buckets = new Map<number, number[]>();
  for (let i = 0; i < count; i += 1) {
    const root = find(i);
    const list = buckets.get(root);
    if (list) list.push(i);
    else buckets.set(root, [i]);
  }

  const clusters: SpectatorCluster[] = [];
  const box = new THREE.Box3();
  let counter = 0;
  for (const members of buckets.values()) {
    const group = new THREE.Group();
    group.name = `spectator_cluster_${counter}`;
    const bounds = new THREE.Box3();
    let started = false;
    const meshesInCluster: THREE.Mesh[] = [];

    const staged: { mesh: THREE.Mesh; matrix: THREE.Matrix4 }[] = [];

    for (const index of members) {
      const mesh = local[index].mesh;
      // Mede no espaço do sceneGroup: converte o matrixWorld — que inclui a
      // cadeia inteira de grupos aninhados — e não o matrix local. Aplicar a
      // inversa só no matrix local (o que applyMatrix4 faz) descartava o offset
      // do subgrupo e trazia o portal para o meio do mapa.
      mesh.updateWorldMatrix(true, false);
      const matrix = new THREE.Matrix4().copy(sceneInverse).multiply(mesh.matrixWorld);
      staged.push({ mesh, matrix });
      box.copy((mesh.geometry.boundingBox as THREE.Box3)).applyMatrix4(matrix);
      if (!started) {
        bounds.copy(box);
        started = true;
      } else {
        bounds.union(box);
      }
    }

    const origin = bounds.getCenter(new THREE.Vector3());
    // O grupo fica no pivô e escala a partir dele, então cada peça entra no
    // grupo já com o pivô subtraído. Sem esta subtração a posição do grupo
    // contaria duas vezes e a construção andaria na direção do centro do mundo.
    const unpivot = new THREE.Matrix4().makeTranslation(-origin.x, -origin.y, -origin.z);
    for (const entry of staged) {
      const mesh = entry.mesh;
      mesh.matrix.multiplyMatrices(unpivot, entry.matrix);
      mesh.matrix.decompose(mesh.position, mesh.quaternion, mesh.scale);
      // O id permite descobrir o cluster a partir da malha atingida no raycast.
      mesh.userData.spectatorClusterId = group.name;
      group.add(mesh);
      meshesInCluster.push(mesh);
    }
    // O pivô fica no centro do volume, na horizontal.
    group.position.copy(origin);
    // Sem isto o grupo nasce órfão: as malhas saem do grupo visível e todas as
    // construções desaparecem assim que o modo espectador liga.
    sceneGroup.add(group);
    group.updateMatrixWorld(true);

    clusters.push({
      id: group.name,
      group,
      meshes: meshesInCluster,
      origin,
      bounds,
    });
    counter += 1;
  }

  return clusters;
}

/** Lê a transformação efetiva do cluster. */
export function readTransform(cluster: SpectatorCluster): StructureTransform {
  return {
    offsetX: cluster.group.position.x - cluster.origin.x,
    offsetY: cluster.group.position.y - cluster.origin.y,
    offsetZ: cluster.group.position.z - cluster.origin.z,
    rotX: cluster.group.rotation.x,
    rotY: cluster.group.rotation.y,
    rotZ: cluster.group.rotation.z,
    scaleX: cluster.group.scale.x,
    scaleY: cluster.group.scale.y,
    scaleZ: cluster.group.scale.z,
  };
}

/** Aplica transformação absoluta a partir do estado original. */
export function applyTransform(
  cluster: SpectatorCluster,
  transform: StructureTransform
): void {
  cluster.group.position.set(
    cluster.origin.x + transform.offsetX,
    cluster.origin.y + transform.offsetY,
    cluster.origin.z + transform.offsetZ
  );
  cluster.group.rotation.set(transform.rotX, transform.rotY, transform.rotZ, 'YXZ');
  cluster.group.scale.set(
    Math.max(transform.scaleX, 0.05),
    Math.max(transform.scaleY, 0.05),
    Math.max(transform.scaleZ, 0.05)
  );
  cluster.group.updateMatrixWorld(true);
}

/** Devolve o grupo ao estado original. */
export function resetTransform(cluster: SpectatorCluster): void {
  cluster.group.position.copy(cluster.origin);
  cluster.group.rotation.set(0, 0, 0);
  cluster.group.scale.set(1, 1, 1);
  cluster.group.updateMatrixWorld(true);
}

/** Caixa de seleção: arestas + helper, para o objeto escolhido ficar evidente. */
export interface SelectionVisual {
  box: THREE.LineSegments;
  highlight: THREE.Box3Helper;
  dispose: () => void;
}

export function createSelectionVisual(): SelectionVisual {
  const edgesGeometry = new THREE.EdgesGeometry(new THREE.BoxGeometry(1, 1, 1));
  const edgesMaterial = new THREE.LineBasicMaterial({
    color: new THREE.Color('#6ee7b7'),
    transparent: true,
    opacity: 0.95,
    depthTest: false,
  });
  const edges = new THREE.LineSegments(edgesGeometry, edgesMaterial);
  edges.renderOrder = 999;
  edges.visible = false;

  const highlight = new THREE.Box3Helper(new THREE.Box3(), new THREE.Color('#6ee7b7'));
  highlight.visible = false;

  return {
    box: edges,
    highlight,
    dispose: () => {
      edgesGeometry.dispose();
      edgesMaterial.dispose();
      highlight.geometry.dispose();
      (highlight.material as THREE.Material).dispose();
    },
  };
}

/** Sincroniza a caixa de seleção com a transformação atual do cluster. */
export function syncSelectionVisual(
  visual: SelectionVisual,
  cluster: SpectatorCluster | null
): void {
  if (!cluster) {
    visual.box.visible = false;
    visual.highlight.visible = false;
    return;
  }
  cluster.group.updateMatrixWorld(true);
  const world = new THREE.Box3().setFromObject(cluster.group);
  const size = world.getSize(new THREE.Vector3());
  const center = world.getCenter(new THREE.Vector3());

  visual.box.position.copy(center);
  visual.box.scale.set(Math.max(size.x, 0.5), Math.max(size.y, 0.5), Math.max(size.z, 0.5));
  visual.box.visible = true;

  visual.highlight.box.copy(world);
  visual.highlight.visible = true;
  visual.highlight.updateMatrixWorld(true);
}

/** Maior dimensão do cluster, em metros. */
export function clusterSize(cluster: SpectatorCluster): THREE.Vector3 {
  const size = new THREE.Box3().setFromObject(cluster.group).getSize(new THREE.Vector3());
  return size;
}
