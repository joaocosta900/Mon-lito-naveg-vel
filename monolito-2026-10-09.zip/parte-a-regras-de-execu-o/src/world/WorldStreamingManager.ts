import * as THREE from 'three';
import {
  WorldPlan,
  WorldRegionDefinition,
  WORLD_SIZE_MAP,
} from './types/worldPlan';

export interface ChunkStreamingState {
  currentRegionId: string;
  currentGridCoord: [number, number];
  neighborRegionIds: string[];
  loadedRegionIds: string[];
  unloadedRegionIds: string[];
  horizonLODCount: number;
}

export class WorldStreamingManager {
  private plan: WorldPlan;
  private currentGridCoord: [number, number] = [0, 0];
  private currentRegionId: string = '';
  private loadedRegionIds: Set<string> = new Set();
  private chunkSizeMeters: number;
  private gridSize: number;
  private onRegionTransition?: (newRegionId: string) => void;

  constructor(plan: WorldPlan, onRegionTransition?: (newRegionId: string) => void) {
    this.plan = plan;
    this.onRegionTransition = onRegionTransition;

    const sizeSpec = WORLD_SIZE_MAP[plan.size.scaleLabel] || WORLD_SIZE_MAP['20km'];
    this.chunkSizeMeters = sizeSpec.chunkDimensionMeters;
    this.gridSize = sizeSpec.regionGridSize;

    // Set initial region
    const initialRegion = plan.regions[0];
    if (initialRegion) {
      this.currentRegionId = initialRegion.id;
      this.currentGridCoord = initialRegion.gridCoord;
      this.loadedRegionIds.add(initialRegion.id);
    }
  }

  /**
   * Updates streaming state based on player position in world space.
   * Priority:
   * 1. Player active region
   * 2. Immediate neighbor regions
   * 3. Visible camera frustum
   * 4. Distance culling of distant chunks
   */
  public updatePlayerPosition(playerWorldPos: THREE.Vector3): ChunkStreamingState {
    const halfWidth = this.plan.size.width / 2;
    const halfDepth = this.plan.size.depth / 2;

    // Shift origin so (0,0) is center of region 0
    const normX = playerWorldPos.x + halfWidth;
    const normZ = playerWorldPos.z + halfDepth;

    const col = Math.max(0, Math.min(this.gridSize - 1, Math.floor(normX / this.chunkSizeMeters)));
    const row = Math.max(0, Math.min(this.gridSize - 1, Math.floor(normZ / this.chunkSizeMeters)));

    if (col !== this.currentGridCoord[0] || row !== this.currentGridCoord[1]) {
      this.currentGridCoord = [col, row];
      const found = this.plan.regions.find(
        (r) => r.gridCoord[0] === col && r.gridCoord[1] === row
      );
      if (found && found.id !== this.currentRegionId) {
        this.currentRegionId = found.id;
        this.loadedRegionIds.add(found.id);
        this.onRegionTransition?.(found.id);
      }
    }

    // Determine neighbor regions (Chebyshev distance <= 1)
    const neighborIds: string[] = [];
    for (let dc = -1; dc <= 1; dc++) {
      for (let dr = -1; dr <= 1; dr++) {
        if (dc === 0 && dr === 0) continue;
        const nc = col + dc;
        const nr = row + dr;
        if (nc >= 0 && nc < this.gridSize && nr >= 0 && nr < this.gridSize) {
          const neighbor = this.plan.regions.find(
            (r) => r.gridCoord[0] === nc && r.gridCoord[1] === nr
          );
          if (neighbor) {
            neighborIds.push(neighbor.id);
            this.loadedRegionIds.add(neighbor.id);
          }
        }
      }
    }

    // Distance culling: identify unloaded regions (distance > 2 chunks)
    const unloaded: string[] = [];
    this.plan.regions.forEach((r) => {
      const dist = Math.max(
        Math.abs(r.gridCoord[0] - col),
        Math.abs(r.gridCoord[1] - row)
      );
      if (dist > 2) {
        unloaded.push(r.id);
        this.loadedRegionIds.delete(r.id);
      }
    });

    return {
      currentRegionId: this.currentRegionId,
      currentGridCoord: this.currentGridCoord,
      neighborRegionIds: neighborIds,
      loadedRegionIds: Array.from(this.loadedRegionIds),
      unloadedRegionIds: unloaded,
      horizonLODCount: Math.min(18, this.plan.landmarks.length),
    };
  }

  public getCurrentRegionDefinition(): WorldRegionDefinition {
    return (
      this.plan.regions.find((r) => r.id === this.currentRegionId) ||
      this.plan.regions[0]
    );
  }

  public getRegionById(regionId: string): WorldRegionDefinition | undefined {
    return this.plan.regions.find((r) => r.id === regionId);
  }
}
