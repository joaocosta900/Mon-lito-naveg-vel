import * as THREE from 'three';
import {
  WorldPlan,
  WorldRegionDefinition,
  WorldStructureSpec,
} from './types/worldPlan';
import {
  AcousticZone,
  ArchitecturalPortal,
  RegionId,
  ResonancePoint,
  SurfaceMaterialType,
  WalkableBox,
  WeatherPreset,
  WeatherPresetId,
} from '../types/world';
import { WorldMaterialLibrary } from './ProceduralTextures';
import { AnimatedWorldHandles, BuiltWorld } from './ColossalWorldBuilder';
import { WEATHER_PRESETS } from './AtmospherePresets';

interface StructureFootprint {
  id: string;
  label: string;
  x: number;
  z: number;
  width: number;
  depth: number;
  height: number;
  style: WorldStructureSpec['style'];
}

interface GapEvaluation {
  from: StructureFootprint;
  to: StructureFootprint;
  start: { x: number; z: number };
  end: { x: number; z: number };
  distance: number;
}

const BRIDGE_CONNECTOR_MAX_GAP = 240;
const BRIDGE_CONNECTOR_MIN_GAP = 8;
const BRIDGE_CONNECTOR_MAX_COUNT = 12;

function clampNumber(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

function hashString(value: string): number {
  let hash = 2166136261;
  for (let index = 0; index < value.length; index++) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return Math.abs(hash >>> 0);
}

function createMegaWallDetailNormalMap(seed: number): THREE.CanvasTexture {
  const size = 256;
  const heightCanvas = document.createElement('canvas');
  heightCanvas.width = size;
  heightCanvas.height = size;
  const heightContext = heightCanvas.getContext('2d')!;
  const normalCanvas = document.createElement('canvas');
  normalCanvas.width = size;
  normalCanvas.height = size;
  const normalContext = normalCanvas.getContext('2d')!;

  heightContext.fillStyle = '#7f7f7f';
  heightContext.fillRect(0, 0, size, size);

  const noise = heightContext.getImageData(0, 0, size, size);
  let randomState = seed >>> 0;
  const nextRandom = () => {
    randomState = (Math.imul(randomState, 1664525) + 1013904223) >>> 0;
    return randomState / 0xffffffff;
  };
  for (let index = 0; index < noise.data.length; index += 4) {
    const grain = Math.floor((nextRandom() - 0.5) * 24);
    noise.data[index] = clampNumber(noise.data[index] + grain, 0, 255);
    noise.data[index + 1] = noise.data[index];
    noise.data[index + 2] = noise.data[index];
    noise.data[index + 3] = 255;
  }
  heightContext.putImageData(noise, 0, 0);

  // Raised service pipes and conduit joints.
  heightContext.lineCap = 'round';
  heightContext.strokeStyle = '#d6d6d6';
  heightContext.lineWidth = 14;
  [
    [30, -12, 30, 274],
    [178, -12, 178, 274],
    [-12, 44, 274, 44],
    [-12, 208, 274, 208],
  ].forEach(([x1, y1, x2, y2]) => {
    heightContext.beginPath();
    heightContext.moveTo(x1, y1);
    heightContext.lineTo(x2, y2);
    heightContext.stroke();
  });
  heightContext.strokeStyle = '#9d9d9d';
  heightContext.lineWidth = 3;
  [
    [30, -12, 30, 274],
    [178, -12, 178, 274],
    [-12, 44, 274, 44],
    [-12, 208, 274, 208],
  ].forEach(([x1, y1, x2, y2]) => {
    heightContext.beginPath();
    heightContext.moveTo(x1, y1);
    heightContext.lineTo(x2, y2);
    heightContext.stroke();
  });
  heightContext.fillStyle = '#eeeeee';
  [
    [30, 44],
    [178, 44],
    [30, 208],
    [178, 208],
  ].forEach(([x, y]) => {
    heightContext.beginPath();
    heightContext.arc(x, y, 13, 0, Math.PI * 2);
    heightContext.fill();
  });

  // Recessed vent banks with alternating slats.
  const ventBanks = [
    { x: 72, y: 76, width: 74, height: 54 },
    { x: 198, y: 116, width: 48, height: 70 },
    { x: 68, y: 224, width: 84, height: 38 },
  ];
  ventBanks.forEach((vent, ventIndex) => {
    heightContext.fillStyle = '#303030';
    heightContext.fillRect(vent.x, vent.y, vent.width, vent.height);
    heightContext.strokeStyle = '#e1e1e1';
    heightContext.lineWidth = 5;
    heightContext.strokeRect(vent.x, vent.y, vent.width, vent.height);
    const slatCount = Math.max(4, Math.floor(vent.height / 10));
    for (let slat = 1; slat < slatCount; slat++) {
      const slatY = vent.y + (vent.height / slatCount) * slat;
      heightContext.strokeStyle = slat % 2 === ventIndex % 2 ? '#bdbdbd' : '#5d5d5d';
      heightContext.lineWidth = 4;
      heightContext.beginPath();
      heightContext.moveTo(vent.x + 5, slatY);
      heightContext.lineTo(vent.x + vent.width - 5, slatY);
      heightContext.stroke();
    }
  });

  // Panel seams keep the micro-detail readable from grazing angles.
  heightContext.strokeStyle = '#515151';
  heightContext.lineWidth = 3;
  [128, 256].forEach((position) => {
    heightContext.beginPath();
    heightContext.moveTo(position, 0);
    heightContext.lineTo(position, size);
    heightContext.stroke();
  });

  const source = heightContext.getImageData(0, 0, size, size).data;
  const output = normalContext.createImageData(size, size);
  const heightAt = (x: number, y: number) => {
    const wrappedX = (x + size) % size;
    const wrappedY = (y + size) % size;
    return source[(wrappedY * size + wrappedX) * 4];
  };
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const left = heightAt(x - 1, y);
      const right = heightAt(x + 1, y);
      const down = heightAt(x, y - 1);
      const up = heightAt(x, y + 1);
      const normalX = -(right - left) * 0.075;
      const normalY = -(up - down) * 0.075;
      const normalZ = 1;
      const length = Math.hypot(normalX, normalY, normalZ);
      const offset = (y * size + x) * 4;
      output.data[offset] = Math.round(((normalX / length) * 0.5 + 0.5) * 255);
      output.data[offset + 1] = Math.round(((normalY / length) * 0.5 + 0.5) * 255);
      output.data[offset + 2] = Math.round(((normalZ / length) * 0.5 + 0.5) * 255);
      output.data[offset + 3] = 255;
    }
  }
  normalContext.putImageData(output, 0, 0);

  const texture = new THREE.CanvasTexture(normalCanvas);
  texture.name = 'Detail Normal Mapping — pipes, vents and panel seams';
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(3, 3);
  texture.anisotropy = 4;
  return texture;
}

function createHolographicSignageTexture(
  label: string,
  gapMeters: number,
  color: string
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 768;
  canvas.height = 192;
  const context = canvas.getContext('2d')!;
  const gradient = context.createLinearGradient(0, 0, canvas.width, 0);
  gradient.addColorStop(0, 'rgba(4, 12, 24, 0.18)');
  gradient.addColorStop(0.5, 'rgba(7, 19, 34, 0.78)');
  gradient.addColorStop(1, 'rgba(4, 12, 24, 0.18)');
  context.fillStyle = gradient;
  context.fillRect(0, 0, canvas.width, canvas.height);

  context.strokeStyle = color;
  context.lineWidth = 7;
  context.strokeRect(8, 8, canvas.width - 16, canvas.height - 16);
  context.shadowColor = color;
  context.shadowBlur = 22;
  context.fillStyle = '#f4fbff';
  context.font = '700 54px monospace';
  context.textAlign = 'center';
  context.textBaseline = 'middle';
  context.fillText(`BRIDGE-CONNECTOR // ${label}`, canvas.width / 2, 75);
  context.font = '700 34px monospace';
  context.fillStyle = color;
  context.fillText(`NEXUS LINK · ${Math.round(gapMeters)}M`, canvas.width / 2, 135);
  context.shadowBlur = 0;

  context.globalAlpha = 0.24;
  context.fillStyle = '#ffffff';
  for (let y = 14; y < canvas.height; y += 8) {
    context.fillRect(12, y, canvas.width - 24, 1);
  }
  context.globalAlpha = 1;

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.ClampToEdgeWrapping;
  texture.wrapT = THREE.ClampToEdgeWrapping;
  return texture;
}

export class WorldPlanCompiler {
  /**
   * Compiles an abstract WorldPlan into a live, interactive 3D BuiltWorld for Three.js.
   * Leverages the existing brutalist materials library, physics resolver, and atmospheric shaders.
   */
  public static compileWorldRegion(
    plan: WorldPlan,
    regionDefinition: WorldRegionDefinition,
    materials: WorldMaterialLibrary
  ): BuiltWorld {
    const sceneGroup = new THREE.Group();
    const colliders: WalkableBox[] = [];
    const resonancePoints: ResonancePoint[] = [];
    const portals: ArchitecturalPortal[] = [];
    const geometriesToDispose: THREE.BufferGeometry[] = [];
    const texturesToDispose: THREE.Texture[] = [];
    const materialsToDispose: THREE.Material[] = [];

    const trackGeo = <T extends THREE.BufferGeometry>(geo: T): T => {
      geometriesToDispose.push(geo);
      return geo;
    };

    const dummy = new THREE.Object3D();
    const basePreset =
      WEATHER_PRESETS[plan.atmosphere.presetId as WeatherPresetId] || WEATHER_PRESETS.manha_neblina;

    // 1. Sky Dome Shader with dynamic colors from WorldPlan
    const skyGeo = trackGeo(new THREE.SphereGeometry(3800, 32, 24));
    const skyMaterial = new THREE.ShaderMaterial({
      uniforms: {
        uTopColor: { value: new THREE.Color(plan.atmosphere.skyTopColor || basePreset.skyTopColor) },
        uHorizonColor: { value: new THREE.Color(plan.atmosphere.skyHorizonColor || basePreset.skyHorizonColor) },
        uSunDir: { value: new THREE.Vector3(-0.45, 0.42, -0.78) },
        uSunColor: { value: new THREE.Color(plan.atmosphere.sunColor || basePreset.sunColor) },
      },
      vertexShader: `
        varying vec3 vWorldPosition;
        void main() {
          vec4 worldPosition = modelMatrix * vec4(position, 1.0);
          vWorldPosition = worldPosition.xyz;
          gl_Position = projectionMatrix * viewMatrix * worldPosition;
        }
      `,
      fragmentShader: `
        uniform vec3 uTopColor;
        uniform vec3 uHorizonColor;
        uniform vec3 uSunDir;
        uniform vec3 uSunColor;
        varying vec3 vWorldPosition;
        void main() {
          vec3 dir = normalize(vWorldPosition);
          float h = clamp(dir.y, 0.0, 1.0);
          vec3 sky = mix(uHorizonColor, uTopColor, pow(h, 0.52));
          float sunAmt = max(dot(dir, normalize(uSunDir)), 0.0);
          sky += uSunColor * pow(sunAmt, 18.0) * 0.28;
          sky += uSunColor * smoothstep(0.996, 0.9995, sunAmt) * 0.65;
          gl_FragColor = vec4(sky, 1.0);
        }
      `,
      side: THREE.BackSide,
      depthWrite: false,
    });
    sceneGroup.add(new THREE.Mesh(skyGeo, skyMaterial));

    // Detail Normal Mapping layer: one texture/material pair adds readable pipes,
    // vents and panel seams to large flat walls without adding tessellation.
    const detailNormalMap = createMegaWallDetailNormalMap(plan.seed);
    texturesToDispose.push(detailNormalMap);

    const createDetailMaterial = (
      source: THREE.MeshStandardMaterial,
      name: string
    ): THREE.MeshStandardMaterial => {
      const detailMaterial = source.clone();
      detailMaterial.name = name;
      detailMaterial.normalMap = detailNormalMap;
      detailMaterial.normalScale = new THREE.Vector2(1.25, 1.25);
      detailMaterial.needsUpdate = true;
      materialsToDispose.push(detailMaterial);
      return detailMaterial;
    };

    const detailColossalMaterial = createDetailMaterial(
      materials.concreteColossal,
      'Mega-wall detail — concrete normal layer'
    );
    const detailDarkRibMaterial = createDetailMaterial(
      materials.concreteDarkRib,
      'Mega-wall detail — ribbed normal layer'
    );

    const getMegaWallMaterial = (
      w: number,
      h: number,
      d: number,
      source: THREE.MeshStandardMaterial = materials.concreteColossal
    ): THREE.MeshStandardMaterial => {
      if (Math.max(w, h, d) < 60) return source;
      if (source === materials.concreteDarkRib) return detailDarkRibMaterial;
      return detailColossalMaterial;
    };

    // Helper: Add Structural Box
    const addBox = (
      w: number,
      h: number,
      d: number,
      x: number,
      yBottom: number,
      z: number,
      mat: THREE.Material,
      options?: {
        isWall?: boolean;
        walkableTop?: boolean;
        surface?: SurfaceMaterialType;
        zone?: AcousticZone;
        castShadow?: boolean;
        receiveShadow?: boolean;
        rotY?: number;
        noCollision?: boolean;
      }
    ): THREE.Mesh => {
      const geo = trackGeo(new THREE.BoxGeometry(w, h, d));
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(x, yBottom + h / 2, z);
      if (options?.rotY) mesh.rotation.y = options.rotY;
      if (options?.castShadow !== false) mesh.castShadow = true;
      if (options?.receiveShadow !== false) mesh.receiveShadow = true;
      sceneGroup.add(mesh);

      // REGRA UNIVERSAL DE ANTI-COLISÃO (NO CLIPPING):
      // Toda estrutura física criada no alcance do jogador possui colisão sólida obrigatória.
      const isFloorTile = Boolean(options?.walkableTop && h <= 0.6 && yBottom <= 0.2);
      const isHighCeiling = yBottom >= 4.5;
      const shouldHaveWallCollision =
        options?.noCollision !== true &&
        (options?.isWall === true ||
          (options?.isWall !== false && !isHighCeiling && !isFloorTile));

      if (shouldHaveWallCollision) {
        colliders.push({
          minX: x - w / 2,
          maxX: x + w / 2,
          minZ: z - d / 2,
          maxZ: z + d / 2,
          minY: yBottom,
          maxY: yBottom + h,
          isWall: true,
        });
      }

      if (options?.walkableTop) {
        colliders.push({
          minX: x - w / 2,
          maxX: x + w / 2,
          minZ: z - d / 2,
          maxZ: z + d / 2,
          minY: yBottom,
          maxY: yBottom + h,
          surface: options.surface ?? 'concrete',
          zone: options.zone,
        });
      }

      return mesh;
    };

    // Helper: Human-Scale Door (2.1m high x 1.1m wide)
    const addHumanDoor = (x: number, yBottom: number, z: number, rotY = 0) => {
      const group = new THREE.Group();
      group.position.set(x, yBottom, z);
      group.rotation.y = rotY;

      const frame = new THREE.Mesh(
        trackGeo(new THREE.BoxGeometry(1.3, 2.25, 0.28)),
        materials.concreteDarkRib
      );
      frame.position.y = 1.125;
      group.add(frame);

      const door = new THREE.Mesh(
        trackGeo(new THREE.BoxGeometry(1.0, 2.05, 0.34)),
        materials.humanScaleAccent
      );
      door.position.y = 1.025;
      group.add(door);

      const canopy = new THREE.Mesh(
        trackGeo(new THREE.BoxGeometry(1.6, 0.14, 0.9)),
        materials.concreteDarkRib
      );
      canopy.position.set(0, 2.32, 0.3);
      group.add(canopy);

      sceneGroup.add(group);
    };

    // Helper: Human-Scale Bench
    const addHumanBench = (x: number, yBottom: number, z: number, rotY = 0) => {
      const bench = new THREE.Mesh(
        trackGeo(new THREE.BoxGeometry(1.8, 0.45, 0.55)),
        materials.concreteDarkRib
      );
      bench.position.set(x, yBottom + 0.225, z);
      bench.rotation.y = rotY;
      bench.castShadow = true;
      sceneGroup.add(bench);
    };

    // Helper: Solitary Tree
    const addSolitaryTree = (x: number, yBottom: number, z: number, scale = 1.0) => {
      const tree = new THREE.Group();
      tree.position.set(x, yBottom, z);
      tree.scale.setScalar(scale);

      const trunk = new THREE.Mesh(
        trackGeo(new THREE.CylinderGeometry(0.12, 0.22, 2.2, 6)),
        materials.rustedSteel
      );
      trunk.position.y = 1.1;
      trunk.castShadow = true;
      tree.add(trunk);

      const crown1 = new THREE.Mesh(
        trackGeo(new THREE.ConeGeometry(1.35, 3.2, 7)),
        materials.foliageDark
      );
      crown1.position.set(0.15, 3.1, 0);
      crown1.rotation.z = -0.06;
      crown1.castShadow = true;
      tree.add(crown1);

      sceneGroup.add(tree);
    };

    // Helper: Architectural Portal Frame
    const addArchitecturalPortal = (portal: ArchitecturalPortal) => {
      portals.push(portal);
      const [px, py, pz] = portal.position;
      const pGroup = new THREE.Group();
      pGroup.position.set(px, py, pz);

      const leftPillar = new THREE.Mesh(
        trackGeo(new THREE.BoxGeometry(1.4, 9.5, 2.4)),
        materials.concreteDarkRib
      );
      leftPillar.position.set(-2.1, 4.75, 0);
      leftPillar.castShadow = true;
      pGroup.add(leftPillar);

      const rightPillar = new THREE.Mesh(
        trackGeo(new THREE.BoxGeometry(1.4, 9.5, 2.4)),
        materials.concreteDarkRib
      );
      rightPillar.position.set(2.1, 4.75, 0);
      rightPillar.castShadow = true;
      pGroup.add(rightPillar);

      const lintel = new THREE.Mesh(
        trackGeo(new THREE.BoxGeometry(6.2, 2.2, 2.8)),
        materials.concreteColossal
      );
      lintel.position.set(0, 10.2, 0);
      lintel.castShadow = true;
      pGroup.add(lintel);

      const veil = new THREE.Mesh(
        trackGeo(new THREE.PlaneGeometry(2.8, 9.2)),
        materials.portalGlowMaterial
      );
      veil.position.set(0, 4.6, 0);
      pGroup.add(veil);

      const beacon = new THREE.Mesh(
        trackGeo(new THREE.BoxGeometry(2.4, 0.18, 0.25)),
        materials.distantBeaconLight
      );
      beacon.position.set(0, 8.9, 1.25);
      pGroup.add(beacon);

      sceneGroup.add(pGroup);
    };

    // 2. TERRAIN COMPILATION
    const isWaterWorld = plan.terrain.type === 'island_abyss' || plan.terrain.waterLevel > 0.4;
    const isConcreteOcean = plan.terrain.type === 'concrete_ocean';
    const groundMat = isConcreteOcean ? materials.concreteFissuredOcean : materials.meadowGround;

    const terrainGeo = trackGeo(new THREE.PlaneGeometry(4800, 4800, 48, 48));
    terrainGeo.rotateX(-Math.PI / 2);

    // Apply procedural undulating elevation based on terrain spec
    const posAttr = terrainGeo.attributes.position;
    const hVar = plan.terrain.heightVariation * 35;
    for (let i = 0; i < posAttr.count; i++) {
      const vx = posAttr.getX(i);
      const vz = posAttr.getZ(i);

      // Keep walkable spawn corridor relatively level
      const distFromCenter = Math.hypot(vx, vz);
      const centerFactor = Math.min(1.0, distFromCenter / 120);

      const wave1 = Math.sin(vx * 0.008 + plan.seed) * Math.cos(vz * 0.008 + plan.seed);
      const wave2 = Math.sin(vx * 0.02 + vz * 0.015) * 0.35;
      const height = (wave1 + wave2) * hVar * centerFactor;
      posAttr.setY(i, height - 0.06);
    }
    terrainGeo.computeVertexNormals();

    const groundMesh = new THREE.Mesh(terrainGeo, groundMat);
    groundMesh.receiveShadow = true;
    sceneGroup.add(groundMesh);

    // Water level sheet if terrain has water
    if (plan.terrain.waterLevel > 0.05) {
      const waterGeo = trackGeo(new THREE.PlaneGeometry(5000, 5000));
      waterGeo.rotateX(-Math.PI / 2);
      const waterMesh = new THREE.Mesh(waterGeo, materials.reflectiveWater);
      waterMesh.position.y = (plan.terrain.waterLevel - 0.2) * 20 - 0.8;
      waterMesh.receiveShadow = true;
      sceneGroup.add(waterMesh);
    }

    // 2.5 ROAD & URBAN ARTERIAL NETWORK
    if (plan.roads && plan.roads.length > 0) {
      plan.roads.forEach((road) => {
        const [x1, , z1] = road.fromPosition;
        const [x2, , z2] = road.toPosition;
        const dx = x2 - x1;
        const dz = z2 - z1;
        const length = Math.hypot(dx, dz);
        if (length < 2) return;
        const angle = Math.atan2(dx, dz);
        const midX = (x1 + x2) / 2;
        const midZ = (z1 + z2) / 2;
        const elev = road.elevation || 0;
        const width = road.widthMeters || 16;

        if (road.isElevatedViaduct && elev > 3) {
          // Elevated Viaduct Deck
          addBox(width, 2.4, length, midX, elev - 1.2, midZ, materials.concreteColossal, {
            walkableTop: true,
            rotY: angle,
            surface: 'concrete',
            zone: 'elevated_bridge',
          });

          // Viaduct Guardrails / Safety Parapets
          const halfW = width / 2;
          const perpX = Math.cos(angle);
          const perpZ = -Math.sin(angle);
          addBox(0.9, 1.4, length, midX + perpX * halfW, elev + 0.7, midZ + perpZ * halfW, materials.concreteDarkRib, {
            rotY: angle,
            isWall: true,
          });
          addBox(0.9, 1.4, length, midX - perpX * halfW, elev + 0.7, midZ - perpZ * halfW, materials.concreteDarkRib, {
            rotY: angle,
            isWall: true,
          });

          // Titanic Support Piers every 65 meters
          const numPiers = Math.max(1, Math.floor(length / 65));
          for (let p = 0; p <= numPiers; p++) {
            const frac = p / numPiers;
            const px = x1 + dx * frac;
            const pz = z1 + dz * frac;
            addBox(6.5, elev, 6.5, px, 0, pz, materials.concreteDarkRib, { isWall: true });
          }
        } else {
          // Ground-Level Avenue / Boulevard
          addBox(width, 0.22, length, midX, elev - 0.06, midZ, materials.concreteWeatheredPath, {
            walkableTop: true,
            rotY: angle,
            surface: 'concrete',
            zone: regionDefinition.acousticZone,
            castShadow: false,
          });
        }
      });
    } else {
      // Default Interconnected Boulevards (Crossroads & Grand Central Plaza)
      // 1. Cardinal North-South Boulevard
      addBox(18, 0.22, 540, 0, -0.06, -110, materials.concreteWeatheredPath, {
        walkableTop: true,
        surface: 'concrete',
        zone: regionDefinition.acousticZone,
        castShadow: false,
      });
      // 2. Transverse East-West Boulevard
      addBox(540, 0.22, 18, 0, -0.05, -70, materials.concreteWeatheredPath, {
        walkableTop: true,
        surface: 'concrete',
        zone: regionDefinition.acousticZone,
        castShadow: false,
      });
      // 3. Grand Central Plaza at intersection (0, 0, -70)
      addBox(80, 0.26, 80, 0, -0.04, -70, materials.concreteDarkRib, {
        walkableTop: true,
        surface: 'concrete',
        zone: regionDefinition.acousticZone,
        castShadow: false,
      });
    }

    // 3. STRUCTURE GENERATION
    const structuresInRegion = plan.structures.filter((s) =>
      regionDefinition.structureIds.includes(s.id) || regionDefinition.structureIds.length === 0
    );

    const activeStructures = structuresInRegion.length > 0 ? structuresInRegion : plan.structures;
    const structureFootprints: StructureFootprint[] = [];

    activeStructures.forEach((struct: WorldStructureSpec, sIdx: number) => {
      const [sw, sh, sd] = struct.scale;
      const [px, , pz] = struct.position;
      if (struct.type !== 'megacity') {
        structureFootprints.push({
          id: struct.id,
          label: struct.name,
          x: px,
          z: pz,
          width: sw,
          depth: sd,
          height: sh,
          style: struct.style,
        });
      }

      if (struct.type === 'megacity' || struct.type === 'megatower') {
        const isMegaCity = struct.type === 'megacity';
        const isCyberpunk = struct.style === 'cyberpunk';
        const towerCount = isMegaCity ? 20 : 1;

        const streetSpacingX = sw + 34;
        const streetSpacingZ = sd + 38;

        for (let t = 0; t < towerCount; t++) {
          let offsetX = px;
          let offsetZ = pz;
          let hScale = 1.0;

          if (isMegaCity) {
            // Distribute across 4 multidirectional urban quadrants (2D City Blocks)
            const col = (t % 4) - 1.5; // -1.5, -0.5, 0.5, 1.5
            const row = Math.floor(t / 4) - 2; // -2, -1, 0, 1, 2
            const signX = col >= 0 ? 1 : -1;
            const signZ = row >= 0 ? 1 : -1;
            const boulevardClearance = 24;

            offsetX = px + col * streetSpacingX + signX * boulevardClearance;
            offsetZ = pz + row * streetSpacingZ + signZ * boulevardClearance;
            hScale = 0.75 + Math.abs(Math.sin(t * 2.1 + plan.seed)) * 0.65;
          }

          const currentTotalH = sh * hScale;

          // 1. Podium Base (Plinth) - 16m tall, wider footprint, walkable rooftop deck!
          const podW = sw * 1.35;
          const podD = sd * 1.35;
          structureFootprints.push({
            id: `${struct.id}_tower_${t}`,
            label: `${struct.name} · ${String(t + 1).padStart(2, '0')}`,
            x: offsetX,
            z: offsetZ,
            width: podW,
            depth: podD,
            height: currentTotalH,
            style: struct.style,
          });
          addBox(
            podW,
            16,
            podD,
            offsetX,
            8,
            offsetZ,
            getMegaWallMaterial(podW, 16, podD, materials.concreteDarkRib),
            { isWall: true }
          );

          // Walkable Podium Promenade Deck (+16m)
          addBox(podW + 0.8, 0.4, podD + 0.8, offsetX, 16, offsetZ, materials.concreteWeatheredPath, {
            walkableTop: true,
            surface: 'concrete',
            zone: regionDefinition.acousticZone,
          });

          // Ground-Level Human Door & Colonnaded Entrance
          addHumanDoor(offsetX, 0, offsetZ + podD / 2 + 0.1, 0);

          // 2. Mid-Rise Setback Tower Shaft (from Y = 16 to Y = 16 + midH)
          const midH = Math.max(40, currentTotalH * 0.65);
          addBox(
            sw,
            midH,
            sd,
            offsetX,
            16 + midH / 2,
            offsetZ,
            getMegaWallMaterial(sw, midH, sd),
            { isWall: true }
          );

          // Mid-level observation balcony ledge at Y = 16 + midH
          addBox(sw + 3.2, 1.2, sd + 3.2, offsetX, 16 + midH, offsetZ, materials.concreteDarkRib, {
            walkableTop: true,
            surface: 'concrete',
            zone: 'sky_platform',
          });

          // 3. Crown Spire / Upper Setback (from Y = 16 + midH to currentTotalH)
          const crownH = Math.max(25, currentTotalH * 0.35);
          const crownW = sw * 0.65;
          const crownD = sd * 0.65;
          addBox(
            crownW,
            crownH,
            crownD,
            offsetX,
            16 + midH + crownH / 2,
            offsetZ,
            getMegaWallMaterial(crownW, crownH, crownD, materials.concreteDarkRib),
            { isWall: true }
          );

          // Communications Mast / Needle on apex
          const mastH = 35 + (t % 3) * 20;
          const mastGeo = trackGeo(new THREE.CylinderGeometry(0.4, 1.2, mastH, 8));
          const mastMesh = new THREE.Mesh(mastGeo, materials.rustedSteel);
          mastMesh.position.set(offsetX, 16 + midH + crownH + mastH / 2, offsetZ);
          sceneGroup.add(mastMesh);

          // Full solid wall collision for the tower
          colliders.push({
            minX: offsetX - podW / 2,
            maxX: offsetX + podW / 2,
            minZ: offsetZ - podD / 2,
            maxZ: offsetZ + podD / 2,
            minY: 0,
            maxY: currentTotalH,
            isWall: true,
          });

          // Cyberpunk vertical luminous neon beacons
          if (isCyberpunk && t % 2 === 0) {
            addBox(0.9, currentTotalH * 0.85, 0.9, offsetX + sw / 2 + 0.45, 16, offsetZ, materials.distantBeaconLight, {
              isWall: false,
              noCollision: true,
            });
          }

          // Rest bench on podium terrace for towers close to center
          if (t < 4) {
            addHumanBench(offsetX - podW / 2 + 2, 16.2, offsetZ, Math.PI / 2);
          }
        }

        // 4. ACCESSIBLE MONUMENTAL RAMPS FROM BOULEVARD TO PODIUM LEVEL (+16m)
        // Two ramps connecting ground level directly to the elevated podium network
        [-1, 1].forEach((dir) => {
          const rampX = px + dir * 32;
          const rampZ = pz - 20;
          colliders.push({
            minX: rampX - 6,
            maxX: rampX + 6,
            minZ: rampZ - 26,
            maxZ: rampZ + 26,
            minY: -1,
            maxY: 18,
            isRamp: true,
            rampAxis: 'z',
            rampStartY: 16,
            rampEndY: 0,
            surface: 'concrete',
            zone: 'colossal_staircase',
          });
          const rampMesh = new THREE.Mesh(
            trackGeo(new THREE.BoxGeometry(8, 1.2, 52)),
            materials.concreteDarkRib
          );
          rampMesh.position.set(rampX, 8, rampZ);
          rampMesh.rotation.x = Math.atan2(16, 50);
          sceneGroup.add(rampMesh);
        });

        // 5. INTERCONNECTED WALKABLE SKYBRIDGES BRIDGING STREET CANYONS
        // Level 1 (+16m): Elevated pedestrian concourse bridges
        addBox(streetSpacingX * 2.2, 1.8, 10, px, 16, pz, materials.concreteWeatheredPath, {
          walkableTop: true,
          surface: 'concrete',
          zone: 'elevated_bridge',
        });
        addBox(10, 1.8, streetSpacingZ * 2.2, px, 16, pz, materials.concreteWeatheredPath, {
          walkableTop: true,
          surface: 'concrete',
          zone: 'elevated_bridge',
        });

        // Level 2 (+68m): High-level suspended skybridge
        addBox(14, 6.5, streetSpacingZ * 2.4, px + 24, 68, pz, materials.concreteDarkRib, {
          walkableTop: true,
          surface: 'concrete',
          zone: 'elevated_bridge',
          isWall: true,
        });
        addBox(14, 1.2, 0.6, px + 24, 71.8, pz + (streetSpacingZ * 1.2), materials.concreteColossal, { isWall: true });
        addBox(14, 1.2, 0.6, px + 24, 71.8, pz - (streetSpacingZ * 1.2), materials.concreteColossal, { isWall: true });

        // Level 3 (+140m): Stratospheric skyway bridge
        addBox(streetSpacingX * 2.4, 7.5, 14, px, 140, pz - 20, materials.concreteColossal, {
          walkableTop: true,
          surface: 'concrete',
          zone: 'elevated_bridge',
          isWall: true,
        });
      } else if (struct.type === 'colossal_pillars') {
        // Aligned colonnade of titanic pillars
        const cols = 4;
        const rows = 12;
        const totalPillars = cols * rows;
        const colGeo = trackGeo(new THREE.BoxGeometry(sw, sh, sd));
        const colInst = new THREE.InstancedMesh(
          colGeo,
          getMegaWallMaterial(sw, sh, sd),
          totalPillars
        );
        colInst.castShadow = true;
        colInst.receiveShadow = true;
        colInst.frustumCulled = false;

        let idx = 0;
        for (let r = 0; r < rows; r++) {
          const rz = pz + 40 - r * 54;
          for (let c = 0; c < cols; c++) {
            const rx = px + (c - (cols - 1) / 2) * (sw * 1.5 + 42);
            dummy.position.set(rx, sh / 2, rz);
            dummy.updateMatrix();
            colInst.setMatrixAt(idx++, dummy.matrix);

            // Regra Anti-Colisão: Todo pilar possui colisor sólido impenetrável
            colliders.push({
              minX: rx - sw / 2,
              maxX: rx + sw / 2,
              minZ: rz - sd / 2,
              maxZ: rz + sd / 2,
              minY: 0,
              maxY: sh,
              isWall: true,
            });
          }
        }
        colInst.instanceMatrix.needsUpdate = true;
        sceneGroup.add(colInst);

        // Overhead arch beams
        for (let r = 1; r < rows; r += 2) {
          addBox(240, 14, 18, px, 190, pz + 40 - r * 54, materials.concreteDarkRib);
        }
      } else if (struct.type === 'viaduct_network' || struct.type === 'suspended_bridge') {
        // Vast viaduct deck overhead and walkable ramp
        const deckHeight = Math.min(sh, 140);
        addBox(
          sw * 2.2,
          12,
          1400,
          px,
          deckHeight,
          pz - 300,
          getMegaWallMaterial(sw * 2.2, 12, 1400)
        );

        // Titanic piers
        for (let pzStep = pz + 60; pzStep >= pz - 700; pzStep -= 95) {
          addBox(16, deckHeight, 14, px - 28, 0, pzStep, materials.concreteDarkRib, { isWall: true });
          addBox(16, deckHeight, 14, px + 28, 0, pzStep, materials.concreteDarkRib, { isWall: true });
        }

        // Walkable access ramp onto an elevated observation tier (+18m)
        colliders.push({
          minX: 24,
          maxX: 38,
          minZ: -140,
          maxZ: -60,
          minY: -1,
          maxY: 20,
          isRamp: true,
          rampAxis: 'z',
          rampStartY: 18,
          rampEndY: 0,
          surface: 'concrete',
          zone: 'colossal_staircase',
        });
        const ramp = new THREE.Mesh(
          trackGeo(new THREE.BoxGeometry(14, 1.4, 82)),
          materials.concreteDarkRib
        );
        ramp.position.set(31, 8.8, -100);
        ramp.rotation.x = Math.atan2(18, 80);
        sceneGroup.add(ramp);

        addBox(28, 18, 36, 31, 0, -158, materials.concreteWeatheredPath, {
          walkableTop: true,
          surface: 'concrete',
          zone: 'elevated_bridge',
        });
        addHumanBench(31, 18, -165, 0);
      } else {
        // Universal Colossal Monolith
        addBox(sw, sh, sd, px, 0, pz, getMegaWallMaterial(sw, sh, sd), { isWall: true });
        addBox(
          sw * 1.25,
          32,
          sd * 1.25,
          px,
          0,
          pz,
          getMegaWallMaterial(sw * 1.25, 32, sd * 1.25, materials.concreteDarkRib),
          { isWall: true }
        );
        addHumanDoor(px, 0, pz + sd / 2 + 0.1, 0);
      }

      // Add human scale contrasts around the main structure
      if (sIdx === 0) {
        addHumanBench(-6.5, 0, -15, Math.PI / 2);
        addHumanBench(6.5, 0, -55, -Math.PI / 2);
        addSolitaryTree(-16, 0, -25, 1.1);
        addSolitaryTree(18, 0, -85, 0.95);
      }
    });

    // 3B. GAP EVALUATION AND AUTOMATIC BRIDGE-CONNECTOR MODULES
    const evaluateGap = (
      from: StructureFootprint,
      to: StructureFootprint
    ): GapEvaluation | null => {
      const fromMinX = from.x - from.width / 2;
      const fromMaxX = from.x + from.width / 2;
      const fromMinZ = from.z - from.depth / 2;
      const fromMaxZ = from.z + from.depth / 2;
      const toMinX = to.x - to.width / 2;
      const toMaxX = to.x + to.width / 2;
      const toMinZ = to.z - to.depth / 2;
      const toMaxZ = to.z + to.depth / 2;
      const gapX = Math.max(toMinX - fromMaxX, fromMinX - toMaxX, 0);
      const gapZ = Math.max(toMinZ - fromMaxZ, fromMinZ - toMaxZ, 0);
      const distance = Math.hypot(gapX, gapZ);
      if (distance <= 0) return null;

      const axisPoints = (
        fromMin: number,
        fromMax: number,
        toMin: number,
        toMax: number,
        gap: number
      ): [number, number] => {
        if (gap > 0) {
          const fromCenter = (fromMin + fromMax) / 2;
          const toCenter = (toMin + toMax) / 2;
          return toCenter >= fromCenter
            ? [fromMax, toMin]
            : [fromMin, toMax];
        }
        const overlapStart = Math.max(fromMin, toMin);
        const overlapEnd = Math.min(fromMax, toMax);
        const shared = (overlapStart + overlapEnd) / 2;
        return [shared, shared];
      };

      const [startX, endX] = axisPoints(fromMinX, fromMaxX, toMinX, toMaxX, gapX);
      const [startZ, endZ] = axisPoints(fromMinZ, fromMaxZ, toMinZ, toMaxZ, gapZ);
      return {
        from,
        to,
        start: { x: startX, z: startZ },
        end: { x: endX, z: endZ },
        distance,
      };
    };

    const gapCandidates: GapEvaluation[] = [];
    for (let fromIndex = 0; fromIndex < structureFootprints.length; fromIndex++) {
      for (let toIndex = fromIndex + 1; toIndex < structureFootprints.length; toIndex++) {
        const from = structureFootprints[fromIndex];
        const to = structureFootprints[toIndex];
        if (Math.min(from.height, to.height) < 24) continue;
        const evaluation = evaluateGap(from, to);
        if (
          evaluation &&
          evaluation.distance >= BRIDGE_CONNECTOR_MIN_GAP &&
          evaluation.distance <= BRIDGE_CONNECTOR_MAX_GAP
        ) {
          gapCandidates.push(evaluation);
        }
      }
    }

    gapCandidates.sort((left, right) => left.distance - right.distance);
    const nodeDegrees = new Map<string, number>();
    const selectedConnectors: GapEvaluation[] = [];
    for (const candidate of gapCandidates) {
      if (selectedConnectors.length >= BRIDGE_CONNECTOR_MAX_COUNT) break;
      const fromDegree = nodeDegrees.get(candidate.from.id) || 0;
      const toDegree = nodeDegrees.get(candidate.to.id) || 0;
      if (fromDegree >= 2 || toDegree >= 2) continue;
      selectedConnectors.push(candidate);
      nodeDegrees.set(candidate.from.id, fromDegree + 1);
      nodeDegrees.set(candidate.to.id, toDegree + 1);
    }

    const addBridgeConnector = (evaluation: GapEvaluation, connectorIndex: number) => {
      const { from, to, start, end, distance } = evaluation;
      const dx = end.x - start.x;
      const dz = end.z - start.z;
      const directionLength = Math.max(distance, 0.001);
      const rotationY = -Math.atan2(dz, dx);
      const shortestHeight = Math.min(from.height, to.height);
      const bridgeY = clampNumber(
        shortestHeight * 0.42,
        18,
        Math.max(18, Math.min(shortestHeight - 6, 140))
      );
      const deckLength = Math.max(distance + 2, 5);
      const deckWidth = clampNumber(
        Math.min(from.width, from.depth, to.width, to.depth) * 0.16,
        7,
        14
      );
      const midX = (start.x + end.x) / 2;
      const midZ = (start.z + end.z) / 2;
      const moduleKey = `${from.id}__${to.id}`;
      const accentColor = [
        '#38f4ff',
        '#ff48b7',
        '#ffb347',
        '#9a6cff',
        '#65ff9d',
      ][hashString(moduleKey) % 5];

      const module = new THREE.Group();
      module.name = 'Bridge-Connector';
      module.userData.moduleType = 'Bridge-Connector';
      module.userData.from = from.id;
      module.userData.to = to.id;
      module.userData.gapMeters = distance;
      module.userData.accentColor = accentColor;
      module.position.set(midX, bridgeY, midZ);
      module.rotation.y = rotationY;

      const deckGeometry = trackGeo(new THREE.BoxGeometry(deckLength, 1.4, deckWidth));
      const deck = new THREE.Mesh(
        deckGeometry,
        getMegaWallMaterial(deckLength, 1.4, deckWidth, materials.concreteDarkRib)
      );
      deck.position.y = 0.7;
      deck.castShadow = true;
      deck.receiveShadow = true;
      module.add(deck);

      const railGeometry = trackGeo(new THREE.BoxGeometry(deckLength, 0.48, 0.22));
      const railMaterial = new THREE.MeshBasicMaterial({
        color: new THREE.Color(accentColor),
        toneMapped: false,
      });
      materialsToDispose.push(railMaterial);
      const railOffset = deckWidth / 2 - 0.16;
      const perpendicularX = -dz / directionLength;
      const perpendicularZ = dx / directionLength;
      const rotatedBounds = (
        centerX: number,
        centerZ: number,
        length: number,
        width: number
      ) => {
        const extentX =
          Math.abs(Math.cos(rotationY)) * (length / 2) +
          Math.abs(Math.sin(rotationY)) * (width / 2);
        const extentZ =
          Math.abs(Math.sin(rotationY)) * (length / 2) +
          Math.abs(Math.cos(rotationY)) * (width / 2);
        return {
          minX: centerX - extentX,
          maxX: centerX + extentX,
          minZ: centerZ - extentZ,
          maxZ: centerZ + extentZ,
        };
      };

      [-1, 1].forEach((side) => {
        const localOffset = railOffset * side;
        const rail = new THREE.Mesh(railGeometry, railMaterial);
        rail.position.set(0, 1.64, localOffset);
        module.add(rail);

        const railCenterX = midX + perpendicularX * localOffset;
        const railCenterZ = midZ + perpendicularZ * localOffset;
        const bounds = rotatedBounds(railCenterX, railCenterZ, deckLength, 0.22);
        colliders.push({
          ...bounds,
          minY: bridgeY + 1.4,
          maxY: bridgeY + 1.88,
          isWall: true,
        });
      });

      const signTexture = createHolographicSignageTexture(
        `${String(connectorIndex + 1).padStart(2, '0')} · ${from.style.toUpperCase()}`,
        distance,
        accentColor
      );
      texturesToDispose.push(signTexture);
      const signMaterial = new THREE.MeshBasicMaterial({
        map: signTexture,
        color: new THREE.Color('#ffffff'),
        transparent: true,
        opacity: 0.96,
        side: THREE.DoubleSide,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
        toneMapped: false,
      });
      materialsToDispose.push(signMaterial);
      const signGeometry = trackGeo(new THREE.PlaneGeometry(deckWidth * 1.08, 3.1));
      const sign = new THREE.Mesh(signGeometry, signMaterial);
      sign.position.set(0, 4.6, 0);
      sign.rotation.y = Math.PI / 2;
      module.add(sign);

      const hangerGeometry = trackGeo(new THREE.BoxGeometry(0.16, 3.2, 0.16));
      [-1, 1].forEach((side) => {
        const hanger = new THREE.Mesh(hangerGeometry, railMaterial);
        hanger.position.set(0, 3.05, side * deckWidth * 0.46);
        module.add(hanger);
      });

      if (connectorIndex < 2) {
        const connectorLight = new THREE.PointLight(
          new THREE.Color(accentColor),
          1.7,
          Math.max(24, Math.min(distance, 80)),
          2
        );
        connectorLight.position.y = 3.6;
        module.add(connectorLight);
      }

      const deckBounds = rotatedBounds(midX, midZ, deckLength, deckWidth);
      colliders.push({
        ...deckBounds,
        minY: bridgeY,
        maxY: bridgeY + 1.4,
        surface: 'metal',
        zone: 'elevated_bridge',
      });

      sceneGroup.add(module);
    };

    selectedConnectors.forEach((connector, index) => addBridgeConnector(connector, index));
    sceneGroup.userData.bridgeConnectorCount = selectedConnectors.length;

    // 4. VEGETATION COMPILATION (Instanced grass blades)
    if (plan.vegetation.density > 0.15 && !isConcreteOcean) {
      const grassCount = Math.floor(1200 * plan.vegetation.density);
      const bladeGeo = trackGeo(new THREE.ConeGeometry(0.18, 0.85, 3));
      bladeGeo.translate(0, 0.42, 0);
      const grassMat = new THREE.MeshLambertMaterial({
        color: new THREE.Color(plan.vegetation.foliageColor || '#586952'),
      });
      const grassInst = new THREE.InstancedMesh(bladeGeo, grassMat, grassCount);
      grassInst.frustumCulled = false;

      let gIdx = 0;
      for (let i = 0; i < grassCount; i++) {
        const gx = (Math.random() - 0.5) * 260;
        const gz = -320 + Math.random() * 380;
        if (Math.abs(gx) < 8.0) continue; // Clear central path

        dummy.position.set(gx, 0, gz);
        dummy.rotation.y = Math.random() * Math.PI;
        const sc = 0.6 + Math.random() * 0.9;
        dummy.scale.set(sc, sc, sc);
        dummy.updateMatrix();
        grassInst.setMatrixAt(gIdx++, dummy.matrix);
      }
      grassInst.count = gIdx;
      grassInst.instanceMatrix.needsUpdate = true;
      sceneGroup.add(grassInst);
    }

    // 5. LANDMARKS & ACOUSTIC RESONANCE POINTS
    const landmarksToCompile = plan.landmarks.length > 0 ? plan.landmarks : [
      {
        id: 'lm_default',
        title: regionDefinition.title,
        subtitle: regionDefinition.subtitle,
        scaleNote: 'Olhar humano a 1,72 m diante da escala monumental',
        position: [0, 0, -40],
        colossalHeightMeters: regionDefinition.colossalHeightMeters || 680,
        lookTarget: [0, 240, -180],
        fundamentalFreq: 32.7,
      },
    ];

    landmarksToCompile.forEach((lm) => {
      resonancePoints.push({
        id: lm.id,
        position: lm.position as [number, number, number],
        radius: 18,
        title: lm.title,
        scaleNote: lm.scaleNote,
        lookTarget: lm.lookTarget as [number, number, number],
        fundamentalFreq: lm.fundamentalFreq || 32.7,
      });

      // Visual resonator monument
      const [rx, ry, rz] = lm.position;
      const markerGroup = new THREE.Group();
      markerGroup.position.set(rx + 4.2, ry, rz);
      const plinth = new THREE.Mesh(
        trackGeo(new THREE.BoxGeometry(0.7, 1.5, 0.7)),
        materials.concreteDarkRib
      );
      plinth.position.y = 0.75;
      markerGroup.add(plinth);
      const totem = new THREE.Mesh(
        trackGeo(new THREE.BoxGeometry(0.3, 0.7, 0.3)),
        materials.humanScaleAccent
      );
      totem.position.y = 1.75;
      markerGroup.add(totem);
      sceneGroup.add(markerGroup);
    });

    // 6. PORTALS COMPILATION
    if (plan.portals.length > 0) {
      plan.portals.forEach((p) => {
        addArchitecturalPortal({
          id: p.id,
          position: p.position as [number, number, number],
          radius: p.radius || 10,
          targetRegion: p.targetRegionId as RegionId,
          passageType: p.passageType || 'Pórtico Monumental',
          label: p.label || 'Passagem Liminar',
        });
      });
    } else {
      // Default exit portal back to canon world
      addArchitecturalPortal({
        id: `portal_to_vale_${regionDefinition.id}`,
        position: [0, 0, -280],
        radius: 10,
        targetRegion: 'vale_pilares',
        passageType: 'Pórtico de Retorno Canônico',
        label: 'Vale dos Pilares Colossais',
      });
    }

    // 7. ATMOSPHERIC LAYERS
    const cloudGroup = new THREE.Group();
    const cloudPlaneGeo = trackGeo(new THREE.PlaneGeometry(500, 500));
    cloudPlaneGeo.rotateX(-Math.PI / 2);
    for (let i = 0; i < 28; i++) {
      const cloudMesh = new THREE.Mesh(cloudPlaneGeo, materials.cloudLayerMaterial);
      cloudMesh.position.set(
        (Math.random() - 0.5) * 2400,
        220 + (i % 4) * 35,
        -150 + (Math.random() - 0.5) * 2200
      );
      cloudMesh.rotation.y = Math.random() * Math.PI * 2;
      cloudGroup.add(cloudMesh);
    }
    sceneGroup.add(cloudGroup);

    const lowMistGroup = new THREE.Group();
    const mistPlaneGeo = trackGeo(new THREE.PlaneGeometry(160, 160));
    mistPlaneGeo.rotateX(-Math.PI / 2);
    for (let i = 0; i < 16; i++) {
      const mistMesh = new THREE.Mesh(mistPlaneGeo, materials.lowMistMaterial);
      mistMesh.position.set(
        (Math.random() - 0.5) * 320,
        2.5 + (i % 3) * 2.2,
        60 - i * 36
      );
      lowMistGroup.add(mistMesh);
    }
    sceneGroup.add(lowMistGroup);

    // Rain lines
    const rainCount = 900;
    const rainPositions = new Float32Array(rainCount * 6);
    for (let i = 0; i < rainCount; i++) {
      const rx = (Math.random() - 0.5) * 70;
      const ry = Math.random() * 38;
      const rz = (Math.random() - 0.5) * 70;
      const idx = i * 6;
      rainPositions[idx] = rx;
      rainPositions[idx + 1] = ry;
      rainPositions[idx + 2] = rz;
      rainPositions[idx + 3] = rx - 0.35;
      rainPositions[idx + 4] = ry - 2.4;
      rainPositions[idx + 5] = rz;
    }
    const rainGeo = trackGeo(new THREE.BufferGeometry());
    rainGeo.setAttribute('position', new THREE.BufferAttribute(rainPositions, 3));
    const rainMaterial = new THREE.LineBasicMaterial({
      color: new THREE.Color('#c9d6de'),
      transparent: true,
      opacity: 0.0,
      depthWrite: false,
    });
    const rainLines = new THREE.LineSegments(rainGeo, rainMaterial);
    rainLines.visible = false;
    sceneGroup.add(rainLines);

    const handles: AnimatedWorldHandles = {
      pendulumGroup: null,
      upperRingMesh: null,
      lowerRingMesh: null,
      birdFlockInstanced: null,
      cloudGroup,
      lowMistGroup,
      rainLines,
      rainMaterial,
      grassShaderUniforms: {
        uTime: { value: 0 },
        uWindStrength: { value: plan.atmosphere.windMultiplier || 1.0 },
      },
      skyMaterial,
    };

    // 8. PHYSICS AND ELEVATION RESOLVER
    const worldBounds = { minX: -260, maxX: 260, minZ: -480, maxZ: 100 };
    const defaultGroundSurface: SurfaceMaterialType = isConcreteOcean ? 'concrete' : 'grass';
    const defaultZone: AcousticZone = regionDefinition.acousticZone || 'open_meadow';

    const resolvePlayerPhysics = (
      prevPos: THREE.Vector3,
      desiredPos: THREE.Vector3,
      playerRadius: number
    ) => {
      const nextPos = desiredPos.clone();
      nextPos.x = Math.max(worldBounds.minX, Math.min(worldBounds.maxX, nextPos.x));
      nextPos.z = Math.max(worldBounds.minZ, Math.min(worldBounds.maxZ, nextPos.z));

      for (const box of colliders) {
        if (!box.isWall) continue;
        // If player is standing safely on top of this structure, don't collide with the wall:
        if (prevPos.y >= box.maxY - 0.1) continue;
        // If player is completely below or above the vertical extents:
        if (prevPos.y + 1.85 < box.minY) continue;

        const minX = box.minX - playerRadius;
        const maxX = box.maxX + playerRadius;
        const minZ = box.minZ - playerRadius;
        const maxZ = box.maxZ + playerRadius;

        if (nextPos.x > minX && nextPos.x < maxX && nextPos.z > minZ && nextPos.z < maxZ) {
          const wasOutsideX = prevPos.x <= minX || prevPos.x >= maxX;
          const wasOutsideZ = prevPos.z <= minZ || prevPos.z >= maxZ;

          if (wasOutsideX && !wasOutsideZ) {
            nextPos.x = prevPos.x <= minX ? minX : maxX;
          } else if (wasOutsideZ && !wasOutsideX) {
            nextPos.z = prevPos.z <= minZ ? minZ : maxZ;
          } else if (wasOutsideX && wasOutsideZ) {
            const penX = prevPos.x <= minX ? (nextPos.x - minX) : (maxX - nextPos.x);
            const penZ = prevPos.z <= minZ ? (nextPos.z - minZ) : (maxZ - nextPos.z);
            if (penX < penZ) {
              nextPos.x = prevPos.x <= minX ? minX : maxX;
            } else {
              nextPos.z = prevPos.z <= minZ ? minZ : maxZ;
            }
          } else {
            // Push out to the nearest surface
            const dLeft = Math.abs(nextPos.x - minX);
            const dRight = Math.abs(maxX - nextPos.x);
            const dBottom = Math.abs(nextPos.z - minZ);
            const dTop = Math.abs(maxZ - nextPos.z);
            const minD = Math.min(dLeft, dRight, dBottom, dTop);
            if (minD === dLeft) nextPos.x = minX;
            else if (minD === dRight) nextPos.x = maxX;
            else if (minD === dBottom) nextPos.z = minZ;
            else nextPos.z = maxZ;
          }
        }
      }

      let groundY = 0.0;
      let surface: SurfaceMaterialType = defaultGroundSurface;
      let zone: AcousticZone = defaultZone;

      for (const box of colliders) {
        if (box.isWall) continue;
        if (
          nextPos.x >= box.minX &&
          nextPos.x <= box.maxX &&
          nextPos.z >= box.minZ &&
          nextPos.z <= box.maxZ
        ) {
          if (box.isRamp && box.rampStartY !== undefined && box.rampEndY !== undefined) {
            const t = (nextPos.z - box.minZ) / (box.maxZ - box.minZ);
            const rampY = box.rampStartY + t * (box.rampEndY - box.rampStartY);
            if (Math.abs(prevPos.y - rampY) < 4.8 && rampY >= groundY) {
              groundY = rampY;
              if (box.surface) surface = box.surface;
              if (box.zone) zone = box.zone;
            }
          } else {
            const topY = box.maxY;
            if (prevPos.y + 1.8 >= topY && topY >= groundY) {
              groundY = topY;
              if (box.surface) surface = box.surface;
              if (box.zone) zone = box.zone;
            }
          }
        }
      }

      nextPos.y = groundY;
      return { position: nextPos, groundY, surface, zone };
    };

    const dispose = () => {
      geometriesToDispose.forEach((g) => g.dispose());
      materialsToDispose.forEach((material) => material.dispose());
      texturesToDispose.forEach((texture) => texture.dispose());
      rainMaterial.dispose();
      skyMaterial.dispose();
    };

    return {
      regionId: regionDefinition.id,
      sceneGroup,
      colliders,
      resonancePoints,
      portals,
      handles,
      dispose,
      resolvePlayerPhysics,
    };
  }
}
