import {
  WorldPlan,
  WorldPatch,
  WORLD_SIZE_MAP,
  WorldSizeLabel,
  WorldRegionDefinition,
} from './types/worldPlan';
import { WEATHER_PRESETS } from './AtmospherePresets';

export interface ValidationResult<T> {
  isValid: boolean;
  data: T;
  warnings: string[];
  errors: string[];
}

export class WorldPlanValidator {
  /**
   * Validates and sanitizes a raw WorldPlan object returned by any AI provider.
   * Auto-repairs missing fields, clamps out-of-range numerical parameters,
   * and guarantees a structurally stable world plan for the Three.js compiler.
   */
  public static validate(raw: any, fallbackPrompt = ''): ValidationResult<WorldPlan> {
    const warnings: string[] = [];
    const errors: string[] = [];

    if (!raw || typeof raw !== 'object') {
      errors.push('O plano do mundo retornado pela IA não é um objeto JSON válido.');
      return {
        isValid: false,
        data: this.createEmergencyFallbackPlan(fallbackPrompt),
        warnings,
        errors,
      };
    }

    const worldId = typeof raw.worldId === 'string' && raw.worldId.trim().length > 0
      ? raw.worldId.trim()
      : `world_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;

    const name = typeof raw.name === 'string' && raw.name.trim().length > 0
      ? raw.name.trim()
      : 'Mundo Colossal Desconhecido';

    const tagline = typeof raw.tagline === 'string' ? raw.tagline : 'Paisagem monumental gerada por IA';
    const theme = typeof raw.theme === 'string' ? raw.theme : 'brutalist_colossal';

    // Normalize world size
    let scaleLabel: WorldSizeLabel = '20km';
    if (raw.size && typeof raw.size.scaleLabel === 'string' && WORLD_SIZE_MAP[raw.size.scaleLabel as WorldSizeLabel]) {
      scaleLabel = raw.size.scaleLabel as WorldSizeLabel;
    } else if (raw.size && typeof raw.size.width === 'number') {
      const w = raw.size.width;
      if (w >= 400000) scaleLabel = '500km';
      else if (w >= 80000) scaleLabel = '100km';
      else if (w >= 40000) scaleLabel = '50km';
      else if (w >= 15000) scaleLabel = '20km';
      else scaleLabel = '10km';
    }

    const sizeSpec = WORLD_SIZE_MAP[scaleLabel];
    const size = {
      width: sizeSpec.widthMeters,
      depth: sizeSpec.depthMeters,
      scaleLabel,
    };

    const seed = typeof raw.seed === 'number' && !isNaN(raw.seed)
      ? raw.seed
      : Math.floor(Math.random() * 1000000);

    // Normalize Terrain
    const rawTerrain = raw.terrain || {};
    const terrainTypes = [
      'tropical_forest',
      'concrete_ocean',
      'mountain_ravine',
      'crater_basin',
      'island_abyss',
      'desert_dunes',
      'subterranean_cavern',
      'coastal_cliffs',
    ] as const;

    const terrainType = terrainTypes.includes(rawTerrain.type) ? rawTerrain.type : 'tropical_forest';
    const terrain = {
      type: terrainType,
      heightVariation: this.clamp(typeof rawTerrain.heightVariation === 'number' ? rawTerrain.heightVariation : 0.65, 0.05, 1.0),
      waterLevel: this.clamp(typeof rawTerrain.waterLevel === 'number' ? rawTerrain.waterLevel : 0.25, 0.0, 0.9),
      roughness: this.clamp(typeof rawTerrain.roughness === 'number' ? rawTerrain.roughness : 0.7, 0.1, 1.0),
      baseElevation: this.clamp(typeof rawTerrain.baseElevation === 'number' ? rawTerrain.baseElevation : 0, -200, 2000),
    };

    // Normalize Atmosphere
    const rawAtmo = raw.atmosphere || {};
    const presetId = (rawAtmo.presetId && WEATHER_PRESETS[rawAtmo.presetId as keyof typeof WEATHER_PRESETS])
      ? rawAtmo.presetId
      : 'manha_neblina';
    const basePreset = WEATHER_PRESETS[presetId as keyof typeof WEATHER_PRESETS] || WEATHER_PRESETS.manha_neblina;

    const atmosphere = {
      presetId,
      skyTopColor: this.sanitizeHexColor(rawAtmo.skyTopColor, basePreset.skyTopColor),
      skyHorizonColor: this.sanitizeHexColor(rawAtmo.skyHorizonColor, basePreset.skyHorizonColor),
      fogColor: this.sanitizeHexColor(rawAtmo.fogColor, basePreset.fogColor),
      fogDensity: this.clamp(typeof rawAtmo.fogDensity === 'number' ? rawAtmo.fogDensity : basePreset.fogDensity, 0.0005, 0.015),
      sunColor: this.sanitizeHexColor(rawAtmo.sunColor, basePreset.sunColor),
      sunIntensity: this.clamp(typeof rawAtmo.sunIntensity === 'number' ? rawAtmo.sunIntensity : basePreset.sunIntensity, 0.2, 3.5),
      ambientColor: this.sanitizeHexColor(rawAtmo.ambientColor, basePreset.ambientColor),
      ambientIntensity: this.clamp(typeof rawAtmo.ambientIntensity === 'number' ? rawAtmo.ambientIntensity : basePreset.ambientIntensity, 0.3, 2.0),
      sunElevationDeg: this.clamp(typeof rawAtmo.sunElevationDeg === 'number' ? rawAtmo.sunElevationDeg : basePreset.sunElevationDeg, 5, 85),
      sunAzimuthDeg: typeof rawAtmo.sunAzimuthDeg === 'number' ? rawAtmo.sunAzimuthDeg : basePreset.sunAzimuthDeg,
      cloudOpacity: this.clamp(typeof rawAtmo.cloudOpacity === 'number' ? rawAtmo.cloudOpacity : basePreset.cloudOpacity, 0.1, 1.0),
      windMultiplier: this.clamp(typeof rawAtmo.windMultiplier === 'number' ? rawAtmo.windMultiplier : basePreset.windMultiplier, 0.4, 3.0),
      rainIntensity: this.clamp(typeof rawAtmo.rainIntensity === 'number' ? rawAtmo.rainIntensity : basePreset.rainIntensity, 0.0, 1.0),
    };

    // Normalize Biomes
    const biomes: any[] = [];
    if (Array.isArray(raw.biomes) && raw.biomes.length > 0) {
      raw.biomes.forEach((b: any, idx: number) => {
        if (!b || typeof b !== 'object') return;
        biomes.push({
          id: b.id || `biome_${idx}`,
          name: b.name || `Bioma ${idx + 1}`,
          description: b.description || 'Zona ecológica monumental',
          coverageRatio: this.clamp(typeof b.coverageRatio === 'number' ? b.coverageRatio : 1 / raw.biomes.length, 0.05, 1.0),
          colorPalette: {
            ground: this.sanitizeHexColor(b.colorPalette?.ground, '#6c7a65'),
            accent: this.sanitizeHexColor(b.colorPalette?.accent, '#b06c49'),
            foliage: this.sanitizeHexColor(b.colorPalette?.foliage, '#3f4f3c'),
            water: this.sanitizeHexColor(b.colorPalette?.water, '#2c353b'),
          },
          dominantSurface: ['grass', 'concrete', 'metal', 'water'].includes(b.dominantSurface) ? b.dominantSurface : 'grass',
          acousticZone: b.acousticZone || 'open_meadow',
        });
      });
    }

    if (biomes.length === 0) {
      biomes.push({
        id: 'biome_core',
        name: 'Região Monumental Primária',
        description: 'Vasta extensão de arquitetura colossal e topografia procedural',
        coverageRatio: 1.0,
        colorPalette: {
          ground: '#6c7a65',
          accent: '#b06c49',
          foliage: '#3f4f3c',
          water: '#2c353b',
        },
        dominantSurface: 'grass',
        acousticZone: 'open_meadow',
      });
    }

    // Normalize Structures
    const structures: any[] = [];
    if (Array.isArray(raw.structures)) {
      raw.structures.forEach((s: any, idx: number) => {
        if (!s || typeof s !== 'object') return;
        const width = this.clamp(s.scale?.[0] ?? 40, 5, 2000);
        const height = this.clamp(s.scale?.[1] ?? 520, 20, 3000);
        const depth = this.clamp(s.scale?.[2] ?? 40, 5, 2000);

        structures.push({
          id: s.id || `struct_${idx}`,
          name: s.name || `Estrutura ${idx + 1}`,
          type: s.type || 'colossal_pillars',
          style: s.style || 'brutalist',
          position: [
            typeof s.position?.[0] === 'number' ? s.position[0] : 0,
            typeof s.position?.[1] === 'number' ? s.position[1] : 0,
            typeof s.position?.[2] === 'number' ? s.position[2] : -100 - idx * 60,
          ],
          scale: [width, height, depth],
          density: this.clamp(typeof s.density === 'number' ? s.density : 0.7, 0.1, 1.0),
          heightRange: [
            this.clamp(s.heightRange?.[0] ?? 50, 10, 500),
            this.clamp(s.heightRange?.[1] ?? height, 100, 3000),
          ],
          materials: Array.isArray(s.materials) ? s.materials : ['concreteColossal'],
          features: Array.isArray(s.features) ? s.features : ['human_doors', 'cantilever_slabs'],
        });
      });
    }

    if (structures.length === 0) {
      structures.push({
        id: 'struct_main',
        name: 'Complexo Megalítico Central',
        type: 'colossal_pillars',
        style: 'brutalist',
        position: [0, 0, -180],
        scale: [36, 680, 36],
        density: 0.8,
        heightRange: [80, 680],
        materials: ['concreteColossal', 'concreteDarkRib'],
        features: ['human_doors', 'skybridges'],
      });
    }

    // Normalize Roads
    const roads: any[] = [];
    if (Array.isArray(raw.roads)) {
      raw.roads.forEach((r: any, idx: number) => {
        if (!r || typeof r !== 'object') return;
        roads.push({
          id: r.id || `road_${idx}`,
          name: r.name || `Via Monumental ${idx + 1}`,
          widthMeters: this.clamp(typeof r.widthMeters === 'number' ? r.widthMeters : 18, 4, 150),
          elevation: typeof r.elevation === 'number' ? r.elevation : 0,
          fromPosition: r.fromPosition || [0, 0, 50],
          toPosition: r.toPosition || [0, 0, -350],
          isElevatedViaduct: Boolean(r.isElevatedViaduct),
          material: ['grass', 'concrete', 'metal', 'water'].includes(r.material) ? r.material : 'concrete',
        });
      });
    }

    // Normalize Vegetation
    const rawVeg = raw.vegetation || {};
    const vegetation = {
      density: this.clamp(typeof rawVeg.density === 'number' ? rawVeg.density : 0.6, 0.0, 1.0),
      dominantType: rawVeg.dominantType || 'tropical_canopy',
      foliageColor: this.sanitizeHexColor(rawVeg.foliageColor, '#3f4f3c'),
      averageHeightMeters: this.clamp(typeof rawVeg.averageHeightMeters === 'number' ? rawVeg.averageHeightMeters : 4.8, 1.5, 45),
    };

    // Normalize Landmarks
    const landmarks: any[] = [];
    if (Array.isArray(raw.landmarks) && raw.landmarks.length > 0) {
      raw.landmarks.forEach((lm: any, idx: number) => {
        if (!lm || typeof lm !== 'object') return;
        landmarks.push({
          id: lm.id || `landmark_${idx}`,
          title: lm.title || `Marco Colossal ${idx + 1}`,
          subtitle: lm.subtitle || 'Ponto de contemplação de escala',
          scaleNote: lm.scaleNote || 'Olhar humano diante de estruturas monumentais',
          position: lm.position || [0, 0, -30 - idx * 100],
          colossalHeightMeters: this.clamp(typeof lm.colossalHeightMeters === 'number' ? lm.colossalHeightMeters : 520, 50, 3000),
          lookTarget: lm.lookTarget || [0, 180, -180 - idx * 100],
          fundamentalFreq: typeof lm.fundamentalFreq === 'number' ? lm.fundamentalFreq : 32.7,
        });
      });
    } else {
      landmarks.push({
        id: 'lm_primario',
        title: 'Nadir da Estrutura Colossal',
        subtitle: 'Ponto focal de ressonância acústica e perspectiva monumental',
        scaleNote: 'Dimensão arquitetônica incomparável contra a imensidão do horizonte',
        position: [0, 0, -35],
        colossalHeightMeters: structures[0]?.scale?.[1] || 680,
        lookTarget: [0, 220, -180],
        fundamentalFreq: 32.7,
      });
    }

    // Normalize Portals
    const portals: any[] = [];
    if (Array.isArray(raw.portals)) {
      raw.portals.forEach((p: any, idx: number) => {
        if (!p || typeof p !== 'object') return;
        portals.push({
          id: p.id || `portal_${idx}`,
          targetRegionId: p.targetRegionId || 'vale_pilares',
          position: p.position || [0, 0, -250],
          radius: this.clamp(typeof p.radius === 'number' ? p.radius : 10, 4, 30),
          label: p.label || 'Pórtico de Transição Liminar',
          passageType: p.passageType || 'Passagem Monolítica',
        });
      });
    }

    // Normalize Regions (Partition the world into logical grid regions)
    const regions: WorldRegionDefinition[] = [];
    if (Array.isArray(raw.regions) && raw.regions.length > 0) {
      raw.regions.forEach((r: any, idx: number) => {
        if (!r || typeof r !== 'object') return;
        regions.push({
          id: r.id || `region_${idx}`,
          gridCoord: Array.isArray(r.gridCoord) ? [r.gridCoord[0], r.gridCoord[1]] : [idx % sizeSpec.regionGridSize, Math.floor(idx / sizeSpec.regionGridSize)],
          title: r.title || `Setor ${idx + 1}`,
          subtitle: r.subtitle || 'Região monumental procedural',
          acousticDescription: r.acousticDescription || 'Vozes do vento e ressonância grave',
          biomeId: r.biomeId || biomes[0].id,
          acousticZone: r.acousticZone || biomes[0].acousticZone,
          defaultWeather: presetId,
          colossalHeightMeters: typeof r.colossalHeightMeters === 'number' ? r.colossalHeightMeters : structures[0]?.scale?.[1] || 520,
          spawnOffset: r.spawnOffset || [0, 0, 40],
          structureIds: Array.isArray(r.structureIds) ? r.structureIds : [structures[0]?.id],
          portalIds: Array.isArray(r.portalIds) ? r.portalIds : [],
          landmarkIds: Array.isArray(r.landmarkIds) ? r.landmarkIds : [landmarks[0]?.id],
        });
      });
    }

    // If regions are empty, create initial primary region
    if (regions.length === 0) {
      regions.push({
        id: `${worldId}_region_0`,
        gridCoord: [0, 0],
        title: `${name} — Setor Central`,
        subtitle: tagline,
        acousticDescription: 'Silêncio contemplativo, vento distante e eco em superfícies colossais',
        biomeId: biomes[0].id,
        acousticZone: biomes[0].acousticZone,
        defaultWeather: presetId,
        colossalHeightMeters: structures[0]?.scale?.[1] || 680,
        spawnOffset: [0, 0, 40],
        structureIds: structures.map((s) => s.id),
        portalIds: portals.map((p) => p.id),
        landmarkIds: landmarks.map((l) => l.id),
      });
    }

    const plan: WorldPlan = {
      worldId,
      name,
      tagline,
      theme,
      size,
      seed,
      terrain,
      biomes,
      structures,
      roads,
      vegetation,
      landmarks,
      atmosphere,
      portals,
      regions,
      metadata: {
        generatedByProvider: raw.metadata?.generatedByProvider || 'AI Provider',
        model: raw.metadata?.model || 'unknown-model',
        createdAt: typeof raw.metadata?.createdAt === 'number' ? raw.metadata.createdAt : Date.now(),
        version: '1.0.0',
        generationPrompt: fallbackPrompt,
      },
    };

    return {
      isValid: true,
      data: plan,
      warnings,
      errors,
    };
  }

  /**
   * Validates a WorldPatch before applying it to the world.
   */
  public static validatePatch(raw: any, currentPlan: WorldPlan): ValidationResult<WorldPatch> {
    const warnings: string[] = [];
    const errors: string[] = [];

    if (!raw || typeof raw !== 'object') {
      errors.push('O patch de modificação não é um objeto válido.');
      return {
        isValid: false,
        data: {
          patchId: `patch_err_${Date.now()}`,
          worldId: currentPlan.worldId,
          targetRegion: currentPlan.regions[0]?.id || 'region_0',
          description: 'Patch inválido',
          operations: [],
        },
        warnings,
        errors,
      };
    }

    const patchId = raw.patchId || `patch_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    const targetRegion = typeof raw.targetRegion === 'string' && raw.targetRegion.trim().length > 0
      ? raw.targetRegion.trim()
      : currentPlan.regions[0]?.id || 'region_0';

    const operations: any[] = [];
    if (Array.isArray(raw.operations)) {
      raw.operations.forEach((op: any) => {
        if (!op || typeof op !== 'object' || !op.type) return;
        operations.push({
          type: op.type,
          payload: op.payload || {},
        });
      });
    }

    return {
      isValid: errors.length === 0,
      data: {
        patchId,
        worldId: currentPlan.worldId,
        targetRegion,
        description: raw.description || 'Modificação localizada de região',
        operations,
        appliedAt: Date.now(),
      },
      warnings,
      errors,
    };
  }

  private static clamp(v: number, min: number, max: number): number {
    if (isNaN(v)) return min;
    return Math.max(min, Math.min(max, v));
  }

  private static sanitizeHexColor(hex: any, fallback: string): string {
    if (typeof hex === 'string' && /^#([0-9A-Fa-f]{3}|[0-9A-Fa-f]{6})$/.test(hex.trim())) {
      return hex.trim();
    }
    return fallback;
  }

  private static createEmergencyFallbackPlan(prompt: string): WorldPlan {
    const sizeSpec = WORLD_SIZE_MAP['20km'];
    return {
      worldId: `world_emergency_${Date.now()}`,
      name: 'Monólito Cósmico',
      tagline: 'Vasta paisagem de pilares e estruturas colossais',
      theme: 'brutalist_colossal',
      size: {
        width: sizeSpec.widthMeters,
        depth: sizeSpec.depthMeters,
        scaleLabel: '20km',
      },
      seed: 42,
      terrain: {
        type: 'tropical_forest',
        heightVariation: 0.65,
        waterLevel: 0.25,
        roughness: 0.7,
        baseElevation: 0,
      },
      biomes: [
        {
          id: 'biome_core',
          name: 'Vale dos Pilares',
          description: 'Vale verde atravessado por pilares alinhados que somem na cerração',
          coverageRatio: 1.0,
          colorPalette: {
            ground: '#6c7a65',
            accent: '#b06c49',
            foliage: '#3f4f3c',
            water: '#2c353b',
          },
          dominantSurface: 'grass',
          acousticZone: 'open_meadow',
        },
      ],
      structures: [
        {
          id: 'struct_fallback_pillars',
          name: 'Alinhamento dos Pilares de 520 Metros',
          type: 'colossal_pillars',
          style: 'brutalist',
          position: [0, 0, -120],
          scale: [28, 520, 28],
          density: 0.85,
          heightRange: [50, 520],
          materials: ['concreteColossal'],
          features: ['human_doors'],
        },
      ],
      roads: [
        {
          id: 'road_central',
          name: 'Avenida de Pedra Monumental',
          widthMeters: 14,
          elevation: 0,
          fromPosition: [0, 0, 50],
          toPosition: [0, 0, -320],
          isElevatedViaduct: false,
          material: 'concrete',
        },
      ],
      vegetation: {
        density: 0.6,
        dominantType: 'tropical_canopy',
        foliageColor: '#3f4f3c',
        averageHeightMeters: 5.2,
      },
      landmarks: [
        {
          id: 'lm_core',
          title: 'Corredor das Colunas Alinhadas',
          subtitle: 'Visão de pilares de 520 m de altura',
          scaleNote: 'Olhar humano a 1,72 m diante da escala vertical brutalista',
          position: [0, 0, -32],
          colossalHeightMeters: 520,
          lookTarget: [-32, 220, -84],
          fundamentalFreq: 43.65,
        },
      ],
      atmosphere: {
        presetId: 'manha_neblina',
        skyTopColor: '#73828c',
        skyHorizonColor: '#b8c2c7',
        fogColor: '#b5bfc4',
        fogDensity: 0.0026,
        sunColor: '#fff6e8',
        sunIntensity: 1.55,
        ambientColor: '#8d9aa3',
        ambientIntensity: 0.85,
        sunElevationDeg: 22,
        sunAzimuthDeg: -38,
        cloudOpacity: 0.78,
        windMultiplier: 1.0,
        rainIntensity: 0,
      },
      portals: [
        {
          id: 'portal_to_orig',
          targetRegionId: 'vale_pilares',
          position: [0, 0, -245],
          radius: 10,
          label: 'Vale dos Pilares Canônico',
          passageType: 'Pórtico Monumental',
        },
      ],
      regions: [
        {
          id: 'region_fallback_0',
          gridCoord: [0, 0],
          title: 'Região Inicial do Monólito',
          subtitle: 'Estruturas colossais sob neblina matinal',
          acousticDescription: 'Vento e eco distante entre pilares',
          biomeId: 'biome_core',
          acousticZone: 'open_meadow',
          defaultWeather: 'manha_neblina',
          colossalHeightMeters: 520,
          spawnOffset: [0, 0, 40],
          structureIds: ['struct_fallback_pillars'],
          portalIds: ['portal_to_orig'],
          landmarkIds: ['lm_core'],
        },
      ],
      metadata: {
        generatedByProvider: 'Fallback Engine',
        model: 'deterministic-generator',
        createdAt: Date.now(),
        version: '1.0.0',
        generationPrompt: prompt,
      },
    };
  }
}
