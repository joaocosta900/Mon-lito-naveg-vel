import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import * as THREE from 'three';
import {
  applyTransform,
  clusterStructures,
  createSelectionVisual,
  IDENTITY_TRANSFORM,
  readTransform,
  resetTransform,
  StructureTransform,
  SpectatorCluster,
  syncSelectionVisual,
} from './SpectatorStructures';
import { anchorFor, clearEdit, loadEdits, saveEdit } from './SpectatorEditStore';

export interface SpectatorState {
  active: boolean;
  clusterCount: number;
  selectedId: string | null;
  transform: StructureTransform;
  /** Quantas peças compose a construção escolhida. */
  selectedPieces: number;
  /** Tamanho da construção escolhida em metros, no estado original. */
  selectedSize: { x: number; y: number; z: number } | null;
}

export interface SpectatorApi {
  state: SpectatorState;
  enter: () => void;
  exit: () => void;
  /** Toque/click na tela: seleciona a construção sob o cursor. */
  pickAt: (normalizedX: number, normalizedY: number) => boolean;
  /** Desloca a construção em metros, no eixo escolhido. */
  nudge: (axis: 'x' | 'y' | 'z', delta: number) => void;
  /** Gira a construção, em radianos, em torno do próprio pivô. */
  rotateBy: (axis: 'x' | 'y' | 'z', delta: number) => void;
  /** Multiplica um eixo da escala. */
  scaleBy: (axis: 'x' | 'y' | 'z', factor: number) => void;
  resetSelection: () => void;
  deselect: () => void;
}

/**
 * Qual construção o raio atravessa primeiro, pela caixa envolvente.
 *
 * Só é usado como reserva: o acerto por malha continua sendo o caminho
 * principal, e este só entra quando o raio não pegou peça nenhuma.
 */
export function nearestClusterAlongRay(
  ray: THREE.Ray,
  clusters: SpectatorCluster[]
): SpectatorCluster | null {
  const box = new THREE.Box3();
  const point = new THREE.Vector3();
  let best: SpectatorCluster | null = null;
  let bestDistance = Infinity;
  for (const cluster of clusters) {
    cluster.group.updateMatrixWorld(true);
    box.setFromObject(cluster.group);
    if (box.isEmpty()) continue;
    if (!ray.intersectBox(box, point)) continue;
    const distance = point.distanceToSquared(ray.origin);
    if (distance < bestDistance) {
      bestDistance = distance;
      best = cluster;
    }
  }
  return best;
}

const IDLE: SpectatorState = {
  active: false,
  clusterCount: 0,
  selectedId: null,
  transform: { ...IDENTITY_TRANSFORM },
  selectedPieces: 0,
  selectedSize: null,
};

/**
 * Liga o modo espectador à cena viva.
 *
 * O agrupamento é caro (O(n²) sobre as malhas), então só acontece ao entrar no
 * modo — e é refeito quando o mundo é reconstruído, não a cada quadro.
 */
export function useSpectatorMode(
  sceneGroup: THREE.Group | null,
  camera: THREE.Camera | null,
  /** Identidade da região-edited. Separa as edições de cada região do mundo. */
  scopeId: string
): SpectatorApi {
  const [state, setState] = useState<SpectatorState>(IDLE);
  const clustersRef = useRef<SpectatorCluster[]>([]);
  const selectedRef = useRef<SpectatorCluster | null>(null);
  const visualRef = useRef<ReturnType<typeof createSelectionVisual> | null>(null);
  const raycasterRef = useRef(new THREE.Raycaster());

  // Reflete o transform aplicado, para o painel mostrar os valores atuais.
  const pushState = useCallback((active: boolean) => {
    const selected = selectedRef.current;
    const size = selected?.bounds.getSize(new THREE.Vector3());
    setState({
      active,
      clusterCount: clustersRef.current.length,
      selectedId: selected?.id ?? null,
      transform: selected ? readTransform(selected) : { ...IDENTITY_TRANSFORM },
      selectedPieces: selected?.meshes.length ?? 0,
      selectedSize: size ? { x: size.x, y: size.y, z: size.z } : null,
    });
  }, []);

  // Mundo para o qual os clusters atuais pertencem. Enquanto for o mesmo, os
  // clusters seguem válidos e — o que importa — a âncora de cada construção não
  // muda, porque o pivô continua sendo o do mundo original.
  const builtForRef = useRef<THREE.Group | null>(null);

  const build = useCallback(() => {
    if (!sceneGroup) return;
    if (builtForRef.current === sceneGroup && clustersRef.current.length > 0) {
      // Mesmo mundo: as edições já estão aplicadas e visíveis na cena. Reagrupar
      // aqui mediria as construções já movidas, e a âncora deixaria de bater
      // com a que foi gravada.
      return;
    }
    // Mundo novo (recarga, troca de região): os clusters antigos pertenciam à
    // cena que acabou de ser descartada, então só são largados.
    builtForRef.current = sceneGroup;
    clustersRef.current = clusterStructures(sceneGroup);
    selectedRef.current = null;

    // Reaplica o que o jogador já editou nesta região: o mundo foi reconstruído
    // do zero, mas a edição é dado salvo, não estado de tela.
    const saved = loadEdits(scopeId).entries;
    for (const cluster of clustersRef.current) {
      const edit = saved[anchorFor(cluster.origin)];
      if (edit) applyTransform(cluster, edit);
    }
  }, [sceneGroup, scopeId]);

  const enter = useCallback(() => {
    if (!sceneGroup || !camera) return;
    build();
    if (!visualRef.current) visualRef.current = createSelectionVisual();
    const visual = visualRef.current;
    visual.box.visible = false;
    visual.highlight.visible = false;
    sceneGroup.add(visual.box);
    sceneGroup.add(visual.highlight);
    pushState(true);
  }, [build, camera, pushState, sceneGroup]);

  const exit = useCallback(() => {
    const visual = visualRef.current;
    if (visual) {
      visual.box.removeFromParent();
      visual.highlight.removeFromParent();
      visual.box.visible = false;
      visual.highlight.visible = false;
    }
    // Sair NÃO desfaz o trabalho: as construções ficam como o jogador deixou.
    // Para isso os clusters continuam vivos, com a transformação aplicada, e
    // só a interface some. Desmontá-los aqui devolveria tudo ao tamanho
    // original — era esse o bug — e reagrupar depois mediria as construções já
    // movidas, quebrando a âncora usada para reaplicar as edições salvas.
    selectedRef.current = null;
    setState({ ...IDLE });
  }, []);

  const pickAt = useCallback(
    (normalizedX: number, normalizedY: number) => {
      if (!camera || !state.active) return false;
      const visual = visualRef.current;
      if (visual) syncSelectionVisual(visual, null);

      raycasterRef.current.setFromCamera(
        new THREE.Vector2(normalizedX, normalizedY),
        camera
      );
      const meshes = clustersRef.current.flatMap((cluster) => cluster.meshes);
      const hits = raycasterRef.current.intersectObjects(meshes, false);
      const hit = hits[0];
      const hitId = hit?.object.userData.spectatorClusterId as string | undefined;
      let cluster: SpectatorCluster | null | undefined = hitId
        ? clustersRef.current.find((item) => item.id === hitId) ??
          clustersRef.current.find((item) => item.meshes.includes(hit!.object as THREE.Mesh))
        : undefined;
      if (!cluster && hit) {
        cluster = clustersRef.current.find((item) => item.meshes.includes(hit.object as THREE.Mesh));
      }
      if (!cluster) {
        // Câmera livre costuma ficar colada — ou dentro — da construção, e de
        // dentro o raio não acerta face nenhuma (as traseiras não são testadas).
        // Nesse caso vale a construção cuja caixa o raio atravessa primeiro.
        cluster = nearestClusterAlongRay(raycasterRef.current.ray, clustersRef.current);
      }
      if (!cluster) {
        selectedRef.current = null;
        pushState(true);
        return false;
      }
      selectedRef.current = cluster;
      if (visual) syncSelectionVisual(visual, cluster);
      pushState(true);
      return true;
    },
    [camera, pushState, state.active]
  );

  // Aplica, grava e redesenha numa função só: toda edição passa por aqui, senão
  // uma delas esqueceria de sincronizar a caixa de seleção.
  const commit = useCallback(
    (next: StructureTransform) => {
      const cluster = selectedRef.current;
      if (!cluster) return;
      applyTransform(cluster, next);
      saveEdit(scopeId, anchorFor(cluster.origin), next);
      const visual = visualRef.current;
      if (visual) syncSelectionVisual(visual, cluster);
      pushState(true);
    },
    [pushState, scopeId]
  );

  const nudge = useCallback(
    (axis: 'x' | 'y' | 'z', delta: number) => {
      const cluster = selectedRef.current;
      if (!cluster) return;
      const current = readTransform(cluster);
      const next = { ...current };
      if (axis === 'x') next.offsetX += delta;
      if (axis === 'y') next.offsetY += delta;
      if (axis === 'z') next.offsetZ += delta;
      commit(next);
    },
    [commit]
  );

  const rotateBy = useCallback(
    (axis: 'x' | 'y' | 'z', delta: number) => {
      const cluster = selectedRef.current;
      if (!cluster) return;
      const current = readTransform(cluster);
      const next = { ...current };
      if (axis === 'x') next.rotX += delta;
      if (axis === 'y') next.rotY += delta;
      if (axis === 'z') next.rotZ += delta;
      commit(next);
    },
    [commit]
  );

  const scaleBy = useCallback(
    (axis: 'x' | 'y' | 'z', factor: number) => {
      const cluster = selectedRef.current;
      if (!cluster) return;
      const current = readTransform(cluster);
      const next = {
        ...current,
        scaleX: axis === 'x' ? current.scaleX * factor : current.scaleX,
        scaleY: axis === 'y' ? current.scaleY * factor : current.scaleY,
        scaleZ: axis === 'z' ? current.scaleZ * factor : current.scaleZ,
      };
      commit(next);
    },
    [commit]
  );

  const resetSelection = useCallback(() => {
    const cluster = selectedRef.current;
    if (!cluster) return;
    resetTransform(cluster);
    // RESTAURAR é um comando de dados: apaga a edição salva, senão ela voltaria
    // na próxima vez que a região for reconstruída.
    clearEdit(scopeId, anchorFor(cluster.origin));
    const visual = visualRef.current;
    if (visual) syncSelectionVisual(visual, cluster);
    pushState(true);
  }, [pushState, scopeId]);

  const deselect = useCallback(() => {
    selectedRef.current = null;
    const visual = visualRef.current;
    if (visual) syncSelectionVisual(visual, null);
    pushState(true);
  }, [pushState]);

  // Mundo reconstruído (troca de região): os clusters antigos não valem mais.
  useEffect(() => {
    if (!state.active) return;
    build();
    const visual = visualRef.current;
    if (visual && sceneGroup && !visual.box.parent) sceneGroup.add(visual.box);
    if (visual && sceneGroup && !visual.highlight.parent) sceneGroup.add(visual.highlight);
    pushState(true);
  }, [build, pushState, sceneGroup, state.active]);

  useEffect(
    () => () => {
      visualRef.current?.dispose();
      visualRef.current = null;
    },
    []
  );

  return useMemo(
    () => ({ state, enter, exit, pickAt, nudge, rotateBy, scaleBy, resetSelection, deselect }),
    [deselect, exit, nudge, pickAt, resetSelection, rotateBy, scaleBy, state]
  );
}
