import { AcousticZone, WeatherPresetId, SurfaceMaterialType } from '../../types/world';

export type WorldSizeKm = 10 | 20 | 50 | 100 | 500;
export type WorldSizeLabel = '10km' | '20km' | '50km' | '100km' | '500km';

export interface WorldSizeSpec {
  label: WorldSizeLabel;
  widthMeters: number;
  depthMeters: number;
  regionGridSize: number; // e.g. 5x5 for 10km, 8x8 for 20km, 12x12 for 50km
  chunkDimensionMeters: number;
}

export const WORLD_SIZE_MAP: Record<WorldSizeLabel, WorldSizeSpec> = {
  '10km': {
    label: '10km',
    widthMeters: 10000,
    depthMeters: 10000,
    regionGridSize: 5,
    chunkDimensionMeters: 2000,
  },
  '20km': {
    label: '20km',
    widthMeters: 20000,
    depthMeters: 20000,
    regionGridSize: 8,
    chunkDimensionMeters: 2500,
  },
  '50km': {
    label: '50km',
    widthMeters: 50000,
    depthMeters: 50000,
    regionGridSize: 10,
    chunkDimensionMeters: 5000,
  },
  '100km': {
    label: '100km',
    widthMeters: 100000,
    depthMeters: 100000,
    regionGridSize: 14,
    chunkDimensionMeters: 7142,
  },
  '500km': {
    label: '500km',
    widthMeters: 500000,
    depthMeters: 500000,
    regionGridSize: 20,
    chunkDimensionMeters: 25000,
  },
};

export interface WorldTerrainSpec {
  type:
    | 'tropical_forest'
    | 'concrete_ocean'
    | 'mountain_ravine'
    | 'crater_basin'
    | 'island_abyss'
    | 'desert_dunes'
    | 'subterranean_cavern'
    | 'coastal_cliffs';
  heightVariation: number; // 0.0 to 1.0
  waterLevel: number; // 0.0 to 1.0 (sea level / river elevation ratio)
  roughness: number; // 0.0 to 1.0
  baseElevation: number; // in meters
}

export interface WorldBiomeSpec {
  id: string;
  name: string;
  description: string;
  coverageRatio: number; // e.g. 0.35
  colorPalette: {
    ground: string;
    accent: string;
    foliage?: string;
    water?: string;
  };
  dominantSurface: SurfaceMaterialType;
  acousticZone: AcousticZone;
}

export interface WorldStructureSpec {
  id: string;
  name: string;
  type:
    | 'megacity'
    | 'megatower'
    | 'colossal_pillars'
    | 'viaduct_network'
    | 'cathedral'
    | 'suspended_bridge'
    | 'subterranean_tunnel'
    | 'inverted_pendulum'
    | 'orbital_tether'
    | 'industrial_complex'
    | 'ancient_ruin'
    | 'floating_citadel'
    | 'solitary_monolith';
  style:
    | 'brutalist'
    | 'cyberpunk'
    | 'ancient_futuristic'
    | 'biomechanical'
    | 'minimalist_monumental'
    | 'industrial_decay';
  position: [number, number, number]; // [x, y, z] in meters relative to world center
  scale: [number, number, number]; // [width, height, depth] in meters
  density: number; // 0.0 to 1.0
  heightRange: [number, number]; // e.g. [50, 800]
  roadDensity?: number;
  neonDensity?: number;
  materials: string[];
  features: string[]; // e.g. ["skybridges", "glowing_ribs", "cantilever_slabs", "human_doors"]
}

export interface WorldRoadSpec {
  id: string;
  name: string;
  widthMeters: number;
  elevation: number;
  fromPosition: [number, number, number];
  toPosition: [number, number, number];
  isElevatedViaduct: boolean;
  material: SurfaceMaterialType;
}

export interface WorldVegetationSpec {
  density: number; // 0.0 to 1.0
  dominantType: 'coniferous' | 'tropical_canopy' | 'solitary_windbent' | 'sparse_shrubs' | 'none';
  foliageColor: string;
  averageHeightMeters: number;
}

export interface WorldLandmarkSpec {
  id: string;
  title: string;
  subtitle: string;
  scaleNote: string;
  position: [number, number, number];
  colossalHeightMeters: number;
  lookTarget: [number, number, number];
  fundamentalFreq: number;
}

export interface WorldAtmosphereSpec {
  presetId: WeatherPresetId;
  skyTopColor: string;
  skyHorizonColor: string;
  fogColor: string;
  fogDensity: number;
  sunColor: string;
  sunIntensity: number;
  ambientColor: string;
  ambientIntensity: number;
  sunElevationDeg: number;
  sunAzimuthDeg: number;
  cloudOpacity: number;
  windMultiplier: number;
  rainIntensity: number;
}

export interface WorldPortalSpec {
  id: string;
  targetRegionId: string;
  position: [number, number, number];
  radius: number;
  label: string;
  passageType: string;
}

export interface WorldRegionDefinition {
  id: string;
  gridCoord: [number, number]; // [col, row]
  title: string;
  subtitle: string;
  acousticDescription: string;
  biomeId: string;
  acousticZone: AcousticZone;
  defaultWeather: WeatherPresetId;
  colossalHeightMeters: number;
  spawnOffset: [number, number, number];
  structureIds: string[];
  portalIds: string[];
  landmarkIds: string[];
}

export interface WorldPlan {
  worldId: string;
  name: string;
  tagline: string;
  theme: string;
  size: {
    width: number;
    depth: number;
    scaleLabel: WorldSizeLabel;
  };
  seed: number;
  terrain: WorldTerrainSpec;
  biomes: WorldBiomeSpec[];
  structures: WorldStructureSpec[];
  roads: WorldRoadSpec[];
  vegetation: WorldVegetationSpec;
  landmarks: WorldLandmarkSpec[];
  atmosphere: WorldAtmosphereSpec;
  portals: WorldPortalSpec[];
  regions: WorldRegionDefinition[];
  metadata: {
    generatedByProvider: string;
    model: string;
    createdAt: number;
    version: string;
    generationPrompt: string;
  };
}

export interface WorldPatchOperation {
  type:
    | 'addStructure'
    | 'removeStructure'
    | 'modifyAtmosphere'
    | 'addPortal'
    | 'addLandmark'
    | 'adjustTerrain';
  payload: any;
}

export interface WorldPatch {
  patchId: string;
  worldId: string;
  targetRegion: string; // e.g. "region_0_1"
  description: string;
  operations: WorldPatchOperation[];
  appliedAt?: number;
}

export interface WorldState {
  worldId: string;
  seed: number;
  dimensions: {
    widthMeters: number;
    depthMeters: number;
    scaleLabel: WorldSizeLabel;
  };
  plan: WorldPlan;
  regions: Record<string, WorldRegionDefinition>;
  structures: Record<string, WorldStructureSpec>;
  landmarks: Record<string, WorldLandmarkSpec>;
  portals: Record<string, WorldPortalSpec>;
  modifications: WorldPatch[];
  activeRegionId: string;
  playerPosition: [number, number, number];
  metadata: {
    createdAt: number;
    updatedAt: number;
    lastProviderUsed: string;
    version: number;
  };
}
