import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import * as THREE from 'three';
import {
  Volume2,
  VolumeX,
  SlidersHorizontal,
  Compass,
  Sparkles,
  Cpu,
  Layers,
  Wrench,
  X,
  Eye,
} from 'lucide-react';
import {
  PlayerTelemetry,
  QualityTier,
  RegionId,
  WeatherPresetId,
} from './types/world';
import {
  REGIONS_LIST,
  REGIONS_MAP,
  WEATHER_PRESETS,
} from './world/AtmospherePresets';
import { SpatialAudioEngine } from './audio/SpatialAudioEngine';
import { ColossalViewport } from './components/ColossalViewport';
import { TouchControlsOverlay } from './components/TouchControlsOverlay';
import { AIProvidersPanel } from './components/AIProvidersPanel';
import { CreateWorldModal } from './components/CreateWorldModal';
import { WorldPatchModal } from './components/WorldPatchModal';
import { SavedWorldsDrawer } from './components/SavedWorldsDrawer';
import { SpectatorPanel } from './components/SpectatorPanel';
import { useSpectatorMode } from './world/useSpectatorMode';
import { CreatorWorldsPanel } from './components/CreatorWorldsPanel';
import { WorldPlan, WorldPatch } from './world/types/worldPlan';
import { WorldPlanCache } from './world/WorldPlanCache';
import { DEFAULT_FUTURISTIC_PLAN } from './world/FuturisticWorldPlan';
import { AIProviderManager } from './ai/AIProviderManager';
import { ChunkStreamingState } from './world/WorldStreamingManager';

const WEATHER_ORDER: WeatherPresetId[] = [
  'manha_neblina',
  'dia_azul',
  'ceu_nublado',
  'vento_forte',
  'chuva_fraca',
  'chuva_intensa',
  'neblina_densa',
  'por_do_sol',
  'noite_futurista',
  'ceu_limpo',
  'crepusculo_orbital',
  'abismo_oceanico',
  'nevoa_antigravidade',
  'aurora_polar',
  'br2049_laranja_vegas',
  'br2049_los_angeles_neon',
];

export default function App() {
  const [hasStarted, setHasStarted] = useState(false);
  const [regionId, setRegionId] = useState<RegionId>('horizon_megacity');
  const [weatherId, setWeatherId] = useState<WeatherPresetId>(
    DEFAULT_FUTURISTIC_PLAN.atmosphere.presetId
  );
  const [dynamicWeatherCycle, setDynamicWeatherCycle] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [fov, setFov] = useState(74);
  const [qualityTier, setQualityTier] = useState<QualityTier>('equilibrado');
  const [isRunning, setIsRunning] = useState(false);
  const [showTouchControls, setShowTouchControls] = useState(true);

  // Modals & Panels
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [drawerTab, setDrawerTab] = useState<'regions' | 'atmosphere'>('regions');
  const [isProvidersOpen, setIsProvidersOpen] = useState(false);
  const [isCreateWorldOpen, setIsCreateWorldOpen] = useState(false);
  const [isPatchModalOpen, setIsPatchModalOpen] = useState(false);
  const [isSavedWorldsOpen, setIsSavedWorldsOpen] = useState(false);
  const [isCreatorOpen, setIsCreatorOpen] = useState(false);

  // Custom AI World State
  const [activeCustomPlan, setActiveCustomPlan] = useState<WorldPlan | null>(() => {
    const savedPlan = WorldPlanCache.getPlan(DEFAULT_FUTURISTIC_PLAN.worldId);
    const initialPlan = savedPlan || DEFAULT_FUTURISTIC_PLAN;
    WorldPlanCache.savePlan(initialPlan);
    return initialPlan;
  });
  const [activeCustomRegionId, setActiveCustomRegionId] = useState<string | null>(
    DEFAULT_FUTURISTIC_PLAN.regions[0]?.id || null
  );
  const [streamingState, setStreamingState] = useState<ChunkStreamingState | null>(null);

  // ---- Modo espectador: editar construções já existentes no mundo ----
  const [spectatorSceneGroup, setSpectatorSceneGroup] = useState<THREE.Group | null>(null);
  const [spectatorCamera, setSpectatorCamera] = useState<THREE.Camera | null>(null);
  const spectatorPickHandlerRef = useRef<
    ((normalizedX: number, normalizedY: number) => void) | null
  >(null);
  // Controle da câmera livre: eixo vertical dos botões Subir/Descer e o
  // multiplicador de velocidade do Turbo. Vive em ref porque o loop de
  // animação lê a cada quadro sem re-renderizar.
  const spectatorFlyRef = useRef({ vertical: 0, speed: 1 });
  // Cada região tem seu próprio conjunto de edições. Mundo canônico e mundo
  // customizado não podem compartilhar o mesmo escopo, senão as construções de
  // um reapareceriam editadas no outro.
  const spectatorScopeId = activeCustomPlan
    ? `custom:${activeCustomRegionId ?? 'regiao_padrao'}`
    : `canonico:${regionId}`;
  const spectator = useSpectatorMode(
    spectatorSceneGroup,
    spectatorCamera,
    spectatorScopeId
  );
  const [isSpectatorActive, setIsSpectatorActive] = useState(false);

  // O viewport chama este callback no toque quando o modo está ligado.
  const handleSpectatorSceneReady = useCallback(
    (group: THREE.Group | null, camera: THREE.Camera | null) => {
      setSpectatorSceneGroup(group);
      setSpectatorCamera(camera);
    },
    []
  );

  const handleToggleSpectator = useCallback(() => {
    // Decidido fora do setState: chamar setState do hook dentro do atualizador
    // do React é antipadrão e embaralha a ordem de render.
    const next = !isSpectatorActive;
    if (next) {
      spectator.enter();
      registerUserActivity();
    } else {
      spectator.exit();
    }
    setIsSpectatorActive(next);
  }, [isSpectatorActive, spectator]);

  // Mantém o handler de seleção do viewport apontando para o hook.
  useEffect(() => {
    spectatorPickHandlerRef.current = spectator.pickAt;
  }, [spectator.pickAt]);

  // Sai do modo se o mundo for reconstruído enquanto ele estava ligado.
  useEffect(() => {
    setIsSpectatorActive(false);
    spectator.exit();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [regionId, activeCustomPlan, activeCustomRegionId]);

  const [uiActive, setUiActive] = useState(true);
  const [isTransitioningRegion, setIsTransitioningRegion] = useState(false);
  const [regionArrivalBanner, setRegionArrivalBanner] = useState<{
    number: string;
    title: string;
    subtitle: string;
  } | null>(null);
  const [resonancePulseText, setResonancePulseText] = useState<string | null>(null);

  const [telemetry, setTelemetry] = useState<PlayerTelemetry>({
    regionId: 'vale_pilares',
    x: 0,
    y: 0,
    z: 40,
    pitchDeg: 6,
    yawDeg: 0,
    zone: 'open_meadow',
    surface: 'concrete',
    nearbyResonance: null,
    nearbyPortal: null,
    lookingAtMegastructure: false,
    perceivedStructureHeightMeters: null,
  });

  const audioEngine = useMemo(() => new SpatialAudioEngine(), []);
  const providerManager = useMemo(() => AIProviderManager.getInstance(), []);

  const joystickVectorRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const touchLookDeltaRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const triggerContextualActionRef = useRef<(() => void) | null>(null);
  const jumpRequestRef = useRef(false);
  const uiFadeTimerRef = useRef<number | null>(null);
  const arrivalBannerTimerRef = useRef<number | null>(null);

  const registerUserActivity = useCallback(() => {
    setUiActive(true);
    if (uiFadeTimerRef.current) {
      window.clearTimeout(uiFadeTimerRef.current);
    }
    uiFadeTimerRef.current = window.setTimeout(() => {
      setUiActive(false);
    }, 4500);
  }, []);

  useEffect(() => {
    return () => {
      if (uiFadeTimerRef.current) window.clearTimeout(uiFadeTimerRef.current);
      if (arrivalBannerTimerRef.current) window.clearTimeout(arrivalBannerTimerRef.current);
    };
  }, []);

  // Weather cycle
  useEffect(() => {
    if (!hasStarted || !dynamicWeatherCycle) return;
    const interval = window.setInterval(() => {
      setWeatherId((prev) => {
        const idx = WEATHER_ORDER.indexOf(prev);
        return WEATHER_ORDER[(idx + 1) % WEATHER_ORDER.length];
      });
    }, 50000);
    return () => window.clearInterval(interval);
  }, [hasStarted, dynamicWeatherCycle]);

  const showArrivalTitle = useCallback(
    (title: string, subtitle: string, numberStr = 'AI') => {
      setRegionArrivalBanner({
        number: numberStr,
        title,
        subtitle,
      });
      if (arrivalBannerTimerRef.current) {
        window.clearTimeout(arrivalBannerTimerRef.current);
      }
      arrivalBannerTimerRef.current = window.setTimeout(() => {
        setRegionArrivalBanner(null);
      }, 4200);
    },
    []
  );

  const handleRegionChange = useCallback(
    (targetRegion: RegionId) => {
      if (isTransitioningRegion) return;
      setIsTransitioningRegion(true);
      setDrawerOpen(false);
      setResonancePulseText(null);

      window.setTimeout(() => {
        if (activeCustomPlan) {
          const customReg = activeCustomPlan.regions.find((r) => r.id === targetRegion);
          if (customReg) {
            setActiveCustomRegionId(targetRegion);
            showArrivalTitle(customReg.title, customReg.subtitle, 'SETOR');
          } else {
            // Might be transitioning back to a canonical region
            setActiveCustomPlan(null);
            setActiveCustomRegionId(null);
            setRegionId(targetRegion);
            const meta = REGIONS_MAP[targetRegion] || REGIONS_MAP['vale_pilares'];
            setWeatherId(meta.defaultWeather);
            showArrivalTitle(meta.title, meta.subtitle, meta.number);
          }
        } else {
          const meta = REGIONS_MAP[targetRegion] || REGIONS_MAP['vale_pilares'];
          setRegionId(targetRegion);
          setWeatherId(meta.defaultWeather);
          showArrivalTitle(meta.title, meta.subtitle, meta.number);
        }

        window.setTimeout(() => {
          setIsTransitioningRegion(false);
        }, 450);
      }, 380);
    },
    [activeCustomPlan, isTransitioningRegion, showArrivalTitle]
  );

  const handleStartExploration = () => {
    audioEngine.init();
    setHasStarted(true);
    registerUserActivity();

    if (activeCustomPlan) {
      showArrivalTitle(activeCustomPlan.name, activeCustomPlan.tagline, 'AI');
    } else {
      const meta = REGIONS_MAP[regionId] || REGIONS_MAP['vale_pilares'];
      showArrivalTitle(meta.title, meta.subtitle, meta.number);
    }

    const canvas = document.querySelector('canvas');
    if (canvas && !('ontouchstart' in window) && canvas.requestPointerLock) {
      try {
        canvas.requestPointerLock();
      } catch {
        // pointer lock fallback
      }
    }
  };

  const handleToggleMute = () => {
    audioEngine.init();
    const next = !isMuted;
    setIsMuted(next);
    audioEngine.setMuted(next);
    registerUserActivity();
  };

  const handleWorldCreated = useCallback(
    (plan: WorldPlan, providerUsed: string) => {
      WorldPlanCache.savePlan(plan);
      setActiveCustomPlan(plan);
      setActiveCustomRegionId(plan.regions[0]?.id || null);
      setWeatherId(plan.atmosphere.presetId);
      setHasStarted(true);
      registerUserActivity();

      showArrivalTitle(
        plan.name,
        `Sintetizado com sucesso por ${providerUsed} · Escala ${plan.size.scaleLabel}`,
        'IA'
      );
    },
    [registerUserActivity, showArrivalTitle]
  );

  const handlePatchApplied = useCallback(
    (patch: WorldPatch, providerUsed: string) => {
      if (!activeCustomPlan) return;

      // Apply patch selectively to the target region without modifying other regions
      const updatedPlan: WorldPlan = JSON.parse(JSON.stringify(activeCustomPlan));

      patch.operations.forEach((op) => {
        if (op.type === 'addStructure' && op.payload) {
          updatedPlan.structures.push(op.payload);
          const targetReg = updatedPlan.regions.find((r) => r.id === patch.targetRegion);
          if (targetReg && !targetReg.structureIds.includes(op.payload.id)) {
            targetReg.structureIds.push(op.payload.id);
          }
        } else if (op.type === 'modifyAtmosphere' && op.payload) {
          if (op.payload.presetId) updatedPlan.atmosphere.presetId = op.payload.presetId;
          if (op.payload.fogDensity) updatedPlan.atmosphere.fogDensity = op.payload.fogDensity;
        } else if (op.type === 'addLandmark' && op.payload) {
          updatedPlan.landmarks.push(op.payload);
        }
      });

      WorldPlanCache.savePlan(updatedPlan);
      setActiveCustomPlan(updatedPlan);
      registerUserActivity();

      setResonancePulseText(
        `WorldPatch aplicado em ${patch.targetRegion} via ${providerUsed}: ${patch.description}`
      );
      window.setTimeout(() => setResonancePulseText(null), 5500);
    },
    [activeCustomPlan, registerUserActivity]
  );

  const handleSelectCustomWorld = useCallback(
    (plan: WorldPlan) => {
      setActiveCustomPlan(plan);
      setActiveCustomRegionId(plan.regions[0]?.id || null);
      setWeatherId(plan.atmosphere.presetId);
      showArrivalTitle(plan.name, plan.tagline, 'IA');
    },
    [showArrivalTitle]
  );

  const handleSelectCanonicalRegion = useCallback(
    (canonId: RegionId) => {
      setActiveCustomPlan(null);
      setActiveCustomRegionId(null);
      setRegionId(canonId);
      const meta = REGIONS_MAP[canonId] || REGIONS_MAP['vale_pilares'];
      setWeatherId(meta.defaultWeather);
      showArrivalTitle(meta.title, meta.subtitle, meta.number);
    },
    [showArrivalTitle]
  );

  const handleTriggerContextualAction = useCallback(() => {
    if (telemetry.nearbyPortal) {
      if (triggerContextualActionRef.current) {
        triggerContextualActionRef.current();
      }
      return;
    }
    if (triggerContextualActionRef.current) {
      triggerContextualActionRef.current();
    }
    const label = telemetry.nearbyResonance
      ? `${telemetry.nearbyResonance.title} · ${telemetry.nearbyResonance.scaleNote}`
      : 'O eco grave percorre quilômetros de concreto antes de se dissipar na neblina.';
    setResonancePulseText(label);
    window.setTimeout(() => {
      setResonancePulseText(null);
    }, 5200);
  }, [telemetry.nearbyPortal, telemetry.nearbyResonance]);

  const currentRegionMeta = REGIONS_MAP[regionId] || REGIONS_MAP['vale_pilares'];
  const currentWeatherMeta = WEATHER_PRESETS[weatherId] || WEATHER_PRESETS.manha_neblina;
  const activeProvider = providerManager.getActiveConfig();

  const isModalOpen =
    drawerOpen ||
    isProvidersOpen ||
    isCreateWorldOpen ||
    isPatchModalOpen ||
    isSavedWorldsOpen ||
    isCreatorOpen;

  return (
    <main className="relative w-full h-full overflow-hidden bg-[#0d0f11] text-[#e2e4e6] select-none">
      {/* 3D WebGL Spatial World Viewport */}
      <ColossalViewport
        hasStarted={hasStarted}
        regionId={regionId}
        weatherId={weatherId}
        fov={fov}
        qualityTier={qualityTier}
        isRunning={isRunning}
        joystickVector={joystickVectorRef}
        touchLookDelta={touchLookDeltaRef}
        audioEngine={audioEngine}
        triggerContextualActionRef={triggerContextualActionRef}
        jumpRequestRef={jumpRequestRef}
        onRegionChangeRequest={handleRegionChange}
        onTelemetryUpdate={setTelemetry}
        onUserActivity={registerUserActivity}
        customWorldPlan={activeCustomPlan}
        activeCustomRegionId={activeCustomRegionId}
        onStreamingUpdate={setStreamingState}
        spectatorActive={isSpectatorActive}
        onSceneReady={handleSpectatorSceneReady}
        spectatorPickHandlerRef={spectatorPickHandlerRef}
        spectatorFlyRef={spectatorFlyRef}
      />

      {/* Cinematic Fog Transition Veil */}
      <div
        className={`fixed inset-0 z-25 bg-[#121619] pointer-events-none transition-opacity duration-500 ${
          isTransitioningRegion ? 'opacity-100' : 'opacity-0'
        }`}
      />

      {/* 3-Zone Top Bar */}
      {hasStarted && (
        <header
          className={`fixed top-0 left-0 right-0 z-20 flex flex-col gap-2 px-3 py-2.5 sm:flex-row sm:items-center sm:justify-between sm:gap-4 sm:px-5 sm:py-3.5 transition-opacity duration-700 pointer-events-none ${
            uiActive || isModalOpen ? 'opacity-95' : 'opacity-20 hover:opacity-95'
          }`}
        >
          {/* Zone 1: Brand Wordmark */}
          <div className="pointer-events-auto flex w-full items-center justify-between gap-3 sm:w-auto sm:justify-start">
            <span className="font-display text-lg font-semibold tracking-wider text-white/95">
              MONOLITO
            </span>
            {activeCustomPlan && (
              <span className="whitespace-nowrap text-[10px] text-emerald-400 font-mono-tabular border border-emerald-500/30 bg-emerald-500/10 px-2 py-0.5 rounded-md">
                <span className="hidden sm:inline">WORLD PLANNER IA</span>
                <span className="sm:hidden">IA</span>
              </span>
            )}
          </div>

          {/* Zone 2: Quiet unboxed region, weather, scale & AI Provider status */}
          <div className="hidden lg:flex items-center gap-2 text-xs text-white/70 font-sans">
            <span>
              {activeCustomPlan
                ? activeCustomPlan.name
                : `${currentRegionMeta.number}. ${currentRegionMeta.title}`}
            </span>
            <span aria-hidden="true">·</span>
            <span>{currentWeatherMeta.name}</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono-tabular">
              {activeCustomPlan
                ? `Escala ${activeCustomPlan.size.scaleLabel}`
                : `Elevação ${telemetry.y >= 0 ? `+${telemetry.y}` : telemetry.y} m`}
            </span>
            {activeProvider && (
              <>
                <span aria-hidden="true">·</span>
                <span className="font-mono-tabular text-white/50">
                  {activeProvider.name} ({activeProvider.model})
                </span>
              </>
            )}
          </div>

          {/* Zone 3: Primary Actions */}
          <div className="pointer-events-auto grid w-full grid-cols-6 items-center gap-1.5 sm:flex sm:w-auto sm:gap-2">
            {/* Audio Toggle */}
            <button
              type="button"
              onClick={handleToggleMute}
              className="min-h-[42px] w-full flex items-center justify-center rounded-xl bg-black/45 backdrop-blur-sm border border-white/10 text-white/80 hover:text-white hover:bg-black/65 transition-colors cursor-pointer sm:w-auto sm:min-w-[42px]"
              aria-label={isMuted ? 'Ativar áudio espacial' : 'Silenciar áudio espacial'}
              title={isMuted ? 'Ativar áudio' : 'Silenciar áudio'}
            >
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>

            {/* Spectator / Edit Existing Structures */}
            <button
              type="button"
              onClick={handleToggleSpectator}
              disabled={!hasStarted}
              className={`min-h-[42px] w-full flex items-center justify-center gap-2 rounded-xl backdrop-blur-sm border text-xs font-medium transition-colors cursor-pointer sm:w-auto sm:min-w-[42px] ${
                isSpectatorActive
                  ? 'bg-emerald-500/25 border-emerald-400/60 text-emerald-100'
                  : 'bg-black/45 border-white/10 text-white/80 hover:text-white hover:bg-black/65'
              } disabled:opacity-30`}
              aria-label="Modo espectador: editar construções existentes"
              aria-pressed={isSpectatorActive}
              title="Espectador: tocar, mover e redimensionar construções"
            >
              <Eye className="w-4 h-4" />
            </button>

            {/* AI Providers Panel Button */}
            <button
              type="button"
              onClick={() => {
                setIsProvidersOpen(true);
                registerUserActivity();
              }}
              className="min-h-[42px] w-full flex items-center justify-center gap-2 rounded-xl bg-black/45 backdrop-blur-sm border border-white/10 text-xs font-medium text-white/85 hover:text-white hover:bg-black/65 transition-colors cursor-pointer sm:w-auto sm:px-3.5 sm:py-2"
              title="Configurar Provedores de IA"
            >
              <Cpu className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">AI Providers</span>
            </button>

            {/* Create World Button */}
            <button
              type="button"
              onClick={() => {
                setIsCreateWorldOpen(true);
                registerUserActivity();
              }}
              className="min-h-[42px] w-full flex items-center justify-center gap-2 rounded-xl bg-white text-[#0d0f11] text-xs font-semibold hover:bg-white/90 transition-colors shadow-md cursor-pointer sm:w-auto sm:px-3.5 sm:py-2"
              title="Sintetizar Novo Mundo com IA"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Create World</span>
            </button>

            {/* Worlds & Regions Switcher */}
            <button
              type="button"
              onClick={() => {
                setIsSavedWorldsOpen(true);
                registerUserActivity();
              }}
              className="min-h-[42px] w-full flex items-center justify-center gap-2 rounded-xl bg-black/45 backdrop-blur-sm border border-white/10 text-xs font-medium text-white/85 hover:text-white hover:bg-black/65 transition-colors cursor-pointer sm:w-auto sm:px-3.5 sm:py-2"
              aria-label="Abrir mundos e regiões"
              title="Mundos e regiões"
            >
              <Compass className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Mundos</span>
            </button>

            {/* Atmosphere & Camera */}
            <button
              type="button"
              onClick={() => {
                setDrawerTab('atmosphere');
                setDrawerOpen(true);
                registerUserActivity();
              }}
              className="min-h-[42px] w-full flex items-center justify-center rounded-xl bg-black/45 backdrop-blur-sm border border-white/10 text-white/80 hover:text-white hover:bg-black/65 transition-colors cursor-pointer sm:w-auto sm:min-w-[42px]"
              title="Meteorologia e Câmera"
            >
              <SlidersHorizontal className="w-4 h-4" />
            </button>
          </div>
        </header>
      )}

      {/* Region Arrival Title Card */}
      {hasStarted && regionArrivalBanner && !isModalOpen && (
        <div className="fixed top-32 left-1/2 -translate-x-1/2 z-15 pointer-events-none text-center px-4 transition-opacity duration-700 sm:top-20">
          <p className="text-[11px] tracking-widest text-white/50 font-mono-tabular">
            {regionArrivalBanner.number.startsWith('0') || regionArrivalBanner.number.startsWith('1')
              ? `REGIÃO ${regionArrivalBanner.number}`
              : regionArrivalBanner.number}
          </p>
          <h2 className="font-display text-2xl sm:text-3xl text-white/95 tracking-wide mt-0.5">
            {regionArrivalBanner.title}
          </h2>
          <p className="text-xs text-white/65 mt-1 max-w-md mx-auto">
            {regionArrivalBanner.subtitle}
          </p>
        </div>
      )}

      {/* Subtle Bottom Scale / Resonance Caption */}
      {hasStarted &&
        !isModalOpen &&
        (telemetry.nearbyPortal ||
          resonancePulseText ||
          telemetry.nearbyResonance ||
          telemetry.lookingAtMegastructure) && (
          <div className="fixed bottom-24 left-1/2 -translate-x-1/2 z-10 max-w-xl w-[88%] pointer-events-none text-center transition-opacity duration-500">
            <div className="inline-block px-4 py-2 rounded-xl bg-black/60 backdrop-blur-xs border border-white/10 text-xs text-[#e2e4e6]/90 leading-relaxed shadow-lg">
              {telemetry.nearbyPortal ? (
                <span>
                  {telemetry.nearbyPortal.passageType} <span aria-hidden="true">·</span>{' '}
                  <span className="text-white">
                    Caminhe através do pórtico ou pressione [E] para ir a{' '}
                    {telemetry.nearbyPortal.label}
                  </span>
                </span>
              ) : resonancePulseText ? (
                <span>{resonancePulseText}</span>
              ) : telemetry.nearbyResonance ? (
                <span>
                  {telemetry.nearbyResonance.title} <span aria-hidden="true">·</span>{' '}
                  <span className="text-white/65">{telemetry.nearbyResonance.scaleNote}</span>
                </span>
              ) : (
                <span>
                  Escala vertical dominante:{' '}
                  <span className="font-mono-tabular text-white">
                    {telemetry.perceivedStructureHeightMeters ??
                      (activeCustomPlan
                        ? activeCustomPlan.structures[0]?.scale[1] || 680
                        : currentRegionMeta.colossalHeightMeters)}{' '}
                    m
                  </span>{' '}
                  <span aria-hidden="true">·</span>{' '}
                  <span className="text-white/65">
                    Olhar humano a 1,72 m diante da estrutura monumental
                  </span>
                </span>
              )}
            </div>
          </div>
        )}

      {/* Mobile & Touch Controls Overlay */}
      {hasStarted && (
        <TouchControlsOverlay
          visible={showTouchControls}
          uiActive={uiActive}
          isRunning={isRunning}
          onToggleRun={() => setIsRunning((r) => !r)}
          nearbyResonance={telemetry.nearbyResonance}
          nearbyPortal={telemetry.nearbyPortal}
          lookingAtMegastructure={telemetry.lookingAtMegastructure}
          onTriggerContextualAction={handleTriggerContextualAction}
          onJump={() => {
            jumpRequestRef.current = true;
            registerUserActivity();
          }}
          joystickVector={joystickVectorRef}
          touchLookDelta={touchLookDeltaRef}
          onUserActivity={registerUserActivity}
          spectatorActive={isSpectatorActive}
          spectatorFlyRef={spectatorFlyRef}
        />
      )}

      {/* Spectator Edit Panel */}
      {hasStarted && (
        <SpectatorPanel
          state={spectator.state}
          onExit={handleToggleSpectator}
          onNudge={spectator.nudge}
          onRotate={spectator.rotateBy}
          onScale={spectator.scaleBy}
          onReset={spectator.resetSelection}
          onDeselect={spectator.deselect}
        />
      )}

      {/* Initial Entry Screen */}
      {!hasStarted && (
        <div className="fixed inset-0 z-30 flex items-center justify-center p-4 sm:p-6 bg-gradient-to-t from-black/90 via-black/70 to-black/50 backdrop-blur-xs overflow-y-auto">
          <div className="max-w-xl w-full p-6 sm:p-8 rounded-2xl bg-[#111417]/95 border border-white/10 shadow-2xl text-center space-y-6">
            <div className="space-y-1.5">
              <p className="text-xs text-white/55 tracking-widest uppercase">
                Motor Colossal 3D · AI World Provider System
              </p>
              {activeCustomPlan && (
                <p className="text-xs font-mono-tabular tracking-widest uppercase text-cyan-300">
                  Mapa ativo: {activeCustomPlan.name}
                </p>
              )}
              <h1 className="font-display text-4xl sm:text-5xl font-normal tracking-wide text-white">
                MONOLITO
              </h1>
            </div>

            <blockquote className="font-display italic text-lg sm:text-xl text-white/80 leading-relaxed max-w-md mx-auto">
              “Eu não sei quem construiu isso, não sei onde termina e não consigo compreender o tamanho.”
            </blockquote>

            <button
              type="button"
              onClick={() => {
                setIsCreatorOpen(true);
                registerUserActivity();
              }}
              className="w-full min-h-[58px] px-5 rounded-2xl border-2 border-emerald-300/55 bg-emerald-400/12 hover:bg-emerald-400/20 text-emerald-100 font-semibold text-sm tracking-wide flex items-center justify-center gap-3 transition-colors cursor-pointer"
            >
              <Wrench className="w-5 h-5" />
              CRIADOR DE MUNDOS
            </button>

            {/* Quick Actions Strip */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <button
                type="button"
                onClick={() => setIsCreateWorldOpen(true)}
                className="p-3.5 rounded-xl border border-white/20 bg-white/5 hover:bg-white/10 text-left transition-colors flex items-center gap-3 cursor-pointer"
              >
                <Sparkles className="w-5 h-5 text-white/80 shrink-0" />
                <div>
                  <div className="text-xs font-semibold text-white">Sintetizar com IA</div>
                  <div className="text-[11px] text-white/50">Gemini, OpenAI, Claude, OpenRouter</div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => setIsProvidersOpen(true)}
                className="p-3.5 rounded-xl border border-white/15 bg-black/40 hover:bg-black/60 text-left transition-colors flex items-center gap-3 cursor-pointer"
              >
                <Cpu className="w-5 h-5 text-white/80 shrink-0" />
                <div>
                  <div className="text-xs font-semibold text-white">Painel de Provedores</div>
                  <div className="text-[11px] text-white/50">Gerenciar chaves, endpoints e modelos</div>
                </div>
              </button>
            </div>

            {/* Canonical Regions & Futuristic Megamaps Selector */}
            <div className="text-left space-y-2">
              <div className="flex items-center justify-between text-xs text-white/60">
                <span>Ou explore os {REGIONS_LIST.length} setores e megamundos:</span>
                <span className="font-mono-tabular text-white/80">
                  {currentRegionMeta.number}/{REGIONS_LIST.length}
                </span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-1.5 max-h-36 overflow-y-auto pr-1">
                {REGIONS_LIST.map((r) => {
                  const active = r.id === regionId;
                  return (
                    <button
                      key={r.id}
                      type="button"
                      onClick={() => {
                        setRegionId(r.id);
                        setWeatherId(r.defaultWeather);
                        setActiveCustomPlan(null);
                      }}
                      className={`text-left px-3 py-2 rounded-xl border text-xs transition-colors cursor-pointer ${
                        active
                          ? 'bg-white/15 border-white/40 text-white'
                          : 'bg-white/4 border-white/8 text-white/65 hover:text-white hover:bg-white/8'
                      }`}
                    >
                      <div className="font-mono-tabular text-[10px] text-white/45">
                        {r.number} · {r.colossalHeightMeters} m
                      </div>
                      <div className="font-medium truncate">{r.title}</div>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="pt-2">
              <button
                type="button"
                onClick={handleStartExploration}
                className="w-full min-h-[48px] px-8 py-3 rounded-xl bg-white text-[#0d0f11] font-medium text-sm tracking-wide hover:bg-white/90 transition-all duration-150 active:scale-98 cursor-pointer"
              >
                {activeCustomPlan
                  ? `Jogar ${activeCustomPlan.name}`
                  : `Iniciar Exploração em ${currentRegionMeta.title}`}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Atmosphere Drawer */}
      {drawerOpen && (
        <div className="fixed inset-0 z-35 flex justify-end bg-black/45 backdrop-blur-xs select-none">
          <aside className="w-full max-w-md h-full bg-[#121518]/95 border-l border-white/10 p-6 overflow-y-auto flex flex-col justify-between space-y-6">
            <div className="space-y-5">
              <div className="flex items-center justify-between pb-3 border-b border-white/10">
                <div>
                  <h2 className="font-display text-2xl text-white">Meteorologia &amp; Câmera</h2>
                  <p className="text-xs text-white/55">
                    Ajuste dinâmico de iluminação, neblina, FOV e controles táteis
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setDrawerOpen(false)}
                  className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-white/70 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-6">
                {/* Weather Toggle */}
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-xs font-medium text-white/85">
                      Transição Climática Natural
                    </div>
                    <div className="text-[11px] text-white/50">
                      Alterna lentamente as condições atmosféricas
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setDynamicWeatherCycle((prev) => !prev)}
                    className={`min-h-[40px] px-3.5 py-1.5 rounded-lg text-xs font-medium border transition-colors cursor-pointer ${
                      dynamicWeatherCycle
                        ? 'bg-white/15 border-white/30 text-white'
                        : 'bg-black/30 border-white/10 text-white/55'
                    }`}
                  >
                    {dynamicWeatherCycle ? 'Ativa' : 'Fixa'}
                  </button>
                </div>

                {/* Weather Presets */}
                <div className="space-y-2">
                  <label className="block text-xs font-medium text-white/75">
                    Condições Climáticas (10 Estados)
                  </label>
                  <div className="grid grid-cols-1 gap-1.5 max-h-56 overflow-y-auto pr-1">
                    {Object.values(WEATHER_PRESETS).map((preset) => {
                      const active = weatherId === preset.id;
                      return (
                        <button
                          key={preset.id}
                          type="button"
                          onClick={() => {
                            setWeatherId(preset.id);
                            setDynamicWeatherCycle(false);
                          }}
                          className={`w-full text-left px-3.5 py-2.5 rounded-xl border transition-colors cursor-pointer ${
                            active
                              ? 'bg-white/14 border-white/35 text-white'
                              : 'bg-white/4 border-white/8 text-white/70 hover:bg-white/8'
                          }`}
                        >
                          <div className="text-xs font-semibold">{preset.name}</div>
                          <div className="text-[11px] text-white/50 mt-0.5">
                            {preset.subtitle}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* FOV */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-white/75 font-medium">Campo de Visão (FOV)</span>
                    <span className="font-mono-tabular text-white">{fov}°</span>
                  </div>
                  <input
                    type="range"
                    min={60}
                    max={100}
                    step={1}
                    value={fov}
                    onChange={(e) => setFov(Number(e.target.value))}
                    className="w-full accent-[#b06c49] cursor-pointer"
                  />
                  <div className="flex justify-between text-[11px] text-white/45 font-mono-tabular">
                    <span>60° Telefoto</span>
                    <span>74° Natural</span>
                    <span>100° Grande Angular</span>
                  </div>
                </div>

                {/* Quality Tier */}
                <div className="space-y-2">
                  <label className="block text-xs font-medium text-white/75">
                    Nível de Renderização
                  </label>
                  <div className="grid grid-cols-3 gap-1.5 p-1 bg-black/40 rounded-xl border border-white/10">
                    {(['leve', 'equilibrado', 'cinematografico'] as QualityTier[]).map(
                      (tier) => (
                        <button
                          key={tier}
                          type="button"
                          onClick={() => setQualityTier(tier)}
                          className={`min-h-[40px] px-3 py-1.5 rounded-lg text-xs font-medium capitalize transition-colors cursor-pointer ${
                            qualityTier === tier
                              ? 'bg-white/18 text-white'
                              : 'text-white/60 hover:text-white'
                          }`}
                        >
                          {tier === 'cinematografico' ? 'Cinema' : tier}
                        </button>
                      )
                    )}
                  </div>
                </div>

                {/* Touch Controls Toggle */}
                <div className="flex items-center justify-between pt-1">
                  <span className="text-xs text-white/75">Controles de Toque na Tela</span>
                  <button
                    type="button"
                    onClick={() => setShowTouchControls((prev) => !prev)}
                    className={`min-h-[40px] px-4 py-1.5 rounded-lg text-xs font-medium border transition-colors cursor-pointer ${
                      showTouchControls
                        ? 'bg-white/15 border-white/30 text-white'
                        : 'bg-black/30 border-white/10 text-white/55'
                    }`}
                  >
                    {showTouchControls ? 'Visíveis' : 'Ocultos'}
                  </button>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-white/10 flex items-center justify-between text-[11px] text-white/45 font-mono-tabular">
              <span>
                Posição: X {telemetry.x} · Y {telemetry.y} · Z {telemetry.z}
              </span>
              <span>Inclinação: {telemetry.pitchDeg}°</span>
            </div>
          </aside>
        </div>
      )}

      {/* AI Providers Modal */}
      <AIProvidersPanel
        isOpen={isProvidersOpen}
        onClose={() => setIsProvidersOpen(false)}
      />

      {/* Create World Modal */}
      <CreateWorldModal
        isOpen={isCreateWorldOpen}
        onClose={() => setIsCreateWorldOpen(false)}
        onWorldCreated={handleWorldCreated}
        onOpenProviders={() => {
          setIsCreateWorldOpen(false);
          setIsProvidersOpen(true);
        }}
      />

      {/* World Patch Modal */}
      <WorldPatchModal
        isOpen={isPatchModalOpen}
        onClose={() => setIsPatchModalOpen(false)}
        activePlan={activeCustomPlan}
        currentRegionId={activeCustomRegionId || activeCustomPlan?.regions[0]?.id || 'region_0'}
        onPatchApplied={handlePatchApplied}
      />

      {/* Saved Worlds & Canonical Regions Drawer */}
      <SavedWorldsDrawer
        isOpen={isSavedWorldsOpen}
        onClose={() => setIsSavedWorldsOpen(false)}
        activePlan={activeCustomPlan}
        activeCanonicalRegionId={regionId}
        onSelectCanonicalRegion={handleSelectCanonicalRegion}
        onSelectCustomWorld={handleSelectCustomWorld}
        onOpenCreateWorld={() => setIsCreateWorldOpen(true)}
        onOpenPatchModal={() => setIsPatchModalOpen(true)}
      />

      <CreatorWorldsPanel
        isOpen={isCreatorOpen}
        onClose={() => setIsCreatorOpen(false)}
      />
    </main>
  );
}
