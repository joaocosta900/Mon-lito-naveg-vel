export type RegionId =
  | 'vale_pilares'
  | 'viaduto_infinito'
  | 'catedral_industrial'
  | 'oceano_concreto'
  | 'cidade_sem_cidade'
  | 'ponte_nuvens'
  | 'tunel_colossal'
  | 'estrutura_impossivel'
  | 'campo_torre'
  | 'cidade_ceu'
  | 'complexo_maquinas'
  | 'elevador_planetario'
  | 'megacidade_horizonte'
  | 'colonia_dyson_anel'
  | 'aquapolis_abissal'
  | 'metropole_antigravidade'
  | 'citadela_hiperboreia'
  | 'blade_runner_2049'
  | (string & {});

export type AcousticZone =
  | 'open_meadow'
  | 'concrete_threshold'
  | 'industrial_tunnel'
  | 'monolith_basin'
  | 'colossal_staircase'
  | 'elevated_bridge'
  | 'cathedral_nave'
  | 'urban_canyon'
  | 'concrete_ocean'
  | 'sky_platform'
  | 'machine_foundry'
  | 'planetary_tether'
  | 'horizon_megacity'
  | 'dyson_ring'
  | 'abyssal_aquapolis'
  | 'antigravity_skyline'
  | 'hyperborean_quantum'
  | 'blade_runner_monolith'
  | 'vegas_dust_basin';

export type SurfaceMaterialType = 'grass' | 'concrete' | 'metal' | 'water';

export type WeatherPresetId =
  | 'manha_neblina'
  | 'dia_azul'
  | 'ceu_nublado'
  | 'por_do_sol'
  | 'noite_futurista'
  | 'chuva_fraca'
  | 'chuva_intensa'
  | 'vento_forte'
  | 'neblina_densa'
  | 'ceu_limpo'
  | 'aurora_polar'
  | 'abismo_oceanico'
  | 'crepusculo_orbital'
  | 'nevoa_antigravidade'
  | 'br2049_laranja_vegas'
  | 'br2049_los_angeles_neon';

export type QualityTier = 'leve' | 'equilibrado' | 'cinematografico';

export interface WeatherPreset {
  id: WeatherPresetId;
  name: string;
  subtitle: string;
  skyTopColor: string;
  skyHorizonColor: string;
  fogColor: string;
  fogDensity: number;
  sunColor: string;
  sunIntensity: number;
  ambientColor: string;
  ambientIntensity: number;
  sunElevationDeg: number;
  sunAzimuthDeg: number;
  cloudOpacity: number;
  windMultiplier: number;
  rainIntensity: number; // 0 = dry, 0.4 = light rain, 1.0 = heavy rain
}

export interface RegionMetadata {
  id: RegionId;
  number: string;
  title: string;
  subtitle: string;
  acousticDescription: string;
  defaultWeather: WeatherPresetId;
  spawnPosition: [number, number, number];
  spawnYawDeg: number;
  spawnPitchDeg: number;
  colossalHeightMeters: number;
}

export interface ArchitecturalPortal {
  id: string;
  position: [number, number, number];
  radius: number;
  targetRegion: RegionId;
  passageType: string;
  label: string;
}

export interface ResonancePoint {
  id: string;
  position: [number, number, number];
  radius: number;
  title: string;
  scaleNote: string;
  lookTarget: [number, number, number];
  fundamentalFreq: number;
}

export interface WalkableBox {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  minY: number;
  maxY: number;
  isWall?: boolean;
  walkableTop?: boolean;
  isRamp?: boolean;
  rampAxis?: 'x' | 'z';
  rampStartY?: number;
  rampEndY?: number;
  surface?: SurfaceMaterialType;
  zone?: AcousticZone;
}

export interface PlayerTelemetry {
  regionId: RegionId;
  x: number;
  y: number;
  z: number;
  pitchDeg: number;
  yawDeg: number;
  zone: AcousticZone;
  surface: SurfaceMaterialType;
  nearbyResonance: ResonancePoint | null;
  nearbyPortal: ArchitecturalPortal | null;
  lookingAtMegastructure: boolean;
  perceivedStructureHeightMeters: number | null;
}
